import * as bcrypt from 'bcrypt';
import request = require('supertest');
import { v4 as uuidv4 } from 'uuid';
import { createTestApp, extractRefreshCookie, TestApp } from './helpers/create-test-app';

const ADMIN_EMAIL = 'admin@test.ao';
const ADMIN_PASSWORD = 'Password123!';

describe('Auth (e2e)', () => {
  let testApp: TestApp;

  beforeAll(async () => {
    testApp = await createTestApp();
    const { getModel } = testApp;

    // Seed: role com todas as permissões
    const roleId = uuidv4();
    await getModel('Role').create({
      _id: roleId,
      nome: 'Administrador',
      descricao: 'Papel de teste',
      permissions: ['documents.read', 'documents.create'],
    });

    // Seed: utilizador com senha bcrypt
    const senhaHash = await bcrypt.hash(ADMIN_PASSWORD, 10);
    await getModel('User').create({
      _id: uuidv4(),
      nome: 'Admin Teste',
      email: ADMIN_EMAIL,
      roleId,
      ativo: true,
      criadoEm: new Date().toISOString(),
      senhaHash,
    });
  });

  afterAll(async () => {
    await testApp.teardown();
  });

  // ── POST /auth/login ────────────────────────────────────────────────────────

  describe('POST /api/v1/auth/login', () => {
    it('deve retornar 201 com accessToken e cookie refresh_token', async () => {
      const res = await request(testApp.app.getHttpServer())
        .post('/api/v1/auth/login')
        .send({ email: ADMIN_EMAIL, senha: ADMIN_PASSWORD })
        .expect(201);

      expect(res.body.accessToken).toBeDefined();
      expect(typeof res.body.accessToken).toBe('string');
      expect(res.body.user).toBeDefined();
      expect(res.body.user.email).toBe(ADMIN_EMAIL);
      expect(res.body.user.senhaHash).toBeUndefined();

      const cookies = res.headers['set-cookie'] as unknown as string[];
      expect(cookies).toBeDefined();
      const refreshCookie = cookies.find((c) => c.startsWith('refresh_token='));
      expect(refreshCookie).toBeDefined();
      expect(refreshCookie).toContain('HttpOnly');
    });

    it('deve retornar 401 com senha incorrecta', async () => {
      await request(testApp.app.getHttpServer())
        .post('/api/v1/auth/login')
        .send({ email: ADMIN_EMAIL, senha: 'senha_errada' })
        .expect(401);
    });

    it('deve retornar 401 com email desconhecido', async () => {
      await request(testApp.app.getHttpServer())
        .post('/api/v1/auth/login')
        .send({ email: 'naoexiste@test.ao', senha: ADMIN_PASSWORD })
        .expect(401);
    });

    it('deve retornar 400 sem body', async () => {
      await request(testApp.app.getHttpServer())
        .post('/api/v1/auth/login')
        .send({})
        .expect(400);
    });
  });

  // ── GET /auth/me ────────────────────────────────────────────────────────────

  describe('GET /api/v1/auth/me', () => {
    let accessToken: string;

    beforeAll(async () => {
      const res = await request(testApp.app.getHttpServer())
        .post('/api/v1/auth/login')
        .send({ email: ADMIN_EMAIL, senha: ADMIN_PASSWORD });
      accessToken = res.body.accessToken as string;
    });

    it('deve retornar o utilizador autenticado', async () => {
      const res = await request(testApp.app.getHttpServer())
        .get('/api/v1/auth/me')
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(200);

      expect(res.body.email).toBe(ADMIN_EMAIL);
      expect(res.body.id).toBeDefined();
      expect(res.body.senhaHash).toBeUndefined();
    });

    it('deve retornar 401 sem token', async () => {
      await request(testApp.app.getHttpServer())
        .get('/api/v1/auth/me')
        .expect(401);
    });

    it('deve retornar 401 com token inválido', async () => {
      await request(testApp.app.getHttpServer())
        .get('/api/v1/auth/me')
        .set('Authorization', 'Bearer token_invalido')
        .expect(401);
    });
  });

  // ── POST /auth/refresh ──────────────────────────────────────────────────────

  describe('POST /api/v1/auth/refresh', () => {
    let refreshCookie: string;

    beforeAll(async () => {
      const res = await request(testApp.app.getHttpServer())
        .post('/api/v1/auth/login')
        .send({ email: ADMIN_EMAIL, senha: ADMIN_PASSWORD });

      const cookies = res.headers['set-cookie'] as unknown as string[];
      refreshCookie = extractRefreshCookie(cookies);
    });

    it('deve retornar novo accessToken com cookie válido', async () => {
      const res = await request(testApp.app.getHttpServer())
        .post('/api/v1/auth/refresh')
        .set('Cookie', refreshCookie)
        .expect(201);

      expect(res.body.accessToken).toBeDefined();
      expect(typeof res.body.accessToken).toBe('string');
    });

    it('deve retornar 401 sem cookie', async () => {
      await request(testApp.app.getHttpServer())
        .post('/api/v1/auth/refresh')
        .expect(401);
    });
  });

  // ── POST /auth/logout ───────────────────────────────────────────────────────

  describe('POST /api/v1/auth/logout', () => {
    let accessToken: string;

    beforeAll(async () => {
      const res = await request(testApp.app.getHttpServer())
        .post('/api/v1/auth/login')
        .send({ email: ADMIN_EMAIL, senha: ADMIN_PASSWORD });
      accessToken = res.body.accessToken as string;
    });

    it('deve retornar { ok: true } e limpar o cookie', async () => {
      const res = await request(testApp.app.getHttpServer())
        .post('/api/v1/auth/logout')
        .set('Authorization', `Bearer ${accessToken}`)
        .expect(201);

      expect(res.body.ok).toBe(true);
    });

    it('deve retornar 401 sem token', async () => {
      await request(testApp.app.getHttpServer())
        .post('/api/v1/auth/logout')
        .expect(401);
    });
  });
});
