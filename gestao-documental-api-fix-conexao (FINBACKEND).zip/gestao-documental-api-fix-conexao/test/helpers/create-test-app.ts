import { ClassSerializerInterceptor, INestApplication, ValidationPipe } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Test, TestingModule } from '@nestjs/testing';
import { getModelToken } from '@nestjs/mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';
import { Model } from 'mongoose';
import * as cookieParser from 'cookie-parser';
import { AppModule } from '../../src/app.module';

export interface TestApp {
  app: INestApplication;
  moduleFixture: TestingModule;
  mongod: MongoMemoryServer;
  /** Obtém um Mongoose Model registado em qualquer módulo. */
  getModel: <T>(name: string) => Model<T>;
  teardown: () => Promise<void>;
}

/**
 * Cria instância NestJS completa ligada a um MongoDB em memória.
 * Espelha exactamente o bootstrap de main.ts (sem Swagger e sem CORS).
 * Cada test file chama createTestApp() no beforeAll e teardown() no afterAll.
 */
export async function createTestApp(): Promise<TestApp> {
  const mongod = await MongoMemoryServer.create();
  // Definir ANTES de compilar — ConfigModule lê a variável na factory
  process.env.MONGODB_URI = mongod.getUri();

  const moduleFixture: TestingModule = await Test.createTestingModule({
    imports: [AppModule],
  }).compile();

  const app = moduleFixture.createNestApplication();

  app.use(cookieParser());
  app.setGlobalPrefix('api/v1');
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
    }),
  );
  app.useGlobalInterceptors(
    new ClassSerializerInterceptor(app.get(Reflector), {
      excludeExtraneousValues: false,
    }),
  );

  await app.init();

  return {
    app,
    moduleFixture,
    mongod,
    getModel: <T>(name: string) =>
      moduleFixture.get<Model<T>>(getModelToken(name)),
    teardown: async () => {
      await app.close();
      await mongod.stop();
    },
  };
}

/** Extrai o valor do cookie refresh_token do cabeçalho Set-Cookie. */
export function extractRefreshCookie(setCookieHeader: string[]): string {
  const cookie = setCookieHeader.find((c) => c.startsWith('refresh_token='));
  if (!cookie) throw new Error('refresh_token cookie not found in Set-Cookie');
  return cookie.split(';')[0]; // "refresh_token=<value>"
}
