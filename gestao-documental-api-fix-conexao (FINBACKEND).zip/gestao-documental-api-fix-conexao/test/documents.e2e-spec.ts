import * as bcrypt from 'bcrypt';
import request = require('supertest');
import { v4 as uuidv4 } from 'uuid';
import { createTestApp, TestApp } from './helpers/create-test-app';

const ADMIN_EMAIL = 'docadmin@test.ao';
const READONLY_EMAIL = 'docreadonly@test.ao';
const PASSWORD = 'Password123!';

const DOC_TYPE_ID = uuidv4();

describe('Documents (e2e)', () => {
  let testApp: TestApp;
  let adminToken: string;
  let readonlyToken: string;

  beforeAll(async () => {
    testApp = await createTestApp();
    const { getModel } = testApp;

    // Role com todas as permissões de documentos
    const adminRoleId = uuidv4();
    await getModel('Role').create({
      _id: adminRoleId,
      nome: 'DocAdmin',
      descricao: 'Papel de teste com todas as permissões de documentos',
      permissions: [
        'documents.create',
        'documents.read',
        'documents.update',
        'documents.delete',
        'documents.forward',
      ],
    });

    // Role apenas com leitura
    const readonlyRoleId = uuidv4();
    await getModel('Role').create({
      _id: readonlyRoleId,
      nome: 'DocReadOnly',
      descricao: 'Papel de teste só de leitura',
      permissions: ['documents.read'],
    });

    const hash = await bcrypt.hash(PASSWORD, 10);
    const now = new Date().toISOString();

    await getModel('User').create([
      {
        _id: uuidv4(),
        nome: 'Admin Doc',
        email: ADMIN_EMAIL,
        roleId: adminRoleId,
        ativo: true,
        criadoEm: now,
        senhaHash: hash,
      },
      {
        _id: uuidv4(),
        nome: 'ReadOnly Doc',
        email: READONLY_EMAIL,
        roleId: readonlyRoleId,
        ativo: true,
        criadoEm: now,
        senhaHash: hash,
      },
    ]);

    // DocumentType mínimo — registro é required (enum: entrada|saida|interno|todos)
    await getModel('DocumentType').create({
      _id: DOC_TYPE_ID,
      nome: 'Tipo Teste',
      descricao: 'Para testes E2E',
      registro: 'todos',
      campos: [],
      ativo: true,
    });

    // Obter tokens de ambos os utilizadores
    const [adminRes, readonlyRes] = await Promise.all([
      request(testApp.app.getHttpServer())
        .post('/api/v1/auth/login')
        .send({ email: ADMIN_EMAIL, senha: PASSWORD }),
      request(testApp.app.getHttpServer())
        .post('/api/v1/auth/login')
        .send({ email: READONLY_EMAIL, senha: PASSWORD }),
    ]);

    adminToken = adminRes.body.accessToken as string;
    readonlyToken = readonlyRes.body.accessToken as string;
  });

  afterAll(async () => {
    await testApp.teardown();
  });

  // ── POST /documents ─────────────────────────────────────────────────────────

  describe('POST /api/v1/documents', () => {
    it('deve criar documento e retornar 201 com id gerado', async () => {
      const res = await request(testApp.app.getHttpServer())
        .post('/api/v1/documents')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          tipoRegistro: 'entrada',
          tipoDocumentoId: DOC_TYPE_ID,
          assunto: 'Contrato de teste E2E',
          data: '2025-01-15',
        })
        .expect(201);

      expect(res.body.id).toBeDefined();
      expect(res.body.assunto).toBe('Contrato de teste E2E');
      expect(res.body.tipoRegistro).toBe('entrada');
      expect(res.body.estado).toBe('novo');
      // número gerado automaticamente
      expect(res.body.numero).toMatch(/^ENT-\d{4}\/\d{5}$/);
      // senhaHash e campos internos nunca devem aparecer
      expect(res.body.senhaHash).toBeUndefined();
    });

    it('deve aceitar id fornecido pelo cliente', async () => {
      const clientId = uuidv4();
      const res = await request(testApp.app.getHttpServer())
        .post('/api/v1/documents')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          id: clientId,
          tipoRegistro: 'saida',
          tipoDocumentoId: DOC_TYPE_ID,
          assunto: 'Documento com id do cliente',
          data: '2025-01-16',
        })
        .expect(201);

      expect(res.body.id).toBe(clientId);
    });

    it('deve retornar 403 sem permissão de criação', async () => {
      await request(testApp.app.getHttpServer())
        .post('/api/v1/documents')
        .set('Authorization', `Bearer ${readonlyToken}`)
        .send({
          tipoRegistro: 'entrada',
          tipoDocumentoId: DOC_TYPE_ID,
          assunto: 'Sem permissão',
          data: '2025-01-15',
        })
        .expect(403);
    });

    it('deve retornar 401 sem token', async () => {
      await request(testApp.app.getHttpServer())
        .post('/api/v1/documents')
        .send({
          tipoRegistro: 'entrada',
          tipoDocumentoId: DOC_TYPE_ID,
          assunto: 'Sem auth',
          data: '2025-01-15',
        })
        .expect(401);
    });

    it('deve retornar 400 com tipoRegistro inválido', async () => {
      await request(testApp.app.getHttpServer())
        .post('/api/v1/documents')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          tipoRegistro: 'invalido',
          tipoDocumentoId: DOC_TYPE_ID,
          assunto: 'Test',
          data: '2025-01-15',
        })
        .expect(400);
    });
  });

  // ── GET /documents ──────────────────────────────────────────────────────────

  describe('GET /api/v1/documents', () => {
    it('deve retornar lista de documentos', async () => {
      const res = await request(testApp.app.getHttpServer())
        .get('/api/v1/documents')
        .set('Authorization', `Bearer ${adminToken}`)
        .expect(200);

      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.length).toBeGreaterThanOrEqual(1);
    });

    it('deve filtrar por tipoRegistro', async () => {
      const res = await request(testApp.app.getHttpServer())
        .get('/api/v1/documents?tipoRegistro=entrada')
        .set('Authorization', `Bearer ${adminToken}`)
        .expect(200);

      expect(Array.isArray(res.body)).toBe(true);
      res.body.forEach((doc: { tipoRegistro: string }) => {
        expect(doc.tipoRegistro).toBe('entrada');
      });
    });

    it('deve retornar 401 sem token', async () => {
      await request(testApp.app.getHttpServer())
        .get('/api/v1/documents')
        .expect(401);
    });
  });

  // ── GET /documents/:id ──────────────────────────────────────────────────────

  describe('GET /api/v1/documents/:id', () => {
    let createdId: string;

    beforeAll(async () => {
      const res = await request(testApp.app.getHttpServer())
        .post('/api/v1/documents')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          tipoRegistro: 'interno',
          tipoDocumentoId: DOC_TYPE_ID,
          assunto: 'Documento para GET por id',
          data: '2025-02-01',
        });
      createdId = res.body.id as string;
    });

    it('deve retornar o documento por id', async () => {
      const res = await request(testApp.app.getHttpServer())
        .get(`/api/v1/documents/${createdId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .expect(200);

      expect(res.body.id).toBe(createdId);
      expect(res.body.assunto).toBe('Documento para GET por id');
    });

    it('deve retornar 404 para id inexistente', async () => {
      await request(testApp.app.getHttpServer())
        .get(`/api/v1/documents/${uuidv4()}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .expect(404);
    });
  });

  // ── PATCH /documents/:id ────────────────────────────────────────────────────

  describe('PATCH /api/v1/documents/:id', () => {
    let docId: string;

    beforeAll(async () => {
      const res = await request(testApp.app.getHttpServer())
        .post('/api/v1/documents')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          tipoRegistro: 'entrada',
          tipoDocumentoId: DOC_TYPE_ID,
          assunto: 'Documento para PATCH',
          data: '2025-03-01',
        });
      docId = res.body.id as string;
    });

    it('deve actualizar o assunto do documento', async () => {
      const res = await request(testApp.app.getHttpServer())
        .patch(`/api/v1/documents/${docId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ assunto: 'Assunto actualizado' })
        .expect(200);

      expect(res.body.assunto).toBe('Assunto actualizado');
      expect(res.body.id).toBe(docId);
    });

    it('deve retornar 403 sem permissão de actualização', async () => {
      await request(testApp.app.getHttpServer())
        .patch(`/api/v1/documents/${docId}`)
        .set('Authorization', `Bearer ${readonlyToken}`)
        .send({ assunto: 'Sem permissão' })
        .expect(403);
    });
  });

  // ── PATCH /documents/:id/estado ────────────────────────────────────────────

  describe('PATCH /api/v1/documents/:id/estado', () => {
    let docId: string;

    beforeAll(async () => {
      const res = await request(testApp.app.getHttpServer())
        .post('/api/v1/documents')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          tipoRegistro: 'saida',
          tipoDocumentoId: DOC_TYPE_ID,
          assunto: 'Documento para transição de estado',
          data: '2025-04-01',
        });
      docId = res.body.id as string;
    });

    it('deve transicionar estado para em_circulacao', async () => {
      const res = await request(testApp.app.getHttpServer())
        .patch(`/api/v1/documents/${docId}/estado`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ estado: 'em_circulacao' })
        .expect(200);

      expect(res.body.estado).toBe('em_circulacao');
    });
  });

  // ── DELETE /documents/:id ───────────────────────────────────────────────────

  describe('DELETE /api/v1/documents/:id', () => {
    let docId: string;

    beforeAll(async () => {
      const res = await request(testApp.app.getHttpServer())
        .post('/api/v1/documents')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          tipoRegistro: 'interno',
          tipoDocumentoId: DOC_TYPE_ID,
          assunto: 'Documento para DELETE',
          data: '2025-05-01',
        });
      docId = res.body.id as string;
    });

    it('deve eliminar o documento (204)', async () => {
      await request(testApp.app.getHttpServer())
        .delete(`/api/v1/documents/${docId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .expect(204);
    });

    it('deve retornar 404 após eliminação', async () => {
      await request(testApp.app.getHttpServer())
        .get(`/api/v1/documents/${docId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .expect(404);
    });

    it('deve retornar 403 sem permissão de eliminação', async () => {
      // Criar um novo documento para tentar apagar sem permissão
      const createRes = await request(testApp.app.getHttpServer())
        .post('/api/v1/documents')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          tipoRegistro: 'entrada',
          tipoDocumentoId: DOC_TYPE_ID,
          assunto: 'Para testar 403 em delete',
          data: '2025-05-02',
        });

      await request(testApp.app.getHttpServer())
        .delete(`/api/v1/documents/${createRes.body.id}`)
        .set('Authorization', `Bearer ${readonlyToken}`)
        .expect(403);
    });
  });
});
