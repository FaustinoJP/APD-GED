import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { BaseResponseDto } from '../../common/dto/base.dto';

export class NotificationResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  userId: string;

  @ApiProperty()
  @Expose()
  titulo: string;

  @ApiProperty()
  @Expose()
  mensagem: string;

  @ApiProperty()
  @Expose()
  lida: boolean;

  @ApiProperty({ required: false })
  @Expose()
  link?: string;

  @ApiProperty()
  @Expose()
  criadoEm: string;

  constructor(partial: Partial<NotificationResponseDto>) {
    super(partial);
    Object.assign(this, partial);
  }
}
