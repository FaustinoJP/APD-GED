import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import { Notification, NotificationDocument } from './schemas/notification.schema';

export interface CreateNotificationData {
  id?: string;
  userId: string;
  titulo: string;
  mensagem: string;
  lida?: boolean;
  link?: string;
  criadoEm?: string;
}

@Injectable()
export class NotificationsService {
  constructor(
    @InjectModel(Notification.name)
    private readonly model: Model<NotificationDocument>,
  ) {}

  async create(data: CreateNotificationData): Promise<NotificationDocument> {
    const notif = new this.model({
      _id: data.id || uuidv4(),
      userId: data.userId,
      titulo: data.titulo,
      mensagem: data.mensagem,
      lida: data.lida ?? false,
      link: data.link,
      criadoEm: data.criadoEm || new Date().toISOString(),
    });
    return notif.save();
  }

  async findByUser(userId: string): Promise<NotificationDocument[]> {
    return this.model.find({ userId }).sort({ criadoEm: -1 }).exec();
  }

  async countUnread(userId: string): Promise<number> {
    return this.model.countDocuments({ userId, lida: false }).exec();
  }

  async markAsRead(id: string): Promise<NotificationDocument | null> {
    return this.model
      .findByIdAndUpdate(id, { $set: { lida: true } }, { new: true })
      .exec();
  }

  async markAllAsRead(userId: string): Promise<void> {
    await this.model.updateMany({ userId, lida: false }, { $set: { lida: true } }).exec();
  }

  /** Actualização genérica — usada pelo ApiStorageAdapter (PATCH com objecto completo). */
  async update(id: string, updates: { lida?: boolean }): Promise<NotificationDocument | null> {
    const allowed: Record<string, unknown> = {};
    if (updates.lida !== undefined) allowed.lida = updates.lida;
    return this.model
      .findByIdAndUpdate(id, { $set: allowed }, { new: true })
      .exec();
  }

  async remove(id: string): Promise<void> {
    await this.model.findByIdAndDelete(id).exec();
  }
}
