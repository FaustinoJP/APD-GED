import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Patch,
  Post,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtPayload } from '../common/types/jwt-payload.interface';
import { NotificationsService } from './notifications.service';
import { NotificationResponseDto } from './dto/notification-response.dto';
import { UpdateNotificationDto } from './dto/update-notification.dto';
import { CreateNotificationDto } from './dto/create-notification.dto';

@ApiTags('notifications')
@ApiBearerAuth('access-token')
@Controller('notifications')
export class NotificationsController {
  constructor(private readonly service: NotificationsService) {}

  private toDto(doc: object): NotificationResponseDto {
    return plainToInstance(NotificationResponseDto, doc, {
      excludeExtraneousValues: true,
    });
  }

  @Post()
  @ApiOperation({ summary: 'Criar uma nova notificação' })
  @ApiResponse({ status: 201, type: NotificationResponseDto })
  async create(
    @Body() dto: CreateNotificationDto,
  ): Promise<NotificationResponseDto> {
    const doc = await this.service.create(dto);
    return this.toDto(doc.toJSON());
  }

  @Get()
  @ApiOperation({ summary: 'Listar notificações do utilizador autenticado' })
  @ApiResponse({ status: 200, type: [NotificationResponseDto] })
  async findMine(
    @CurrentUser() user: JwtPayload,
  ): Promise<NotificationResponseDto[]> {
    const docs = await this.service.findByUser(user.sub);
    return docs.map((d) => this.toDto(d.toJSON()));
  }

  @Get('unread-count')
  @ApiOperation({ summary: 'Número de notificações não lidas' })
  @ApiResponse({ status: 200, schema: { properties: { count: { type: 'number' } } } })
  async unreadCount(
    @CurrentUser() user: JwtPayload,
  ): Promise<{ count: number }> {
    const count = await this.service.countUnread(user.sub);
    return { count };
  }

  // ── Rotas literais antes das paramétricas (evita conflito de routing) ────────

  @Patch('read-all')
  @ApiOperation({ summary: 'Marcar todas as notificações como lidas' })
  @HttpCode(HttpStatus.NO_CONTENT)
  async markAllAsRead(@CurrentUser() user: JwtPayload): Promise<void> {
    await this.service.markAllAsRead(user.sub);
  }

  // PATCH genérico — usado pelo ApiStorageAdapter quando qualquer campo muda.
  // Apenas 'lida' é actualizado (outros campos de uma notificação são imutáveis).

  @Patch(':id')
  @ApiOperation({
    summary: 'Actualizar notificação (genérico — aceita objecto completo do ApiStorageAdapter)',
    description: 'Apenas o campo lida é actualizado. Outros campos são ignorados.',
  })
  @ApiResponse({ status: 200, type: NotificationResponseDto })
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateNotificationDto,
  ): Promise<NotificationResponseDto | null> {
    const doc = await this.service.update(id, { lida: dto.lida });
    if (!doc) return null;
    return this.toDto(doc.toJSON());
  }

  @Patch(':id/read')
  @ApiOperation({ summary: 'Marcar notificação como lida' })
  @ApiResponse({ status: 200, type: NotificationResponseDto })
  async markAsRead(
    @Param('id') id: string,
  ): Promise<NotificationResponseDto | null> {
    const doc = await this.service.markAsRead(id);
    if (!doc) return null;
    return this.toDto(doc.toJSON());
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Remover notificação' })
  @ApiResponse({ status: 204 })
  async remove(@Param('id') id: string): Promise<void> {
    await this.service.remove(id);
  }
}
