import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

export type NotificationDocument = HydratedDocument<Notification> & { _id: string };

@Schema({ collection: 'notifications', timestamps: false })
export class Notification {
  @Prop({ type: String, default: () => uuidv4() })
  _id: string;

  // Referência ao utilizador destinatário — string pura, sem populate
  @Prop({ required: true })
  userId: string;

  @Prop({ required: true })
  titulo: string;

  @Prop({ default: '' })
  mensagem: string;

  @Prop({ default: false })
  lida: boolean;

  @Prop()
  link?: string;

  @Prop({ required: true })
  criadoEm: string;
}

export const NotificationSchema = SchemaFactory.createForClass(Notification);

// Índice para acelerar queries por userId (caso de uso mais frequente)
NotificationSchema.index({ userId: 1, lida: 1 });
