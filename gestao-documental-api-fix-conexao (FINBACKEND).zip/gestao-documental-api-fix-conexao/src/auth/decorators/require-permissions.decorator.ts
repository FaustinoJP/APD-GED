import { SetMetadata } from '@nestjs/common';
import { Permission } from '../../common/constants/permissions.constant';

/**
 * Declara as permissions necessárias para aceder ao endpoint.
 * O PermissionsGuard valida contra user.permissions do JWT (sem DB lookup).
 *
 * Uso:
 *   @RequirePermissions('documents.create', 'documents.update')
 *   @Post()
 *   create() { ... }
 */
export const PERMISSIONS_KEY = 'permissions';
export const RequirePermissions = (...permissions: Permission[]) =>
  SetMetadata(PERMISSIONS_KEY, permissions);
