import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { JwtPayload } from '../../common/types/jwt-payload.interface';

/**
 * Extrai o utilizador autenticado da request (injectado pelo JwtStrategy).
 * Uso: @CurrentUser() user: JwtPayload
 *
 * NOTA: só funciona em rotas protegidas (sem @Public()).
 * Em rotas públicas, user pode ser undefined.
 */
export const CurrentUser = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): JwtPayload => {
    const request = ctx.switchToHttp().getRequest<{ user: JwtPayload }>();
    return request.user;
  },
);
