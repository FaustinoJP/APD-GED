import { SetMetadata } from '@nestjs/common';

// Marca um endpoint como público — JwtGuard não valida token nestas rotas.
// Usar com moderação: apenas login, refresh e rotas do portal externo sem auth.
export const IS_PUBLIC_KEY = 'isPublic';
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);
