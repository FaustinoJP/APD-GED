import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

// Valida o refresh token do cookie httpOnly.
// Usado apenas no endpoint POST /auth/refresh.
@Injectable()
export class JwtRefreshGuard extends AuthGuard('jwt-refresh') {}
