import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Permission } from '../../common/constants/permissions.constant';
import { JwtPayload } from '../../common/types/jwt-payload.interface';
import { PERMISSIONS_KEY } from '../decorators/require-permissions.decorator';

/**
 * Guard de permissões global — registado como APP_GUARD em AuthModule.
 * Corre APÓS o JwtGuard (req.user já está disponível).
 *
 * Valida as permissions directamente a partir do JWT payload (sem DB lookup).
 * Se o endpoint não tem @RequirePermissions(), o guard passa automaticamente.
 * Se a rota é pública (sem JWT), o guard também passa.
 */
@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<Permission[]>(
      PERMISSIONS_KEY,
      [context.getHandler(), context.getClass()],
    );

    // Sem @RequirePermissions() — acesso livre para utilizadores autenticados
    if (!required?.length) return true;

    const user: JwtPayload | undefined = context
      .switchToHttp()
      .getRequest<{ user?: JwtPayload }>().user;

    // Rota pública sem JWT — PermissionsGuard não bloqueia
    if (!user) return true;

    return required.every((p) => user.permissions.includes(p));
  }
}
