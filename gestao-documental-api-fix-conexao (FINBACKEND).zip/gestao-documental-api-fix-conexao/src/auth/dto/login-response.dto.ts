import { ApiProperty } from '@nestjs/swagger';
import { UserResponseDto } from '../../users/dto/user-response.dto';

export class LoginResponseDto {
  @ApiProperty({
    description:
      'JWT de acesso (válido 15 min). Incluir em cada request: Authorization: Bearer <token>',
    example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
  })
  accessToken: string;

  @ApiProperty({
    type: () => UserResponseDto,
    description: 'Dados do utilizador autenticado (senhaHash excluído)',
  })
  user: UserResponseDto;
}
