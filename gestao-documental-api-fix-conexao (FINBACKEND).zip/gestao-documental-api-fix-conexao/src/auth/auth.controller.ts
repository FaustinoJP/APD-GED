import {
  Body,
  Controller,
  Get,
  NotFoundException,
  Post,
  Res,
  UseGuards,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';
import { Response } from 'express';
import { JwtPayload } from '../common/types/jwt-payload.interface';
import { UserResponseDto } from '../users/dto/user-response.dto';
import { AuthService } from './auth.service';
import { CurrentUser } from './decorators/current-user.decorator';
import { Public } from './decorators/public.decorator';
import { LoginDto } from './dto/login.dto';
import { LoginResponseDto } from './dto/login-response.dto';
import { JwtRefreshGuard } from './guards/jwt-refresh.guard';

// Opções do cookie de refresh — idênticas no login e no logout
const REFRESH_COOKIE = 'refresh_token';
const REFRESH_COOKIE_PATH = '/api/v1/auth/refresh';
const REFRESH_COOKIE_OPTIONS = {
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'strict' as const,
  maxAge: 7 * 24 * 60 * 60 * 1000, // 7 dias em ms
  path: REFRESH_COOKIE_PATH,
};

@ApiTags('auth')
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Public()
  @Post('login')
  @ApiOperation({ summary: 'Autenticar utilizador com email e senha' })
  @ApiResponse({ status: 200, type: LoginResponseDto })
  @ApiResponse({ status: 401, description: 'Credenciais inválidas' })
  async login(
    @Body() dto: LoginDto,
    @Res({ passthrough: true }) res: Response,
  ): Promise<LoginResponseDto> {
    const { accessToken, refreshToken, user } = await this.authService.login(
      dto.email,
      dto.senha,
    );

    // Refresh token em cookie httpOnly — inacessível via JavaScript (protege contra XSS)
    res.cookie(REFRESH_COOKIE, refreshToken, REFRESH_COOKIE_OPTIONS);

    return {
      accessToken,
      user: plainToInstance(UserResponseDto, user.toJSON(), {
        excludeExtraneousValues: true,
      }),
    };
  }

  @Post('logout')
  @ApiBearerAuth('access-token')
  @ApiOperation({ summary: 'Encerrar sessão e limpar cookie de refresh' })
  logout(@Res({ passthrough: true }) res: Response): { ok: boolean } {
    res.clearCookie(REFRESH_COOKIE, { path: REFRESH_COOKIE_PATH });
    return { ok: true };
  }

  @Get('me')
  @ApiBearerAuth('access-token')
  @ApiOperation({ summary: 'Retorna os dados do utilizador autenticado' })
  @ApiResponse({ status: 200, type: UserResponseDto })
  @ApiResponse({ status: 401, description: 'Token inválido ou expirado' })
  async me(@CurrentUser() payload: JwtPayload): Promise<UserResponseDto> {
    const user = await this.authService.getMe(payload.sub);
    if (!user) throw new NotFoundException('Utilizador não encontrado');
    return plainToInstance(UserResponseDto, user.toJSON(), {
      excludeExtraneousValues: true,
    });
  }

  // @Public() aqui pois o JwtGuard global não deve bloquear — o JwtRefreshGuard
  // trata da sua própria validação via cookie httpOnly
  @Public()
  @UseGuards(JwtRefreshGuard)
  @Post('refresh')
  @ApiOperation({
    summary: 'Renovar access token usando o refresh token (cookie httpOnly)',
  })
  @ApiResponse({ status: 200, schema: { properties: { accessToken: { type: 'string' } } } })
  @ApiResponse({ status: 401, description: 'Refresh token inválido ou expirado' })
  refresh(@CurrentUser() payload: JwtPayload): { accessToken: string } {
    return this.authService.refreshToken(payload);
  }
}
