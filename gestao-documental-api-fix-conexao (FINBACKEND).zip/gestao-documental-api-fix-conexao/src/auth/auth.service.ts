import { Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { JwtPayload } from '../common/types/jwt-payload.interface';
import { RolesService } from '../roles/roles.service';
import { UserDocument } from '../users/schemas/user.schema';
import { UsersService } from '../users/users.service';

export interface LoginResult {
  accessToken: string;
  refreshToken: string;
  user: UserDocument;
}

@Injectable()
export class AuthService {
  constructor(
    private readonly usersService: UsersService,
    private readonly rolesService: RolesService,
    private readonly jwtService: JwtService,
    private readonly config: ConfigService,
  ) {}

  async login(email: string, senha: string): Promise<LoginResult> {
    const user = await this.usersService.findByEmailWithPassword(email);

    // Mensagem genérica intencional — não revelar se o email existe ou não
    if (!user || !user.ativo) {
      throw new UnauthorizedException('Credenciais inválidas');
    }

    if (!user.senhaHash) {
      throw new UnauthorizedException('Credenciais inválidas');
    }

    const passwordValid = await bcrypt.compare(senha, user.senhaHash);
    if (!passwordValid) {
      throw new UnauthorizedException('Credenciais inválidas');
    }

    const role = await this.rolesService.findById(user.roleId);

    // Permissions incluídas no payload — PermissionsGuard valida sem DB lookup
    const payload: JwtPayload = {
      sub: user._id,
      email: user.email,
      roleId: user.roleId,
      permissions: role?.permissions ?? [],
    };

    const accessToken = this.jwtService.sign(payload);

    const refreshToken = this.jwtService.sign(payload, {
      secret: this.config.getOrThrow<string>('JWT_REFRESH_SECRET'),
      expiresIn: this.config.get<string>('JWT_REFRESH_EXPIRES', '7d'),
    });

    return { accessToken, refreshToken, user };
  }

  // Gera novo access token a partir de um refresh token já validado pelo JwtRefreshGuard
  refreshToken(payload: JwtPayload): { accessToken: string } {
    const newPayload: JwtPayload = {
      sub: payload.sub,
      email: payload.email,
      roleId: payload.roleId,
      permissions: payload.permissions,
    };
    return { accessToken: this.jwtService.sign(newPayload) };
  }

  async getMe(userId: string): Promise<UserDocument | null> {
    return this.usersService.findById(userId);
  }
}
