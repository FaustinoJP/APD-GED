import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import { Folder, FolderDocument } from './schemas/folder.schema';
import { CreateFolderDto } from './dto/create-folder.dto';
import { UpdateFolderDto } from './dto/update-folder.dto';

@Injectable()
export class FoldersService {
  constructor(
    @InjectModel(Folder.name) private readonly model: Model<FolderDocument>,
  ) {}

  async findAll(): Promise<FolderDocument[]> {
    return this.model.find().exec();
  }

  async findById(id: string): Promise<FolderDocument | null> {
    return this.model.findById(id).exec();
  }

  async create(dto: CreateFolderDto): Promise<FolderDocument> {
    const doc = new this.model({
      _id: dto.id ?? uuidv4(),
      nome: dto.nome,
      parentId: dto.parentId,
      documentTypeId: dto.documentTypeId,
      criadoEm: dto.criadoEm ?? new Date().toISOString(),
    });
    return doc.save();
  }

  async update(id: string, dto: UpdateFolderDto): Promise<FolderDocument> {
    const doc = await this.model
      .findByIdAndUpdate(id, { $set: dto }, { new: true, runValidators: true })
      .exec();
    if (!doc) throw new NotFoundException(`Pasta '${id}' não encontrada`);
    return doc;
  }

  async remove(id: string): Promise<void> {
    const result = await this.model.findByIdAndDelete(id).exec();
    if (!result) throw new NotFoundException(`Pasta '${id}' não encontrada`);
  }
}
