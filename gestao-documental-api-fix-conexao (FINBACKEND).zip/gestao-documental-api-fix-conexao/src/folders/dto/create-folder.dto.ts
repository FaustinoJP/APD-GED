import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class CreateFolderDto {
  @ApiProperty({ required: false }) @IsOptional() @IsString() id?: string;
  @ApiProperty({ example: 'Contratos de Trabalho' }) @IsString() nome: string;
  @ApiProperty({ required: false, description: 'ID da pasta pai (self-reference)' })
  @IsOptional() @IsString() parentId?: string;
  @ApiProperty({ required: false }) @IsOptional() @IsString() documentTypeId?: string;
  @ApiProperty({ required: false }) @IsOptional() @IsString() criadoEm?: string;
}
