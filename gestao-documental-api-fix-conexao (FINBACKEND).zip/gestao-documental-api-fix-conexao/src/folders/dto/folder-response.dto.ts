import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { BaseResponseDto } from '../../common/dto/base.dto';

export class FolderResponseDto extends BaseResponseDto {
  @ApiProperty() @Expose() nome: string;
  @ApiProperty({ required: false }) @Expose() parentId?: string;
  @ApiProperty({ required: false }) @Expose() documentTypeId?: string;
  @ApiProperty() @Expose() criadoEm: string;
}
