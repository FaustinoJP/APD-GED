import {
  Body, Controller, Delete, Get, HttpCode, HttpStatus,
  NotFoundException, Param, Patch, Post,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';
import { RequirePermissions } from '../auth/decorators/require-permissions.decorator';
import { CreateFolderDto } from './dto/create-folder.dto';
import { FolderResponseDto } from './dto/folder-response.dto';
import { UpdateFolderDto } from './dto/update-folder.dto';
import { FoldersService } from './folders.service';

@ApiTags('folders')
@ApiBearerAuth('access-token')
@Controller('folders')
export class FoldersController {
  constructor(private readonly service: FoldersService) {}

  private toDto(f: object): FolderResponseDto {
    return plainToInstance(FolderResponseDto, f, { excludeExtraneousValues: true });
  }

  @Get()
  @ApiOperation({ summary: 'Listar todas as pastas' })
  @ApiResponse({ status: 200, type: [FolderResponseDto] })
  async findAll(): Promise<FolderResponseDto[]> {
    return (await this.service.findAll()).map((f) => this.toDto(f.toJSON()));
  }

  @Get(':id')
  @ApiOperation({ summary: 'Obter pasta por ID' })
  @ApiResponse({ status: 200, type: FolderResponseDto })
  async findOne(@Param('id') id: string): Promise<FolderResponseDto> {
    const f = await this.service.findById(id);
    if (!f) throw new NotFoundException(`Pasta '${id}' não encontrada`);
    return this.toDto(f.toJSON());
  }

  @Post()
  @RequirePermissions('files.manage')
  @ApiOperation({ summary: 'Criar pasta' })
  @ApiResponse({ status: 201, type: FolderResponseDto })
  async create(@Body() dto: CreateFolderDto): Promise<FolderResponseDto> {
    return this.toDto((await this.service.create(dto)).toJSON());
  }

  @Patch(':id')
  @RequirePermissions('files.manage')
  @ApiOperation({ summary: 'Actualizar pasta' })
  @ApiResponse({ status: 200, type: FolderResponseDto })
  async update(@Param('id') id: string, @Body() dto: UpdateFolderDto): Promise<FolderResponseDto> {
    return this.toDto((await this.service.update(id, dto)).toJSON());
  }

  @Delete(':id')
  @RequirePermissions('files.manage')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Eliminar pasta' })
  async remove(@Param('id') id: string): Promise<void> {
    await this.service.remove(id);
  }
}
