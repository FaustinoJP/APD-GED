import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

export type FolderDocument = HydratedDocument<Folder> & { _id: string };

@Schema({ collection: 'folders', timestamps: false })
export class Folder {
  @Prop({ type: String, default: () => uuidv4() })
  _id: string;

  @Prop({ required: true, trim: true })
  nome: string;

  // Referência ao pai como string — NUNCA usar .populate() aqui.
  // A hierarquia é resolvida em memória pelo frontend (buildFileTree).
  @Prop()
  parentId?: string;

  @Prop()
  documentTypeId?: string;

  @Prop({ required: true })
  criadoEm: string;
}

export const FolderSchema = SchemaFactory.createForClass(Folder);
