import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';

export class CreateSignatureDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  id?: string;


  @ApiProperty({ enum: ['desenho', 'imagem', 'digitada'] })
  @IsEnum(['desenho', 'imagem', 'digitada'])
  tipo: string;

  @ApiProperty({ description: 'URL, dataURL (base64) ou dados SVG' })
  @IsString()
  dado: string;
}
