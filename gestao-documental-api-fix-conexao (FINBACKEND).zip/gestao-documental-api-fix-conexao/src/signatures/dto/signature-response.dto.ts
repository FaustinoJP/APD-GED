import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { BaseResponseDto } from '../../common/dto/base.dto';

export class SignatureResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  userId: string;

  @ApiProperty({ enum: ['desenho', 'imagem', 'digitada'] })
  @Expose()
  tipo: string;

  @ApiProperty()
  @Expose()
  dado: string;

  @ApiProperty()
  @Expose()
  criadoEm: string;

  constructor(partial: Partial<SignatureResponseDto>) {
    super(partial);
    Object.assign(this, partial);
  }
}
