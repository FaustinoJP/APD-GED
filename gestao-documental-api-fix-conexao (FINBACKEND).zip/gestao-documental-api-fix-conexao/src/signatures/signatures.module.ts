import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { Signature, SignatureSchema } from './schemas/signature.schema';
import { SignaturesService } from './signatures.service';
import { SignaturesController } from './signatures.controller';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Signature.name, schema: SignatureSchema },
    ]),
  ],
  providers: [SignaturesService],
  controllers: [SignaturesController],
  exports: [SignaturesService],
})
export class SignaturesModule {}
