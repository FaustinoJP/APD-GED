import { Body, Controller, Delete, Get, Param, Post } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';
import { SignaturesService } from './signatures.service';
import { CreateSignatureDto } from './dto/create-signature.dto';
import { SignatureResponseDto } from './dto/signature-response.dto';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { JwtPayload } from '../common/types/jwt-payload.interface';

@ApiTags('signatures')
@ApiBearerAuth()
@Controller('signatures')
export class SignaturesController {
  constructor(private readonly service: SignaturesService) {}

  @Post()
  @ApiOperation({ summary: 'Guardar nova assinatura' })
  async create(
    @Body() dto: CreateSignatureDto,
    @CurrentUser() user: JwtPayload,
  ): Promise<SignatureResponseDto> {
    const doc = await this.service.create(dto, user.sub);
    return plainToInstance(SignatureResponseDto, doc.toJSON(), {
      excludeExtraneousValues: true,
    });
  }

  @Get()
  @ApiOperation({ summary: 'Listar assinaturas do utilizador autenticado' })
  async findMine(
    @CurrentUser() user: JwtPayload,
  ): Promise<SignatureResponseDto[]> {
    const docs = await this.service.findByUser(user.sub);
    return docs.map((d) =>
      plainToInstance(SignatureResponseDto, d.toJSON(), {
        excludeExtraneousValues: true,
      }),
    );
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Remover assinatura' })
  async remove(
    @Param('id') id: string,
    @CurrentUser() user: JwtPayload,
  ): Promise<void> {
    await this.service.remove(id, user.sub);
  }
}
