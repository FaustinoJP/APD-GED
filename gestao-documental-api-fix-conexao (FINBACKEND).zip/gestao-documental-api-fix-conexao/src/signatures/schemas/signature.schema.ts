import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

export type SignatureDocument = HydratedDocument<Signature> & { _id: string };

@Schema({ collection: 'signatures', timestamps: false })
export class Signature {
  @Prop({ type: String, default: () => uuidv4() })
  _id: string;

  @Prop({ required: true })
  userId: string;

  @Prop({ required: true, enum: ['desenho', 'imagem', 'digitada'] })
  tipo: string;

  /** URL or dataURL (base64) or SVG path data */
  @Prop({ required: true })
  dado: string;

  @Prop({ required: true })
  criadoEm: string;
}

export const SignatureSchema = SchemaFactory.createForClass(Signature);

SignatureSchema.index({ userId: 1 });
