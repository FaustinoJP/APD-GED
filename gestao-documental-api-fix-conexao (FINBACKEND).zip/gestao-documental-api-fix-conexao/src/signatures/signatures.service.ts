import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import { Signature, SignatureDocument } from './schemas/signature.schema';
import { CreateSignatureDto } from './dto/create-signature.dto';

@Injectable()
export class SignaturesService {
  constructor(
    @InjectModel(Signature.name)
    private readonly model: Model<SignatureDocument>,
  ) {}

  async create(dto: CreateSignatureDto, userId: string): Promise<SignatureDocument> {
    const sig = new this.model({
      _id: dto.id ?? uuidv4(),
      userId,
      tipo: dto.tipo,
      dado: dto.dado,
      criadoEm: new Date().toISOString(),
    });
    return sig.save();
  }

  async findByUser(userId: string): Promise<SignatureDocument[]> {
    return this.model.find({ userId }).sort({ criadoEm: -1 }).exec();
  }

  async findById(id: string): Promise<SignatureDocument> {
    const doc = await this.model.findById(id).exec();
    if (!doc) throw new NotFoundException('Assinatura não encontrada');
    return doc;
  }

  async remove(id: string, userId: string): Promise<void> {
    const sig = await this.findById(id);
    if (sig.userId !== userId) {
      throw new NotFoundException('Assinatura não encontrada');
    }
    await this.model.findByIdAndDelete(id).exec();
  }
}
