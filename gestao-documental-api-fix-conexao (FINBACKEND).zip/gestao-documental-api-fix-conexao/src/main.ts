import 'reflect-metadata';
import { join } from 'path';
import * as cookieParser from 'cookie-parser';
import { json, urlencoded } from 'express';
import { NestFactory, Reflector } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import {
  ValidationPipe,
  ClassSerializerInterceptor,
  Logger,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { AppModule } from './app.module';

async function bootstrap(): Promise<void> {
  const logger = new Logger('Bootstrap');
  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  const config = app.get(ConfigService);
  const port = config.get<number>('PORT', 3001);
  const frontendUrl = config.get<string>('FRONTEND_URL', 'http://localhost:3000');
  const nodeEnv = config.get<string>('NODE_ENV', 'development');

  // ── Cookie parser (necessário para ler o refresh_token httpOnly) ──────────
  app.use(cookieParser());

  // ── Limite de tamanho de payload para JSON e formulários ──────────────────
  app.use(json({ limit: '5mb' }));
  app.use(urlencoded({ limit: '5mb', extended: true }));

  // ── Prefixo global da API ──────────────────────────────────────────────────
  app.setGlobalPrefix('api/v1');

  // ── CORS ──────────────────────────────────────────────────────────────────
  app.enableCors({
    origin: frontendUrl,
    credentials: true,
    methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  });

  // ── Validação global (class-validator) ────────────────────────────────────
  // whitelist: remove campos não declarados no DTO (segurança)
  // transform: converte tipos automaticamente (string → number, etc.)
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
    }),
  );

  // ── Serialização global (class-transformer) ───────────────────────────────
  // Garante que @Exclude() em DTOs de resposta seja sempre respeitado.
  // CRÍTICO: impede que senhaHash e outros campos internos saiam da API.
  app.useGlobalInterceptors(
    new ClassSerializerInterceptor(app.get(Reflector), {
      excludeExtraneousValues: false,
    }),
  );

  // ── Swagger / OpenAPI ─────────────────────────────────────────────────────
  if (nodeEnv !== 'production') {
    const swaggerConfig = new DocumentBuilder()
      .setTitle('Faustware — Gestão Documental API')
      .setDescription(
        'API enterprise-grade para o sistema de gestão documental Faustware. ' +
        'Todos os endpoints protegidos requerem Bearer JWT no header Authorization.',
      )
      .setVersion('1.0')
      .addBearerAuth(
        {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
          description: 'Token JWT obtido via POST /api/v1/auth/login',
        },
        'access-token',
      )
      .addTag('auth', 'Autenticação e gestão de sessão')
      .addTag('users', 'Gestão de utilizadores')
      .addTag('roles', 'Gestão de papéis e permissões')
      .addTag('document-types', 'Tipos de documento e campos dinâmicos')
      .addTag('entities', 'Entidades externas (clientes, fornecedores, etc.)')
      .addTag('documents', 'Registo e gestão de documentos')
      .addTag('circulations', 'Fluxo de circulação e aprovação')
      .addTag('signatures', 'Assinaturas digitais')
      .addTag('folders', 'Pastas e organização hierárquica')
      .addTag('dossiers', 'Dossiês e agrupamento de documentos')
      .addTag('notifications', 'Notificações por utilizador')
      .addTag('templates', 'Templates de documentos com zonas de assinatura')
      .addTag('audit', 'Registo de auditoria (append-only)')
      .addTag('company', 'Configurações da empresa (singleton)')
      .build();

    const swaggerDocument = SwaggerModule.createDocument(app, swaggerConfig);
    SwaggerModule.setup('api/docs', app, swaggerDocument, {
      swaggerOptions: {
        persistAuthorization: true,
        tagsSorter: 'alpha',
        operationsSorter: 'alpha',
      },
    });

    logger.log(`Swagger disponível em http://localhost:${port}/api/docs`);
  }

  // Servir ficheiros carregados estaticamente em /uploads
  app.useStaticAssets(join(process.cwd(), 'uploads'), { prefix: '/uploads' });

  await app.listen(port);
  logger.log(`API a correr em http://localhost:${port}/api/v1`);
  logger.log(`Ambiente: ${nodeEnv}`);
}

bootstrap();
