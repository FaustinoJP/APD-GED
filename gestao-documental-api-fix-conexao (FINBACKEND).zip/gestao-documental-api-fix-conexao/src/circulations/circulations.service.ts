import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import {
  Circulation,
  CirculationDocument,
  CirculationResponse,
} from './schemas/circulation.schema';
import { CreateCirculationDto } from './dto/create-circulation.dto';
import { RespondCirculationDto } from './dto/respond-circulation.dto';
import { QueryCirculationDto } from './dto/query-circulation.dto';
import { UpdateCirculationDto } from './dto/update-circulation.dto';
import { DocumentsService } from '../documents/documents.service';
import { NotificationsService } from '../notifications/notifications.service';

// Mapa de decisão → estado do documento (null = não altera estado)
const DECISAO_ESTADO: Record<string, Record<string, string | null>> = {
  aprovar: { aprovado: 'aprovado', rejeitado: 'rejeitado' },
  assinar: { assinado: 'aprovado', nao_assinado: 'rejeitado' },
  deferir: { deferido: 'deferido' },
  parecer: {},    // nunca altera estado
  despachar: {},
  verificar: {},
  encaminhar_interno: {},
  encaminhar_externo: {},
};

@Injectable()
export class CirculationsService {
  constructor(
    @InjectModel(Circulation.name)
    private readonly model: Model<CirculationDocument>,
    private readonly documentsService: DocumentsService,
    private readonly notificationsService: NotificationsService,
  ) {}

  async forward(
    dto: CreateCirculationDto,
    deUserId: string,
  ): Promise<CirculationDocument> {
    const id = dto.id ?? uuidv4();
    const circulation = new this.model({
      _id: id,
      ...dto,
      deUserId,
      status: 'pendente',
      respostas: [],
      criadoEm: new Date().toISOString(),
    });
    const saved = await circulation.save();

    // Coloca o documento em circulação
    await this.documentsService.updateEstado(dto.documentId, 'em_circulacao');

    // Notifica destinatários individuais (tipo 'user')
    if (dto.receberNotificacao !== false) {
      const userDestinatarios = dto.paraDestinatarios.filter(
        (d) => d.tipo === 'user',
      );
      await Promise.all(
        userDestinatarios.map((d) =>
          this.notificationsService.create({
            userId: d.id,
            titulo: 'Nova circulação recebida',
            mensagem: dto.mensagem || `Tem uma acção de ${dto.acao} pendente no documento.`,
            link: `/documentos/${dto.documentId}`,
          }),
        ),
      );
    }

    return saved;
  }

  async respond(
    circulationId: string,
    dto: RespondCirculationDto,
    userId: string,
  ): Promise<CirculationDocument> {
    const circulation = await this.model.findById(circulationId).exec();
    if (!circulation) throw new NotFoundException('Circulação não encontrada');

    if (circulation.status !== 'pendente') {
      throw new BadRequestException('Circulação já foi encerrada');
    }

    const isDestinatario = circulation.paraDestinatarios.some(
      (d) => d.tipo === 'user' && d.id === userId,
    );
    if (!isDestinatario) {
      throw new BadRequestException('Utilizador não é destinatário desta circulação');
    }

    const jaRespondeu = circulation.respostas.some((r) => r.userId === userId);
    if (jaRespondeu) {
      throw new BadRequestException('Já respondeu a esta circulação');
    }

    const response: Partial<CirculationResponse> = {
      id: uuidv4(),
      circulationId,
      userId,
      decisao: dto.decisao,
      mensagem: dto.mensagem,
      assinaturaId: dto.assinaturaId,
      signatureZoneId: dto.signatureZoneId,
      certificadoDigital: dto.certificadoDigital ?? false,
      criadoEm: new Date().toISOString(),
    };

    await this.model
      .findByIdAndUpdate(circulationId, { $push: { respostas: response } })
      .exec();

    // Recarrega com a resposta já incluída
    const updated = (await this.model.findById(circulationId).exec())!;

    // Verifica se deve encerrar a circulação
    const novoEstadoDoc = await this.resolveEstadoDocumento(updated);
    if (novoEstadoDoc !== null) {
      await this.model
        .findByIdAndUpdate(circulationId, { $set: { status: 'respondido' } })
        .exec();
      await this.documentsService.updateEstado(
        updated.documentId,
        novoEstadoDoc,
      );
    }

    // Notifica o remetente
    if (updated.receberNotificacao) {
      await this.notificationsService.create({
        userId: updated.deUserId,
        titulo: 'Resposta recebida na circulação',
        mensagem: `${userId} respondeu: ${dto.decisao}`,
        link: `/documentos/${updated.documentId}`,
      });
    }

    return (await this.model.findById(circulationId).exec())!;
  }

  async findAll(query: QueryCirculationDto): Promise<CirculationDocument[]> {
    const filter: Record<string, unknown> = {};
    if (query.documentId) filter.documentId = query.documentId;
    if (query.status) filter.status = query.status;
    if (query.deUserId) filter.deUserId = query.deUserId;
    return this.model.find(filter).sort({ criadoEm: -1 }).exec();
  }

  async findPendingForUser(userId: string): Promise<CirculationDocument[]> {
    return this.model
      .find({
        status: 'pendente',
        paraDestinatarios: { $elemMatch: { tipo: 'user', id: userId } },
        'respostas.userId': { $ne: userId },
      })
      .sort({ criadoEm: -1 })
      .exec();
  }

  async findById(id: string): Promise<CirculationDocument> {
    const doc = await this.model.findById(id).exec();
    if (!doc) throw new NotFoundException('Circulação não encontrada');
    return doc;
  }

  async update(
    id: string,
    dto: UpdateCirculationDto,
  ): Promise<CirculationDocument> {
    const { criadoEm: _ce, deUserId: _de, id: _id, ...safeChanges } = dto as any;
    void _ce; void _de; void _id;

    const circ = await this.model
      .findByIdAndUpdate(
        id,
        { $set: safeChanges },
        { new: true, runValidators: true },
      )
      .exec();

    if (!circ) throw new NotFoundException(`Circulação '${id}' não encontrada`);
    return circ;
  }

  // Determina o novo estado do documento com base nas respostas.
  // Retorna null quando o estado não deve ser alterado ainda.
  private async resolveEstadoDocumento(
    circulation: CirculationDocument,
  ): Promise<string | null> {
    const acaoMap = DECISAO_ESTADO[circulation.acao] ?? {};
    const userDestinatarios = circulation.paraDestinatarios.filter(
      (d) => d.tipo === 'user',
    );
    const totalDestinatarios = userDestinatarios.length;

    if (circulation.obrigatoriaTodos) {
      // Só encerra quando todos responderam
      if (circulation.respostas.length < totalDestinatarios) return null;

      // Verifica se algum rejeitou/não assinou
      const temRejeicao = circulation.respostas.some((r) =>
        ['rejeitado', 'nao_assinado'].includes(r.decisao),
      );
      if (temRejeicao) {
        return acaoMap['rejeitado'] ?? null;
      }
      // Usa a decisão da última resposta para determinar o estado
      const ultimaDecisao =
        circulation.respostas[circulation.respostas.length - 1].decisao;
      return acaoMap[ultimaDecisao] ?? null;
    }

    // Basta uma resposta para encerrar
    const ultimaDecisao =
      circulation.respostas[circulation.respostas.length - 1].decisao;
    return acaoMap[ultimaDecisao] ?? null;
  }
}
