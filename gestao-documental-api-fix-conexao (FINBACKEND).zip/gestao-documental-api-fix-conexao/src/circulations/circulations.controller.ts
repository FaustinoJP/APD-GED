import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';
import { CirculationsService } from './circulations.service';
import { CreateCirculationDto } from './dto/create-circulation.dto';
import { RespondCirculationDto } from './dto/respond-circulation.dto';
import { QueryCirculationDto } from './dto/query-circulation.dto';
import { CirculationResponseDto } from './dto/circulation-response.dto';
import { UpdateCirculationDto } from './dto/update-circulation.dto';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { RequirePermissions } from '../auth/decorators/require-permissions.decorator';
import { JwtPayload } from '../common/types/jwt-payload.interface';

@ApiTags('circulations')
@ApiBearerAuth()
@Controller('circulations')
export class CirculationsController {
  constructor(private readonly service: CirculationsService) {}

  @Post()
  @RequirePermissions('documents.forward')
  @ApiOperation({ summary: 'Criar e enviar uma circulação' })
  async forward(
    @Body() dto: CreateCirculationDto,
    @CurrentUser() user: JwtPayload,
  ): Promise<CirculationResponseDto> {
    const doc = await this.service.forward(dto, user.sub);
    return plainToInstance(CirculationResponseDto, doc.toJSON(), {
      excludeExtraneousValues: true,
    });
  }

  @Get()
  @ApiOperation({ summary: 'Listar circulações (com filtros opcionais)' })
  async findAll(
    @Query() query: QueryCirculationDto,
  ): Promise<CirculationResponseDto[]> {
    const docs = await this.service.findAll(query);
    return docs.map((d) =>
      plainToInstance(CirculationResponseDto, d.toJSON(), {
        excludeExtraneousValues: true,
      }),
    );
  }

  @Get('pending')
  @ApiOperation({ summary: 'Circulações pendentes para o utilizador autenticado' })
  async findPending(
    @CurrentUser() user: JwtPayload,
  ): Promise<CirculationResponseDto[]> {
    const docs = await this.service.findPendingForUser(user.sub);
    return docs.map((d) =>
      plainToInstance(CirculationResponseDto, d.toJSON(), {
        excludeExtraneousValues: true,
      }),
    );
  }

  @Get(':id')
  @ApiOperation({ summary: 'Obter circulação por ID' })
  async findOne(@Param('id') id: string): Promise<CirculationResponseDto> {
    const doc = await this.service.findById(id);
    return plainToInstance(CirculationResponseDto, doc.toJSON(), {
      excludeExtraneousValues: true,
    });
  }

  @Post(':id/respond')
  @ApiOperation({ summary: 'Responder a uma circulação' })
  async respond(
    @Param('id') id: string,
    @Body() dto: RespondCirculationDto,
    @CurrentUser() user: JwtPayload,
  ): Promise<CirculationResponseDto> {
    const doc = await this.service.respond(id, dto, user.sub);
    return plainToInstance(CirculationResponseDto, doc.toJSON(), {
      excludeExtraneousValues: true,
    });
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualizar circulação (PATCH — merge parcial)' })
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateCirculationDto,
  ): Promise<CirculationResponseDto> {
    const doc = await this.service.update(id, dto);
    return plainToInstance(CirculationResponseDto, doc.toJSON(), {
      excludeExtraneousValues: true,
    });
  }
}
