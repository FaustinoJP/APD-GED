import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BaseResponseDto } from '../../common/dto/base.dto';

export class DestinatarioResponseDto {
  @ApiProperty({ enum: ['user', 'group', 'entity'] })
  @Expose()
  tipo: string;

  @ApiProperty()
  @Expose()
  id: string;
}

export class CirculationResponseItemDto {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  circulationId: string;

  @ApiProperty()
  @Expose()
  userId: string;

  @ApiProperty({ enum: ['aprovado', 'rejeitado', 'assinado', 'nao_assinado', 'parecer_dado', 'deferido'] })
  @Expose()
  decisao: string;

  @ApiProperty()
  @Expose()
  mensagem: string;

  @ApiProperty({ required: false })
  @Expose()
  assinaturaId?: string;

  @ApiProperty({ required: false })
  @Expose()
  signatureZoneId?: string;

  @ApiProperty({ required: false })
  @Expose()
  certificadoDigital?: boolean;

  @ApiProperty()
  @Expose()
  criadoEm: string;
}

export class CirculationResponseDto extends BaseResponseDto {
  @ApiProperty()
  @Expose()
  documentId: string;

  @ApiProperty({ enum: ['aprovar', 'assinar', 'parecer', 'despachar', 'deferir', 'verificar', 'encaminhar_interno', 'encaminhar_externo'] })
  @Expose()
  acao: string;

  @ApiProperty()
  @Expose()
  deUserId: string;

  @ApiProperty({ type: [DestinatarioResponseDto] })
  @Expose()
  @Type(() => DestinatarioResponseDto)
  paraDestinatarios: DestinatarioResponseDto[];

  @ApiProperty()
  @Expose()
  mensagem: string;

  @ApiProperty({ required: false })
  @Expose()
  dataLimite?: string;

  @ApiProperty()
  @Expose()
  obrigatoriaTodos: boolean;

  @ApiProperty()
  @Expose()
  enviarEmail: boolean;

  @ApiProperty()
  @Expose()
  receberNotificacao: boolean;

  @ApiProperty({ enum: ['pendente', 'respondido', 'expirado'] })
  @Expose()
  status: string;

  @ApiProperty({ type: [CirculationResponseItemDto] })
  @Expose()
  @Type(() => CirculationResponseItemDto)
  respostas: CirculationResponseItemDto[];

  @ApiProperty()
  @Expose()
  criadoEm: string;

  constructor(partial: Partial<CirculationResponseDto>) {
    super(partial);
    Object.assign(this, partial);
  }
}
