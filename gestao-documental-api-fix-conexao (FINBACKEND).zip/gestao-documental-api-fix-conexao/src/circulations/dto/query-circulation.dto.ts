import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';

export class QueryCirculationDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  documentId?: string;

  @ApiProperty({ required: false, enum: ['pendente', 'respondido', 'expirado'] })
  @IsOptional()
  @IsEnum(['pendente', 'respondido', 'expirado'])
  status?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  deUserId?: string;
}
