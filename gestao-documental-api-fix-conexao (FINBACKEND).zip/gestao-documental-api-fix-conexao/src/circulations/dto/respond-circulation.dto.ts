import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsEnum, IsObject, IsOptional, IsString } from 'class-validator';

export class RespondCirculationDto {
  @ApiProperty({
    enum: ['aprovado', 'rejeitado', 'assinado', 'nao_assinado', 'parecer_dado', 'deferido'],
  })
  @IsEnum(['aprovado', 'rejeitado', 'assinado', 'nao_assinado', 'parecer_dado', 'deferido'])
  decisao: string;

  @ApiProperty({ example: 'Documento aprovado conforme solicitado.' })
  @IsString()
  mensagem: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  assinaturaId?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  signatureZoneId?: string;

  @ApiProperty({ required: false, default: false })
  @IsOptional()
  @IsBoolean()
  certificadoDigital?: boolean;

  @ApiProperty({ required: false, description: 'Todas as zonas assinadas: zoneId → assinaturaId' })
  @IsOptional()
  @IsObject()
  allSignedZones?: Record<string, string>;
}
