import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsBoolean,
  IsEnum,
  IsObject,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

// Redefinido localmente para manter o módulo independente
class DestinatarioDto {
  @ApiProperty({ enum: ['user', 'group', 'entity'] })
  @IsEnum(['user', 'group', 'entity'])
  tipo: string;

  @ApiProperty({ example: 'user-123' })
  @IsString()
  id: string;
}

export class CreateCirculationDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  id?: string;

  @ApiProperty({ example: 'doc-ent-001' })
  @IsString()
  documentId: string;

  @ApiProperty({
    enum: ['aprovar', 'assinar', 'parecer', 'despachar', 'deferir', 'verificar', 'encaminhar_interno', 'encaminhar_externo'],
  })
  @IsEnum(['aprovar', 'assinar', 'parecer', 'despachar', 'deferir', 'verificar', 'encaminhar_interno', 'encaminhar_externo'])
  acao: string;

  @ApiProperty({ type: [DestinatarioDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => DestinatarioDto)
  paraDestinatarios: DestinatarioDto[];

  @ApiProperty({ required: false, example: 'Por favor aprovar com urgência' })
  @IsOptional()
  @IsString()
  mensagem?: string;

  @ApiProperty({ required: false, example: '2024-04-30' })
  @IsOptional()
  @IsString()
  dataLimite?: string;

  @ApiProperty({ required: false, default: false })
  @IsOptional()
  @IsBoolean()
  obrigatoriaTodos?: boolean;

  @ApiProperty({ required: false, default: false })
  @IsOptional()
  @IsBoolean()
  enviarEmail?: boolean;

  @ApiProperty({ required: false, default: true })
  @IsOptional()
  @IsBoolean()
  receberNotificacao?: boolean;

  @ApiProperty({ required: false, description: 'Mapeamento zoneId → userId para assinatura por zona' })
  @IsOptional()
  @IsObject()
  zoneAssignments?: Record<string, string>;
}
