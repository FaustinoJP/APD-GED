import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateCirculationDto } from './create-circulation.dto';
import { IsArray, IsBoolean, IsEnum, IsObject, IsOptional, IsString, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

class UpdateCirculationResponseDto {
  @ApiProperty()
  @IsString()
  id: string;

  @ApiProperty()
  @IsString()
  circulationId: string;

  @ApiProperty()
  @IsString()
  userId: string;

  @ApiProperty({ enum: ['aprovado', 'rejeitado', 'assinado', 'nao_assinado', 'parecer_dado', 'deferido'] })
  @IsEnum(['aprovado', 'rejeitado', 'assinado', 'nao_assinado', 'parecer_dado', 'deferido'])
  decisao: string;

  @ApiProperty()
  @IsString()
  mensagem: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  assinaturaId?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  signatureZoneId?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsObject()
  allSignedZones?: Record<string, string>;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  certificadoDigital?: boolean;

  @ApiProperty()
  @IsString()
  criadoEm: string;
}

export class UpdateCirculationDto extends PartialType(CreateCirculationDto) {
  @ApiProperty({ required: false, enum: ['pendente', 'respondido', 'expirado'] })
  @IsOptional()
  @IsEnum(['pendente', 'respondido', 'expirado'])
  status?: string;

  @ApiProperty({ required: false, type: [UpdateCirculationResponseDto] })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => UpdateCirculationResponseDto)
  respostas?: UpdateCirculationResponseDto[];

  /** Campos somente de leitura — aceites para não rejeitar o payload completo do frontend, mas ignorados pelo serviço. */
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  deUserId?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  criadoEm?: string;
}
