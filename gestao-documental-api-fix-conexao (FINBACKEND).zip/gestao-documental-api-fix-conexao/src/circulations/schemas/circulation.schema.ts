import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import {
  Destinatario,
  DestinatarioSchema,
} from '../../common/schemas/destinatario.schema';

export { Destinatario };

// ─── CirculationResponse sub-schema ──────────────────────────────────────────
// Embebido em Circulation.respostas[].
// { _id: false }: tem o seu próprio campo 'id'.
// 'circulationId' é denormalizado (mesmo que o pai) — mantido por compatibilidade
// com o tipo CirculationResponse do frontend.
@Schema({ _id: false })
export class CirculationResponse {
  @Prop({ required: true }) id: string;
  @Prop({ required: true }) circulationId: string;
  @Prop({ required: true }) userId: string;
  @Prop({
    required: true,
    enum: ['aprovado', 'rejeitado', 'assinado', 'nao_assinado', 'parecer_dado', 'deferido'],
  })
  decisao: string;
  @Prop({ default: '' }) mensagem: string;
  @Prop() assinaturaId?: string;
  @Prop() signatureZoneId?: string;
  @Prop({ type: Map, of: String }) allSignedZones?: Map<string, string>;
  @Prop({ default: false }) certificadoDigital?: boolean;
  @Prop({ required: true }) criadoEm: string;
}
export const CirculationResponseSchema =
  SchemaFactory.createForClass(CirculationResponse);

// ─── Circulation schema ───────────────────────────────────────────────────────
export type CirculationDocument = HydratedDocument<Circulation> & { _id: string };

@Schema({ collection: 'circulations', timestamps: false })
export class Circulation {
  @Prop({ type: String, default: () => uuidv4() })
  _id: string;

  // Referência a DocumentRecord — string pura, sem populate
  @Prop({ required: true })
  documentId: string;

  @Prop({
    required: true,
    enum: [
      'aprovar', 'assinar', 'parecer', 'despachar', 'deferir',
      'verificar', 'encaminhar_interno', 'encaminhar_externo',
    ],
  })
  acao: string;

  // Utilizador que enviou — derivado do JWT no backend
  @Prop({ required: true })
  deUserId: string;

  @Prop({ type: [DestinatarioSchema], default: [] })
  paraDestinatarios: Destinatario[];

  @Prop({ default: '' })
  mensagem: string;

  @Prop()
  dataLimite?: string;

  @Prop({ default: false })
  obrigatoriaTodos: boolean;

  @Prop({ default: false })
  enviarEmail: boolean;

  @Prop({ default: true })
  receberNotificacao: boolean;

  @Prop({
    required: true,
    enum: ['pendente', 'respondido', 'expirado'],
    default: 'pendente',
  })
  status: string;

  @Prop({ type: [CirculationResponseSchema], default: [] })
  respostas: CirculationResponse[];

  @Prop({ type: Map, of: String, default: () => ({}) })
  zoneAssignments: Map<string, string>;

  @Prop({ required: true })
  criadoEm: string;
}

export const CirculationSchema = SchemaFactory.createForClass(Circulation);

// Índices para as queries mais frequentes
CirculationSchema.index({ documentId: 1 });
CirculationSchema.index({ status: 1, 'paraDestinatarios.id': 1 });
