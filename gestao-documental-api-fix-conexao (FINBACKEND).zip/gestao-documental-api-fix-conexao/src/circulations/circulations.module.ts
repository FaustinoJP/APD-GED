import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { Circulation, CirculationSchema } from './schemas/circulation.schema';
import { CirculationsService } from './circulations.service';
import { CirculationsController } from './circulations.controller';
import { DocumentsModule } from '../documents/documents.module';
import { NotificationsModule } from '../notifications/notifications.module';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Circulation.name, schema: CirculationSchema },
    ]),
    DocumentsModule,
    NotificationsModule,
  ],
  providers: [CirculationsService],
  controllers: [CirculationsController],
  exports: [CirculationsService],
})
export class CirculationsModule {}
