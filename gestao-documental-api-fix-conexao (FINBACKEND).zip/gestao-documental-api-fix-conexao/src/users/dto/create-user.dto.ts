import { ApiProperty } from '@nestjs/swagger';
import {
  IsBoolean,
  IsEmail,
  IsOptional,
  IsString,
  MinLength,
} from 'class-validator';

export class CreateUserDto {
  @ApiProperty({ required: false, description: 'Se omitido, UUID gerado automaticamente' })
  @IsOptional()
  @IsString()
  id?: string;

  @ApiProperty({ example: 'João Baptista' })
  @IsString()
  nome: string;

  @ApiProperty({ example: 'joao@faustware.ao' })
  @IsEmail({}, { message: 'Email inválido' })
  email: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  avatarUrl?: string;

  @ApiProperty({ example: 'role-colaborador' })
  @IsString()
  roleId: string;

  @ApiProperty({ required: false, default: true })
  @IsOptional()
  @IsBoolean()
  ativo?: boolean;

  @ApiProperty({
    required: false,
    description: 'Senha em texto simples — será hashada com bcrypt. Obrigatória na criação.',
    example: 'senha123',
  })
  @IsOptional()
  @IsString()
  @MinLength(4, { message: 'Senha deve ter pelo menos 4 caracteres' })
  senha?: string;
}
