import { PartialType } from '@nestjs/swagger';
import { CreateUserDto } from './create-user.dto';

// PartialType torna todos os campos opcionais e mantém validadores + Swagger
export class UpdateUserDto extends PartialType(CreateUserDto) {}
