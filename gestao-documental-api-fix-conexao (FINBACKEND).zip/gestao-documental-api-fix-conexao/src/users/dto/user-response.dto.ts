import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { BaseResponseDto } from '../../common/dto/base.dto';

/**
 * DTO de resposta para User.
 *
 * Extends BaseResponseDto (que tem @Exclude() a nível de classe).
 * Apenas campos com @Expose() são incluídos na resposta.
 * senhaHash é propositadamente ausente — nunca retornado pela API.
 */
export class UserResponseDto extends BaseResponseDto {
  @ApiProperty({ example: 'João Baptista' })
  @Expose()
  nome: string;

  @ApiProperty({ example: 'joao@faustware.ao' })
  @Expose()
  email: string;

  @ApiProperty({ required: false, nullable: true, example: 'https://...' })
  @Expose()
  avatarUrl?: string;

  @ApiProperty({ example: 'role-colaborador', description: 'ID do Role atribuído' })
  @Expose()
  roleId: string;

  @ApiProperty({ example: true })
  @Expose()
  ativo: boolean;

  @ApiProperty({ example: '2024-01-15T10:00:00.000Z' })
  @Expose()
  criadoEm: string;
}
