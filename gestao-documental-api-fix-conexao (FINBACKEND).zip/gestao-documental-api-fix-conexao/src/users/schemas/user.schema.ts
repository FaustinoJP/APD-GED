import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

// Intersecção garante que TypeScript sabe que _id é string, não ObjectId
export type UserDocument = HydratedDocument<User> & { _id: string };

@Schema({ collection: 'users', timestamps: false })
export class User {
  // _id como string UUID — compatível 1:1 com o frontend (id: string)
  // O plugin mongooseIdPlugin converte _id → id no toJSON()
  @Prop({ type: String, default: () => uuidv4() })
  _id: string;

  @Prop({ required: true, trim: true })
  nome: string;

  @Prop({ required: true, unique: true, lowercase: true, trim: true })
  email: string;

  @Prop()
  avatarUrl?: string;

  @Prop({ required: true })
  roleId: string;

  @Prop({ default: true })
  ativo: boolean;

  @Prop({ required: true })
  criadoEm: string;

  // select: false — CRÍTICO: nunca retornado por queries normais.
  // Apenas acessível via .select('+senhaHash') no UsersService.findByEmailWithPassword()
  @Prop({ select: false })
  senhaHash?: string;
}

export const UserSchema = SchemaFactory.createForClass(User);
