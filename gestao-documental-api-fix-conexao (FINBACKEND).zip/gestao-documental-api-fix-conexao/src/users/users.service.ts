import {
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import * as bcrypt from 'bcrypt';
import { Model } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { User, UserDocument } from './schemas/user.schema';

const BCRYPT_ROUNDS = 10;

@Injectable()
export class UsersService {
  constructor(
    @InjectModel(User.name) private readonly userModel: Model<UserDocument>,
  ) {}

  async findAll(): Promise<UserDocument[]> {
    return this.userModel.find().exec();
  }

  async findById(id: string): Promise<UserDocument | null> {
    return this.userModel.findById(id).exec();
  }

  async findByEmail(email: string): Promise<UserDocument | null> {
    return this.userModel.findOne({ email: email.toLowerCase() }).exec();
  }

  // APENAS para autenticação — inclui senhaHash explicitamente
  async findByEmailWithPassword(email: string): Promise<UserDocument | null> {
    return this.userModel
      .findOne({ email: email.toLowerCase() })
      .select('+senhaHash')
      .exec();
  }

  async create(dto: CreateUserDto): Promise<UserDocument> {
    const existing = await this.findByEmail(dto.email);
    if (existing) {
      throw new ConflictException(`Email '${dto.email}' já está registado`);
    }

    const senhaHash = dto.senha
      ? await bcrypt.hash(dto.senha, BCRYPT_ROUNDS)
      : undefined;

    const user = new this.userModel({
      _id: dto.id ?? uuidv4(),
      nome: dto.nome,
      email: dto.email.toLowerCase(),
      avatarUrl: dto.avatarUrl,
      roleId: dto.roleId,
      ativo: dto.ativo ?? true,
      criadoEm: new Date().toISOString(),
      senhaHash,
    });

    return user.save();
  }

  async update(id: string, dto: UpdateUserDto): Promise<UserDocument> {
    const changes: Partial<User> & { senhaHash?: string } = { ...dto };

    // Se uma nova senha foi enviada, hash antes de guardar
    if (dto.senha) {
      changes.senhaHash = await bcrypt.hash(dto.senha, BCRYPT_ROUNDS);
    }
    // Remover 'senha' do objecto de update — não é campo do schema
    delete (changes as { senha?: string }).senha;

    if (dto.email) {
      changes.email = dto.email.toLowerCase();
    }

    const user = await this.userModel
      .findByIdAndUpdate(id, { $set: changes }, { new: true, runValidators: true })
      .exec();

    if (!user) throw new NotFoundException(`Utilizador '${id}' não encontrado`);
    return user;
  }

  async remove(id: string): Promise<void> {
    const result = await this.userModel.findByIdAndDelete(id).exec();
    if (!result) throw new NotFoundException(`Utilizador '${id}' não encontrado`);
  }
}
