import {
  Body, Controller, Delete, Get, HttpCode, HttpStatus,
  NotFoundException, Param, Patch, Post,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';
import { RequirePermissions } from '../auth/decorators/require-permissions.decorator';
import { CreateDossierDto } from './dto/create-dossier.dto';
import { DossierResponseDto } from './dto/dossier-response.dto';
import { UpdateDossierDto } from './dto/update-dossier.dto';
import { DossiersService } from './dossiers.service';

@ApiTags('dossiers')
@ApiBearerAuth('access-token')
@Controller('dossiers')
export class DossiersController {
  constructor(private readonly service: DossiersService) {}

  private toDto(d: object): DossierResponseDto {
    return plainToInstance(DossierResponseDto, d, { excludeExtraneousValues: true });
  }

  @Get()
  @ApiOperation({ summary: 'Listar todos os dossiers' })
  @ApiResponse({ status: 200, type: [DossierResponseDto] })
  async findAll(): Promise<DossierResponseDto[]> {
    return (await this.service.findAll()).map((d) => this.toDto(d.toJSON()));
  }

  @Get(':id')
  @ApiOperation({ summary: 'Obter dossier por ID' })
  @ApiResponse({ status: 200, type: DossierResponseDto })
  async findOne(@Param('id') id: string): Promise<DossierResponseDto> {
    const d = await this.service.findById(id);
    if (!d) throw new NotFoundException(`Dossier '${id}' não encontrado`);
    return this.toDto(d.toJSON());
  }

  @Post()
  @RequirePermissions('files.manage')
  @ApiOperation({ summary: 'Criar dossier' })
  @ApiResponse({ status: 201, type: DossierResponseDto })
  async create(@Body() dto: CreateDossierDto): Promise<DossierResponseDto> {
    return this.toDto((await this.service.create(dto)).toJSON());
  }

  @Patch(':id')
  @RequirePermissions('files.manage')
  @ApiOperation({ summary: 'Actualizar dossier' })
  @ApiResponse({ status: 200, type: DossierResponseDto })
  async update(@Param('id') id: string, @Body() dto: UpdateDossierDto): Promise<DossierResponseDto> {
    return this.toDto((await this.service.update(id, dto)).toJSON());
  }

  @Delete(':id')
  @RequirePermissions('files.manage')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Eliminar dossier' })
  async remove(@Param('id') id: string): Promise<void> {
    await this.service.remove(id);
  }
}
