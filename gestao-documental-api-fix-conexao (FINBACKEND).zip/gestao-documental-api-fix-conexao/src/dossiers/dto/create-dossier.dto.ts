import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsOptional, IsString } from 'class-validator';

export class CreateDossierDto {
  @ApiProperty({ required: false }) @IsOptional() @IsString() id?: string;
  @ApiProperty({ example: 'Dossier Fiscal 2024' }) @IsString() nome: string;
  @ApiProperty({ required: false }) @IsOptional() @IsString() descricao?: string;
  @ApiProperty({ type: [String], required: false, default: [], description: 'IDs de DocumentRecord' })
  @IsOptional() @IsArray() @IsString({ each: true }) documentos?: string[];
}
