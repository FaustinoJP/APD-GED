import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { BaseResponseDto } from '../../common/dto/base.dto';

export class DossierResponseDto extends BaseResponseDto {
  @ApiProperty() @Expose() nome: string;
  @ApiProperty({ required: false }) @Expose() descricao?: string;
  @ApiProperty({ type: [String] }) @Expose() documentos: string[];
}
