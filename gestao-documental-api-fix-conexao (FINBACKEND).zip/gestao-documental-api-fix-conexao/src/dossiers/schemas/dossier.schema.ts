import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

export type DossierDocument = HydratedDocument<Dossier> & { _id: string };

@Schema({ collection: 'dossiers', timestamps: false })
export class Dossier {
  @Prop({ type: String, default: () => uuidv4() })
  _id: string;

  @Prop({ required: true, trim: true })
  nome: string;

  @Prop()
  descricao?: string;

  // IDs de DocumentRecord — armazenados como strings, sem .populate()
  @Prop({ type: [String], default: [] })
  documentos: string[];
}

export const DossierSchema = SchemaFactory.createForClass(Dossier);
