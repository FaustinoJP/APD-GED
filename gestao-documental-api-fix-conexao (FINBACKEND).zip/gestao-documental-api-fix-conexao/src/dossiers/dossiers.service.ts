import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import { Dossier, DossierDocument } from './schemas/dossier.schema';
import { CreateDossierDto } from './dto/create-dossier.dto';
import { UpdateDossierDto } from './dto/update-dossier.dto';

@Injectable()
export class DossiersService {
  constructor(
    @InjectModel(Dossier.name) private readonly model: Model<DossierDocument>,
  ) {}

  async findAll(): Promise<DossierDocument[]> {
    return this.model.find().exec();
  }

  async findById(id: string): Promise<DossierDocument | null> {
    return this.model.findById(id).exec();
  }

  async create(dto: CreateDossierDto): Promise<DossierDocument> {
    const doc = new this.model({
      _id: dto.id ?? uuidv4(),
      nome: dto.nome,
      descricao: dto.descricao,
      documentos: dto.documentos ?? [],
    });
    return doc.save();
  }

  async update(id: string, dto: UpdateDossierDto): Promise<DossierDocument> {
    const doc = await this.model
      .findByIdAndUpdate(id, { $set: dto }, { new: true, runValidators: true })
      .exec();
    if (!doc) throw new NotFoundException(`Dossier '${id}' não encontrado`);
    return doc;
  }

  async remove(id: string): Promise<void> {
    const result = await this.model.findByIdAndDelete(id).exec();
    if (!result) throw new NotFoundException(`Dossier '${id}' não encontrado`);
  }
}
