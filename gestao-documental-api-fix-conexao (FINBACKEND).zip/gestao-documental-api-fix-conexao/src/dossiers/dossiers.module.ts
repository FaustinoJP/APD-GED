import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { Dossier, DossierSchema } from './schemas/dossier.schema';
import { DossiersService } from './dossiers.service';
import { DossiersController } from './dossiers.controller';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: Dossier.name, schema: DossierSchema }]),
  ],
  providers: [DossiersService],
  controllers: [DossiersController],
  exports: [DossiersService],
})
export class DossiersModule {}
