import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BaseResponseDto } from '../../common/dto/base.dto';

export class CustomFieldResponseDto {
  @ApiProperty() @Expose() id: string;
  @ApiProperty() @Expose() label: string;
  @ApiProperty() @Expose() key: string;
  @ApiProperty() @Expose() tipo: string;
  @ApiProperty() @Expose() obrigatorio: boolean;
  @ApiProperty({ required: false, type: [String] }) @Expose() opcoes?: string[];
  @ApiProperty() @Expose() ordem: number;
}

export class DocumentTypeResponseDto extends BaseResponseDto {
  @ApiProperty() @Expose() nome: string;
  @ApiProperty() @Expose() descricao: string;
  @ApiProperty({ enum: ['entrada', 'saida', 'interno', 'todos'] }) @Expose() registro: string;
  @ApiProperty({ type: [CustomFieldResponseDto] })
  @Expose()
  @Type(() => CustomFieldResponseDto)
  campos: CustomFieldResponseDto[];
  @ApiProperty() @Expose() ativo: boolean;
}
