import { ApiProperty } from '@nestjs/swagger';
import {
  IsArray,
  IsBoolean,
  IsEnum,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
import { Type } from 'class-transformer';

export class CreateCustomFieldDto {
  @ApiProperty({ example: 'field-tipo-001' })
  @IsString()
  id: string;

  @ApiProperty({ example: 'Tipo de Contrato' })
  @IsString()
  label: string;

  @ApiProperty({ example: 'tipo' })
  @IsString()
  key: string;

  @ApiProperty({ enum: ['text', 'number', 'date', 'select', 'textarea', 'boolean', 'currency'] })
  @IsEnum(['text', 'number', 'date', 'select', 'textarea', 'boolean', 'currency'])
  tipo: string;

  @ApiProperty({ default: false })
  @IsBoolean()
  obrigatorio: boolean;

  @ApiProperty({ required: false, type: [String] })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  opcoes?: string[];

  @ApiProperty({ example: 0, description: 'Posição na lista de campos' })
  @IsNumber()
  ordem: number;
}

export class CreateDocumentTypeDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  id?: string;

  @ApiProperty({ example: 'Contrato de Trabalho' })
  @IsString()
  nome: string;

  @ApiProperty({ example: 'Contratos celebrados com colaboradores' })
  @IsString()
  descricao: string;

  @ApiProperty({ enum: ['entrada', 'saida', 'interno', 'todos'] })
  @IsEnum(['entrada', 'saida', 'interno', 'todos'])
  registro: string;

  @ApiProperty({ type: [CreateCustomFieldDto], required: false, default: [] })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateCustomFieldDto)
  campos?: CreateCustomFieldDto[];

  @ApiProperty({ required: false, default: true })
  @IsOptional()
  @IsBoolean()
  ativo?: boolean;
}
