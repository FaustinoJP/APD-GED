import {
  Body, Controller, Delete, Get, HttpCode, HttpStatus,
  NotFoundException, Param, Patch, Post,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';
import { RequirePermissions } from '../auth/decorators/require-permissions.decorator';
import { CreateDocumentTypeDto } from './dto/create-document-type.dto';
import { DocumentTypeResponseDto } from './dto/document-type-response.dto';
import { UpdateDocumentTypeDto } from './dto/update-document-type.dto';
import { DocumentTypesService } from './document-types.service';

@ApiTags('document-types')
@ApiBearerAuth('access-token')
@Controller('document-types')
export class DocumentTypesController {
  constructor(private readonly service: DocumentTypesService) {}

  private toDto(doc: object): DocumentTypeResponseDto {
    return plainToInstance(DocumentTypeResponseDto, doc, { excludeExtraneousValues: true });
  }

  @Get()
  @ApiOperation({ summary: 'Listar todos os tipos de documento' })
  @ApiResponse({ status: 200, type: [DocumentTypeResponseDto] })
  async findAll(): Promise<DocumentTypeResponseDto[]> {
    return (await this.service.findAll()).map((d) => this.toDto(d.toJSON()));
  }

  @Get(':id')
  @ApiOperation({ summary: 'Obter tipo de documento por ID' })
  @ApiResponse({ status: 200, type: DocumentTypeResponseDto })
  async findOne(@Param('id') id: string): Promise<DocumentTypeResponseDto> {
    const doc = await this.service.findById(id);
    if (!doc) throw new NotFoundException(`Tipo '${id}' não encontrado`);
    return this.toDto(doc.toJSON());
  }

  @Post()
  @RequirePermissions('config.types.manage')
  @ApiOperation({ summary: 'Criar tipo de documento' })
  @ApiResponse({ status: 201, type: DocumentTypeResponseDto })
  async create(@Body() dto: CreateDocumentTypeDto): Promise<DocumentTypeResponseDto> {
    return this.toDto((await this.service.create(dto)).toJSON());
  }

  @Patch(':id')
  @RequirePermissions('config.types.manage')
  @ApiOperation({ summary: 'Actualizar tipo de documento' })
  @ApiResponse({ status: 200, type: DocumentTypeResponseDto })
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateDocumentTypeDto,
  ): Promise<DocumentTypeResponseDto> {
    return this.toDto((await this.service.update(id, dto)).toJSON());
  }

  @Delete(':id')
  @RequirePermissions('config.types.manage')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Eliminar tipo de documento' })
  async remove(@Param('id') id: string): Promise<void> {
    await this.service.remove(id);
  }
}
