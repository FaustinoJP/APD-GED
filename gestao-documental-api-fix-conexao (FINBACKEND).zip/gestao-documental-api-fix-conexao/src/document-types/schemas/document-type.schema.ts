import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

// ─── CustomField sub-schema ───────────────────────────────────────────────────
// { _id: false } porque CustomField já tem o seu próprio campo 'id' (string).
// O plugin mongooseIdPlugin verifica 'if (_id in ret)' antes de transformar,
// portanto não interfere com este campo 'id' directo.
@Schema({ _id: false })
export class CustomField {
  @Prop({ required: true }) id: string;
  @Prop({ required: true }) label: string;
  @Prop({ required: true }) key: string;
  @Prop({
    required: true,
    enum: ['text', 'number', 'date', 'select', 'textarea', 'boolean', 'currency'],
  })
  tipo: string;
  @Prop({ default: false }) obrigatorio: boolean;
  @Prop({ type: [String] }) opcoes?: string[];
  @Prop({ required: true, default: 0 }) ordem: number;
}
export const CustomFieldSchema = SchemaFactory.createForClass(CustomField);

// ─── DocumentType schema ──────────────────────────────────────────────────────
export type DocumentTypeDocument = HydratedDocument<DocumentType> & { _id: string };

@Schema({ collection: 'document_types', timestamps: false })
export class DocumentType {
  @Prop({ type: String, default: () => uuidv4() })
  _id: string;

  @Prop({ required: true, trim: true })
  nome: string;

  @Prop({ required: true })
  descricao: string;

  @Prop({ required: true, enum: ['entrada', 'saida', 'interno', 'todos'] })
  registro: string;

  @Prop({ type: [CustomFieldSchema], default: [] })
  campos: CustomField[];

  @Prop({ default: true })
  ativo: boolean;
}

export const DocumentTypeSchema = SchemaFactory.createForClass(DocumentType);
