import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import { DocumentType, DocumentTypeDocument } from './schemas/document-type.schema';
import { CreateDocumentTypeDto } from './dto/create-document-type.dto';
import { UpdateDocumentTypeDto } from './dto/update-document-type.dto';

@Injectable()
export class DocumentTypesService {
  constructor(
    @InjectModel(DocumentType.name)
    private readonly model: Model<DocumentTypeDocument>,
  ) {}

  async findAll(): Promise<DocumentTypeDocument[]> {
    return this.model.find().exec();
  }

  async findById(id: string): Promise<DocumentTypeDocument | null> {
    return this.model.findById(id).exec();
  }

  async create(dto: CreateDocumentTypeDto): Promise<DocumentTypeDocument> {
    const doc = new this.model({
      _id: dto.id ?? uuidv4(),
      nome: dto.nome,
      descricao: dto.descricao,
      registro: dto.registro,
      campos: dto.campos ?? [],
      ativo: dto.ativo ?? true,
    });
    return doc.save();
  }

  async update(id: string, dto: UpdateDocumentTypeDto): Promise<DocumentTypeDocument> {
    const doc = await this.model
      .findByIdAndUpdate(id, { $set: dto }, { new: true, runValidators: true })
      .exec();
    if (!doc) throw new NotFoundException(`Tipo de documento '${id}' não encontrado`);
    return doc;
  }

  async remove(id: string): Promise<void> {
    const result = await this.model.findByIdAndDelete(id).exec();
    if (!result) throw new NotFoundException(`Tipo de documento '${id}' não encontrado`);
  }
}
