import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

export type RoleDocument = HydratedDocument<Role> & { _id: string };

@Schema({ collection: 'roles', timestamps: false })
export class Role {
  @Prop({ type: String, default: () => uuidv4() })
  _id: string;

  @Prop({ required: true, trim: true })
  nome: string;

  @Prop({ required: true })
  descricao: string;

  // permissions armazenadas como array de strings (ex: 'documents.create')
  // Espelha o tipo Permission[] do frontend
  @Prop({ type: [String], default: [] })
  permissions: string[];
}

export const RoleSchema = SchemaFactory.createForClass(Role);
