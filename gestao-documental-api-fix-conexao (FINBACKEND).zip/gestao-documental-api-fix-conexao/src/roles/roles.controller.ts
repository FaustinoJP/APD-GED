import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  NotFoundException,
  Param,
  Patch,
  Post,
} from '@nestjs/common';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';
import { RequirePermissions } from '../auth/decorators/require-permissions.decorator';
import { CreateRoleDto } from './dto/create-role.dto';
import { RoleResponseDto } from './dto/role-response.dto';
import { UpdateRoleDto } from './dto/update-role.dto';
import { RolesService } from './roles.service';

@ApiTags('roles')
@ApiBearerAuth('access-token')
@Controller('roles')
export class RolesController {
  constructor(private readonly rolesService: RolesService) {}

  private toDto(role: object): RoleResponseDto {
    return plainToInstance(RoleResponseDto, role, { excludeExtraneousValues: true });
  }

  @Get()
  @ApiOperation({ summary: 'Listar todos os roles' })
  @ApiResponse({ status: 200, type: [RoleResponseDto] })
  async findAll(): Promise<RoleResponseDto[]> {
    const roles = await this.rolesService.findAll();
    return roles.map((r) => this.toDto(r.toJSON()));
  }

  @Get(':id')
  @ApiOperation({ summary: 'Obter role por ID' })
  @ApiResponse({ status: 200, type: RoleResponseDto })
  async findOne(@Param('id') id: string): Promise<RoleResponseDto> {
    const role = await this.rolesService.findById(id);
    if (!role) throw new NotFoundException(`Role '${id}' não encontrado`);
    return this.toDto(role.toJSON());
  }

  @Post()
  @RequirePermissions('config.permissions.manage')
  @ApiOperation({ summary: 'Criar role' })
  @ApiResponse({ status: 201, type: RoleResponseDto })
  async create(@Body() dto: CreateRoleDto): Promise<RoleResponseDto> {
    const role = await this.rolesService.create(dto);
    return this.toDto(role.toJSON());
  }

  @Patch(':id')
  @RequirePermissions('config.permissions.manage')
  @ApiOperation({ summary: 'Actualizar role' })
  @ApiResponse({ status: 200, type: RoleResponseDto })
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateRoleDto,
  ): Promise<RoleResponseDto> {
    const role = await this.rolesService.update(id, dto);
    return this.toDto(role.toJSON());
  }

  @Delete(':id')
  @RequirePermissions('config.permissions.manage')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Eliminar role' })
  @ApiResponse({ status: 204 })
  async remove(@Param('id') id: string): Promise<void> {
    await this.rolesService.remove(id);
  }
}
