import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { BaseResponseDto } from '../../common/dto/base.dto';
import { PERMISSIONS } from '../../common/constants/permissions.constant';

export class RoleResponseDto extends BaseResponseDto {
  @ApiProperty({ example: 'Gestor Documental' })
  @Expose()
  nome: string;

  @ApiProperty({ example: 'Gere documentos e configurações básicas' })
  @Expose()
  descricao: string;

  @ApiProperty({ type: [String], enum: PERMISSIONS })
  @Expose()
  permissions: string[];
}
