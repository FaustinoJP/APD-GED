import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsOptional, IsString } from 'class-validator';
import { PERMISSIONS, Permission } from '../../common/constants/permissions.constant';

export class CreateRoleDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  id?: string;

  @ApiProperty({ example: 'Gestor Documental' })
  @IsString()
  nome: string;

  @ApiProperty({ example: 'Gere documentos e configurações básicas' })
  @IsString()
  descricao: string;

  @ApiProperty({
    type: [String],
    enum: PERMISSIONS,
    example: ['documents.create', 'documents.read'],
    description: 'Lista de permissions atribuídas ao role',
  })
  @IsArray()
  @IsString({ each: true })
  permissions: Permission[];
}
