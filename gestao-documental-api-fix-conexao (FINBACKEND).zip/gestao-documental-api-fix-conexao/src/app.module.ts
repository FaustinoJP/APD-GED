import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { Connection } from 'mongoose';
import { mongooseIdPlugin } from './common/plugins/mongoose-id.plugin';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { RolesModule } from './roles/roles.module';
import { DocumentTypesModule } from './document-types/document-types.module';
import { EntitiesModule } from './entities/entities.module';
import { FoldersModule } from './folders/folders.module';
import { LocationLevelsModule } from './location-levels/location-levels.module';
import { LocationNodesModule } from './location-nodes/location-nodes.module';
import { DossiersModule } from './dossiers/dossiers.module';
import { FuncionariosModule } from './funcionarios/funcionarios.module';
import { DocumentsModule } from './documents/documents.module';
import { CirculationsModule } from './circulations/circulations.module';
import { NotificationsModule } from './notifications/notifications.module';
import { AuditModule } from './audit/audit.module';
import { SignaturesModule } from './signatures/signatures.module';
import { TemplatesModule } from './templates/templates.module';
import { CompanyModule } from './company/company.module';
import { UploadsModule } from './uploads/uploads.module';
import { ProvincesModule } from './provinces/provinces.module';

@Module({
  imports: [
    // ── Variáveis de ambiente ────────────────────────────────────────────────
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),

    // ── MongoDB via Mongoose ─────────────────────────────────────────────────
    MongooseModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        uri: config.getOrThrow<string>('MONGODB_URI'),
        connectionFactory: (connection: Connection): Connection => {
          connection.plugin(mongooseIdPlugin);
          return connection;
        },
      }),
    }),

    // ── Fase 2: Auth + Users + Roles ─────────────────────────────────────────
    AuthModule,   // registra JwtGuard e PermissionsGuard como APP_GUARD global
    UsersModule,
    RolesModule,

    // ── Fase 3: CRUD simples ──────────────────────────────────────────────────
    DocumentTypesModule,
    EntitiesModule,
    FoldersModule,
    LocationLevelsModule,
    LocationNodesModule,
    DossiersModule,
    FuncionariosModule,

    // ── Fase 4: Documents (núcleo do sistema) ────────────────────────────────
    DocumentsModule,

    // ── Fase 5: Circulações e Notificações ───────────────────────────────────
    NotificationsModule,
    CirculationsModule,

    // ── Fase 6: Templates, Assinaturas, Auditoria, Empresa ──────────────────
    TemplatesModule,
    SignaturesModule,
    AuditModule,
    CompanyModule,

    // ── Utilitários ──────────────────────────────────────────────────────────
    UploadsModule,

    // ── Referências estáticas ─────────────────────────────────────────────────
    ProvincesModule,
  ],
})
export class AppModule {}
