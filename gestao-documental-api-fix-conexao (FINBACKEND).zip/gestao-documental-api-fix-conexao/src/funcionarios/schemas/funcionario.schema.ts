import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

export type FuncionarioDocument = HydratedDocument<Funcionario> & {
  _id: string;
};

export const ESTADOS_FUNCIONARIO = [
  'ativo',
  'reforma',
  'licenca',
  'suspenso',
  'exonerado',
  'falecido',
] as const;

@Schema({ collection: 'funcionarios', timestamps: false })
export class Funcionario {
  @Prop({ type: String, default: () => uuidv4() })
  _id: string;

  @Prop({ required: true, trim: true })
  nome: string;

  @Prop({ required: true, trim: true })
  apelido: string;

  @Prop({ required: true, trim: true })
  numeroProcesso: string;

  @Prop({ required: true, enum: ESTADOS_FUNCIONARIO, default: 'ativo' })
  estado: string;

  @Prop({ required: true })
  dataNascimento: string;

  @Prop({ required: true })
  dataInicioFuncoes: string;

  @Prop()
  dataFimFuncoes?: string;

  @Prop({ required: true })
  criadoEm: string;

  @Prop({ required: true })
  atualizadoEm: string;
}

export const FuncionarioSchema = SchemaFactory.createForClass(Funcionario);
