import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { BaseResponseDto } from '../../common/dto/base.dto';
import { ESTADOS_FUNCIONARIO } from '../schemas/funcionario.schema';

export class FuncionarioResponseDto extends BaseResponseDto {
  @ApiProperty() @Expose() nome: string;
  @ApiProperty() @Expose() apelido: string;
  @ApiProperty() @Expose() numeroProcesso: string;
  @ApiProperty({ enum: ESTADOS_FUNCIONARIO }) @Expose() estado: string;
  @ApiProperty() @Expose() dataNascimento: string;
  @ApiProperty() @Expose() dataInicioFuncoes: string;
  @ApiProperty({ required: false }) @Expose() dataFimFuncoes?: string;
  @ApiProperty() @Expose() criadoEm: string;
  @ApiProperty() @Expose() atualizadoEm: string;
}
