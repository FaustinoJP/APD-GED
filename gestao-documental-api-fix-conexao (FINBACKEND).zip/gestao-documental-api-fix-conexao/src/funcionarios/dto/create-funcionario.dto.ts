import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';
import { ESTADOS_FUNCIONARIO } from '../schemas/funcionario.schema';

export class CreateFuncionarioDto {
  @ApiProperty({ required: false }) @IsOptional() @IsString() id?: string;

  @ApiProperty({ example: 'João' }) @IsString() nome: string;

  @ApiProperty({ example: 'Silva' }) @IsString() apelido: string;

  @ApiProperty({ example: 'PROC-2024/00123' })
  @IsString()
  numeroProcesso: string;

  @ApiProperty({ enum: ESTADOS_FUNCIONARIO, default: 'ativo' })
  @IsEnum(ESTADOS_FUNCIONARIO)
  estado: string;

  @ApiProperty({ example: '1985-04-12', description: 'ISO date' })
  @IsString()
  dataNascimento: string;

  @ApiProperty({ example: '2010-01-15', description: 'ISO date' })
  @IsString()
  dataInicioFuncoes: string;

  @ApiProperty({ required: false, example: '2024-12-31', description: 'ISO date' })
  @IsOptional()
  @IsString()
  dataFimFuncoes?: string;

  @ApiProperty({ required: false }) @IsOptional() @IsString() criadoEm?: string;

  @ApiProperty({ required: false }) @IsOptional() @IsString() atualizadoEm?: string;
}
