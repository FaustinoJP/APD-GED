import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import { Funcionario, FuncionarioDocument } from './schemas/funcionario.schema';
import { CreateFuncionarioDto } from './dto/create-funcionario.dto';
import { UpdateFuncionarioDto } from './dto/update-funcionario.dto';

@Injectable()
export class FuncionariosService {
  constructor(
    @InjectModel(Funcionario.name)
    private readonly model: Model<FuncionarioDocument>,
  ) {}

  async findAll(): Promise<FuncionarioDocument[]> {
    return this.model.find().exec();
  }

  async findById(id: string): Promise<FuncionarioDocument | null> {
    return this.model.findById(id).exec();
  }

  async create(dto: CreateFuncionarioDto): Promise<FuncionarioDocument> {
    const now = new Date().toISOString();
    const doc = new this.model({
      _id: dto.id ?? uuidv4(),
      nome: dto.nome,
      apelido: dto.apelido,
      numeroProcesso: dto.numeroProcesso,
      estado: dto.estado,
      dataNascimento: dto.dataNascimento,
      dataInicioFuncoes: dto.dataInicioFuncoes,
      dataFimFuncoes: dto.dataFimFuncoes,
      criadoEm: dto.criadoEm ?? now,
      atualizadoEm: now,
    });
    return doc.save();
  }

  async update(
    id: string,
    dto: UpdateFuncionarioDto,
  ): Promise<FuncionarioDocument> {
    const now = new Date().toISOString();
    // Campos imutáveis não são sobrescritos pelo cliente
    const { id: _id, criadoEm: _ce, ...safeChanges } = dto as Record<
      string,
      unknown
    >;
    void _id;
    void _ce;

    const doc = await this.model
      .findByIdAndUpdate(
        id,
        { $set: { ...safeChanges, atualizadoEm: now } },
        { new: true, runValidators: true },
      )
      .exec();
    if (!doc) throw new NotFoundException(`Funcionário '${id}' não encontrado`);
    return doc;
  }

  async remove(id: string): Promise<void> {
    const result = await this.model.findByIdAndDelete(id).exec();
    if (!result) throw new NotFoundException(`Funcionário '${id}' não encontrado`);
  }
}
