import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  NotFoundException,
  Param,
  Patch,
  Post,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';
import { RequirePermissions } from '../auth/decorators/require-permissions.decorator';
import { CreateFuncionarioDto } from './dto/create-funcionario.dto';
import { FuncionarioResponseDto } from './dto/funcionario-response.dto';
import { UpdateFuncionarioDto } from './dto/update-funcionario.dto';
import { FuncionariosService } from './funcionarios.service';

@ApiTags('funcionarios')
@ApiBearerAuth('access-token')
@Controller('funcionarios')
export class FuncionariosController {
  constructor(private readonly service: FuncionariosService) {}

  private toDto(f: object): FuncionarioResponseDto {
    return plainToInstance(FuncionarioResponseDto, f, {
      excludeExtraneousValues: true,
    });
  }

  @Get()
  @ApiOperation({ summary: 'Listar todos os funcionários' })
  @ApiResponse({ status: 200, type: [FuncionarioResponseDto] })
  async findAll(): Promise<FuncionarioResponseDto[]> {
    return (await this.service.findAll()).map((f) => this.toDto(f.toJSON()));
  }

  @Get(':id')
  @ApiOperation({ summary: 'Obter funcionário por ID' })
  @ApiResponse({ status: 200, type: FuncionarioResponseDto })
  async findOne(@Param('id') id: string): Promise<FuncionarioResponseDto> {
    const f = await this.service.findById(id);
    if (!f) throw new NotFoundException(`Funcionário '${id}' não encontrado`);
    return this.toDto(f.toJSON());
  }

  @Post()
  @RequirePermissions('config.users.manage')
  @ApiOperation({ summary: 'Registar novo funcionário' })
  @ApiResponse({ status: 201, type: FuncionarioResponseDto })
  async create(
    @Body() dto: CreateFuncionarioDto,
  ): Promise<FuncionarioResponseDto> {
    return this.toDto((await this.service.create(dto)).toJSON());
  }

  @Patch(':id')
  @RequirePermissions('config.users.manage')
  @ApiOperation({ summary: 'Actualizar funcionário' })
  @ApiResponse({ status: 200, type: FuncionarioResponseDto })
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateFuncionarioDto,
  ): Promise<FuncionarioResponseDto> {
    return this.toDto((await this.service.update(id, dto)).toJSON());
  }

  @Delete(':id')
  @RequirePermissions('config.users.manage')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Eliminar funcionário' })
  async remove(@Param('id') id: string): Promise<void> {
    await this.service.remove(id);
  }
}
