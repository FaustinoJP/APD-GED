import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import {
  Funcionario,
  FuncionarioSchema,
} from './schemas/funcionario.schema';
import { FuncionariosService } from './funcionarios.service';
import { FuncionariosController } from './funcionarios.controller';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Funcionario.name, schema: FuncionarioSchema },
    ]),
  ],
  providers: [FuncionariosService],
  controllers: [FuncionariosController],
  exports: [FuncionariosService],
})
export class FuncionariosModule {}
