import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  NotFoundException,
  Param,
  Patch,
  Post,
  Query,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import {
  ApiBearerAuth,
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { RequirePermissions } from '../auth/decorators/require-permissions.decorator';
import { multerConfig } from '../common/config/multer.config';
import { JwtPayload } from '../common/types/jwt-payload.interface';
import { AnexoMetaDto, CreateDocumentDto } from './dto/create-document.dto';
import { DocumentResponseDto } from './dto/document-response.dto';
import { QueryDocumentDto } from './dto/query-document.dto';
import { UpdateDocumentDto } from './dto/update-document.dto';
import { UpdateEstadoDto } from './dto/update-estado.dto';
import { DocumentsService } from './documents.service';

@ApiTags('documents')
@ApiBearerAuth('access-token')
@Controller('documents')
export class DocumentsController {
  constructor(private readonly service: DocumentsService) {}

  private toDto(doc: object): DocumentResponseDto {
    return plainToInstance(DocumentResponseDto, doc, {
      excludeExtraneousValues: true,
    });
  }

  // ── Listagem e consulta ──────────────────────────────────────────────────────

  @Get()
  @RequirePermissions('documents.read')
  @ApiOperation({ summary: 'Listar documentos' })
  @ApiResponse({ status: 200, type: [DocumentResponseDto] })
  async findAll(@Query() query: QueryDocumentDto): Promise<DocumentResponseDto[]> {
    const docs = await this.service.findAll(query);
    return docs.map((d) => this.toDto(d.toJSON()));
  }

  @Get(':id')
  @RequirePermissions('documents.read')
  @ApiOperation({ summary: 'Obter documento por ID' })
  @ApiResponse({ status: 200, type: DocumentResponseDto })
  async findOne(@Param('id') id: string): Promise<DocumentResponseDto> {
    const doc = await this.service.findById(id);
    if (!doc) throw new NotFoundException(`Documento '${id}' não encontrado`);
    return this.toDto(doc.toJSON());
  }

  // ── Criação (JSON) ────────────────────────────────────────────────────────────
  // Ficheiros já carregados via POST /uploads antes da submissão do formulário.

  @Post()
  @RequirePermissions('documents.create')
  @ApiOperation({
    summary: 'Registar novo documento',
    description:
      'Aceita JSON. Os ficheiros devem ser pré-carregados via POST /uploads. ' +
      'criadoPor é derivado do JWT. numero é gerado atomicamente se omitido.',
  })
  @ApiResponse({ status: 201, type: DocumentResponseDto })
  async create(
    @Body() dto: CreateDocumentDto,
    @CurrentUser() user: JwtPayload,
  ): Promise<DocumentResponseDto> {
    const doc = await this.service.create(dto, user.sub);
    return this.toDto(doc.toJSON());
  }

  // ── Actualização ─────────────────────────────────────────────────────────────

  @Patch(':id')
  @RequirePermissions('documents.update')
  @ApiOperation({ summary: 'Actualizar documento (PATCH — merge parcial)' })
  @ApiResponse({ status: 200, type: DocumentResponseDto })
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateDocumentDto,
  ): Promise<DocumentResponseDto> {
    const doc = await this.service.update(id, dto);
    return this.toDto(doc.toJSON());
  }

  // ── Transição de estado ───────────────────────────────────────────────────────

  @Patch(':id/estado')
  @RequirePermissions('documents.update')
  @ApiOperation({ summary: 'Transicionar estado do documento' })
  @ApiResponse({ status: 200, type: DocumentResponseDto })
  async updateEstado(
    @Param('id') id: string,
    @Body() dto: UpdateEstadoDto,
  ): Promise<DocumentResponseDto> {
    const doc = await this.service.updateEstado(id, dto.estado);
    return this.toDto(doc.toJSON());
  }

  // ── Remoção ──────────────────────────────────────────────────────────────────

  @Delete(':id')
  @RequirePermissions('documents.delete')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Eliminar documento' })
  async remove(@Param('id') id: string): Promise<void> {
    await this.service.remove(id);
  }

  // ── Gestão de anexos ──────────────────────────────────────────────────────────
  // POST /:id/anexos: multipart — upload directo para documentos já existentes.

  @Post(':id/anexos')
  @RequirePermissions('documents.update')
  @UseInterceptors(FileInterceptor('file', multerConfig))
  @ApiConsumes('multipart/form-data')
  @ApiOperation({
    summary: 'Adicionar anexo a documento existente',
    description:
      'Upload directo via multipart/form-data. ' +
      'adicionadoPor é derivado do JWT.',
  })
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: { type: 'string', format: 'binary' },
        nome: { type: 'string' },
        observacao: { type: 'string' },
        versao: { type: 'number' },
        estado: { type: 'string', enum: ['check_in', 'check_out'] },
      },
      required: ['file'],
    },
  })
  @ApiResponse({ status: 201, type: DocumentResponseDto })
  async addAnexo(
    @Param('id') docId: string,
    @UploadedFile() file: Express.Multer.File,
    @Body() meta: AnexoMetaDto,
    @CurrentUser() user: JwtPayload,
  ): Promise<DocumentResponseDto> {
    const doc = await this.service.addAnexo(docId, file, meta, user.sub);
    return this.toDto(doc.toJSON());
  }

  @Delete(':id/anexos/:anexoId')
  @RequirePermissions('documents.update')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Remover anexo do documento' })
  async removeAnexo(
    @Param('id') docId: string,
    @Param('anexoId') anexoId: string,
  ): Promise<void> {
    await this.service.removeAnexo(docId, anexoId);
  }
}
