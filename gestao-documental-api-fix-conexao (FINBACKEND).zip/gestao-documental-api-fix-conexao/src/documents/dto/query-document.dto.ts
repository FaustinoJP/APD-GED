import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';

export class QueryDocumentDto {
  @ApiProperty({ required: false, enum: ['entrada', 'saida', 'interno'] })
  @IsOptional()
  @IsEnum(['entrada', 'saida', 'interno'])
  tipoRegistro?: string;

  @ApiProperty({
    required: false,
    enum: ['novo', 'em_circulacao', 'aprovado', 'rejeitado', 'deferido', 'arquivado', 'concluido'],
  })
  @IsOptional()
  @IsEnum(['novo', 'em_circulacao', 'aprovado', 'rejeitado', 'deferido', 'arquivado', 'concluido'])
  estado?: string;

  @ApiProperty({ required: false, description: 'Filtrar por ID de tipo de documento' })
  @IsOptional()
  @IsString()
  tipoDocumentoId?: string;

  @ApiProperty({ required: false, description: 'Filtrar por ID do criador' })
  @IsOptional()
  @IsString()
  criadoPor?: string;
}
