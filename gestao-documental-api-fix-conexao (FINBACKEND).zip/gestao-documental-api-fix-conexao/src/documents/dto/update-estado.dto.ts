import { ApiProperty } from '@nestjs/swagger';
import { IsEnum } from 'class-validator';

export class UpdateEstadoDto {
  @ApiProperty({
    enum: ['novo', 'em_circulacao', 'aprovado', 'rejeitado', 'deferido', 'arquivado', 'concluido'],
    description: 'Novo estado do documento',
  })
  @IsEnum(['novo', 'em_circulacao', 'aprovado', 'rejeitado', 'deferido', 'arquivado', 'concluido'], {
    message: 'Estado inválido',
  })
  estado: string;
}
