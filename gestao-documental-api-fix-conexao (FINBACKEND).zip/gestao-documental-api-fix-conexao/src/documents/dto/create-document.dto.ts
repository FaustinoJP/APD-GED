import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsBoolean,
  IsEnum,
  IsNumber,
  IsObject,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';

// Metadados opcionais enviados no multipart de POST /:id/anexos
// (tamanho/formato/url derivados do ficheiro pelo Multer)
export class AnexoMetaDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  nome?: string;

  @ApiProperty({ required: false, default: 1 })
  @IsOptional()
  @IsNumber()
  versao?: number;

  @ApiProperty({ enum: ['check_in', 'check_out'], required: false, default: 'check_in' })
  @IsOptional()
  @IsEnum(['check_in', 'check_out'])
  estado?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  observacao?: string;
}

export class CreateDestinatarioDto {
  @ApiProperty({ enum: ['user', 'group', 'entity'] })
  @IsEnum(['user', 'group', 'entity'])
  tipo: string;

  @ApiProperty({ example: 'user-123' })
  @IsString()
  id: string;
}

// Metadados de um ficheiro já carregado via POST /uploads.
// tamanho, formato e url são devolvidos pelo endpoint de pre-upload.
export class CreateAttachmentDto {
  @ApiProperty({ required: false, description: 'Se omitido, UUID gerado pelo servidor' })
  @IsOptional()
  @IsString()
  id?: string;

  @ApiProperty({ example: 'contrato.pdf' })
  @IsString()
  nome: string;

  @ApiProperty({ required: false, default: 1 })
  @IsOptional()
  @IsNumber()
  versao?: number;

  @ApiProperty({ enum: ['check_in', 'check_out'], required: false, default: 'check_in' })
  @IsOptional()
  @IsEnum(['check_in', 'check_out'])
  estado?: string;

  @ApiProperty({ example: 204800, description: 'Tamanho em bytes (devolvido pelo pre-upload)' })
  @IsNumber()
  tamanho: number;

  @ApiProperty({ example: 'pdf', description: 'Extensão (devolvida pelo pre-upload)' })
  @IsString()
  formato: string;

  @ApiProperty({ required: false, description: 'URL do ficheiro no servidor (devolvida pelo pre-upload)' })
  @IsOptional()
  @IsString()
  url?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  adicionadoPor?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  criadoEm?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  observacao?: string;
}

export class CreateDocumentDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  id?: string;

  @ApiProperty({ required: false, example: 'ENT-2024/00001' })
  @IsOptional()
  @IsString()
  numero?: string;

  @ApiProperty({ enum: ['entrada', 'saida', 'interno'] })
  @IsEnum(['entrada', 'saida', 'interno'])
  tipoRegistro: string;

  @ApiProperty({ example: 'doctype-contrato-001' })
  @IsString()
  tipoDocumentoId: string;

  @ApiProperty({ example: 'Contrato de prestação de serviços' })
  @IsString()
  assunto: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  remetenteId?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  remetenteTexto?: string;

  @ApiProperty({ type: [CreateDestinatarioDto], required: false, default: [] })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateDestinatarioDto)
  destinatarios?: CreateDestinatarioDto[];

  @ApiProperty({ example: '2024-03-15' })
  @IsString()
  data: string;

  @ApiProperty({ required: false, default: false })
  @IsOptional()
  @IsBoolean()
  confidencial?: boolean;

  @ApiProperty({ type: [String], required: false, default: [], description: 'Palavras-chave para pesquisa' })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];

  @ApiProperty({
    required: false,
    enum: ['novo', 'em_circulacao', 'aprovado', 'rejeitado', 'deferido', 'arquivado', 'concluido'],
    default: 'novo',
  })
  @IsOptional()
  @IsEnum(['novo', 'em_circulacao', 'aprovado', 'rejeitado', 'deferido', 'arquivado', 'concluido'])
  estado?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  regiao?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  localizacao?: string;

  @ApiProperty({ required: false, description: 'ID do LocationNode (árvore de localização física) mais profundo escolhido' })
  @IsOptional()
  @IsString()
  localizacaoFisicaId?: string;

  @ApiProperty({
    type: 'object',
    additionalProperties: true,
    required: false,
    example: { tipo: 'prazo_determinado', valor: 1500 },
  })
  @IsOptional()
  @IsObject()
  camposValores?: Record<string, unknown>;

  @ApiProperty({
    type: [CreateAttachmentDto],
    required: false,
    description: 'Ficheiros já carregados via POST /uploads.',
  })
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateAttachmentDto)
  anexos?: CreateAttachmentDto[];

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  dossierId?: string;

  @ApiProperty({ required: false, description: 'Referência ao funcionário vinculado' })
  @IsOptional()
  @IsString()
  funcionarioId?: string;
}
