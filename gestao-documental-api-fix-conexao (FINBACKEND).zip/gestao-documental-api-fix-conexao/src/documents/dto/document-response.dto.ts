import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BaseResponseDto } from '../../common/dto/base.dto';

// ─── Sub-DTOs de resposta ─────────────────────────────────────────────────────

export class DestinatarioResponseDto {
  @ApiProperty({ enum: ['user', 'group', 'entity'] }) @Expose() tipo: string;
  @ApiProperty({ example: 'user-123' }) @Expose() id: string;
}

export class AttachmentResponseDto {
  @ApiProperty() @Expose() id: string;
  @ApiProperty() @Expose() nome: string;
  @ApiProperty() @Expose() versao: number;
  @ApiProperty({ enum: ['check_in', 'check_out'] }) @Expose() estado: string;
  @ApiProperty() @Expose() tamanho: number;
  @ApiProperty() @Expose() formato: string;
  @ApiProperty({ required: false }) @Expose() url?: string;
  @ApiProperty() @Expose() adicionadoPor: string;
  @ApiProperty() @Expose() criadoEm: string;
  @ApiProperty({ required: false }) @Expose() observacao?: string;
}

// ─── DocumentResponseDto principal ───────────────────────────────────────────

export class DocumentResponseDto extends BaseResponseDto {
  @ApiProperty({ example: 'ENT-2024/00001' }) @Expose() numero: string;
  @ApiProperty({ enum: ['entrada', 'saida', 'interno'] }) @Expose() tipoRegistro: string;
  @ApiProperty() @Expose() tipoDocumentoId: string;
  @ApiProperty() @Expose() assunto: string;
  @ApiProperty({ required: false }) @Expose() remetenteId?: string;
  @ApiProperty({ required: false }) @Expose() remetenteTexto?: string;

  @ApiProperty({ type: [DestinatarioResponseDto] })
  @Expose()
  @Type(() => DestinatarioResponseDto)
  destinatarios: DestinatarioResponseDto[];

  @ApiProperty() @Expose() data: string;
  @ApiProperty() @Expose() confidencial: boolean;
  @ApiProperty({ type: [String] }) @Expose() tags: string[];

  @ApiProperty({ enum: ['novo', 'em_circulacao', 'aprovado', 'rejeitado', 'deferido', 'arquivado', 'concluido'] })
  @Expose()
  estado: string;

  @ApiProperty({ required: false }) @Expose() regiao?: string;
  @ApiProperty({ required: false }) @Expose() localizacao?: string;
  @ApiProperty({ required: false }) @Expose() localizacaoFisicaId?: string;

  @ApiProperty({
    type: 'object',
    additionalProperties: true,
    description: 'Campos dinâmicos (Mixed) — estrutura definida pelo DocumentType',
  })
  @Expose()
  camposValores: Record<string, unknown>;

  @ApiProperty({ type: [AttachmentResponseDto] })
  @Expose()
  @Type(() => AttachmentResponseDto)
  anexos: AttachmentResponseDto[];

  @ApiProperty() @Expose() criadoPor: string;
  @ApiProperty() @Expose() criadoEm: string;
  @ApiProperty() @Expose() atualizadoEm: string;
  @ApiProperty({ required: false }) @Expose() dossierId?: string;
  @ApiProperty({ required: false }) @Expose() funcionarioId?: string;
}
