import { ApiProperty, OmitType, PartialType } from '@nestjs/swagger';
import { CreateDocumentDto } from './create-document.dto';
import { IsOptional, IsString } from 'class-validator';

// Anexos são geridos por endpoints dedicados (POST/DELETE /:id/anexos).
// Excluir do PATCH para evitar conflitos de validação e erros acidentais.
export class UpdateDocumentDto extends PartialType(
  OmitType(CreateDocumentDto, ['anexos'] as const),
) {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  criadoPor?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  criadoEm?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  atualizadoEm?: string;
}
