import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, Schema as MongooseSchema } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import { Destinatario, DestinatarioSchema } from '../../common/schemas/destinatario.schema';

export { Destinatario, DestinatarioSchema };

// ─── Attachment sub-schema ────────────────────────────────────────────────────
// { _id: false }: tem o seu próprio campo 'id' (não Mongoose _id).
// O plugin mongooseIdPlugin não interferirá — verifica 'if (_id in ret)'.
@Schema({ _id: false })
export class Attachment {
  @Prop({ required: true }) id: string;
  @Prop({ required: true }) nome: string;
  @Prop({ default: 1 }) versao: number;
  @Prop({ enum: ['check_in', 'check_out'], default: 'check_in' }) estado: string;
  @Prop({ default: 0 }) tamanho: number;
  @Prop({ required: true }) formato: string;
  @Prop() url?: string;
  @Prop({ required: true }) adicionadoPor: string;
  @Prop({ required: true }) criadoEm: string;
  @Prop() observacao?: string;
}
export const AttachmentSchema = SchemaFactory.createForClass(Attachment);

// ─── DocumentRecord schema ────────────────────────────────────────────────────
export type DocumentDocument = HydratedDocument<DocumentRecord> & { _id: string };

@Schema({ collection: 'documents', timestamps: false })
export class DocumentRecord {
  @Prop({ type: String, default: () => uuidv4() })
  _id: string;

  @Prop({ required: true })
  numero: string;

  @Prop({ required: true, enum: ['entrada', 'saida', 'interno'] })
  tipoRegistro: string;

  // Referência a DocumentType — string pura, sem populate
  @Prop({ required: true })
  tipoDocumentoId: string;

  @Prop({ required: true })
  assunto: string;

  // Referência a Entity — string pura, sem populate
  @Prop() remetenteId?: string;
  @Prop() remetenteTexto?: string;

  @Prop({ type: [DestinatarioSchema], default: [] })
  destinatarios: Destinatario[];

  @Prop({ required: true })
  data: string;

  @Prop({ default: false })
  confidencial: boolean;

  // Palavras-chave livres para pesquisa avançada
  @Prop({ type: [String], default: [] })
  tags: string[];

  @Prop({
    required: true,
    enum: ['novo', 'em_circulacao', 'aprovado', 'rejeitado', 'deferido', 'arquivado', 'concluido'],
    default: 'novo',
  })
  estado: string;

  @Prop() regiao?: string;
  @Prop() localizacao?: string;

  // Referência ao nó mais profundo escolhido em LocationNode (árvore de
  // localização física configurável) — string pura, sem populate.
  @Prop() localizacaoFisicaId?: string;

  // Mixed: campos dinâmicos definidos em DocumentType.campos — sem validação server-side.
  // Usar sempre $set ao actualizar para evitar problemas de dirty-tracking do Mongoose.
  @Prop({ type: MongooseSchema.Types.Mixed, default: {} })
  camposValores: Record<string, unknown>;

  @Prop({ type: [AttachmentSchema], default: [] })
  anexos: Attachment[];

  // Referência a User — string pura, derivada do JWT no backend
  @Prop({ required: true })
  criadoPor: string;

  @Prop({ required: true })
  criadoEm: string;

  @Prop({ required: true })
  atualizadoEm: string;

  // Referência a Dossier — string pura, sem populate
  @Prop() dossierId?: string;

  // Referência a Funcionario — string pura, sem populate
  @Prop() funcionarioId?: string;
}

export const DocumentSchema = SchemaFactory.createForClass(DocumentRecord);
