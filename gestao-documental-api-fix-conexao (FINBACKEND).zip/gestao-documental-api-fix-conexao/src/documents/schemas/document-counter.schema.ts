import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type DocumentCounterDocument = HydratedDocument<DocumentCounter> & {
  _id: string;
};

// Colecção interna — não exposta via API.
// _id é uma chave semântica: 'entrada:2024', 'saida:2025', etc. (não UUID).
// findByIdAndUpdate + $inc garante atomicidade sem race conditions.
@Schema({ collection: 'document_counters', timestamps: false })
export class DocumentCounter {
  @Prop({ type: String, required: true })
  _id: string;

  @Prop({ default: 0 })
  seq: number;
}

export const DocumentCounterSchema = SchemaFactory.createForClass(DocumentCounter);
