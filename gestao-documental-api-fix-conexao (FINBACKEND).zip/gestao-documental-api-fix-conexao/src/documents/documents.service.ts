import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { extname } from 'path';
import { unlinkSync, existsSync } from 'fs';
import { join } from 'path';
import { v4 as uuidv4 } from 'uuid';
import { DocumentCounter, DocumentCounterDocument } from './schemas/document-counter.schema';
import { DocumentRecord, DocumentDocument } from './schemas/document.schema';
import { AnexoMetaDto, CreateDocumentDto } from './dto/create-document.dto';
import { UpdateDocumentDto } from './dto/update-document.dto';
import { QueryDocumentDto } from './dto/query-document.dto';

type TipoRegistro = 'entrada' | 'saida' | 'interno';

const NUMERO_PREFIX: Record<TipoRegistro, string> = {
  entrada: 'ENT',
  saida: 'SAI',
  interno: 'INT',
};

function deleteUploadedFile(url: string): void {
  try {
    const filename = url.replace('/uploads/documents/', '');
    const fullPath = join(process.cwd(), 'uploads', 'documents', filename);
    if (existsSync(fullPath)) unlinkSync(fullPath);
  } catch {
    // Não bloquear a operação se o ficheiro já não existir
  }
}

@Injectable()
export class DocumentsService {
  constructor(
    @InjectModel(DocumentRecord.name)
    private readonly docModel: Model<DocumentDocument>,
    @InjectModel(DocumentCounter.name)
    private readonly counterModel: Model<DocumentCounterDocument>,
  ) {}

  // ── Gerador de número atómico ───────────────────────────────────────────────
  private async gerarNumero(tipo: TipoRegistro): Promise<string> {
    const year = new Date().getFullYear();
    const key = `${tipo}:${year}`;
    const prefix = NUMERO_PREFIX[tipo];

    const counter = await this.counterModel
      .findByIdAndUpdate(
        key,
        { $inc: { seq: 1 } },
        { new: true, upsert: true },
      )
      .exec();

    const seq = String(counter!.seq).padStart(5, '0');
    return `${prefix}-${year}/${seq}`;
  }

  async lerContador(tipo: TipoRegistro, year?: number): Promise<number> {
    const y = year ?? new Date().getFullYear();
    const counter = await this.counterModel.findById(`${tipo}:${y}`).exec();
    return counter?.seq ?? 0;
  }

  // ── CRUD principal ─────────────────────────────────────────────────────────

  async findAll(query: QueryDocumentDto): Promise<DocumentDocument[]> {
    const filter: Record<string, unknown> = {};
    if (query.tipoRegistro) filter.tipoRegistro = query.tipoRegistro;
    if (query.estado) filter.estado = query.estado;
    if (query.tipoDocumentoId) filter.tipoDocumentoId = query.tipoDocumentoId;
    if (query.criadoPor) filter.criadoPor = query.criadoPor;
    return this.docModel.find(filter).exec();
  }

  async findById(id: string): Promise<DocumentDocument | null> {
    return this.docModel.findById(id).exec();
  }

  // Ficheiros já pré-carregados via POST /uploads — o DTO traz url, tamanho, formato.
  async create(dto: CreateDocumentDto, userId: string): Promise<DocumentDocument> {
    const now = new Date().toISOString();
    const numero =
      dto.numero ?? (await this.gerarNumero(dto.tipoRegistro as TipoRegistro));

    const anexos = (dto.anexos ?? []).map((a) => ({
      id: a.id ?? uuidv4(),
      nome: a.nome,
      versao: a.versao ?? 1,
      estado: a.estado ?? 'check_in',
      tamanho: a.tamanho,
      formato: a.formato,
      url: a.url,
      adicionadoPor: a.adicionadoPor ?? userId,
      criadoEm: a.criadoEm ?? now,
      observacao: a.observacao,
    }));

    const doc = new this.docModel({
      _id: dto.id ?? uuidv4(),
      numero,
      tipoRegistro: dto.tipoRegistro,
      tipoDocumentoId: dto.tipoDocumentoId,
      assunto: dto.assunto,
      remetenteId: dto.remetenteId,
      remetenteTexto: dto.remetenteTexto,
      destinatarios: dto.destinatarios ?? [],
      data: dto.data,
      confidencial: dto.confidencial ?? false,
      tags: dto.tags ?? [],
      estado: dto.estado ?? 'novo',
      regiao: dto.regiao,
      localizacao: dto.localizacao,
      camposValores: dto.camposValores ?? {},
      anexos,
      criadoPor: userId,
      criadoEm: now,
      atualizadoEm: now,
      dossierId: dto.dossierId,
      funcionarioId: dto.funcionarioId,
    });

    return doc.save();
  }

  async update(id: string, dto: UpdateDocumentDto): Promise<DocumentDocument> {
    const now = new Date().toISOString();
    const { numero: _n, criadoPor: _cp, criadoEm: _ce, id: _id, ...safeChanges } = dto as Record<string, unknown>;
    void _n; void _cp; void _ce; void _id;

    const doc = await this.docModel
      .findByIdAndUpdate(
        id,
        { $set: { ...safeChanges, atualizadoEm: now } },
        { new: true, runValidators: true },
      )
      .exec();

    if (!doc) throw new NotFoundException(`Documento '${id}' não encontrado`);
    return doc;
  }

  async remove(id: string): Promise<void> {
    const doc = await this.docModel.findByIdAndDelete(id).exec();
    if (!doc) throw new NotFoundException(`Documento '${id}' não encontrado`);
    for (const anexo of doc.get('anexos') ?? []) {
      if (anexo.url) deleteUploadedFile(anexo.url as string);
    }
  }

  async updateEstado(id: string, estado: string): Promise<DocumentDocument> {
    const doc = await this.docModel
      .findByIdAndUpdate(
        id,
        { $set: { estado, atualizadoEm: new Date().toISOString() } },
        { new: true },
      )
      .exec();
    if (!doc) throw new NotFoundException(`Documento '${id}' não encontrado`);
    return doc;
  }

  // ── Gestão de anexos ───────────────────────────────────────────────────────

  async addAnexo(
    docId: string,
    file: Express.Multer.File,
    meta: AnexoMetaDto,
    userId: string,
  ): Promise<DocumentDocument> {
    const now = new Date().toISOString();
    const ext = extname(file.originalname).replace('.', '').toLowerCase()
      || file.mimetype.split('/')[1]
      || 'bin';

    const anexo = {
      id: uuidv4(),
      nome: meta.nome ?? file.originalname,
      versao: meta.versao ?? 1,
      estado: meta.estado ?? 'check_in',
      tamanho: file.size,
      formato: ext,
      url: `/uploads/documents/${file.filename}`,
      adicionadoPor: userId,
      criadoEm: now,
      observacao: meta.observacao,
    };

    const doc = await this.docModel
      .findByIdAndUpdate(
        docId,
        {
          $push: { anexos: anexo },
          $set: { atualizadoEm: now },
        },
        { new: true },
      )
      .exec();

    if (!doc) throw new NotFoundException(`Documento '${docId}' não encontrado`);
    return doc;
  }

  async removeAnexo(docId: string, anexoId: string): Promise<DocumentDocument> {
    const existing = await this.docModel.findById(docId).exec();
    if (!existing) throw new NotFoundException(`Documento '${docId}' não encontrado`);

    const anexo = (existing.get('anexos') as Array<{ id: string; url?: string }>)
      .find((a) => a.id === anexoId);

    const doc = await this.docModel
      .findByIdAndUpdate(
        docId,
        {
          $pull: { anexos: { id: anexoId } },
          $set: { atualizadoEm: new Date().toISOString() },
        },
        { new: true },
      )
      .exec();

    if (!doc) throw new NotFoundException(`Documento '${docId}' não encontrado`);

    if (anexo?.url) deleteUploadedFile(anexo.url);
    return doc;
  }
}
