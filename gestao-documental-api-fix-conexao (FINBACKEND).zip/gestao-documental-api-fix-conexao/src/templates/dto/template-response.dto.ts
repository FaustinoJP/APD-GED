import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BaseResponseDto } from '../../common/dto/base.dto';

class SignatureZoneResponseDto {
  @Expose() @ApiProperty() id: string;
  @Expose() @ApiProperty() label: string;
  @Expose() @ApiProperty() x: number;
  @Expose() @ApiProperty() y: number;
  @Expose() @ApiProperty() width: number;
  @Expose() @ApiProperty() height: number;
  @Expose() @ApiProperty() obrigatoria: boolean;
  @Expose() @ApiProperty({ required: false }) assignedRole?: string;
}

class WatermarkConfigResponseDto {
  @Expose() @ApiProperty() incluirNomeUtilizador: boolean;
  @Expose() @ApiProperty() incluirDataHora: boolean;
  @Expose() @ApiProperty() incluirEstadoDocumento: boolean;
  @Expose() @ApiProperty() opacidade: number;
  @Expose() @ApiProperty({ required: false }) texto?: string;
}

export class TemplateResponseDto extends BaseResponseDto {
  @ApiProperty() @Expose() nome: string;
  @ApiProperty({ required: false }) @Expose() descricao?: string;
  @ApiProperty({ required: false }) @Expose() documentTypeId?: string;
  @ApiProperty() @Expose() htmlContent: string;
  @ApiProperty({ type: [String] }) @Expose() variaveis: string[];

  @ApiProperty({ type: [SignatureZoneResponseDto] })
  @Expose()
  @Type(() => SignatureZoneResponseDto)
  signatureZones: SignatureZoneResponseDto[];

  @ApiProperty({ type: WatermarkConfigResponseDto })
  @Expose()
  @Type(() => WatermarkConfigResponseDto)
  watermark: WatermarkConfigResponseDto;

  @ApiProperty() @Expose() versao: number;
  @ApiProperty() @Expose() ativo: boolean;
  @ApiProperty() @Expose() criadoEm: string;

  constructor(partial: Partial<TemplateResponseDto>) {
    super(partial);
    Object.assign(this, partial);
  }
}
