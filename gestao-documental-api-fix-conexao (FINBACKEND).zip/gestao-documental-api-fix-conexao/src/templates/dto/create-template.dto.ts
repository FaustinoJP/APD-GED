import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray, IsBoolean, IsNumber, IsOptional, IsString, ValidateNested,
} from 'class-validator';

class SignatureZoneDto {
  @ApiProperty() @IsString() id: string;
  @ApiProperty() @IsString() label: string;
  @ApiProperty() @IsNumber() x: number;
  @ApiProperty() @IsNumber() y: number;
  @ApiProperty() @IsNumber() width: number;
  @ApiProperty() @IsNumber() height: number;
  @ApiProperty({ default: false }) @IsBoolean() obrigatoria: boolean;
  @ApiProperty({ required: false }) @IsOptional() @IsString() assignedRole?: string;
}

class WatermarkConfigDto {
  @ApiProperty({ default: false }) @IsBoolean() incluirNomeUtilizador: boolean;
  @ApiProperty({ default: false }) @IsBoolean() incluirDataHora: boolean;
  @ApiProperty({ default: false }) @IsBoolean() incluirEstadoDocumento: boolean;
  @ApiProperty({ default: 0.3 }) @IsNumber() opacidade: number;
  @ApiProperty({ required: false }) @IsOptional() @IsString() texto?: string;
}

export class CreateTemplateDto {
  @ApiProperty({ required: false }) @IsOptional() @IsString() id?: string;

  @ApiProperty() @IsString() nome: string;

  @ApiProperty({ required: false }) @IsOptional() @IsString() descricao?: string;

  @ApiProperty({ required: false }) @IsOptional() @IsString() documentTypeId?: string;

  @ApiProperty({ description: 'HTML com variáveis {{placeholder}}' })
  @IsString()
  htmlContent: string;

  @ApiProperty({ type: [String], default: [] })
  @IsArray()
  @IsString({ each: true })
  variaveis: string[];

  @ApiProperty({ type: [SignatureZoneDto], default: [] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => SignatureZoneDto)
  signatureZones: SignatureZoneDto[];

  @ApiProperty({ type: WatermarkConfigDto })
  @ValidateNested()
  @Type(() => WatermarkConfigDto)
  watermark: WatermarkConfigDto;

  @ApiProperty({ required: false, default: true })
  @IsOptional()
  @IsBoolean()
  ativo?: boolean;
}
