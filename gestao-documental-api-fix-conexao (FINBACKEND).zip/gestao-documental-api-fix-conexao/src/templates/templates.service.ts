import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import { DocumentTemplate, DocumentTemplateDocument } from './schemas/template.schema';
import { CreateTemplateDto } from './dto/create-template.dto';
import { PartialType } from '@nestjs/swagger';

class UpdateTemplateDto extends PartialType(CreateTemplateDto) {}

@Injectable()
export class TemplatesService {
  constructor(
    @InjectModel(DocumentTemplate.name)
    private readonly model: Model<DocumentTemplateDocument>,
  ) {}

  async create(dto: CreateTemplateDto): Promise<DocumentTemplateDocument> {
    const tpl = new this.model({
      _id: dto.id ?? uuidv4(),
      ...dto,
      versao: 1,
      ativo: dto.ativo ?? true,
      criadoEm: new Date().toISOString(),
    });
    return tpl.save();
  }

  async findAll(apenasAtivos = false): Promise<DocumentTemplateDocument[]> {
    const filter = apenasAtivos ? { ativo: true } : {};
    return this.model.find(filter).sort({ nome: 1 }).exec();
  }

  async findById(id: string): Promise<DocumentTemplateDocument> {
    const doc = await this.model.findById(id).exec();
    if (!doc) throw new NotFoundException('Template não encontrado');
    return doc;
  }

  async update(id: string, dto: UpdateTemplateDto): Promise<DocumentTemplateDocument> {
    const existing = await this.findById(id);
    // Incrementa versão sempre que o conteúdo HTML muda
    const versaoBump = dto.htmlContent && dto.htmlContent !== existing.htmlContent
      ? { versao: existing.versao + 1 }
      : {};
    const updated = await this.model
      .findByIdAndUpdate(id, { $set: { ...dto, ...versaoBump } }, { new: true })
      .exec();
    return updated!;
  }

  async remove(id: string): Promise<void> {
    const doc = await this.findById(id);
    await this.model.findByIdAndDelete(doc._id).exec();
  }
}
