import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

// ─── SignatureZone sub-schema ─────────────────────────────────────────────────
@Schema({ _id: false })
export class SignatureZone {
  @Prop({ required: true }) id: string;
  @Prop({ required: true }) label: string;
  @Prop({ required: true }) x: number;
  @Prop({ required: true }) y: number;
  @Prop({ required: true }) width: number;
  @Prop({ required: true }) height: number;
  @Prop({ default: false }) obrigatoria: boolean;
  @Prop() assignedRole?: string;
}
export const SignatureZoneSchema = SchemaFactory.createForClass(SignatureZone);

// ─── WatermarkConfig sub-schema ───────────────────────────────────────────────
@Schema({ _id: false })
export class WatermarkConfig {
  @Prop({ default: false }) incluirNomeUtilizador: boolean;
  @Prop({ default: false }) incluirDataHora: boolean;
  @Prop({ default: false }) incluirEstadoDocumento: boolean;
  @Prop({ default: 0.3 }) opacidade: number;
  @Prop() texto?: string;
}
export const WatermarkConfigSchema = SchemaFactory.createForClass(WatermarkConfig);

// ─── DocumentTemplate schema ──────────────────────────────────────────────────
export type DocumentTemplateDocument = HydratedDocument<DocumentTemplate> & { _id: string };

@Schema({ collection: 'templates', timestamps: false })
export class DocumentTemplate {
  @Prop({ type: String, default: () => uuidv4() })
  _id: string;

  @Prop({ required: true, trim: true })
  nome: string;

  @Prop()
  descricao?: string;

  @Prop()
  documentTypeId?: string;

  /** Conteúdo HTML com variáveis {{placeholder}} */
  @Prop({ required: true })
  htmlContent: string;

  @Prop({ type: [String], default: [] })
  variaveis: string[];

  @Prop({ type: [SignatureZoneSchema], default: [] })
  signatureZones: SignatureZone[];

  @Prop({ type: WatermarkConfigSchema, default: () => ({}) })
  watermark: WatermarkConfig;

  @Prop({ default: 1 })
  versao: number;

  @Prop({ default: true })
  ativo: boolean;

  @Prop({ required: true })
  criadoEm: string;
}

export const DocumentTemplateSchema = SchemaFactory.createForClass(DocumentTemplate);

DocumentTemplateSchema.index({ documentTypeId: 1 });
DocumentTemplateSchema.index({ ativo: 1 });
