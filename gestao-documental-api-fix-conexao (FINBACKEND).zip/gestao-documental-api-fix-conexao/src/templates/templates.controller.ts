import {
  Body, Controller, Delete, Get, Param, Patch, Post, Query,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiQuery, ApiTags } from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';
import { TemplatesService } from './templates.service';
import { CreateTemplateDto } from './dto/create-template.dto';
import { TemplateResponseDto } from './dto/template-response.dto';
import { PartialType } from '@nestjs/swagger';
import { RequirePermissions } from '../auth/decorators/require-permissions.decorator';

class UpdateTemplateDto extends PartialType(CreateTemplateDto) {}

@ApiTags('templates')
@ApiBearerAuth()
@Controller('templates')
export class TemplatesController {
  constructor(private readonly service: TemplatesService) {}

  @Post()
  @RequirePermissions('config.templates.manage')
  @ApiOperation({ summary: 'Criar template de documento' })
  async create(@Body() dto: CreateTemplateDto): Promise<TemplateResponseDto> {
    const doc = await this.service.create(dto);
    return plainToInstance(TemplateResponseDto, doc.toJSON(), {
      excludeExtraneousValues: true,
    });
  }

  @Get()
  @ApiOperation({ summary: 'Listar templates' })
  @ApiQuery({ name: 'ativo', required: false, type: Boolean })
  async findAll(
    @Query('ativo') ativo?: string,
  ): Promise<TemplateResponseDto[]> {
    const docs = await this.service.findAll(ativo === 'true');
    return docs.map((d) =>
      plainToInstance(TemplateResponseDto, d.toJSON(), {
        excludeExtraneousValues: true,
      }),
    );
  }

  @Get(':id')
  @ApiOperation({ summary: 'Obter template por ID' })
  async findOne(@Param('id') id: string): Promise<TemplateResponseDto> {
    const doc = await this.service.findById(id);
    return plainToInstance(TemplateResponseDto, doc.toJSON(), {
      excludeExtraneousValues: true,
    });
  }

  @Patch(':id')
  @RequirePermissions('config.templates.manage')
  @ApiOperation({ summary: 'Actualizar template (incrementa versão se HTML muda)' })
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateTemplateDto,
  ): Promise<TemplateResponseDto> {
    const doc = await this.service.update(id, dto);
    return plainToInstance(TemplateResponseDto, doc.toJSON(), {
      excludeExtraneousValues: true,
    });
  }

  @Delete(':id')
  @RequirePermissions('config.templates.manage')
  @ApiOperation({ summary: 'Remover template' })
  async remove(@Param('id') id: string): Promise<void> {
    await this.service.remove(id);
  }
}
