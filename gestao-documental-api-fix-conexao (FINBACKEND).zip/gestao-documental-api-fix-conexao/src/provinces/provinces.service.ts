import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Province, ProvinceDocument } from './schemas/province.schema';

@Injectable()
export class ProvincesService {
  constructor(
    @InjectModel(Province.name)
    private readonly model: Model<ProvinceDocument>,
  ) {}

  async findAll(): Promise<ProvinceDocument[]> {
    return this.model.find().sort({ ordem: 1, nome: 1 }).exec();
  }
}
