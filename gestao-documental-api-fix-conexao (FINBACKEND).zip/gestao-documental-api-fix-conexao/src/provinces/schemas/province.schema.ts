import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type ProvinceDocument = HydratedDocument<Province> & { _id: string };

@Schema({ collection: 'provinces', timestamps: false })
export class Province {
  @Prop({ type: String, required: true })
  _id: string;

  @Prop({ required: true, trim: true })
  nome: string;

  @Prop({ required: true, trim: true })
  slug: string;

  @Prop({ default: 0 })
  ordem: number;
}

export const ProvinceSchema = SchemaFactory.createForClass(Province);
ProvinceSchema.index({ slug: 1 }, { unique: true });
