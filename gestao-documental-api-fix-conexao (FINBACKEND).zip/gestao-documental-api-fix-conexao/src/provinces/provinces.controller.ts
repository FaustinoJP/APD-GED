import { Controller, Get } from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Public } from '../auth/decorators/public.decorator';
import { ProvincesService } from './provinces.service';

@ApiTags('provinces')
@Controller('provinces')
export class ProvincesController {
  constructor(private readonly service: ProvincesService) {}

  @Public()
  @Get()
  @ApiOperation({ summary: 'Listar províncias de Angola (rota pública)' })
  @ApiResponse({ status: 200, description: 'Lista ordenada das 21 províncias' })
  async findAll() {
    const docs = await this.service.findAll();
    return docs.map((d) => ({
      id: d._id,
      nome: d.nome,
      slug: d.slug,
    }));
  }
}
