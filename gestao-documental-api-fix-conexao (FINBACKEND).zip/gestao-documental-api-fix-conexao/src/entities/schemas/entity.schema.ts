import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

export type EntityDocument = HydratedDocument<Entity> & { _id: string };

@Schema({ collection: 'entities', timestamps: false })
export class Entity {
  @Prop({ type: String, default: () => uuidv4() })
  _id: string;

  @Prop({ required: true, trim: true })
  nome: string;

  @Prop({ required: true, enum: ['cliente', 'fornecedor', 'parceiro', 'orgao', 'outro'] })
  tipo: string;

  @Prop() email?: string;
  @Prop() telefone?: string;
  @Prop() endereco?: string;
  @Prop() regiao?: string;
  @Prop() localizacao?: string;

  @Prop({ required: true })
  criadoEm: string;
}

export const EntitySchema = SchemaFactory.createForClass(Entity);
