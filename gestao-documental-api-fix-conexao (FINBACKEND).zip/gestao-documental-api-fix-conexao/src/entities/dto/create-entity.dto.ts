import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';

export class CreateEntityDto {
  @ApiProperty({ required: false }) @IsOptional() @IsString() id?: string;

  @ApiProperty({ example: 'TecnoServ Angola Lda' })
  @IsString()
  nome: string;

  @ApiProperty({ enum: ['cliente', 'fornecedor', 'parceiro', 'orgao', 'outro'] })
  @IsEnum(['cliente', 'fornecedor', 'parceiro', 'orgao', 'outro'])
  tipo: string;

  @ApiProperty({ required: false }) @IsOptional() @IsString() email?: string;
  @ApiProperty({ required: false }) @IsOptional() @IsString() telefone?: string;
  @ApiProperty({ required: false }) @IsOptional() @IsString() endereco?: string;
  @ApiProperty({ required: false }) @IsOptional() @IsString() regiao?: string;
  @ApiProperty({ required: false }) @IsOptional() @IsString() localizacao?: string;

  @ApiProperty({ required: false, description: 'Se omitido, o backend define automaticamente' })
  @IsOptional()
  @IsString()
  criadoEm?: string;
}
