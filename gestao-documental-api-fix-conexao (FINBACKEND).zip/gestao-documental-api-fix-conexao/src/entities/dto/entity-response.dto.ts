import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { BaseResponseDto } from '../../common/dto/base.dto';

export class EntityResponseDto extends BaseResponseDto {
  @ApiProperty() @Expose() nome: string;
  @ApiProperty({ enum: ['cliente', 'fornecedor', 'parceiro', 'orgao', 'outro'] }) @Expose() tipo: string;
  @ApiProperty({ required: false }) @Expose() email?: string;
  @ApiProperty({ required: false }) @Expose() telefone?: string;
  @ApiProperty({ required: false }) @Expose() endereco?: string;
  @ApiProperty({ required: false }) @Expose() regiao?: string;
  @ApiProperty({ required: false }) @Expose() localizacao?: string;
  @ApiProperty() @Expose() criadoEm: string;
}
