import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import { Entity, EntityDocument } from './schemas/entity.schema';
import { CreateEntityDto } from './dto/create-entity.dto';
import { UpdateEntityDto } from './dto/update-entity.dto';

@Injectable()
export class EntitiesService {
  constructor(
    @InjectModel(Entity.name) private readonly model: Model<EntityDocument>,
  ) {}

  async findAll(): Promise<EntityDocument[]> {
    return this.model.find().exec();
  }

  async findById(id: string): Promise<EntityDocument | null> {
    return this.model.findById(id).exec();
  }

  async create(dto: CreateEntityDto): Promise<EntityDocument> {
    const doc = new this.model({
      _id: dto.id ?? uuidv4(),
      nome: dto.nome,
      tipo: dto.tipo,
      email: dto.email,
      telefone: dto.telefone,
      endereco: dto.endereco,
      regiao: dto.regiao,
      localizacao: dto.localizacao,
      criadoEm: dto.criadoEm ?? new Date().toISOString(),
    });
    return doc.save();
  }

  async update(id: string, dto: UpdateEntityDto): Promise<EntityDocument> {
    const doc = await this.model
      .findByIdAndUpdate(id, { $set: dto }, { new: true, runValidators: true })
      .exec();
    if (!doc) throw new NotFoundException(`Entidade '${id}' não encontrada`);
    return doc;
  }

  async remove(id: string): Promise<void> {
    const result = await this.model.findByIdAndDelete(id).exec();
    if (!result) throw new NotFoundException(`Entidade '${id}' não encontrada`);
  }
}
