import {
  Body, Controller, Delete, Get, HttpCode, HttpStatus,
  NotFoundException, Param, Patch, Post,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';
import { RequirePermissions } from '../auth/decorators/require-permissions.decorator';
import { CreateEntityDto } from './dto/create-entity.dto';
import { EntityResponseDto } from './dto/entity-response.dto';
import { UpdateEntityDto } from './dto/update-entity.dto';
import { EntitiesService } from './entities.service';

@ApiTags('entities')
@ApiBearerAuth('access-token')
@Controller('entities')
export class EntitiesController {
  constructor(private readonly service: EntitiesService) {}

  private toDto(e: object): EntityResponseDto {
    return plainToInstance(EntityResponseDto, e, { excludeExtraneousValues: true });
  }

  @Get()
  @ApiOperation({ summary: 'Listar todas as entidades' })
  @ApiResponse({ status: 200, type: [EntityResponseDto] })
  async findAll(): Promise<EntityResponseDto[]> {
    return (await this.service.findAll()).map((e) => this.toDto(e.toJSON()));
  }

  @Get(':id')
  @ApiOperation({ summary: 'Obter entidade por ID' })
  @ApiResponse({ status: 200, type: EntityResponseDto })
  async findOne(@Param('id') id: string): Promise<EntityResponseDto> {
    const e = await this.service.findById(id);
    if (!e) throw new NotFoundException(`Entidade '${id}' não encontrada`);
    return this.toDto(e.toJSON());
  }

  @Post()
  @RequirePermissions('config.entities.manage')
  @ApiOperation({ summary: 'Criar entidade' })
  @ApiResponse({ status: 201, type: EntityResponseDto })
  async create(@Body() dto: CreateEntityDto): Promise<EntityResponseDto> {
    return this.toDto((await this.service.create(dto)).toJSON());
  }

  @Patch(':id')
  @RequirePermissions('config.entities.manage')
  @ApiOperation({ summary: 'Actualizar entidade' })
  @ApiResponse({ status: 200, type: EntityResponseDto })
  async update(@Param('id') id: string, @Body() dto: UpdateEntityDto): Promise<EntityResponseDto> {
    return this.toDto((await this.service.update(id, dto)).toJSON());
  }

  @Delete(':id')
  @RequirePermissions('config.entities.manage')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Eliminar entidade' })
  async remove(@Param('id') id: string): Promise<void> {
    await this.service.remove(id);
  }
}
