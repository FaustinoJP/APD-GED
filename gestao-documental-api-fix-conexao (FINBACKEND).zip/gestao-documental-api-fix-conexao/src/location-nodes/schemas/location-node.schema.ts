import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

export type LocationNodeDocument = HydratedDocument<LocationNode> & { _id: string };

// Referências a nivelId/parentId como string — NUNCA usar .populate() aqui.
// A hierarquia é resolvida em memória pelo frontend (tal como em Folder/buildFileTree).
@Schema({ collection: 'location_nodes', timestamps: false })
export class LocationNode {
  @Prop({ type: String, default: () => uuidv4() })
  _id: string;

  @Prop({ required: true, trim: true })
  nome: string;

  @Prop({ required: true })
  nivelId: string;

  @Prop()
  parentId?: string;

  @Prop({ required: true, default: 0 })
  ordem: number;

  @Prop({ required: true })
  criadoEm: string;
}

export const LocationNodeSchema = SchemaFactory.createForClass(LocationNode);
