import {
  Body, Controller, Delete, Get, HttpCode, HttpStatus,
  NotFoundException, Param, Patch, Post,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';
import { RequirePermissions } from '../auth/decorators/require-permissions.decorator';
import { CreateLocationNodeDto } from './dto/create-location-node.dto';
import { LocationNodeResponseDto } from './dto/location-node-response.dto';
import { UpdateLocationNodeDto } from './dto/update-location-node.dto';
import { LocationNodesService } from './location-nodes.service';

@ApiTags('location-nodes')
@ApiBearerAuth('access-token')
@Controller('location-nodes')
export class LocationNodesController {
  constructor(private readonly service: LocationNodesService) {}

  private toDto(n: object): LocationNodeResponseDto {
    return plainToInstance(LocationNodeResponseDto, n, { excludeExtraneousValues: true });
  }

  @Get()
  @ApiOperation({ summary: 'Listar todos os nós da árvore de localização física' })
  @ApiResponse({ status: 200, type: [LocationNodeResponseDto] })
  async findAll(): Promise<LocationNodeResponseDto[]> {
    return (await this.service.findAll()).map((n) => this.toDto(n.toJSON()));
  }

  @Get(':id')
  @ApiOperation({ summary: 'Obter nó de localização por ID' })
  @ApiResponse({ status: 200, type: LocationNodeResponseDto })
  async findOne(@Param('id') id: string): Promise<LocationNodeResponseDto> {
    const n = await this.service.findById(id);
    if (!n) throw new NotFoundException(`Localização '${id}' não encontrada`);
    return this.toDto(n.toJSON());
  }

  @Post()
  @RequirePermissions('config.locations.manage')
  @ApiOperation({ summary: 'Criar nó de localização física' })
  @ApiResponse({ status: 201, type: LocationNodeResponseDto })
  async create(@Body() dto: CreateLocationNodeDto): Promise<LocationNodeResponseDto> {
    return this.toDto((await this.service.create(dto)).toJSON());
  }

  @Patch(':id')
  @RequirePermissions('config.locations.manage')
  @ApiOperation({ summary: 'Actualizar nó de localização física' })
  @ApiResponse({ status: 200, type: LocationNodeResponseDto })
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateLocationNodeDto,
  ): Promise<LocationNodeResponseDto> {
    return this.toDto((await this.service.update(id, dto)).toJSON());
  }

  @Delete(':id')
  @RequirePermissions('config.locations.manage')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Eliminar nó de localização física' })
  async remove(@Param('id') id: string): Promise<void> {
    await this.service.remove(id);
  }
}
