import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import { LocationNode, LocationNodeDocument } from './schemas/location-node.schema';
import { CreateLocationNodeDto } from './dto/create-location-node.dto';
import { UpdateLocationNodeDto } from './dto/update-location-node.dto';

@Injectable()
export class LocationNodesService {
  constructor(
    @InjectModel(LocationNode.name)
    private readonly model: Model<LocationNodeDocument>,
  ) {}

  async findAll(): Promise<LocationNodeDocument[]> {
    return this.model.find().exec();
  }

  async findById(id: string): Promise<LocationNodeDocument | null> {
    return this.model.findById(id).exec();
  }

  async create(dto: CreateLocationNodeDto): Promise<LocationNodeDocument> {
    const doc = new this.model({
      _id: dto.id ?? uuidv4(),
      nome: dto.nome,
      nivelId: dto.nivelId,
      parentId: dto.parentId,
      ordem: dto.ordem,
      criadoEm: dto.criadoEm ?? new Date().toISOString(),
    });
    return doc.save();
  }

  async update(id: string, dto: UpdateLocationNodeDto): Promise<LocationNodeDocument> {
    const doc = await this.model
      .findByIdAndUpdate(id, { $set: dto }, { new: true, runValidators: true })
      .exec();
    if (!doc) throw new NotFoundException(`Localização '${id}' não encontrada`);
    return doc;
  }

  async remove(id: string): Promise<void> {
    const result = await this.model.findByIdAndDelete(id).exec();
    if (!result) throw new NotFoundException(`Localização '${id}' não encontrada`);
  }
}
