import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { BaseResponseDto } from '../../common/dto/base.dto';

export class LocationNodeResponseDto extends BaseResponseDto {
  @ApiProperty() @Expose() nome: string;
  @ApiProperty() @Expose() nivelId: string;
  @ApiProperty({ required: false }) @Expose() parentId?: string;
  @ApiProperty() @Expose() ordem: number;
  @ApiProperty() @Expose() criadoEm: string;
}
