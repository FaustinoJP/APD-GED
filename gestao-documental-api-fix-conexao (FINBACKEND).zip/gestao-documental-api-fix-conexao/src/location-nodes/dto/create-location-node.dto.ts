import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsOptional, IsString } from 'class-validator';

export class CreateLocationNodeDto {
  @ApiProperty({ required: false }) @IsOptional() @IsString() id?: string;
  @ApiProperty({ example: 'Sala A' }) @IsString() nome: string;
  @ApiProperty({ description: 'ID do LocationLevel a que este nó pertence' })
  @IsString()
  nivelId: string;
  @ApiProperty({ required: false, description: 'ID do nó pai (self-reference)' })
  @IsOptional() @IsString() parentId?: string;
  @ApiProperty({ example: 0, description: 'Posição entre os irmãos' })
  @IsNumber()
  ordem: number;
  @ApiProperty({ required: false }) @IsOptional() @IsString() criadoEm?: string;
}
