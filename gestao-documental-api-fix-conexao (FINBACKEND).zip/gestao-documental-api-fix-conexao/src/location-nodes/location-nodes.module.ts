import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { LocationNode, LocationNodeSchema } from './schemas/location-node.schema';
import { LocationNodesService } from './location-nodes.service';
import { LocationNodesController } from './location-nodes.controller';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: LocationNode.name, schema: LocationNodeSchema }]),
  ],
  providers: [LocationNodesService],
  controllers: [LocationNodesController],
  exports: [LocationNodesService],
})
export class LocationNodesModule {}
