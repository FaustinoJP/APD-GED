import { Schema } from 'mongoose';

/**
 * Plugin global Mongoose: resolve o problema estrutural _id vs id.
 *
 * Registado uma única vez na connectionFactory do AppModule e aplicado
 * automaticamente a TODOS os schemas da aplicação, incluindo sub-schemas
 * embebidos (Attachment, Destinatario, CustomField, etc.).
 *
 * Comportamento garantido em cada documento Mongoose serializado:
 *   - Adiciona  `id`    como string alias de `_id`
 *   - Remove    `_id`   (o frontend nunca vê este campo)
 *   - Remove    `__v`   (versão interna do Mongoose, irrelevante para a API)
 *
 * A verificação `'_id' in ret` é necessária para sub-schemas declarados com
 * { _id: false } (ex: Destinatario, WatermarkConfig) — nesses casos o campo
 * não existe e não deve ser copiado.
 */
function applyTransform(schema: Schema): void {
  const transform = (
    _doc: unknown,
    ret: Record<string, unknown>,
  ): Record<string, unknown> => {
    if ('_id' in ret) {
      ret.id = String(ret._id);
      delete ret._id;
    }
    delete ret.__v;
    return ret;
  };

  schema.set('toJSON', { virtuals: true, transform });
  schema.set('toObject', { virtuals: true, transform });
}

export function mongooseIdPlugin(schema: Schema): void {
  // Aplica ao schema raiz
  applyTransform(schema);

  // Aplica recursivamente a todos os sub-schemas (arrays e objectos embebidos)
  schema.eachPath((_pathName, schemaType) => {
    const subSchema = (schemaType as { schema?: Schema }).schema;
    if (subSchema) {
      applyTransform(subSchema);

      // Terceiro nível (ex: signatureZones dentro de DocumentTemplate)
      subSchema.eachPath((_subPath, subSchemaType) => {
        const deepSchema = (subSchemaType as { schema?: Schema }).schema;
        if (deepSchema) {
          applyTransform(deepSchema);
        }
      });
    }
  });
}
