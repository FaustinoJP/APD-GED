import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
  Type,
} from '@nestjs/common';
import { plainToInstance } from 'class-transformer';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

/**
 * SerializeInterceptor — converte o objecto de resposta para uma instância
 * do DTO especificado, activando os decoradores @Exclude/@Expose do
 * class-transformer.
 *
 * Uso nos controllers:
 *   @UseInterceptors(new SerializeInterceptor(UserResponseDto))
 *
 * Desta forma, campos sensíveis decorados com @Exclude() (ex: senhaHash)
 * são sempre removidos antes de sair da API, independentemente da lógica
 * de negócio no service.
 *
 * O ClassSerializerInterceptor global no main.ts actua como fallback;
 * este interceptor permite controlo granular por endpoint ou controller.
 */
@Injectable()
export class SerializeInterceptor<T extends object>
  implements NestInterceptor
{
  constructor(private readonly dto: Type<T>) {}

  intercept(
    _context: ExecutionContext,
    next: CallHandler,
  ): Observable<unknown> {
    return next.handle().pipe(
      map((data: unknown) => {
        if (Array.isArray(data)) {
          return data.map((item) =>
            plainToInstance(this.dto, item, {
              excludeExtraneousValues: false,
              enableImplicitConversion: true,
            }),
          );
        }
        return plainToInstance(this.dto, data, {
          excludeExtraneousValues: false,
          enableImplicitConversion: true,
        });
      }),
    );
  }
}
