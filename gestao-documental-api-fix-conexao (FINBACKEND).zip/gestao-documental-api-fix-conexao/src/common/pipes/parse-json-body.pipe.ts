import { PipeTransform, Injectable, BadRequestException, Type } from '@nestjs/common';
import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';

@Injectable()
export class ParseJsonBodyPipe<T extends object> implements PipeTransform {
  constructor(private readonly cls: Type<T>) {}

  async transform(value: string): Promise<T> {
    let parsed: unknown;
    try {
      parsed = typeof value === 'string' ? JSON.parse(value) : value;
    } catch {
      throw new BadRequestException('O campo "data" deve ser JSON válido');
    }

    const instance = plainToInstance(this.cls, parsed, {
      enableImplicitConversion: true,
    });

    const errors = await validate(instance as object, {
      whitelist: true,
      forbidNonWhitelisted: true,
    });

    if (errors.length > 0) {
      const messages = errors.flatMap((e) => Object.values(e.constraints ?? {}));
      throw new BadRequestException(messages.join('; '));
    }

    return instance;
  }
}
