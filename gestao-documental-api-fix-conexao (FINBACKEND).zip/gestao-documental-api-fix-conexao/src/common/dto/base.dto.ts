import { ApiProperty } from '@nestjs/swagger';
import { Exclude, Expose } from 'class-transformer';
import { IsOptional, IsString } from 'class-validator';

/**
 * DTO base de resposta — todos os DTOs de resposta da API estendem esta classe.
 *
 * Garante que `id: string` está sempre presente e que o campo `_id` do MongoDB
 * nunca é exposto (o plugin mongoose-id.plugin.ts já faz a transformação, mas
 * esta classe actua como segunda linha de defesa ao nível do DTO).
 */
@Exclude()
export class BaseResponseDto {
  @ApiProperty({
    description: 'Identificador único do registo (UUID)',
    example: 'doc-ent-001',
  })
  @Expose()
  @IsString()
  id: string;

  constructor(partial: Partial<BaseResponseDto>) {
    Object.assign(this, partial);
  }
}

/**
 * DTO base de criação — usado em request bodies de POST.
 * O id é opcional: se não fornecido, o backend gera um UUID.
 * Compatível com o comportamento actual do createRepository() no frontend.
 */
export class BaseCreateDto {
  @ApiProperty({
    description: 'ID opcional. Se omitido, é gerado automaticamente. Aceita UUID v4 ou IDs legíveis (ex: doc-ent-001)',
    required: false,
    example: 'doc-ent-001',
  })
  @IsOptional()
  @IsString()
  id?: string;
}
