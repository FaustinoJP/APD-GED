import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

// Schema partilhado entre DocumentRecord e Circulation.
// { _id: false }: sub-documento sem _id próprio — o campo 'id' é referência
// a User, Entity ou grupo (futuro), guardada como string pura.
// NUNCA usar .populate() — o frontend resolve em memória.
@Schema({ _id: false })
export class Destinatario {
  @Prop({ required: true, enum: ['user', 'group', 'entity'] })
  tipo: string;

  @Prop({ required: true })
  id: string;
}

export const DestinatarioSchema = SchemaFactory.createForClass(Destinatario);
