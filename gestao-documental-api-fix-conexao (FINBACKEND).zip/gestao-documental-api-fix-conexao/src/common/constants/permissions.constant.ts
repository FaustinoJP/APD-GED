// Espelha exactamente o tipo Permission do frontend (src/types/index.ts)
// Qualquer alteração aqui deve ser reflectida no frontend e vice-versa.
export const PERMISSIONS = [
  'documents.create',
  'documents.read',
  'documents.update',
  'documents.delete',
  'documents.forward',
  'documents.sign',
  'documents.approve',
  'documents.giveOpinion',
  'documents.dispatch',
  'documents.defer',
  'documents.archive',
  'documents.export',
  'config.types.manage',
  'config.users.manage',
  'config.permissions.manage',
  'config.entities.manage',
  'config.templates.manage',
  'config.company.manage',
  'config.locations.manage',
  'audit.read',
  'exports.run',
  'files.manage',
  'notifications.read',
  'dashboard.view',
] as const;

export type Permission = (typeof PERMISSIONS)[number];
