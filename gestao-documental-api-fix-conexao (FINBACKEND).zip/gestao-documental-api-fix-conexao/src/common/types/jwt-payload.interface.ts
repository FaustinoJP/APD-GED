/**
 * Payload codificado no JWT de acesso.
 *
 * Inclui `permissions` para evitar lookup à BD em cada request:
 * o PermissionsGuard valida directamente contra este array.
 * Tradeoff: alterações de role só têm efeito no próximo login
 * (access token válido 15 min — aceitável para este domínio).
 */
export interface JwtPayload {
  sub: string;           // user._id (UUID string)
  email: string;
  roleId: string;
  permissions: string[]; // cópia das permissions do role no momento do login
  iat?: number;
  exp?: number;
}
