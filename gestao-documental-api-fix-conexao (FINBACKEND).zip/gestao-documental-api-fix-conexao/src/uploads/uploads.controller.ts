import {
  BadRequestException,
  Controller,
  Delete,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { extname, join } from 'path';
import { existsSync, unlinkSync } from 'fs';
import { multerConfig } from '../common/config/multer.config';

// UUID.ext — previne path traversal
const SAFE_FILENAME_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.[a-z0-9]{1,10}$/i;

interface UploadResult {
  id: string;
  url: string;
  nome: string;
  tamanho: number;
  formato: string;
}

@ApiTags('uploads')
@ApiBearerAuth('access-token')
@Controller('uploads')
export class UploadsController {
  @Post()
  @UseInterceptors(FileInterceptor('file', multerConfig))
  @ApiConsumes('multipart/form-data')
  @ApiOperation({
    summary: 'Pre-upload de ficheiro temporário',
    description:
      'Carrega o ficheiro para disco e devolve os metadados. ' +
      'Se o registo não for concluído, chamar DELETE /uploads/:id para limpeza.',
  })
  @ApiBody({
    schema: {
      type: 'object',
      properties: { file: { type: 'string', format: 'binary' } },
      required: ['file'],
    },
  })
  @ApiResponse({ status: 201, description: 'Ficheiro carregado com sucesso' })
  upload(@UploadedFile() file: Express.Multer.File): UploadResult {
    const ext = extname(file.originalname).replace('.', '').toLowerCase()
      || file.mimetype.split('/')[1]
      || 'bin';

    return {
      id: file.filename,                       // UUID.ext — usado para DELETE
      url: `/uploads/documents/${file.filename}`,
      nome: file.originalname,
      tamanho: file.size,
      formato: ext,
    };
  }

  @Delete(':filename')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({
    summary: 'Eliminar ficheiro temporário (rollback)',
    description: 'Chamado quando o registo é abandonado para limpar uploads órfãos.',
  })
  @ApiResponse({ status: 204 })
  deleteUpload(@Param('filename') filename: string): void {
    if (!SAFE_FILENAME_RE.test(filename)) {
      throw new BadRequestException('Nome de ficheiro inválido');
    }
    const fullPath = join(process.cwd(), 'uploads', 'documents', filename);
    if (existsSync(fullPath)) unlinkSync(fullPath);
  }
}
