import {
  Body, Controller, Delete, Get, HttpCode, HttpStatus,
  NotFoundException, Param, Patch, Post,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';
import { RequirePermissions } from '../auth/decorators/require-permissions.decorator';
import { CreateLocationLevelDto } from './dto/create-location-level.dto';
import { LocationLevelResponseDto } from './dto/location-level-response.dto';
import { UpdateLocationLevelDto } from './dto/update-location-level.dto';
import { LocationLevelsService } from './location-levels.service';

@ApiTags('location-levels')
@ApiBearerAuth('access-token')
@Controller('location-levels')
export class LocationLevelsController {
  constructor(private readonly service: LocationLevelsService) {}

  private toDto(l: object): LocationLevelResponseDto {
    return plainToInstance(LocationLevelResponseDto, l, { excludeExtraneousValues: true });
  }

  @Get()
  @ApiOperation({ summary: 'Listar níveis da hierarquia de localização física (ordenados)' })
  @ApiResponse({ status: 200, type: [LocationLevelResponseDto] })
  async findAll(): Promise<LocationLevelResponseDto[]> {
    return (await this.service.findAll()).map((l) => this.toDto(l.toJSON()));
  }

  @Get(':id')
  @ApiOperation({ summary: 'Obter nível de localização por ID' })
  @ApiResponse({ status: 200, type: LocationLevelResponseDto })
  async findOne(@Param('id') id: string): Promise<LocationLevelResponseDto> {
    const l = await this.service.findById(id);
    if (!l) throw new NotFoundException(`Nível de localização '${id}' não encontrado`);
    return this.toDto(l.toJSON());
  }

  @Post()
  @RequirePermissions('config.locations.manage')
  @ApiOperation({ summary: 'Criar nível de localização' })
  @ApiResponse({ status: 201, type: LocationLevelResponseDto })
  async create(@Body() dto: CreateLocationLevelDto): Promise<LocationLevelResponseDto> {
    return this.toDto((await this.service.create(dto)).toJSON());
  }

  @Patch(':id')
  @RequirePermissions('config.locations.manage')
  @ApiOperation({ summary: 'Actualizar nível de localização' })
  @ApiResponse({ status: 200, type: LocationLevelResponseDto })
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateLocationLevelDto,
  ): Promise<LocationLevelResponseDto> {
    return this.toDto((await this.service.update(id, dto)).toJSON());
  }

  @Delete(':id')
  @RequirePermissions('config.locations.manage')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Eliminar nível de localização' })
  async remove(@Param('id') id: string): Promise<void> {
    await this.service.remove(id);
  }
}
