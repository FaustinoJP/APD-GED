import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import { LocationLevel, LocationLevelDocument } from './schemas/location-level.schema';
import { CreateLocationLevelDto } from './dto/create-location-level.dto';
import { UpdateLocationLevelDto } from './dto/update-location-level.dto';

@Injectable()
export class LocationLevelsService {
  constructor(
    @InjectModel(LocationLevel.name)
    private readonly model: Model<LocationLevelDocument>,
  ) {}

  async findAll(): Promise<LocationLevelDocument[]> {
    return this.model.find().sort({ ordem: 1 }).exec();
  }

  async findById(id: string): Promise<LocationLevelDocument | null> {
    return this.model.findById(id).exec();
  }

  async create(dto: CreateLocationLevelDto): Promise<LocationLevelDocument> {
    const doc = new this.model({
      _id: dto.id ?? uuidv4(),
      nome: dto.nome,
      ordem: dto.ordem,
    });
    return doc.save();
  }

  async update(id: string, dto: UpdateLocationLevelDto): Promise<LocationLevelDocument> {
    const doc = await this.model
      .findByIdAndUpdate(id, { $set: dto }, { new: true, runValidators: true })
      .exec();
    if (!doc) throw new NotFoundException(`Nível de localização '${id}' não encontrado`);
    return doc;
  }

  async remove(id: string): Promise<void> {
    const result = await this.model.findByIdAndDelete(id).exec();
    if (!result) throw new NotFoundException(`Nível de localização '${id}' não encontrado`);
  }
}
