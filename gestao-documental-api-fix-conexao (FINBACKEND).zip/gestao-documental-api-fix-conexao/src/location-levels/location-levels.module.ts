import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { LocationLevel, LocationLevelSchema } from './schemas/location-level.schema';
import { LocationLevelsService } from './location-levels.service';
import { LocationLevelsController } from './location-levels.controller';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: LocationLevel.name, schema: LocationLevelSchema }]),
  ],
  providers: [LocationLevelsService],
  controllers: [LocationLevelsController],
  exports: [LocationLevelsService],
})
export class LocationLevelsModule {}
