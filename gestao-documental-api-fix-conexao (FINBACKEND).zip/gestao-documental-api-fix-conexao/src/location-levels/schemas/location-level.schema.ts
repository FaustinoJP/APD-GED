import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

export type LocationLevelDocument = HydratedDocument<LocationLevel> & { _id: string };

@Schema({ collection: 'location_levels', timestamps: false })
export class LocationLevel {
  @Prop({ type: String, default: () => uuidv4() })
  _id: string;

  @Prop({ required: true, trim: true })
  nome: string;

  @Prop({ required: true, default: 0 })
  ordem: number;
}

export const LocationLevelSchema = SchemaFactory.createForClass(LocationLevel);
