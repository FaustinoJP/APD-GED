import { PartialType } from '@nestjs/swagger';
import { CreateLocationLevelDto } from './create-location-level.dto';

export class UpdateLocationLevelDto extends PartialType(CreateLocationLevelDto) {}
