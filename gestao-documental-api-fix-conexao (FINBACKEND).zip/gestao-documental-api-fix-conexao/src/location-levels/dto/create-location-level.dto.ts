import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsOptional, IsString } from 'class-validator';

export class CreateLocationLevelDto {
  @ApiProperty({ required: false }) @IsOptional() @IsString() id?: string;
  @ApiProperty({ example: 'Sala' }) @IsString() nome: string;
  @ApiProperty({ example: 0, description: 'Posição do nível na hierarquia (0 = topo)' })
  @IsNumber()
  ordem: number;
}
