export const HTML_CONTRATO_TRABALHO = `<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Times New Roman',Times,serif;font-size:12pt;color:#1a1a2e;background:#fff}
.page{width:794px;min-height:1123px;padding:56px 70px;margin:0 auto;position:relative}
.header{display:flex;align-items:flex-start;gap:20px;margin-bottom:28px;padding-bottom:18px;border-bottom:3px solid #1e3a5f}
.logo img{max-width:80px;max-height:80px;object-fit:contain;border:1px solid #e2e8f0}
.company-info{flex:1}
.company-name{font-size:17pt;font-weight:bold;color:#1e3a5f}
.company-details{font-size:9pt;color:#4a5568;margin-top:5px;line-height:1.7}
.doc-ref{text-align:right;min-width:140px}
.doc-ref .nr{font-size:10pt;font-weight:bold;color:#1e3a5f}
.doc-ref .dt{font-size:9pt;color:#64748b;margin-top:4px}
.title-wrap{text-align:center;margin:28px 0}
.title{font-size:15pt;font-weight:bold;letter-spacing:3px;text-transform:uppercase;color:#1e3a5f;border-bottom:2px solid #1e3a5f;padding-bottom:6px;display:inline-block}
.clause{margin-bottom:17px}
.clause-title{font-weight:bold;font-size:11pt;color:#1e3a5f;margin-bottom:5px}
.clause p{text-align:justify;line-height:1.85;font-size:10.5pt}
.date-line{text-align:center;margin-top:22px;font-size:10pt}
.sigs{margin-top:56px;display:flex;justify-content:space-between}
.sig-col{width:42%;text-align:center}
.sig-line{border-top:1px solid #1a1a2e;padding-top:8px;margin-top:56px}
.sig-label{font-size:9pt;font-weight:bold;color:#1e3a5f}
.sig-name{font-size:9pt;color:#4a5568;margin-top:3px}
.footer{margin-top:36px;padding-top:10px;border-top:1px solid #e2e8f0;text-align:center;font-size:8pt;color:#94a3b8}
</style></head>
<body><div class="page">
<div class="header">
  <div class="logo"><img src="{{empresa_logo}}" alt="Logo" onerror="this.style.display='none'"/></div>
  <div class="company-info">
    <div class="company-name">{{empresa_nome}}</div>
    <div class="company-details">NIF: {{empresa_nif}}<br>{{empresa_endereco}}</div>
  </div>
  <div class="doc-ref">
    <div class="nr">Ref.: {{nr_documento}}</div>
    <div class="dt">Data: {{data_documento}}</div>
  </div>
</div>
<div class="title-wrap"><div class="title">CONTRATO DE TRABALHO</div></div>
<div class="clause">
  <div class="clause-title">CLÁUSULA 1.ª — IDENTIFICAÇÃO DAS PARTES</div>
  <p><strong>Empregador:</strong> {{empresa_nome}}, com NIF n.º {{empresa_nif}}, sede em {{empresa_endereco}}.<br><br>
  <strong>Trabalhador:</strong> {{destinatario_nome}}.</p>
</div>
<div class="clause">
  <div class="clause-title">CLÁUSULA 2.ª — OBJECTO</div>
  <p>Prestação de actividade profissional nos termos e condições estabelecidos, em conformidade com as instruções do Empregador.</p>
</div>
<div class="clause">
  <div class="clause-title">CLÁUSULA 3.ª — TIPO DE CONTRATO</div>
  <p>Contrato celebrado a título de <strong>{{tipo_contrato}}</strong>, nos termos da legislação laboral angolana.</p>
</div>
<div class="clause">
  <div class="clause-title">CLÁUSULA 4.ª — REMUNERAÇÃO</div>
  <p>Remuneração mensal ilíquida de <strong>{{valor}} AOA</strong>, sujeita aos descontos legais aplicáveis.</p>
</div>
<div class="clause">
  <div class="clause-title">CLÁUSULA 5.ª — LEGISLAÇÃO APLICÁVEL</div>
  <p>Rege-se pela Lei Geral do Trabalho de Angola (Lei n.º 7/15, de 15 de Junho).</p>
</div>
<p class="date-line">{{empresa_endereco}}, {{data_documento}}</p>
<div class="sigs">
  <div class="sig-col"><div class="sig-line">
    <div class="sig-label">O Empregador</div>
    <div class="sig-name">{{utilizador_nome}}</div>
  </div></div>
  <div class="sig-col"><div class="sig-line">
    <div class="sig-label">O Trabalhador</div>
    <div class="sig-name">{{destinatario_nome}}</div>
  </div></div>
</div>
<div class="footer">{{empresa_nome}} — NIF: {{empresa_nif}} — Impresso em: {{data_hora_impressao}}</div>
</div></body></html>`;

export const HTML_FOLHA_SALARIAL = `<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:Arial,Helvetica,sans-serif;font-size:11pt;color:#1a1a2e;background:#fff}
.page{width:794px;min-height:1123px;padding:50px 60px;margin:0 auto}
.header{display:flex;align-items:center;gap:20px;margin-bottom:18px;padding-bottom:14px;border-bottom:3px solid #1e3a5f}
.company-name{font-size:16pt;font-weight:bold;color:#1e3a5f}
.company-details{font-size:9pt;color:#4a5568;margin-top:3px}
.title-box{text-align:center;margin:18px 0;background:#1e3a5f;color:#fff;padding:12px;border-radius:4px}
.title-box .title{font-size:13pt;font-weight:bold;letter-spacing:2px}
table{width:100%;border-collapse:collapse;font-size:10pt}
th{background:#1e3a5f;color:#fff;padding:8px 12px;text-align:left}
td{padding:7px 12px;border-bottom:1px solid #e2e8f0}
.val{text-align:right;font-weight:500}
.total-row td{border-top:2px solid #1e3a5f;font-weight:bold;background:#f1f5f9}
.liquido td{background:#d1fae5;font-weight:bold}
.footer{margin-top:36px;padding-top:10px;border-top:1px solid #e2e8f0;text-align:center;font-size:8pt;color:#94a3b8}
</style></head>
<body><div class="page">
<div class="header">
  <div style="flex:1">
    <div class="company-name">{{empresa_nome}}</div>
    <div class="company-details">NIF: {{empresa_nif}} | {{empresa_endereco}}</div>
  </div>
  <div style="text-align:right">
    <div style="font-size:9pt;font-weight:bold;color:#1e3a5f">Ref: {{nr_documento}}</div>
    <div style="font-size:9pt;color:#64748b">{{data_documento}}</div>
  </div>
</div>
<div class="title-box">
  <div class="title">RECIBO DE REMUNERAÇÃO</div>
  <div style="font-size:10pt;margin-top:4px;opacity:.85">{{mes_referencia}}</div>
</div>
<table>
  <thead><tr><th style="width:60%">Descrição</th><th style="width:40%;text-align:right">Valor (AOA)</th></tr></thead>
  <tbody>
    <tr><td>Salário Base</td><td class="val">{{salario_base}}</td></tr>
    <tr><td>Subsídio de Alimentação</td><td class="val">{{subsidios}}</td></tr>
    <tr style="color:#c0392b"><td>IRT</td><td class="val">- {{descontos}}</td></tr>
  </tbody>
  <tfoot>
    <tr class="total-row"><td>TOTAL BRUTO</td><td class="val">{{total_bruto}} AOA</td></tr>
    <tr class="liquido"><td>LÍQUIDO A PAGAR</td><td class="val">{{liquido_pagar}} AOA</td></tr>
  </tfoot>
</table>
<div class="footer">{{empresa_nome}} — Impresso em: {{data_hora_impressao}} | Doc: {{nr_documento}}</div>
</div></body></html>`;

export const HTML_DECLARACAO_FISCAL = `<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:Arial,Helvetica,sans-serif;font-size:11pt;color:#1a1a2e;background:#fff}
.page{width:794px;min-height:1123px;padding:50px 60px;margin:0 auto}
.header{display:flex;align-items:flex-start;gap:20px;margin-bottom:18px;padding-bottom:14px;border-bottom:3px solid #c0392b}
.company-name{font-size:16pt;font-weight:bold;color:#c0392b}
.title-wrap{text-align:center;margin:20px 0}
.title{font-size:14pt;font-weight:bold;letter-spacing:3px;color:#c0392b;border-bottom:2px solid #c0392b;padding-bottom:6px;display:inline-block}
table{width:100%;border-collapse:collapse;font-size:10pt}
th{background:#c0392b;color:#fff;padding:8px 12px}
td{padding:7px 12px;border-bottom:1px solid #e2e8f0;text-align:center}
.total-row td{border-top:2px solid #c0392b;font-weight:bold;background:#fee2e2}
.sigs{margin-top:50px;display:flex;justify-content:space-around}
.sig-col{width:40%;text-align:center}
.sig-line{border-top:1px solid #1a1a2e;padding-top:8px;margin-top:50px}
.sig-label{font-weight:bold;font-size:9pt;color:#c0392b}
.footer{margin-top:36px;padding-top:10px;border-top:1px solid #e2e8f0;text-align:center;font-size:8pt;color:#94a3b8}
</style></head>
<body><div class="page">
<div class="header">
  <div style="flex:1">
    <div class="company-name">{{empresa_nome}}</div>
    <div style="font-size:9pt;color:#4a5568;margin-top:3px">NIF: {{empresa_nif}} | {{empresa_endereco}}</div>
  </div>
  <div style="text-align:right">
    <div style="font-size:9pt;font-weight:bold;color:#c0392b">Ref: {{nr_documento}}</div>
    <div style="font-size:9pt;color:#64748b">{{data_documento}}</div>
  </div>
</div>
<div class="title-wrap">
  <div class="title">DECLARAÇÃO FISCAL</div>
  <div style="font-size:10pt;color:#4a5568;margin-top:8px">Período: {{periodo}} | Tipo: {{tipo_imposto}}</div>
</div>
<table>
  <thead><tr>
    <th style="text-align:left">Tipo de Imposto</th>
    <th>Base Tributável (AOA)</th><th>Taxa (%)</th><th>Valor a Pagar (AOA)</th>
  </tr></thead>
  <tbody><tr>
    <td style="text-align:left">{{tipo_imposto}}</td>
    <td>{{base_tributavel}}</td><td>{{taxa}}</td><td><strong>{{valor_pagar}}</strong></td>
  </tr></tbody>
  <tfoot><tr class="total-row">
    <td colspan="3" style="text-align:right">TOTAL A PAGAR</td>
    <td>{{valor_pagar}} AOA</td>
  </tr></tfoot>
</table>
<div class="sigs">
  <div class="sig-col"><div class="sig-line">
    <div class="sig-label">O Declarante</div>
    <div style="font-size:9pt;color:#4a5568;margin-top:3px">{{utilizador_nome}}</div>
  </div></div>
  <div class="sig-col"><div class="sig-line">
    <div class="sig-label">Responsável Fiscal</div>
    <div style="font-size:9pt;color:#4a5568;margin-top:3px">{{remetente_nome}}</div>
  </div></div>
</div>
<div class="footer">{{empresa_nome}} — NIF: {{empresa_nif}} — Impresso em: {{data_hora_impressao}}</div>
</div></body></html>`;

export const HTML_CONTRATO_FORNECEDOR = `<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Times New Roman',Times,serif;font-size:12pt;color:#1a1a2e;background:#fff}
.page{width:794px;min-height:1123px;padding:56px 70px;margin:0 auto}
.header{display:flex;align-items:flex-start;gap:20px;margin-bottom:28px;padding-bottom:18px;border-bottom:3px solid #1e5f4e}
.company-name{font-size:17pt;font-weight:bold;color:#1e5f4e}
.company-details{font-size:9pt;color:#4a5568;margin-top:5px;line-height:1.7}
.title-wrap{text-align:center;margin:28px 0}
.title{font-size:15pt;font-weight:bold;letter-spacing:3px;text-transform:uppercase;color:#1e5f4e;border-bottom:2px solid #1e5f4e;padding-bottom:6px;display:inline-block}
.clause{margin-bottom:17px}
.clause-title{font-weight:bold;font-size:11pt;color:#1e5f4e;margin-bottom:5px}
.clause p{text-align:justify;line-height:1.85;font-size:10.5pt}
.sigs{margin-top:56px;display:flex;justify-content:space-between}
.sig-col{width:42%;text-align:center}
.sig-line{border-top:1px solid #1a1a2e;padding-top:8px;margin-top:56px}
.sig-label{font-size:9pt;font-weight:bold;color:#1e5f4e}
.footer{margin-top:36px;padding-top:10px;border-top:1px solid #e2e8f0;text-align:center;font-size:8pt;color:#94a3b8}
</style></head>
<body><div class="page">
<div class="header">
  <div style="flex:1">
    <div class="company-name">{{empresa_nome}}</div>
    <div class="company-details">NIF: {{empresa_nif}}<br>{{empresa_endereco}}</div>
  </div>
  <div style="text-align:right;min-width:140px">
    <div style="font-size:10pt;font-weight:bold;color:#1e5f4e">Ref.: {{nr_documento}}</div>
    <div style="font-size:9pt;color:#64748b;margin-top:4px">Data: {{data_documento}}</div>
  </div>
</div>
<div class="title-wrap"><div class="title">CONTRATO DE FORNECIMENTO</div></div>
<div class="clause">
  <div class="clause-title">CLÁUSULA 1.ª — IDENTIFICAÇÃO DAS PARTES</div>
  <p><strong>Contratante:</strong> {{empresa_nome}}, NIF n.º {{empresa_nif}}, sede em {{empresa_endereco}}.<br><br>
  <strong>Fornecedor:</strong> {{destinatario_nome}}.</p>
</div>
<div class="clause">
  <div class="clause-title">CLÁUSULA 2.ª — OBJECTO</div>
  <p>{{objeto_contrato}}</p>
</div>
<div class="clause">
  <div class="clause-title">CLÁUSULA 3.ª — PREÇO</div>
  <p>Preço global de <strong>{{valor}} AOA</strong> nas condições estabelecidas na Cláusula 5.ª.</p>
</div>
<div class="clause">
  <div class="clause-title">CLÁUSULA 4.ª — PRAZO</div>
  <p>O fornecimento deve ser realizado até ao dia <strong>{{prazo_vigencia}}</strong>.</p>
</div>
<div class="clause">
  <div class="clause-title">CLÁUSULA 5.ª — PAGAMENTO</div>
  <p>Pagamento em 30 dias após recepção e aceitação, mediante transferência bancária.</p>
</div>
<p style="text-align:center;margin-top:22px;font-size:10pt">{{empresa_endereco}}, {{data_documento}}</p>
<div class="sigs">
  <div class="sig-col"><div class="sig-line">
    <div class="sig-label">O Contratante</div>
    <div style="font-size:9pt;color:#4a5568;margin-top:3px">{{utilizador_nome}}</div>
  </div></div>
  <div class="sig-col"><div class="sig-line">
    <div class="sig-label">O Fornecedor</div>
    <div style="font-size:9pt;color:#4a5568;margin-top:3px">{{destinatario_nome}}</div>
  </div></div>
</div>
<div class="footer">{{empresa_nome}} — NIF: {{empresa_nif}} — Impresso em: {{data_hora_impressao}}</div>
</div></body></html>`;
