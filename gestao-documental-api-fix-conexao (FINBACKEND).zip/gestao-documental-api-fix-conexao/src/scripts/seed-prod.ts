/**
 * Seed de PRODUÇÃO — idempotente e NÃO destrutivo.
 *
 * Insere apenas o essencial para a aplicação funcionar, sem dados de teste:
 *   • Roles (4)
 *   • Utilizador admin (1)
 *   • Tipos de documento genéricos (4)
 *   • Templates (4)
 *   • Empresa (singleton)
 *   • Províncias de Angola (21)
 *
 * NÃO insere (nem apaga): entidades, documentos, circulações, pastas, auditoria,
 * notificações, contadores (estes criam-se sozinhos via import:angop / gerarNumero).
 *
 * Ao contrário do seed.ts, este script NUNCA faz deleteMany — pode ser corrido com
 * segurança numa BD já populada (não toca nos documentos importados nem repõe a
 * password do admin se ele já existir).
 *
 * Uso:
 *   npm run seed:prod
 *   # password do admin configurável:
 *   SEED_ADMIN_PASSWORD='algoSeguro' npm run seed:prod
 */

import 'reflect-metadata';
import * as mongoose from 'mongoose';
import * as bcrypt from 'bcrypt';
import * as dotenv from 'dotenv';
import {
  HTML_CONTRATO_TRABALHO,
  HTML_FOLHA_SALARIAL,
  HTML_DECLARACAO_FISCAL,
  HTML_CONTRATO_FORNECEDOR,
} from './seed-data/templates-html';

dotenv.config({ path: '.env' });

const MONGODB_URI =
  process.env.MONGODB_URI ?? 'mongodb://localhost:27017/faustware';
const BCRYPT_ROUNDS = 10;
const ADMIN_PASSWORD = process.env.SEED_ADMIN_PASSWORD ?? 'faustware123';

function iso(date: string): string {
  return new Date(date).toISOString();
}

// Schema permissivo para operações directas (como no seed.ts)
const anySchema = new mongoose.Schema({}, { strict: false, _id: false });
function model(name: string, collection: string): mongoose.Model<any> {
  return mongoose.models[name] ?? mongoose.model(name, anySchema, collection);
}

// ─── Permissões (idênticas ao seed.ts) ───────────────────────────────────────────
const ALL_PERMISSIONS = [
  'documents.create', 'documents.read', 'documents.update', 'documents.delete',
  'documents.forward', 'documents.sign', 'documents.approve', 'documents.giveOpinion',
  'documents.dispatch', 'documents.defer', 'documents.archive', 'documents.export',
  'config.types.manage', 'config.users.manage', 'config.permissions.manage',
  'config.entities.manage', 'config.templates.manage', 'config.company.manage',
  'config.locations.manage',
  'audit.read', 'exports.run', 'files.manage', 'notifications.read', 'dashboard.view',
];

const GESTAO_PERMISSIONS = [
  'documents.create', 'documents.read', 'documents.update', 'documents.delete',
  'documents.forward', 'documents.sign', 'documents.approve', 'documents.giveOpinion',
  'documents.dispatch', 'documents.defer', 'documents.archive', 'documents.export',
  'config.types.manage', 'config.entities.manage', 'config.templates.manage',
  'config.locations.manage',
  'audit.read', 'exports.run', 'files.manage', 'notifications.read', 'dashboard.view',
];

const COLABORADOR_PERMISSIONS = [
  'documents.create', 'documents.read', 'documents.forward',
  'documents.giveOpinion', 'files.manage', 'notifications.read', 'dashboard.view',
];

// ─── Dados essenciais ─────────────────────────────────────────────────────────────
const ROLES = [
  { _id: 'role-admin',       nome: 'Administrador',    descricao: 'Acesso total ao sistema, incluindo configurações e gestão de utilizadores.', permissions: ALL_PERMISSIONS },
  { _id: 'role-gestor',      nome: 'Gestor',           descricao: 'Gestão documental completa e configuração de tipos e entidades.',             permissions: GESTAO_PERMISSIONS },
  { _id: 'role-colaborador', nome: 'Colaborador',      descricao: 'Criação, leitura e encaminhamento de documentos.',                           permissions: COLABORADOR_PERMISSIONS },
  { _id: 'role-externo',     nome: 'Entidade Externa', descricao: 'Acesso restrito ao portal de consulta.',                                     permissions: ['documents.read', 'notifications.read'] },
];

const DOC_TYPES = [
  {
    _id: 'dtype-contrato-trabalho', nome: 'Contrato de Trabalho',
    descricao: 'Contrato de vínculo laboral entre a empresa e colaborador.',
    registro: 'todos', ativo: true,
    campos: [
      { id: 'cf-tipo-contrato', label: 'Tipo de Contrato', key: 'tipoContrato', tipo: 'select', obrigatorio: true, opcoes: ['Efectivo', 'Prazo Certo', 'Prestação de Serviços', 'Estágio'], ordem: 1 },
      { id: 'cf-valor-contrato', label: 'Valor Mensal', key: 'valorMensal', tipo: 'currency', obrigatorio: false, ordem: 2 },
    ],
  },
  {
    _id: 'dtype-folha-salarial', nome: 'Folha Salarial',
    descricao: 'Documento de processamento mensal de salários.',
    registro: 'interno', ativo: true,
    campos: [
      { id: 'cf-mes-referencia', label: 'Mês de Referência', key: 'mesReferencia', tipo: 'date', obrigatorio: true, ordem: 1 },
      { id: 'cf-total-bruto', label: 'Total Bruto', key: 'totalBruto', tipo: 'currency', obrigatorio: true, ordem: 2 },
    ],
  },
  {
    _id: 'dtype-impostos', nome: 'Impostos',
    descricao: 'Documentos fiscais e declarações de impostos.',
    registro: 'saida', ativo: true,
    campos: [
      { id: 'cf-tipo-imposto', label: 'Tipo de Imposto', key: 'tipoImposto', tipo: 'select', obrigatorio: true, opcoes: ['IRT', 'IVA', 'II', 'IPU', 'Outro'], ordem: 1 },
      { id: 'cf-periodo', label: 'Período', key: 'periodo', tipo: 'text', obrigatorio: true, ordem: 2 },
      { id: 'cf-valor-imposto', label: 'Valor a Pagar', key: 'valorPagar', tipo: 'currency', obrigatorio: true, ordem: 3 },
    ],
  },
  {
    _id: 'dtype-contrato-fornecedor', nome: 'Contrato Fornecedor',
    descricao: 'Contrato de prestação de serviços ou fornecimento de bens.',
    registro: 'entrada', ativo: true,
    campos: [
      { id: 'cf-valor-fornecedor', label: 'Valor do Contrato', key: 'valorContrato', tipo: 'currency', obrigatorio: true, ordem: 1 },
      { id: 'cf-prazo-vigencia', label: 'Prazo de Vigência', key: 'prazoVigencia', tipo: 'date', obrigatorio: true, ordem: 2 },
      { id: 'cf-objeto', label: 'Objeto do Contrato', key: 'objetoContrato', tipo: 'textarea', obrigatorio: false, ordem: 3 },
    ],
  },
];

const watermark = { incluirNomeUtilizador: true, incluirDataHora: true, incluirEstadoDocumento: true, opacidade: 0.08 };

const TEMPLATES = [
  {
    _id: 'tpl-contrato-trabalho', nome: 'Contrato de Trabalho',
    descricao: 'Template oficial para contratos laborais com cláusulas da Lei Geral do Trabalho de Angola.',
    documentTypeId: 'dtype-contrato-trabalho',
    htmlContent: HTML_CONTRATO_TRABALHO,
    variaveis: ['{{empresa_nome}}', '{{empresa_nif}}', '{{empresa_endereco}}', '{{empresa_logo}}', '{{nr_documento}}', '{{data_documento}}', '{{assunto}}', '{{remetente_nome}}', '{{destinatario_nome}}', '{{utilizador_nome}}', '{{utilizador_cargo}}', '{{data_hora_impressao}}', '{{tipo_contrato}}', '{{valor}}'],
    signatureZones: [
      { id: 'sz-empregador', label: 'Assinatura do Empregador', x: 5, y: 82, width: 38, height: 10, obrigatoria: true, assignedRole: 'Gestor Documental' },
      { id: 'sz-trabalhador', label: 'Assinatura do Trabalhador', x: 57, y: 82, width: 38, height: 10, obrigatoria: true, assignedRole: 'Técnico' },
    ],
    watermark, versao: 1, ativo: true, criadoEm: iso('2024-01-05'),
  },
  {
    _id: 'tpl-folha-salarial', nome: 'Folha Salarial',
    descricao: 'Recibo de remuneração mensal com componentes salariais e declaração de recebimento.',
    documentTypeId: 'dtype-folha-salarial',
    htmlContent: HTML_FOLHA_SALARIAL,
    variaveis: ['{{empresa_nome}}', '{{empresa_nif}}', '{{empresa_endereco}}', '{{empresa_logo}}', '{{nr_documento}}', '{{data_documento}}', '{{assunto}}', '{{remetente_nome}}', '{{destinatario_nome}}', '{{utilizador_nome}}', '{{data_hora_impressao}}', '{{mes_referencia}}', '{{total_bruto}}', '{{salario_base}}', '{{subsidios}}', '{{descontos}}', '{{liquido_pagar}}'],
    signatureZones: [
      { id: 'sz-trabalhador-fs', label: 'Assinatura do Trabalhador', x: 30, y: 85, width: 40, height: 8, obrigatoria: true, assignedRole: 'Técnico' },
    ],
    watermark: { ...watermark, texto: 'CONFIDENCIAL' }, versao: 1, ativo: true, criadoEm: iso('2024-01-05'),
  },
  {
    _id: 'tpl-impostos', nome: 'Declaração Fiscal',
    descricao: 'Template para declarações fiscais (IRT, IVA, II, IPU) com tabela de valores e zonas de assinatura.',
    documentTypeId: 'dtype-impostos',
    htmlContent: HTML_DECLARACAO_FISCAL,
    variaveis: ['{{empresa_nome}}', '{{empresa_nif}}', '{{empresa_endereco}}', '{{empresa_logo}}', '{{nr_documento}}', '{{data_documento}}', '{{assunto}}', '{{remetente_nome}}', '{{utilizador_nome}}', '{{utilizador_cargo}}', '{{data_hora_impressao}}', '{{tipo_imposto}}', '{{periodo}}', '{{valor_pagar}}', '{{base_tributavel}}', '{{taxa}}'],
    signatureZones: [
      { id: 'sz-declarante', label: 'Assinatura do Declarante', x: 5, y: 82, width: 38, height: 10, obrigatoria: true, assignedRole: 'Gestor Documental' },
      { id: 'sz-fiscal', label: 'Responsável Fiscal', x: 57, y: 82, width: 38, height: 10, obrigatoria: true, assignedRole: 'Gestor Documental' },
    ],
    watermark: { ...watermark, texto: 'CONFIDENCIAL' }, versao: 1, ativo: true, criadoEm: iso('2024-01-10'),
  },
  {
    _id: 'tpl-contrato-fornecedor', nome: 'Contrato de Fornecimento',
    descricao: 'Template para contratos de fornecimento de bens ou serviços com cláusulas de garantia e penalidades.',
    documentTypeId: 'dtype-contrato-fornecedor',
    htmlContent: HTML_CONTRATO_FORNECEDOR,
    variaveis: ['{{empresa_nome}}', '{{empresa_nif}}', '{{empresa_endereco}}', '{{empresa_logo}}', '{{nr_documento}}', '{{data_documento}}', '{{assunto}}', '{{remetente_nome}}', '{{destinatario_nome}}', '{{utilizador_nome}}', '{{utilizador_cargo}}', '{{data_hora_impressao}}', '{{valor}}', '{{prazo_vigencia}}', '{{objeto_contrato}}'],
    signatureZones: [
      { id: 'sz-contratante', label: 'Assinatura do Contratante', x: 5, y: 84, width: 38, height: 10, obrigatoria: true, assignedRole: 'Gestor Documental' },
      { id: 'sz-fornecedor', label: 'Assinatura do Fornecedor', x: 57, y: 84, width: 38, height: 10, obrigatoria: true, assignedRole: 'Técnico' },
    ],
    watermark, versao: 1, ativo: true, criadoEm: iso('2024-01-15'),
  },
];

const COMPANY = {
  _id: 'company',
  nome: 'Faustware Formação e Transformação',
  nif: '5417123456',
  email: 'geral@faustware.ao',
  telefone: '+244 923 456 789',
  website: 'https://faustware.ao',
  endereco: 'Rua dos Coqueiros, 45, Luanda, Angola',
};

const PROVINCES = [
  { _id: 'prov-luanda',       nome: 'Luanda',       slug: 'luanda',       ordem: 1  },
  { _id: 'prov-benguela',     nome: 'Benguela',     slug: 'benguela',     ordem: 2  },
  { _id: 'prov-huambo',       nome: 'Huambo',       slug: 'huambo',       ordem: 3  },
  { _id: 'prov-huila',        nome: 'Huíla',        slug: 'huila',        ordem: 4  },
  { _id: 'prov-malanje',      nome: 'Malanje',      slug: 'malanje',      ordem: 5  },
  { _id: 'prov-cuanza-norte', nome: 'Cuanza Norte', slug: 'cuanza-norte', ordem: 6  },
  { _id: 'prov-cuanza-sul',   nome: 'Cuanza Sul',   slug: 'cuanza-sul',   ordem: 7  },
  { _id: 'prov-lunda-norte',  nome: 'Lunda Norte',  slug: 'lunda-norte',  ordem: 8  },
  { _id: 'prov-lunda-sul',    nome: 'Lunda Sul',    slug: 'lunda-sul',    ordem: 9  },
  { _id: 'prov-bie',          nome: 'Bié',          slug: 'bie',          ordem: 10 },
  { _id: 'prov-moxico',       nome: 'Moxico',       slug: 'moxico',       ordem: 11 },
  { _id: 'prov-cubango',      nome: 'Cubango',      slug: 'cubango',      ordem: 12 },
  { _id: 'prov-cunene',       nome: 'Cunene',       slug: 'cunene',       ordem: 13 },
  { _id: 'prov-namibe',       nome: 'Namibe',       slug: 'namibe',       ordem: 14 },
  { _id: 'prov-bengo',        nome: 'Bengo',        slug: 'bengo',        ordem: 15 },
  { _id: 'prov-uige',         nome: 'Uíge',         slug: 'uige',         ordem: 16 },
  { _id: 'prov-zaire',        nome: 'Zaire',        slug: 'zaire',        ordem: 17 },
  { _id: 'prov-cabinda',      nome: 'Cabinda',      slug: 'cabinda',      ordem: 18 },
  { _id: 'prov-icolo-bengo',  nome: 'Icolo e Bengo', slug: 'icolo-e-bengo', ordem: 19 },
  { _id: 'prov-moxico-leste', nome: 'Moxico Leste',  slug: 'moxico-leste',  ordem: 20 },
  { _id: 'prov-cuando',       nome: 'Cuando',        slug: 'cuando',        ordem: 21 },
];

// ─── Upsert idempotente ────────────────────────────────────────────────────────────
type Mode = 'set' | 'setOnInsert';
async function upsertMany(
  m: mongoose.Model<any>,
  docs: Array<Record<string, any>>,
  mode: Mode,
): Promise<{ criados: number; existentes: number }> {
  let criados = 0;
  let existentes = 0;
  for (const doc of docs) {
    const { _id, ...rest } = doc;
    const update = mode === 'set' ? { $set: rest } : { $setOnInsert: rest };
    const res = await m.updateOne({ _id }, update, { upsert: true });
    if (res.upsertedCount) criados++;
    else existentes++;
  }
  return { criados, existentes };
}

// ─── Script principal ────────────────────────────────────────────────────────────
async function seed(): Promise<void> {
  await mongoose.connect(MONGODB_URI);
  console.log(`\n🔗 Ligado a: ${MONGODB_URI}`);
  console.log('🌱 Seed de PRODUÇÃO (idempotente, não destrutivo)\n');

  const Role = model('SeedProdRole', 'roles');
  const User = model('SeedProdUser', 'users');
  const DocType = model('SeedProdDocType', 'document_types');
  const Template = model('SeedProdTemplate', 'templates');
  const Company = model('SeedProdCompany', 'company');
  const Province = model('SeedProdProvince', 'provinces');

  const rRoles = await upsertMany(Role, ROLES, 'set');
  console.log(`👥 Roles            : +${rRoles.criados} novos, ${rRoles.existentes} já existentes`);

  // Admin — $setOnInsert para NÃO repor a password se já existir
  const senhaHash = await bcrypt.hash(ADMIN_PASSWORD, BCRYPT_ROUNDS);
  const admin = {
    _id: 'user-admin-001',
    nome: 'Admin Utilizador',
    email: 'admin@faustware.ao',
    roleId: 'role-admin',
    ativo: true,
    criadoEm: iso('2024-01-02'),
    senhaHash,
  };
  const rAdmin = await upsertMany(User, [admin], 'setOnInsert');
  console.log(
    `👤 Admin            : ${rAdmin.criados ? 'criado' : 'já existente (password preservada)'}`,
  );

  const rTypes = await upsertMany(DocType, DOC_TYPES, 'set');
  console.log(`📄 Tipos documento : +${rTypes.criados} novos, ${rTypes.existentes} já existentes`);

  const rTpl = await upsertMany(Template, TEMPLATES, 'set');
  console.log(`📑 Templates       : +${rTpl.criados} novos, ${rTpl.existentes} já existentes`);

  const rCompany = await upsertMany(Company, [COMPANY], 'set');
  console.log(`🏭 Empresa         : +${rCompany.criados} novos, ${rCompany.existentes} já existentes`);

  const rProv = await upsertMany(Province, PROVINCES, 'set');
  console.log(`🗺  Províncias      : +${rProv.criados} novas, ${rProv.existentes} já existentes`);

  console.log('\n✅ Seed de produção concluído (nada foi apagado).');
  console.log(`   Login admin: admin@faustware.ao / ${
    process.env.SEED_ADMIN_PASSWORD ? '(SEED_ADMIN_PASSWORD)' : 'faustware123'
  }\n`);

  await mongoose.disconnect();
}

seed().catch((err) => {
  console.error('\n❌ Falha no seed de produção:', err);
  process.exit(1);
});
