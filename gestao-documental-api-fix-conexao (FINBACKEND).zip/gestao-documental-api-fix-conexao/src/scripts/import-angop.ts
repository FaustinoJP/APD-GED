/**
 * Importação em massa dos documentos da ANGOP como "documentos internos".
 *
 * Percorre a pasta `ficheiro_angop/` (estrutura Categoria/<ano>/<ID>/ficheiros),
 * copia cada ficheiro para `uploads/documents/<uuid>.<ext>` e insere um documento
 * por folder (1 folder = 1 documento, ficheiros = anexos) na colecção `documents`.
 *
 * É IDEMPOTENTE: reexecutar só insere o que faltar (chave camposValores.__importKey).
 *
 * Uso:
 *   npm run import:angop
 *   # ou com caminhos personalizados (ex. no VPS):
 *   ANGOP_DIR=/srv/ficheiro_angop ANGOP_XLSX=/srv/anexos_organizado.xlsx npm run import:angop
 *
 * Variáveis de ambiente:
 *   MONGODB_URI   — ligação ao Mongo (lida do .env, como no seed)
 *   ANGOP_DIR     — pasta de origem        (default: ../ficheiro_angop)
 *   ANGOP_XLSX    — Excel de metadados      (default: ../anexos_organizado.xlsx; opcional)
 *   UPLOADS_DIR   — destino dos ficheiros   (default: ./uploads/documents)
 */

import 'reflect-metadata';
import * as mongoose from 'mongoose';
import * as bcrypt from 'bcrypt';
import * as dotenv from 'dotenv';
import * as fs from 'fs';
import * as path from 'path';
import * as XLSX from 'xlsx';
import { v4 as uuidv4 } from 'uuid';

dotenv.config({ path: '.env' });

// ─── Configuração ──────────────────────────────────────────────────────────────
const MONGODB_URI =
  process.env.MONGODB_URI ?? 'mongodb://localhost:27017/faustware';
const ANGOP_DIR = path.resolve(
  process.env.ANGOP_DIR ?? path.join(process.cwd(), '..', 'ficheiro_angop'),
);
const ANGOP_XLSX = path.resolve(
  process.env.ANGOP_XLSX ?? path.join(process.cwd(), '..', 'anexos_organizado.xlsx'),
);
const UPLOADS_DIR = path.resolve(
  process.env.UPLOADS_DIR ?? path.join(process.cwd(), 'uploads', 'documents'),
);
const URL_PREFIX = '/uploads/documents';
const ERROS_LOG = path.join(process.cwd(), 'import-erros.log');

const BCRYPT_ROUNDS = 10;
const DEMO_PASSWORD = 'faustware123';
const ADMIN_EMAIL = 'admin@faustware.ao';
const GESTOR_ROLE_NAME = 'Gestor';
const ESTADO = 'arquivado';

const SKIP_FILES = new Set(['Thumbs.db', '.DS_Store', 'desktop.ini']);
const isSkippable = (name: string): boolean =>
  name.startsWith('~$') || SKIP_FILES.has(name);

// ─── Modelos permissivos (operações directas, como no seed) ──────────────────────
const anySchema = new mongoose.Schema({}, { strict: false, _id: false });
function model(name: string, collection: string): mongoose.Model<any> {
  return mongoose.models[name] ?? mongoose.model(name, anySchema, collection);
}

// ─── Utilitários ─────────────────────────────────────────────────────────────────
function slugify(s: string): string {
  return s
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '') // remover acentos
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

function normId(s: unknown): string {
  const v = String(s ?? '').trim();
  return /^\d+$/.test(v) ? v.padStart(5, '0') : v;
}

function prettifyName(email: string): string {
  const local = email.split('@')[0];
  return local
    .replace(/[._]+/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase())
    .trim();
}

function extOf(filename: string): string {
  return path.extname(filename).replace('.', '').toLowerCase() || 'bin';
}

// Lista recursiva de ficheiros (mantém ordem: raiz primeiro, depois subpastas)
function listFilesRecursive(dir: string): string[] {
  const out: string[] = [];
  const walk = (d: string): void => {
    const entries = fs.readdirSync(d, { withFileTypes: true });
    const dirs: string[] = [];
    for (const e of entries) {
      if (e.isDirectory()) {
        dirs.push(path.join(d, e.name));
      } else if (e.isFile() && !isSkippable(e.name)) {
        out.push(path.join(d, e.name));
      }
    }
    for (const sub of dirs) walk(sub);
  };
  walk(dir);
  return out;
}

// ─── Leitura do Excel → mapa autor por folder ────────────────────────────────────
// Colunas (0-based): 8=Criado por, 11=Categoria, 13=Pasta/Registo
function lerAutoresDoExcel(): Map<string, string> {
  const map = new Map<string, string>();
  if (!fs.existsSync(ANGOP_XLSX)) {
    console.log(`⚠  Excel não encontrado em ${ANGOP_XLSX} — todos ficam com admin.`);
    return map;
  }
  const wb = XLSX.readFile(ANGOP_XLSX);
  const ws = wb.Sheets['Dados'] ?? wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json<any[]>(ws, { header: 1, blankrows: false });
  for (const r of rows) {
    if (!Array.isArray(r)) continue;
    const categoria = r[11];
    const pasta = r[13];
    const email = r[8];
    if (
      typeof categoria === 'string' &&
      categoria.trim() &&
      typeof email === 'string' &&
      email.includes('@')
    ) {
      const key = `${categoria.trim()}/${normId(pasta)}`;
      map.set(key, email.trim().toLowerCase());
    }
  }
  console.log(`📑 Excel: ${map.size} folders com autor mapeado.`);
  return map;
}

// ─── Script principal ────────────────────────────────────────────────────────────
async function run(): Promise<void> {
  if (!fs.existsSync(ANGOP_DIR)) {
    throw new Error(`Pasta de origem não encontrada: ${ANGOP_DIR}`);
  }
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });

  await mongoose.connect(MONGODB_URI);
  console.log(`\n🔗 Ligado a: ${MONGODB_URI}`);
  console.log(`📂 Origem:   ${ANGOP_DIR}`);
  console.log(`📥 Destino:  ${UPLOADS_DIR}\n`);

  const Role = model('ImpRole', 'roles');
  const User = model('ImpUser', 'users');
  const DocType = model('ImpDocType', 'document_types');
  const Document = model('ImpDocument', 'documents');
  const Counter = model('ImpCounter', 'document_counters');

  // ── Resolver admin e role Gestor ──────────────────────────────────────────────
  const admin = (await User.findOne({ email: ADMIN_EMAIL }).lean()) as any;
  if (!admin) {
    throw new Error(
      `Utilizador admin '${ADMIN_EMAIL}' não existe. Corra 'npm run seed' primeiro.`,
    );
  }
  const adminId = admin._id as string;

  const gestorRole = (await Role.findOne({ nome: GESTOR_ROLE_NAME }).lean()) as any;
  if (!gestorRole) {
    throw new Error(`Role '${GESTOR_ROLE_NAME}' não existe. Corra 'npm run seed' primeiro.`);
  }
  const gestorRoleId = gestorRole._id as string;

  // ── Autores do Excel + criação dos utilizadores em falta ──────────────────────
  const autorPorFolder = lerAutoresDoExcel();
  const emailsAutores = new Set([...autorPorFolder.values()]);
  const senhaHash = await bcrypt.hash(DEMO_PASSWORD, BCRYPT_ROUNDS);
  const userIdPorEmail = new Map<string, string>();
  let usersCriados = 0;

  for (const email of emailsAutores) {
    const existing = (await User.findOne({ email }).lean()) as any;
    if (existing) {
      userIdPorEmail.set(email, existing._id as string);
      continue;
    }
    const _id = `user-angop-${slugify(email.split('@')[0])}`;
    await User.updateOne(
      { email },
      {
        $setOnInsert: {
          _id,
          nome: prettifyName(email),
          email,
          roleId: gestorRoleId,
          ativo: true,
          criadoEm: new Date().toISOString(),
          senhaHash,
        },
      },
      { upsert: true },
    );
    userIdPorEmail.set(email, _id);
    usersCriados++;
  }
  console.log(`👤 Utilizadores criados: ${usersCriados} (de ${emailsAutores.size} autores)\n`);

  // ── Helper: garantir DocumentType por categoria (cache) ───────────────────────
  const tipoIdPorCategoria = new Map<string, string>();
  let tiposCriados = 0;
  async function ensureTipo(categoria: string): Promise<string> {
    const cached = tipoIdPorCategoria.get(categoria);
    if (cached) return cached;
    const _id = `dtype-angop-${slugify(categoria)}`;
    const res = await DocType.updateOne(
      { _id },
      {
        $setOnInsert: {
          _id,
          nome: categoria,
          descricao: `Documentos internos importados da ANGOP — ${categoria}.`,
          registro: 'interno',
          campos: [],
          ativo: true,
        },
      },
      { upsert: true },
    );
    if (res.upsertedCount) tiposCriados++;
    tipoIdPorCategoria.set(categoria, _id);
    return _id;
  }

  // ── Helper: gerar número atómico INT-<ano>/<seq> ──────────────────────────────
  async function gerarNumero(ano: string): Promise<string> {
    const counter = await Counter.findByIdAndUpdate(
      `interno:${ano}`,
      { $inc: { seq: 1 } },
      { new: true, upsert: true },
    ).lean();
    const seq = String((counter as any).seq).padStart(5, '0');
    return `INT-${ano}/${seq}`;
  }

  // ── Percorrer folders Categoria/<ano>/<ID> ────────────────────────────────────
  let inseridos = 0;
  let saltados = 0;
  let ficheirosCopiados = 0;
  const foldersVazias: string[] = [];
  const erros: string[] = [];

  const categorias = fs
    .readdirSync(ANGOP_DIR, { withFileTypes: true })
    .filter((e) => e.isDirectory())
    .map((e) => e.name);

  for (const categoria of categorias) {
    const catDir = path.join(ANGOP_DIR, categoria);
    const anos = fs
      .readdirSync(catDir, { withFileTypes: true })
      .filter((e) => e.isDirectory())
      .map((e) => e.name);

    for (const ano of anos) {
      const anoDir = path.join(catDir, ano);
      const ids = fs
        .readdirSync(anoDir, { withFileTypes: true })
        .filter((e) => e.isDirectory())
        .map((e) => e.name);

      for (const id of ids) {
        const idDir = path.join(anoDir, id);
        const importKey = `${categoria}/${ano}/${id}`;

        const files = listFilesRecursive(idDir);
        if (files.length === 0) {
          foldersVazias.push(importKey);
          continue;
        }

        // Idempotência
        const exists = await Document.exists({
          'camposValores.__importKey': importKey,
        });
        if (exists) {
          saltados++;
          continue;
        }

        // Ordenar: ficheiros principais (fora de historico) primeiro
        const isHist = (f: string): boolean =>
          f.replace(/\\/g, '/').toLowerCase().includes('/historico/');
        const principais = files.filter((f) => !isHist(f));
        const historicos = files.filter((f) => isHist(f));
        const ordenados = [...principais, ...historicos];

        const principal = principais[0] ?? ordenados[0];
        const statPrincipal = fs.statSync(principal);
        const assunto = path.basename(principal, path.extname(principal));

        const email = autorPorFolder.get(`${categoria}/${id}`);
        const autorId = (email && userIdPorEmail.get(email)) || adminId;

        // Ficheiros copiados nesta folder — para rollback se a inserção falhar
        const copiadosNestaFolder: string[] = [];

        try {
          // 1) Copiar ficheiros e construir os anexos
          const anexos = ordenados.map((file, i) => {
            const hist = isHist(file);
            const ext = path.extname(file);
            const uuid = uuidv4();
            const destName = `${uuid}${ext}`;
            const destPath = path.join(UPLOADS_DIR, destName);
            fs.copyFileSync(file, destPath);
            copiadosNestaFolder.push(destPath);
            const st = fs.statSync(file);
            return {
              id: uuid,
              nome: path.basename(file),
              versao: hist ? i + 1 : 1,
              estado: 'check_in',
              tamanho: st.size,
              formato: extOf(file),
              url: `${URL_PREFIX}/${destName}`,
              adicionadoPor: autorId,
              criadoEm: st.mtime.toISOString(),
              ...(hist ? { observacao: 'histórico' } : {}),
            };
          });

          const tipoDocumentoId = await ensureTipo(categoria);
          const numero = await gerarNumero(ano);
          const now = new Date().toISOString();

          // 2) Inserir o documento. Só conta os ficheiros como copiados depois disto.
          await Document.create({
            _id: uuidv4(),
            numero,
            tipoRegistro: 'interno',
            tipoDocumentoId,
            assunto,
            remetenteTexto: email ?? undefined,
            destinatarios: [],
            data: statPrincipal.mtime.toISOString(),
            confidencial: false,
            estado: ESTADO,
            camposValores: {
              __fonte: 'ficheiro_angop',
              __importKey: importKey,
              __registo: id,
              __categoria: categoria,
            },
            anexos,
            criadoPor: autorId,
            criadoEm: now,
            atualizadoEm: now,
          });
          inseridos++;
          ficheirosCopiados += copiadosNestaFolder.length;

          if (inseridos % 100 === 0) {
            console.log(`  … ${inseridos} documentos inseridos`);
          }
        } catch (err) {
          // Rollback: remover os ficheiros copiados desta folder (zero órfãos)
          for (const p of copiadosNestaFolder) {
            try {
              fs.unlinkSync(p);
            } catch {
              // ignorar se já não existir
            }
          }
          const msg = err instanceof Error ? err.message : String(err);
          const linha = `[${importKey}] ${msg}`;
          erros.push(linha);
          try {
            fs.appendFileSync(ERROS_LOG, `${linha}\n`);
          } catch {
            // não bloquear por falha de log
          }
          // FAIL-FAST: abortar imediatamente para o erro não passar despercebido
          console.error(`\n❌ Falha ao importar '${importKey}': ${msg}`);
          console.error(
            `   Inseridos até aqui: ${inseridos} | saltados: ${saltados} | ` +
              `ficheiros copiados: ${ficheirosCopiados}`,
          );
          console.error(`   Detalhe registado em: ${ERROS_LOG}`);
          throw err;
        }
      }
    }
  }

  // ── Resumo ────────────────────────────────────────────────────────────────────
  console.log('\n✅ Importação concluída.');
  console.log(`   Tipos de documento criados : ${tiposCriados}`);
  console.log(`   Utilizadores criados       : ${usersCriados}`);
  console.log(`   Documentos inseridos       : ${inseridos}`);
  console.log(`   Documentos saltados        : ${saltados} (já existiam)`);
  console.log(`   Ficheiros copiados         : ${ficheirosCopiados}`);
  if (foldersVazias.length) {
    console.log(`   Folders sem ficheiros      : ${foldersVazias.length}`);
  }
  if (erros.length) {
    console.log(`\n⚠  Erros (${erros.length}):`);
    for (const e of erros.slice(0, 20)) console.log(`     - ${e}`);
    if (erros.length > 20) console.log(`     … e mais ${erros.length - 20}`);
  }

  await mongoose.disconnect();
}

run().catch((err) => {
  console.error('\n❌ Falha na importação:', err);
  process.exit(1);
});
