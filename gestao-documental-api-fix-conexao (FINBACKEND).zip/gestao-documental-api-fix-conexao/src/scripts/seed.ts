/**
 * MongoDB seed script — idempotente.
 *
 * Uso:
 *   npx ts-node -r tsconfig-paths/register src/scripts/seed.ts
 *   # ou via npm script:
 *   npm run seed
 *
 * Palavra-passes demo (bcrypt de 'faustware123'):
 *   admin@faustware.ao   / faustware123
 *   gestor@faustware.ao  / faustware123
 *   colaborador@faustware.ao / faustware123
 */

import 'reflect-metadata';
import * as mongoose from 'mongoose';
import * as bcrypt from 'bcrypt';
import * as dotenv from 'dotenv';
import { v4 as uuidv4 } from 'uuid';
import {
  HTML_CONTRATO_TRABALHO,
  HTML_FOLHA_SALARIAL,
  HTML_DECLARACAO_FISCAL,
  HTML_CONTRATO_FORNECEDOR,
} from './seed-data/templates-html';

dotenv.config({ path: '.env' });

const MONGODB_URI =
  process.env.MONGODB_URI ?? 'mongodb://localhost:27017/faustware';
const BCRYPT_ROUNDS = 10;
const DEMO_PASSWORD = 'faustware123';

// Schema permissivo para operações directas no seed
const any = new mongoose.Schema({}, { strict: false, _id: false });

function model(name: string, collection: string) {
  return mongoose.models[name] ??
    mongoose.model(name, any, collection);
}

function iso(date: string): string {
  return new Date(date).toISOString();
}

// ─── Dados de seed ────────────────────────────────────────────────────────────

const ALL_PERMISSIONS = [
  'documents.create', 'documents.read', 'documents.update', 'documents.delete',
  'documents.forward', 'documents.sign', 'documents.approve', 'documents.giveOpinion',
  'documents.dispatch', 'documents.defer', 'documents.archive', 'documents.export',
  'config.types.manage', 'config.users.manage', 'config.permissions.manage',
  'config.entities.manage', 'config.templates.manage', 'config.company.manage',
  'config.locations.manage',
  'audit.read', 'exports.run', 'files.manage', 'notifications.read', 'dashboard.view',
];

const GESTAO_PERMISSIONS = [
  'documents.create', 'documents.read', 'documents.update', 'documents.delete',
  'documents.forward', 'documents.sign', 'documents.approve', 'documents.giveOpinion',
  'documents.dispatch', 'documents.defer', 'documents.archive', 'documents.export',
  'config.types.manage', 'config.entities.manage', 'config.templates.manage',
  'config.locations.manage',
  'audit.read', 'exports.run', 'files.manage', 'notifications.read', 'dashboard.view',
];

const COLABORADOR_PERMISSIONS = [
  'documents.create', 'documents.read', 'documents.forward',
  'documents.giveOpinion', 'files.manage', 'notifications.read', 'dashboard.view',
];

async function seed(): Promise<void> {
  await mongoose.connect(MONGODB_URI);
  console.log(`\n🔗 Ligado a: ${MONGODB_URI}\n`);

  // ── Modelos ─────────────────────────────────────────────────────────────────
  const Role       = model('SeedRole',       'roles');
  const User       = model('SeedUser',       'users');
  const DocType    = model('SeedDocType',    'document_types');
  const Entity     = model('SeedEntity',     'entities');
  const Document   = model('SeedDocument',   'documents');
  const Circ       = model('SeedCirc',       'circulations');
  const Folder     = model('SeedFolder',     'folders');
  const Audit      = model('SeedAudit',      'audit_logs');
  const Notif      = model('SeedNotif',      'notifications');
  const Template   = model('SeedTemplate',   'templates');
  const Counter    = model('SeedCounter',    'document_counters');
  const Company    = model('SeedCompany',    'company');
  const Province   = model('SeedProvince',   'provinces');

  // ── Limpar colecções existentes ───────────────────────────────────────────
  console.log('🗑  A limpar colecções...');
  await Promise.all([
    Role.deleteMany({}), User.deleteMany({}), DocType.deleteMany({}),
    Entity.deleteMany({}), Document.deleteMany({}), Circ.deleteMany({}),
    Folder.deleteMany({}), Audit.deleteMany({}), Notif.deleteMany({}),
    Template.deleteMany({}), Counter.deleteMany({}), Company.deleteMany({}),
    Province.deleteMany({}),
  ]);

  // ── Password hash (partilhado para todos os utilizadores demo) ────────────
  console.log('🔐 A gerar hash de passwords...');
  const senhaHash = await bcrypt.hash(DEMO_PASSWORD, BCRYPT_ROUNDS);

  // ── Roles ──────────────────────────────────────────────────────────────────
  console.log('👥 A inserir roles...');
  await Role.insertMany([
    { _id: 'role-admin',       nome: 'Administrador',    descricao: 'Acesso total ao sistema, incluindo configurações e gestão de utilizadores.', permissions: ALL_PERMISSIONS },
    { _id: 'role-gestor',      nome: 'Gestor',           descricao: 'Gestão documental completa e configuração de tipos e entidades.',             permissions: GESTAO_PERMISSIONS },
    { _id: 'role-colaborador', nome: 'Colaborador',      descricao: 'Criação, leitura e encaminhamento de documentos.',                           permissions: COLABORADOR_PERMISSIONS },
    { _id: 'role-externo',     nome: 'Entidade Externa', descricao: 'Acesso restrito ao portal de consulta.',                                     permissions: ['documents.read', 'notifications.read'] },
  ]);

  // ── Utilizadores ──────────────────────────────────────────────────────────
  console.log('👤 A inserir utilizadores...');
  await User.insertMany([
    { _id: 'user-admin-001',  nome: 'Admin Utilizador',  email: 'admin@faustware.ao',         roleId: 'role-admin',       ativo: true, criadoEm: iso('2024-01-02'), senhaHash },
    { _id: 'user-gestor-001', nome: 'Maria Fernanda',    email: 'gestor@faustware.ao',        roleId: 'role-gestor',      ativo: true, criadoEm: iso('2024-01-10'), senhaHash },
    { _id: 'user-colab-001',  nome: 'João Baptista',     email: 'colaborador@faustware.ao',   roleId: 'role-colaborador', ativo: true, criadoEm: iso('2024-02-05'), senhaHash },
  ]);

  // ── Tipos de documento ─────────────────────────────────────────────────────
  console.log('📄 A inserir tipos de documento...');
  await DocType.insertMany([
    {
      _id: 'dtype-contrato-trabalho', nome: 'Contrato de Trabalho',
      descricao: 'Contrato de vínculo laboral entre a empresa e colaborador.',
      registro: 'todos', ativo: true,
      campos: [
        { id: 'cf-tipo-contrato', label: 'Tipo de Contrato', key: 'tipoContrato', tipo: 'select', obrigatorio: true, opcoes: ['Efectivo', 'Prazo Certo', 'Prestação de Serviços', 'Estágio'], ordem: 1 },
        { id: 'cf-valor-contrato', label: 'Valor Mensal', key: 'valorMensal', tipo: 'currency', obrigatorio: false, ordem: 2 },
      ],
    },
    {
      _id: 'dtype-folha-salarial', nome: 'Folha Salarial',
      descricao: 'Documento de processamento mensal de salários.',
      registro: 'interno', ativo: true,
      campos: [
        { id: 'cf-mes-referencia', label: 'Mês de Referência', key: 'mesReferencia', tipo: 'date', obrigatorio: true, ordem: 1 },
        { id: 'cf-total-bruto', label: 'Total Bruto', key: 'totalBruto', tipo: 'currency', obrigatorio: true, ordem: 2 },
      ],
    },
    {
      _id: 'dtype-impostos', nome: 'Impostos',
      descricao: 'Documentos fiscais e declarações de impostos.',
      registro: 'saida', ativo: true,
      campos: [
        { id: 'cf-tipo-imposto', label: 'Tipo de Imposto', key: 'tipoImposto', tipo: 'select', obrigatorio: true, opcoes: ['IRT', 'IVA', 'II', 'IPU', 'Outro'], ordem: 1 },
        { id: 'cf-periodo', label: 'Período', key: 'periodo', tipo: 'text', obrigatorio: true, ordem: 2 },
        { id: 'cf-valor-imposto', label: 'Valor a Pagar', key: 'valorPagar', tipo: 'currency', obrigatorio: true, ordem: 3 },
      ],
    },
    {
      _id: 'dtype-contrato-fornecedor', nome: 'Contrato Fornecedor',
      descricao: 'Contrato de prestação de serviços ou fornecimento de bens.',
      registro: 'entrada', ativo: true,
      campos: [
        { id: 'cf-valor-fornecedor', label: 'Valor do Contrato', key: 'valorContrato', tipo: 'currency', obrigatorio: true, ordem: 1 },
        { id: 'cf-prazo-vigencia', label: 'Prazo de Vigência', key: 'prazoVigencia', tipo: 'date', obrigatorio: true, ordem: 2 },
        { id: 'cf-objeto', label: 'Objeto do Contrato', key: 'objetoContrato', tipo: 'textarea', obrigatorio: false, ordem: 3 },
      ],
    },
  ]);

  // ── Entidades ──────────────────────────────────────────────────────────────
  console.log('🏢 A inserir entidades...');
  await Entity.insertMany([
    { _id: 'entity-faustware-001', nome: 'faustware Formação e Transformação', tipo: 'cliente',    email: 'geral@faustware.ao',          telefone: '+244 923 456 789', endereco: 'Rua dos Coqueiros, 45, Luanda',   regiao: 'Luanda',   localizacao: 'Bairro Ingombota', criadoEm: iso('2024-01-01') },
    { _id: 'entity-supplier-001',  nome: 'TecnoServ Angola Lda',               tipo: 'fornecedor', email: 'comercial@tecnoserv.ao',       telefone: '+244 912 345 678', endereco: 'Rua da Missão, 102, Benguela',    regiao: 'Benguela', localizacao: 'Bairro Restinga',  criadoEm: iso('2024-01-15') },
    { _id: 'entity-gov-001',       nome: 'Ministério das Finanças',            tipo: 'orgao',      email: 'protocolo@minfin.gov.ao',      telefone: '+244 222 395 000', endereco: 'Largo da Mutamba, s/n, Luanda',   regiao: 'Luanda',   localizacao: 'Mutamba',          criadoEm: iso('2024-01-20') },
  ]);

  // ── Documentos ─────────────────────────────────────────────────────────────
  console.log('📁 A inserir documentos...');
  await Document.insertMany([
    {
      _id: 'doc-ent-001', numero: 'ENT-2024/00001', tipoRegistro: 'entrada',
      tipoDocumentoId: 'dtype-contrato-trabalho',
      assunto: 'Contrato de Trabalho — João Baptista',
      remetenteId: 'entity-faustware-001', remetenteTexto: 'faustware Formação e Transformação',
      destinatarios: [{ tipo: 'user', id: 'user-admin-001' }],
      data: iso('2024-03-01'), confidencial: false, estado: 'aprovado',
      regiao: 'Luanda', localizacao: 'Luanda',
      camposValores: { tipoContrato: 'Efectivo', valorMensal: 150000 },
      anexos: [{ id: 'att-001', nome: 'contrato_joao.pdf', versao: 1, estado: 'check_in', tamanho: 524288, formato: 'pdf', url: '/mock/attachments/att-001.pdf', adicionadoPor: 'user-admin-001', criadoEm: iso('2024-03-01') }],
      criadoPor: 'user-admin-001', criadoEm: iso('2024-03-01'), atualizadoEm: iso('2024-03-15'),
    },
    {
      _id: 'doc-ent-002', numero: 'ENT-2024/00002', tipoRegistro: 'entrada',
      tipoDocumentoId: 'dtype-folha-salarial',
      assunto: 'Folha Salarial — Março 2024',
      remetenteTexto: 'Departamento de RH',
      destinatarios: [{ tipo: 'user', id: 'user-admin-001' }, { tipo: 'user', id: 'user-gestor-001' }],
      data: iso('2024-04-01'), confidencial: true, estado: 'em_circulacao',
      regiao: 'Luanda', localizacao: 'Luanda',
      camposValores: { mesReferencia: '2024-03-01', totalBruto: 4250000 },
      anexos: [
        { id: 'att-002', nome: 'folha_marco_2024.xlsx', versao: 1, estado: 'check_in', tamanho: 204800, formato: 'xlsx', url: '/mock/attachments/att-002.xlsx', adicionadoPor: 'user-gestor-001', criadoEm: iso('2024-04-01') },
        { id: 'att-003', nome: 'resumo_folha.pdf',      versao: 1, estado: 'check_in', tamanho: 102400, formato: 'pdf',  url: '/mock/attachments/att-003.pdf',  adicionadoPor: 'user-gestor-001', criadoEm: iso('2024-04-01') },
      ],
      criadoPor: 'user-gestor-001', criadoEm: iso('2024-04-01'), atualizadoEm: iso('2024-04-01'),
    },
    {
      _id: 'doc-sai-001', numero: 'SAI-2024/00001', tipoRegistro: 'saida',
      tipoDocumentoId: 'dtype-contrato-fornecedor',
      assunto: 'Contrato de Serviços TI — TecnoServ Angola',
      remetenteTexto: 'faustware Systems & Solutions',
      destinatarios: [{ tipo: 'entity', id: 'entity-supplier-001' }],
      data: iso('2024-03-15'), confidencial: false, estado: 'novo',
      regiao: 'Benguela', localizacao: 'Benguela',
      camposValores: { valorContrato: 5000000, prazoVigencia: '2025-03-15', objetoContrato: 'Manutenção e suporte de infraestrutura tecnológica.' },
      anexos: [{ id: 'att-004', nome: 'contrato_tecnoserv.pdf', versao: 1, estado: 'check_in', tamanho: 786432, formato: 'pdf', url: '/mock/attachments/att-004.pdf', adicionadoPor: 'user-admin-001', criadoEm: iso('2024-03-15') }],
      criadoPor: 'user-admin-001', criadoEm: iso('2024-03-15'), atualizadoEm: iso('2024-03-15'),
    },
    {
      _id: 'doc-sai-002', numero: 'SAI-2024/00002', tipoRegistro: 'saida',
      tipoDocumentoId: 'dtype-impostos',
      assunto: 'Declaração de IVA — 1.º Trimestre 2024',
      remetenteTexto: 'faustware Systems & Solutions',
      destinatarios: [{ tipo: 'entity', id: 'entity-gov-001' }],
      data: iso('2024-04-15'), confidencial: true, estado: 'em_circulacao',
      regiao: 'Huambo', localizacao: 'Huambo',
      camposValores: { tipoImposto: 'IVA', periodo: '1.º Trimestre 2024', valorPagar: 820000 },
      anexos: [{ id: 'att-005', nome: 'declaracao_iva_t1_2024.pdf', versao: 1, estado: 'check_in', tamanho: 409600, formato: 'pdf', url: '/mock/attachments/att-005.pdf', adicionadoPor: 'user-gestor-001', criadoEm: iso('2024-04-15') }],
      criadoPor: 'user-gestor-001', criadoEm: iso('2024-04-15'), atualizadoEm: iso('2024-04-15'),
    },
    {
      _id: 'doc-int-001', numero: 'INT-2024/00001', tipoRegistro: 'interno',
      tipoDocumentoId: 'dtype-folha-salarial',
      assunto: 'Folha Salarial — Fevereiro 2024 (Interno)',
      destinatarios: [{ tipo: 'user', id: 'user-gestor-001' }],
      data: iso('2024-03-05'), confidencial: true, estado: 'deferido',
      regiao: 'Luanda', localizacao: '',
      camposValores: { mesReferencia: '2024-02-01', totalBruto: 4180000 },
      anexos: [{ id: 'att-006', nome: 'folha_fev_2024_int.pdf', versao: 1, estado: 'check_in', tamanho: 327680, formato: 'pdf', url: '/mock/attachments/att-006.pdf', adicionadoPor: 'user-gestor-001', criadoEm: iso('2024-03-05') }],
      criadoPor: 'user-gestor-001', criadoEm: iso('2024-03-05'), atualizadoEm: iso('2024-03-20'),
    },
    {
      _id: 'doc-int-002', numero: 'INT-2024/00002', tipoRegistro: 'interno',
      tipoDocumentoId: 'dtype-contrato-trabalho',
      assunto: 'Renovação de Contrato — Maria Fernanda',
      destinatarios: [{ tipo: 'user', id: 'user-admin-001' }, { tipo: 'user', id: 'user-gestor-001' }],
      data: iso('2024-02-20'), confidencial: false, estado: 'concluido',
      regiao: 'Cabinda', localizacao: 'Cabinda',
      camposValores: { tipoContrato: 'Efectivo', valorMensal: 280000 },
      anexos: [
        { id: 'att-007', nome: 'renovacao_maria.pdf', versao: 1, estado: 'check_in', tamanho: 614400, formato: 'pdf', url: '/mock/attachments/att-007.pdf', adicionadoPor: 'user-admin-001', criadoEm: iso('2024-02-20') },
        { id: 'att-008', nome: 'aditamento.pdf',       versao: 1, estado: 'check_in', tamanho: 102400, formato: 'pdf', url: '/mock/attachments/att-008.pdf', adicionadoPor: 'user-admin-001', criadoEm: iso('2024-02-20') },
      ],
      criadoPor: 'user-admin-001', criadoEm: iso('2024-02-20'), atualizadoEm: iso('2024-03-01'),
    },
  ]);

  // ── Circulações ────────────────────────────────────────────────────────────
  console.log('🔄 A inserir circulações...');
  await Circ.insertMany([
    {
      _id: 'circ-001', documentId: 'doc-ent-002', acao: 'aprovar',
      deUserId: 'user-gestor-001', paraDestinatarios: [{ tipo: 'user', id: 'user-admin-001' }],
      mensagem: 'Por favor aprove a folha salarial de Março antes do dia 10.',
      dataLimite: iso('2024-04-10'), obrigatoriaTodos: false, enviarEmail: true,
      receberNotificacao: true, status: 'pendente', respostas: [], criadoEm: iso('2024-04-02'),
    },
    {
      _id: 'circ-002', documentId: 'doc-int-002', acao: 'assinar',
      deUserId: 'user-gestor-001', paraDestinatarios: [{ tipo: 'user', id: 'user-admin-001' }],
      mensagem: 'Necessita de assinatura do administrador para formalizar a renovação.',
      dataLimite: iso('2024-04-20'), obrigatoriaTodos: true, enviarEmail: true,
      receberNotificacao: true, status: 'pendente', respostas: [], criadoEm: iso('2024-04-05'),
    },
  ]);

  // ── Pastas ─────────────────────────────────────────────────────────────────
  console.log('📂 A inserir pastas...');
  await Folder.insertMany([
    { _id: 'folder-contratos-trabalho', nome: 'Contratos de Trabalho', documentTypeId: 'dtype-contrato-trabalho', criadoEm: iso('2024-01-05') },
    { _id: 'folder-folhas-salariais',   nome: 'Folhas Salariais',      documentTypeId: 'dtype-folha-salarial',    criadoEm: iso('2024-01-05') },
    { _id: 'folder-fiscal',             nome: 'Documentos Fiscais',    documentTypeId: 'dtype-impostos',          criadoEm: iso('2024-01-10') },
  ]);

  // ── Auditoria ──────────────────────────────────────────────────────────────
  console.log('📋 A inserir registos de auditoria...');
  await Audit.insertMany([
    { _id: 'audit-001', evento: 'login',       tabela: 'users',        registroId: 'user-admin-001',     userId: 'user-admin-001',  ip: '192.168.1.10', data: iso('2024-04-15T08:02:00'), detalhe: 'Login via formulário' },
    { _id: 'audit-002', evento: 'login',       tabela: 'users',        registroId: 'user-gestor-001',    userId: 'user-gestor-001', ip: '192.168.1.22', data: iso('2024-04-15T08:30:00'), detalhe: 'Login via formulário' },
    { _id: 'audit-003', evento: 'cadastrado',  tabela: 'documents',    registroId: 'doc-ent-001',        userId: 'user-admin-001',  ip: '192.168.1.10', data: iso('2024-03-01T09:00:00'), detalhe: 'Contrato de Trabalho — João Baptista registado' },
    { _id: 'audit-004', evento: 'cadastrado',  tabela: 'documents',    registroId: 'doc-ent-002',        userId: 'user-gestor-001', ip: '192.168.1.22', data: iso('2024-04-01T10:15:00'), detalhe: 'Folha Salarial Março 2024 registada' },
    { _id: 'audit-005', evento: 'visualizado', tabela: 'documents',    registroId: 'doc-ent-001',        userId: 'user-gestor-001', ip: '192.168.1.22', data: iso('2024-03-02T11:00:00') },
    { _id: 'audit-006', evento: 'aprovado',    tabela: 'documents',    registroId: 'doc-ent-001',        userId: 'user-admin-001',  ip: '192.168.1.10', data: iso('2024-03-15T14:30:00'), detalhe: 'Aprovação final' },
    { _id: 'audit-007', evento: 'encaminhado', tabela: 'circulations', registroId: 'circ-001',           userId: 'user-gestor-001', ip: '192.168.1.22', data: iso('2024-04-02T09:05:00'), detalhe: 'Enviado para aprovação' },
    { _id: 'audit-008', evento: 'encaminhado', tabela: 'circulations', registroId: 'circ-002',           userId: 'user-gestor-001', ip: '192.168.1.22', data: iso('2024-04-05T10:00:00'), detalhe: 'Enviado para assinatura' },
    { _id: 'audit-009', evento: 'cadastrado',  tabela: 'documents',    registroId: 'doc-sai-001',        userId: 'user-admin-001',  ip: '192.168.1.10', data: iso('2024-03-15T15:00:00'), detalhe: 'Contrato Fornecedor registado' },
    { _id: 'audit-010', evento: 'cadastrado',  tabela: 'documents',    registroId: 'doc-sai-002',        userId: 'user-gestor-001', ip: '10.0.0.5',     data: iso('2024-04-15T16:00:00'), detalhe: 'Declaração IVA T1 registada' },
    { _id: 'audit-011', evento: 'atualizado',  tabela: 'documents',    registroId: 'doc-int-001',        userId: 'user-gestor-001', ip: '192.168.1.22', data: iso('2024-03-20T11:30:00'), detalhe: 'Estado alterado para deferido' },
    { _id: 'audit-012', evento: 'assinado',    tabela: 'documents',    registroId: 'doc-int-002',        userId: 'user-admin-001',  ip: '192.168.1.10', data: iso('2024-03-01T12:00:00'), detalhe: 'Assinatura digital aposta' },
    { _id: 'audit-013', evento: 'exportado',   tabela: 'documents',    registroId: 'doc-ent-001',        userId: 'user-admin-001',  ip: '192.168.1.10', data: iso('2024-04-10T09:45:00'), detalhe: 'Exportado para PDF' },
    { _id: 'audit-014', evento: 'cadastrado',  tabela: 'entities',     registroId: 'entity-supplier-001',userId: 'user-admin-001',  ip: '192.168.1.10', data: iso('2024-01-15T10:00:00'), detalhe: 'Nova entidade fornecedor' },
    { _id: 'audit-015', evento: 'login',       tabela: 'users',        registroId: 'user-colab-001',     userId: 'user-colab-001',  ip: '10.0.0.12',    data: iso('2024-04-15T08:55:00'), detalhe: 'Login via formulário' },
  ]);

  // ── Notificações ───────────────────────────────────────────────────────────
  console.log('🔔 A inserir notificações...');
  await Notif.insertMany([
    { _id: 'notif-001', userId: 'user-admin-001', titulo: 'Documento pendente de aprovação', mensagem: 'A Folha Salarial de Março 2024 aguarda a sua aprovação.', lida: false, link: '/pendentes', criadoEm: iso('2024-04-02T09:05:00') },
    { _id: 'notif-002', userId: 'user-admin-001', titulo: 'Assinatura solicitada',            mensagem: 'A Renovação de Contrato — Maria Fernanda requer a sua assinatura.', lida: false, link: '/pendentes', criadoEm: iso('2024-04-05T10:00:00') },
    { _id: 'notif-003', userId: 'user-admin-001', titulo: 'Novo documento registado',         mensagem: 'Um novo contrato de fornecedor foi registado no sistema.', lida: true, link: '/registro/entradas', criadoEm: iso('2024-03-15T15:05:00') },
  ]);

  // ── Templates ──────────────────────────────────────────────────────────────
  console.log('📑 A inserir templates...');
  const watermark = { incluirNomeUtilizador: true, incluirDataHora: true, incluirEstadoDocumento: true, opacidade: 0.08 };

  await Template.insertMany([
    {
      _id: 'tpl-contrato-trabalho', nome: 'Contrato de Trabalho',
      descricao: 'Template oficial para contratos laborais com cláusulas da Lei Geral do Trabalho de Angola.',
      documentTypeId: 'dtype-contrato-trabalho',
      htmlContent: HTML_CONTRATO_TRABALHO,
      variaveis: ['{{empresa_nome}}', '{{empresa_nif}}', '{{empresa_endereco}}', '{{empresa_logo}}', '{{nr_documento}}', '{{data_documento}}', '{{assunto}}', '{{remetente_nome}}', '{{destinatario_nome}}', '{{utilizador_nome}}', '{{utilizador_cargo}}', '{{data_hora_impressao}}', '{{tipo_contrato}}', '{{valor}}'],
      signatureZones: [
        { id: 'sz-empregador', label: 'Assinatura do Empregador', x: 5, y: 82, width: 38, height: 10, obrigatoria: true, assignedRole: 'Gestor Documental' },
        { id: 'sz-trabalhador', label: 'Assinatura do Trabalhador', x: 57, y: 82, width: 38, height: 10, obrigatoria: true, assignedRole: 'Técnico' },
      ],
      watermark, versao: 1, ativo: true, criadoEm: iso('2024-01-05'),
    },
    {
      _id: 'tpl-folha-salarial', nome: 'Folha Salarial',
      descricao: 'Recibo de remuneração mensal com componentes salariais e declaração de recebimento.',
      documentTypeId: 'dtype-folha-salarial',
      htmlContent: HTML_FOLHA_SALARIAL,
      variaveis: ['{{empresa_nome}}', '{{empresa_nif}}', '{{empresa_endereco}}', '{{empresa_logo}}', '{{nr_documento}}', '{{data_documento}}', '{{assunto}}', '{{remetente_nome}}', '{{destinatario_nome}}', '{{utilizador_nome}}', '{{data_hora_impressao}}', '{{mes_referencia}}', '{{total_bruto}}', '{{salario_base}}', '{{subsidios}}', '{{descontos}}', '{{liquido_pagar}}'],
      signatureZones: [
        { id: 'sz-trabalhador-fs', label: 'Assinatura do Trabalhador', x: 30, y: 85, width: 40, height: 8, obrigatoria: true, assignedRole: 'Técnico' },
      ],
      watermark: { ...watermark, texto: 'CONFIDENCIAL' }, versao: 1, ativo: true, criadoEm: iso('2024-01-05'),
    },
    {
      _id: 'tpl-impostos', nome: 'Declaração Fiscal',
      descricao: 'Template para declarações fiscais (IRT, IVA, II, IPU) com tabela de valores e zonas de assinatura.',
      documentTypeId: 'dtype-impostos',
      htmlContent: HTML_DECLARACAO_FISCAL,
      variaveis: ['{{empresa_nome}}', '{{empresa_nif}}', '{{empresa_endereco}}', '{{empresa_logo}}', '{{nr_documento}}', '{{data_documento}}', '{{assunto}}', '{{remetente_nome}}', '{{utilizador_nome}}', '{{utilizador_cargo}}', '{{data_hora_impressao}}', '{{tipo_imposto}}', '{{periodo}}', '{{valor_pagar}}', '{{base_tributavel}}', '{{taxa}}'],
      signatureZones: [
        { id: 'sz-declarante', label: 'Assinatura do Declarante', x: 5, y: 82, width: 38, height: 10, obrigatoria: true, assignedRole: 'Gestor Documental' },
        { id: 'sz-fiscal', label: 'Responsável Fiscal', x: 57, y: 82, width: 38, height: 10, obrigatoria: true, assignedRole: 'Gestor Documental' },
      ],
      watermark: { ...watermark, texto: 'CONFIDENCIAL' }, versao: 1, ativo: true, criadoEm: iso('2024-01-10'),
    },
    {
      _id: 'tpl-contrato-fornecedor', nome: 'Contrato de Fornecimento',
      descricao: 'Template para contratos de fornecimento de bens ou serviços com cláusulas de garantia e penalidades.',
      documentTypeId: 'dtype-contrato-fornecedor',
      htmlContent: HTML_CONTRATO_FORNECEDOR,
      variaveis: ['{{empresa_nome}}', '{{empresa_nif}}', '{{empresa_endereco}}', '{{empresa_logo}}', '{{nr_documento}}', '{{data_documento}}', '{{assunto}}', '{{remetente_nome}}', '{{destinatario_nome}}', '{{utilizador_nome}}', '{{utilizador_cargo}}', '{{data_hora_impressao}}', '{{valor}}', '{{prazo_vigencia}}', '{{objeto_contrato}}'],
      signatureZones: [
        { id: 'sz-contratante', label: 'Assinatura do Contratante', x: 5, y: 84, width: 38, height: 10, obrigatoria: true, assignedRole: 'Gestor Documental' },
        { id: 'sz-fornecedor', label: 'Assinatura do Fornecedor', x: 57, y: 84, width: 38, height: 10, obrigatoria: true, assignedRole: 'Técnico' },
      ],
      watermark, versao: 1, ativo: true, criadoEm: iso('2024-01-15'),
    },
  ]);

  // ── Contadores de documentos ───────────────────────────────────────────────
  console.log('🔢 A inserir contadores...');
  await Counter.insertMany([
    { _id: 'entrada:2024', seq: 2 },
    { _id: 'saida:2024',   seq: 2 },
    { _id: 'interno:2024', seq: 2 },
  ]);

  // ── Empresa (singleton) ────────────────────────────────────────────────────
  console.log('🏭 A inserir empresa...');
  await Company.insertOne({
    _id: 'company',
    nome: 'Faustware Formação e Transformação',
    nif: '5417123456',
    email: 'geral@faustware.ao',
    telefone: '+244 923 456 789',
    website: 'https://faustware.ao',
    endereco: 'Rua dos Coqueiros, 45, Luanda, Angola',
  });

  // ── Províncias de Angola (21 — inclui as 3 criadas em 2025) ─────────────────
  console.log('🗺  A inserir províncias de Angola...');
  await Province.insertMany([
    { _id: 'prov-luanda',       nome: 'Luanda',       slug: 'luanda',       ordem: 1  },
    { _id: 'prov-benguela',     nome: 'Benguela',     slug: 'benguela',     ordem: 2  },
    { _id: 'prov-huambo',       nome: 'Huambo',       slug: 'huambo',       ordem: 3  },
    { _id: 'prov-huila',        nome: 'Huíla',        slug: 'huila',        ordem: 4  },
    { _id: 'prov-malanje',      nome: 'Malanje',      slug: 'malanje',      ordem: 5  },
    { _id: 'prov-cuanza-norte', nome: 'Cuanza Norte', slug: 'cuanza-norte', ordem: 6  },
    { _id: 'prov-cuanza-sul',   nome: 'Cuanza Sul',   slug: 'cuanza-sul',   ordem: 7  },
    { _id: 'prov-lunda-norte',  nome: 'Lunda Norte',  slug: 'lunda-norte',  ordem: 8  },
    { _id: 'prov-lunda-sul',    nome: 'Lunda Sul',    slug: 'lunda-sul',    ordem: 9  },
    { _id: 'prov-bie',          nome: 'Bié',          slug: 'bie',          ordem: 10 },
    { _id: 'prov-moxico',       nome: 'Moxico',       slug: 'moxico',       ordem: 11 },
    { _id: 'prov-cubango',      nome: 'Cubango',      slug: 'cubango',      ordem: 12 },
    { _id: 'prov-cunene',       nome: 'Cunene',       slug: 'cunene',       ordem: 13 },
    { _id: 'prov-namibe',       nome: 'Namibe',       slug: 'namibe',       ordem: 14 },
    { _id: 'prov-bengo',        nome: 'Bengo',        slug: 'bengo',        ordem: 15 },
    { _id: 'prov-uige',         nome: 'Uíge',         slug: 'uige',         ordem: 16 },
    { _id: 'prov-zaire',        nome: 'Zaire',        slug: 'zaire',        ordem: 17 },
    { _id: 'prov-cabinda',      nome: 'Cabinda',      slug: 'cabinda',      ordem: 18 },
    // Províncias criadas em 2025
    { _id: 'prov-icolo-bengo',  nome: 'Icolo e Bengo', slug: 'icolo-e-bengo', ordem: 19 },
    { _id: 'prov-moxico-leste', nome: 'Moxico Leste',  slug: 'moxico-leste',  ordem: 20 },
    { _id: 'prov-cuando',       nome: 'Cuando',        slug: 'cuando',        ordem: 21 },
  ]);

  console.log('\n✅ Seed concluído com sucesso!\n');
  console.log('   Credenciais demo (password: faustware123):');
  console.log('   • admin@faustware.ao  (Administrador)');
  console.log('   • gestor@faustware.ao (Gestor)');
  console.log('   • colaborador@faustware.ao (Colaborador)\n');

  await mongoose.disconnect();
}

void uuidv4; // referenciado para import válido
seed().catch((err) => {
  console.error('❌ Seed falhou:', err);
  void mongoose.disconnect();
  process.exit(1);
});
