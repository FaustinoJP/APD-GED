import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type CompanyDocument = HydratedDocument<Company> & { _id: string };

// Documento singleton — _id fixo 'company'
@Schema({ collection: 'company', timestamps: false })
export class Company {
  @Prop({ type: String, default: 'company' })
  _id: string;

  @Prop({ required: true })
  nome: string;

  @Prop()
  nif?: string;

  @Prop()
  email?: string;

  @Prop()
  telefone?: string;

  @Prop()
  website?: string;

  @Prop()
  endereco?: string;

  /** dataURL do logótipo */
  @Prop()
  logoUrl?: string;
}

export const CompanySchema = SchemaFactory.createForClass(Company);
