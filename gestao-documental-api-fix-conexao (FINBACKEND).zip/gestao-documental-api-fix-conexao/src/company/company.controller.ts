import { Body, Controller, Get, Put } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { CompanyService } from './company.service';
import { CompanyResponseDto, UpdateCompanyDto } from './dto/company.dto';
import { RequirePermissions } from '../auth/decorators/require-permissions.decorator';

@ApiTags('company')
@ApiBearerAuth()
@Controller('company')
export class CompanyController {
  constructor(private readonly service: CompanyService) {}

  @Get()
  @ApiOperation({ summary: 'Obter configurações da empresa' })
  async get(): Promise<CompanyResponseDto> {
    const doc = await this.service.get();
    const { nome, nif, email, telefone, website, endereco, logoUrl } = doc.toJSON() as any;
    return { nome, nif, email, telefone, website, endereco, logoUrl };
  }

  @Put()
  @RequirePermissions('config.company.manage')
  @ApiOperation({ summary: 'Actualizar configurações da empresa' })
  async update(@Body() dto: UpdateCompanyDto): Promise<CompanyResponseDto> {
    const doc = await this.service.update(dto);
    const { nome, nif, email, telefone, website, endereco, logoUrl } = doc.toJSON() as any;
    return { nome, nif, email, telefone, website, endereco, logoUrl };
  }
}
