import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class UpdateCompanyDto {
  @ApiProperty({ example: 'Faustware Lda.' })
  @IsString()
  nome: string;

  @ApiProperty({ required: false, example: '123456789' })
  @IsOptional()
  @IsString()
  nif?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  email?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  telefone?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  website?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  endereco?: string;

  @ApiProperty({ required: false, description: 'dataURL do logótipo' })
  @IsOptional()
  @IsString()
  logoUrl?: string;
}

export class CompanyResponseDto {
  @ApiProperty()
  nome: string;

  @ApiProperty({ required: false })
  nif?: string;

  @ApiProperty({ required: false })
  email?: string;

  @ApiProperty({ required: false })
  telefone?: string;

  @ApiProperty({ required: false })
  website?: string;

  @ApiProperty({ required: false })
  endereco?: string;

  @ApiProperty({ required: false })
  logoUrl?: string;
}
