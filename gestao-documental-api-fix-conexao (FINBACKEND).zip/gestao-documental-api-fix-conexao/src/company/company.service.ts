import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Company, CompanyDocument } from './schemas/company.schema';
import { UpdateCompanyDto } from './dto/company.dto';

const SINGLETON_ID = 'company';

@Injectable()
export class CompanyService {
  constructor(
    @InjectModel(Company.name)
    private readonly model: Model<CompanyDocument>,
  ) {}

  async get(): Promise<CompanyDocument> {
    const existing = await this.model.findById(SINGLETON_ID).exec();
    if (existing) return existing;
    // Cria o documento singleton na primeira chamada
    const created = new this.model({ _id: SINGLETON_ID, nome: 'Empresa' });
    return created.save();
  }

  async update(dto: UpdateCompanyDto): Promise<CompanyDocument> {
    return this.model
      .findByIdAndUpdate(
        SINGLETON_ID,
        { $set: dto },
        { new: true, upsert: true },
      )
      .exec() as Promise<CompanyDocument>;
  }
}
