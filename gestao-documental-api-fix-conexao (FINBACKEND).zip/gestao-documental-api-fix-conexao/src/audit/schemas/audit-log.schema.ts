import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

export type AuditLogDocument = HydratedDocument<AuditLog> & { _id: string };

@Schema({ collection: 'audit_logs', timestamps: false })
export class AuditLog {
  @Prop({ type: String, default: () => uuidv4() })
  _id: string;

  @Prop({
    required: true,
    enum: [
      'visualizado', 'cadastrado', 'atualizado', 'eliminado',
      'encaminhado', 'assinado', 'aprovado', 'rejeitado',
      'exportado', 'login',
    ],
  })
  evento: string;

  @Prop({ required: true })
  tabela: string;

  @Prop()
  registroId?: string;

  @Prop({ required: true })
  userId: string;

  @Prop({ required: true })
  ip: string;

  @Prop({ required: true })
  data: string;

  @Prop()
  detalhe?: string;
}

export const AuditLogSchema = SchemaFactory.createForClass(AuditLog);

AuditLogSchema.index({ userId: 1 });
AuditLogSchema.index({ tabela: 1, registroId: 1 });
AuditLogSchema.index({ data: -1 });
