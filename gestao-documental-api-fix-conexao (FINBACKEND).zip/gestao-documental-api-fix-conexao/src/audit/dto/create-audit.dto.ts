import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';

const EVENTOS = [
  'visualizado', 'cadastrado', 'atualizado', 'eliminado',
  'encaminhado', 'assinado', 'aprovado', 'rejeitado',
  'exportado', 'login',
] as const;

/**
 * O ApiStorageAdapter envia o objecto completo do cache (incluindo userId e ip).
 * Todos os campos são declarados para passar o forbidNonWhitelisted:true.
 * O controlador ignora userId e ip do body e usa sempre os valores do JWT/request.
 */
export class CreateAuditDto {
  @ApiProperty({ required: false, description: 'UUID gerado pelo cliente (preservado no backend)' })
  @IsOptional()
  @IsString()
  id?: string;

  @ApiProperty({ enum: EVENTOS })
  @IsEnum(EVENTOS)
  evento: string;

  @ApiProperty({ example: 'company' })
  @IsString()
  tabela: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  registroId?: string;

  @ApiProperty({ required: false, description: 'Ignorado — derivado do JWT no servidor.' })
  @IsOptional()
  @IsString()
  userId?: string;

  @ApiProperty({ required: false, description: 'Ignorado — derivado do request no servidor.' })
  @IsOptional()
  @IsString()
  ip?: string;

  @ApiProperty({ required: false, description: 'ISO string. Se omitido, o servidor define.' })
  @IsOptional()
  @IsString()
  data?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  detalhe?: string;
}
