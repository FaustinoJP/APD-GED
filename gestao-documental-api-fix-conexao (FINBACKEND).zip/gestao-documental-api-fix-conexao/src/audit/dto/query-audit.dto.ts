import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';

export class QueryAuditDto {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  userId?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  tabela?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  registroId?: string;

  @ApiProperty({
    required: false,
    enum: ['visualizado', 'cadastrado', 'atualizado', 'eliminado', 'encaminhado',
      'assinado', 'aprovado', 'rejeitado', 'exportado', 'login'],
  })
  @IsOptional()
  @IsEnum(['visualizado', 'cadastrado', 'atualizado', 'eliminado', 'encaminhado',
    'assinado', 'aprovado', 'rejeitado', 'exportado', 'login'])
  evento?: string;
}
