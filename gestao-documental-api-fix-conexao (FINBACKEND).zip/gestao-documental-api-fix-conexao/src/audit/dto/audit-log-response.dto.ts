import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { BaseResponseDto } from '../../common/dto/base.dto';

export class AuditLogResponseDto extends BaseResponseDto {
  @ApiProperty({
    enum: ['visualizado', 'cadastrado', 'atualizado', 'eliminado', 'encaminhado',
      'assinado', 'aprovado', 'rejeitado', 'exportado', 'login'],
  })
  @Expose()
  evento: string;

  @ApiProperty()
  @Expose()
  tabela: string;

  @ApiProperty({ required: false })
  @Expose()
  registroId?: string;

  @ApiProperty()
  @Expose()
  userId: string;

  @ApiProperty()
  @Expose()
  ip: string;

  @ApiProperty()
  @Expose()
  data: string;

  @ApiProperty({ required: false })
  @Expose()
  detalhe?: string;

  constructor(partial: Partial<AuditLogResponseDto>) {
    super(partial);
    Object.assign(this, partial);
  }
}
