import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import { AuditLog, AuditLogDocument } from './schemas/audit-log.schema';
import { QueryAuditDto } from './dto/query-audit.dto';

export interface CreateAuditData {
  id?: string;
  evento: string;
  tabela: string;
  registroId?: string;
  userId: string;
  ip: string;
  data?: string;
  detalhe?: string;
}

@Injectable()
export class AuditService {
  constructor(
    @InjectModel(AuditLog.name)
    private readonly model: Model<AuditLogDocument>,
  ) {}

  async log(data: CreateAuditData): Promise<AuditLogDocument> {
    const entry = new this.model({
      _id: data.id ?? uuidv4(),
      evento: data.evento,
      tabela: data.tabela,
      registroId: data.registroId,
      userId: data.userId,
      ip: data.ip,
      data: data.data ?? new Date().toISOString(),
      detalhe: data.detalhe,
    });
    return entry.save();
  }

  async findAll(query: QueryAuditDto): Promise<AuditLogDocument[]> {
    const filter: Record<string, unknown> = {};
    if (query.userId) filter.userId = query.userId;
    if (query.tabela) filter.tabela = query.tabela;
    if (query.registroId) filter.registroId = query.registroId;
    if (query.evento) filter.evento = query.evento;
    return this.model.find(filter).sort({ data: -1 }).exec();
  }
}
