import { Body, Controller, Get, Post, Query, Req } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { plainToInstance } from 'class-transformer';
import { Request } from 'express';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { RequirePermissions } from '../auth/decorators/require-permissions.decorator';
import { JwtPayload } from '../common/types/jwt-payload.interface';
import { AuditService } from './audit.service';
import { CreateAuditDto } from './dto/create-audit.dto';
import { QueryAuditDto } from './dto/query-audit.dto';
import { AuditLogResponseDto } from './dto/audit-log-response.dto';

@ApiTags('audit')
@ApiBearerAuth('access-token')
@Controller('audit')
export class AuditController {
  constructor(private readonly service: AuditService) {}

  @Get()
  @RequirePermissions('audit.read')
  @ApiOperation({ summary: 'Listar registos de auditoria' })
  @ApiResponse({ status: 200, type: [AuditLogResponseDto] })
  async findAll(@Query() query: QueryAuditDto): Promise<AuditLogResponseDto[]> {
    const docs = await this.service.findAll(query);
    return docs.map((d) =>
      plainToInstance(AuditLogResponseDto, d.toJSON(), {
        excludeExtraneousValues: true,
      }),
    );
  }

  @Post()
  @ApiOperation({
    summary: 'Registar entrada de auditoria (criada pelo frontend)',
    description:
      'userId é sempre derivado do JWT — o campo userId no body é ignorado. ' +
      'ip é derivado do request. O campo id do body é preservado para manter ' +
      'consistência com o cache do ApiStorageAdapter.',
  })
  @ApiResponse({ status: 201, type: AuditLogResponseDto })
  async create(
    @Body() dto: CreateAuditDto,
    @CurrentUser() user: JwtPayload,
    @Req() req: Request,
  ): Promise<AuditLogResponseDto> {
    const doc = await this.service.log({
      id: dto.id,
      evento: dto.evento,
      tabela: dto.tabela,
      registroId: dto.registroId,
      // userId e ip derivados do contexto do servidor — nunca do body
      userId: user.sub,
      ip: req.ip ?? req.socket?.remoteAddress ?? '127.0.0.1',
      data: dto.data,
      detalhe: dto.detalhe,
    });
    return plainToInstance(AuditLogResponseDto, doc.toJSON(), {
      excludeExtraneousValues: true,
    });
  }
}
