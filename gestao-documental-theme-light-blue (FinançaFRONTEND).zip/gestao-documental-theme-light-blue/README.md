# faustware GD — Gestão Documental

Sistema de gestão documental para entidades da Administração Pública angolana. MVP com localStorage como camada de persistência, desenhado para migração directa para API REST.

---

## Stack

| Camada | Tecnologia |
|---|---|
| Framework | Next.js 16.2 (App Router, Turbopack) |
| UI | Tailwind CSS v4 + shadcn/ui (Radix primitives) |
| Estado global | Zustand v5 (persist middleware) |
| Formulários | React Hook Form + Zod |
| Gráficos | Recharts 3.8 |
| Persistência | localStorage via adapter pattern (swap-ready para API) |
| Datas | date-fns v4 (locale pt-BR) |
| Notificações | Sonner (toasts) |
| Ícones | Lucide React |
| Tipagem | TypeScript 5, strict mode |

---

## Como rodar

```bash
# Instalar dependências
npm install

# Servidor de desenvolvimento
npm run dev          # http://localhost:3000

# Build de produção
npm run build
npm start

# Typecheck
npx tsc --noEmit
```

Na primeira abertura o browser detecta a ausência do sentinel `gd:seeded` e executa `seedDatabase()`, populando o localStorage com dados de demonstração.

---

## Utilizadores de teste

| Nome | E-mail | Papel | Palavra-passe |
|---|---|---|---|
| Admin Sistema | `admin@faustware.ao` | Administrador (todas as permissões) | qualquer valor não vazio |
| Gestor Documentos | `gestor@faustware.ao` | Gestor Documental | qualquer valor não vazio |
| Chefe Depart. | `chefe@faustware.ao` | Chefe de Departamento | qualquer valor não vazio |
| Técnico | `tecnico@faustware.ao` | Técnico | qualquer valor não vazio |
| faustware Formação (Portal) | `entidade@portal.ao` | Entidade Externa | qualquer valor não vazio |

> **Mock de autenticação:** o campo de palavra-passe apenas verifica que não está vazio. Para implementação real, substitua o corpo de `useAuthStore.login()` por uma chamada `fetch` à sua API de autenticação.

### Limpar dados e repor dataset

Aceda a **Configurações → Empresa → Zona de risco → Repor dados de demonstração**, ou em consola:

```js
localStorage.clear(); location.reload();
```

---

## Estrutura de pastas

```
src/
├── app/
│   ├── (app)/               # Área administrativa (com sidebar)
│   │   ├── page.tsx         # Dashboard
│   │   ├── pendentes/       # Circulações pendentes
│   │   ├── pesquisas/       # Pesquisa de documentos
│   │   ├── registro/        # Entrada / Saída / Interno
│   │   ├── documentos/      # Ficha + preview de documento
│   │   ├── arquivos/        # Gerenciador de arquivos (árvore virtual)
│   │   ├── exportacoes/     # Centro de exportação CSV/JSON
│   │   └── configuracoes/   # Tipos, Templates, Entidades, Utilizadores,
│   │                        # Permissões, Auditoria, Empresa
│   ├── (auth)/              # Login administrativo
│   └── (portal)/            # Portal das Entidades (layout próprio)
│       └── portal/          # Dashboard + login do portal externo
│
├── components/
│   ├── auth/                # AuthGuard, PermissionGuard, Can
│   ├── circulacao/          # CirculationResponsePanel, SignatureDialog, …
│   ├── common/              # DataTable, PageHeader, ConfirmDialog, …
│   ├── documentos/          # AttachmentManager, ForwardDialog, …
│   ├── layout/              # Sidebar, Topbar, AppShell
│   ├── providers/           # SeedProvider, Providers
│   ├── registro/            # DocumentForm, FileDropZone, RecipientSelector
│   └── ui/                  # shadcn/ui primitives (Button, Dialog, …)
│
├── data/
│   └── seed.ts              # Dataset de demonstração (idempotente)
│
├── hooks/
│   ├── use-permissions.ts   # Hook can(permission) derivado do auth store
│   └── use-sidebar.ts       # Estado da sidebar
│
├── lib/
│   └── db/
│       ├── storage.ts       # StorageAdapter interface + LocalStorageAdapter
│       ├── repository.ts    # Factory genérico (list/get/create/update/remove/query)
│       ├── repositories.ts  # Instâncias nomeadas de cada colecção
│       ├── index.ts         # Re-exports + clearAppData()
│       └── apiAdapter.ts    # Skeleton para migração para API REST
│
├── store/                   # Zustand stores (auth, config, circulation, …)
└── types/index.ts           # Todos os tipos do domínio
```

---

## Modelo de dados (resumo)

```
Role ──< Permission[]
User >── Role

DocumentType ──< CustomField[]
DocumentRecord ──< Attachment[]
DocumentRecord ──< Circulation ──< CirculationResponse
DocumentRecord → AuditLog

Entity  (entidade externa)
Folder  (hierárquica, parentId)
Dossier ──< DocumentRecord[]
Notification → User
DocumentTemplate  (HTML com {{placeholders}})
CompanySettings   (singleton)
```

Todas as colecções são arrays JSON guardados em localStorage com chave `gd:<nome>`. O campo `id` é um UUID gerado por `crypto.randomUUID()`.

---

## Mapa de permissões

| Permissão | O que protege |
|---|---|
| `dashboard.view` | Página de dashboard |
| `documents.read` | Listar e ver documentos |
| `documents.create` | Registar entrada/saída/interno |
| `documents.update` | Editar campos de documento |
| `documents.delete` | Eliminar documento |
| `documents.forward` | Encaminhar / circular documento |
| `documents.sign` | Assinar documento |
| `documents.approve` | Aprovar documento |
| `documents.giveOpinion` | Emitir parecer |
| `documents.dispatch` | Despachar |
| `documents.defer` | Deferir |
| `documents.archive` | Arquivar |
| `documents.export` | Exportar documento individual |
| `config.types.manage` | CRUD de tipos de documento |
| `config.templates.manage` | CRUD de templates |
| `config.entities.manage` | CRUD de entidades externas |
| `config.users.manage` | CRUD de utilizadores |
| `config.permissions.manage` | Gestão de papéis e permissões |
| `config.company.manage` | Configurações da empresa |
| `audit.read` | Ver log de auditoria |
| `exports.run` | Centro de exportações |
| `files.manage` | Gerenciador de arquivos |
| `notifications.read` | Ver notificações |

### Papéis pré-definidos

| Papel | Permissões notáveis |
|---|---|
| Administrador | Todas |
| Gestor Documental | Documentos (tudo) + config básicas |
| Chefe de Departamento | documents.read/approve/sign/dispatch |
| Técnico | documents.read/create/forward |
| Entidade Externa | documents.read/create/forward + notifications |

---

## Como migrar para API real

A camada de persistência está totalmente abstraída atrás de `StorageAdapter`. A migração é cirúrgica:

### 1. Variáveis de ambiente

```env
# .env.local
NEXT_PUBLIC_DATA_SOURCE=api
NEXT_PUBLIC_API_BASE_URL=https://sua-api.exemplo.com/v1
```

### 2. Activar o ApiStorageAdapter

Em `src/lib/db/repositories.ts`, substitua:

```ts
import { storageAdapter } from './storage';
```

por:

```ts
import { getAdapter } from './apiAdapter';
const storageAdapter = getAdapter();
```

### 3. Implementar os métodos

Abra `src/lib/db/apiAdapter.ts` e substitua cada `throw new Error(...)` pela chamada HTTP correspondente. O ficheiro tem comentários detalhando o mapeamento chave → endpoint.

### 4. Tratar assincronismo

O `Repository<T>` é síncrono por design (compatibilidade com Zustand). Para APIs assíncronas, a abordagem recomendada é usar **React Query** para pre-fetch das colecções e servir a cache sincronamente ao adapter.

### 5. Autenticação real

Substitua o corpo de `useAuthStore.login()` em `src/store/auth-store.ts`:

```ts
login: async (email, senha) => {
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, senha }),
    headers: { 'Content-Type': 'application/json' },
  });
  if (!res.ok) return { ok: false, error: (await res.json()).message };
  const { user, role, token } = await res.json();
  localStorage.setItem('gd:token', token); // ou cookie httpOnly
  set({ currentUser: user, currentRole: role, isAuthenticated: true });
  return { ok: true };
},
```

---

## Decisões de arquitectura

**localStorage como persistência de MVP** — permite demonstrar o produto sem infra-estrutura. A arquitectura de repositórios garante que a troca para API não altera nenhum componente React.

**Zustand em vez de Context** — subscriptions selectivas evitam re-renders em tabelas grandes. O middleware `persist` serializa o estado de sessão automaticamente.

**App Router (Next.js)** — prepara o projecto para Server Components e Server Actions quando a API REST estiver pronta, sem alterar estrutura de pastas.

**Seed idempotente** — `seedDatabase()` verifica o sentinel `gd:seeded` antes de escrever qualquer dado. Seguro chamar múltiplas vezes.

**RBAC no cliente** — as permissões escondem elementos de UI para melhorar a experiência. A autorização real **deve** ser reforçada no servidor quando a API estiver ligada.

**Portal das Entidades** — route group `(portal)` com layout separado (sem sidebar). Demonstra isolamento multi-papel num único sistema.

---

## Checklist de módulos MVP

| Módulo | Estado |
|---|---|
| Registo de Entrada | ✅ |
| Registo de Saída | ✅ |
| Registo Interno | ✅ |
| Formulário dinâmico (campos custom) | ✅ |
| Lista de Documentos | ✅ |
| Ficha de Documento | ✅ |
| Preview de anexos | ✅ |
| Gestão de anexos (check-in/out, versões) | ✅ |
| Circulação (encaminhar, aprovar, assinar, parecer) | ✅ |
| Pendentes | ✅ |
| Resposta a circulação | ✅ |
| Assinatura + Certificado Digital (mock) | ✅ |
| Tipos de documento + Form Builder | ✅ |
| Templates HTML | ✅ |
| Entidades externas | ✅ |
| Utilizadores (CRUD + reset senha) | ✅ |
| Permissões (matrix por papel) | ✅ |
| Empresa (logo, NIF, contactos) | ✅ |
| Gerenciador de Arquivos | ✅ |
| Auditoria | ✅ |
| Dashboard | ✅ |
| Exportações (CSV + JSON segmentado) | ✅ |
| Portal das Entidades | ✅ |
| Notificações (dropdown, marcar lida) | ✅ |
| Busca global (topbar) | ✅ |
| RBAC (sidebar + page guards) | ✅ |
| Hardening (corrupt detection + reset demo) | ✅ |
| Camada API-ready (adapter skeleton) | ✅ |
