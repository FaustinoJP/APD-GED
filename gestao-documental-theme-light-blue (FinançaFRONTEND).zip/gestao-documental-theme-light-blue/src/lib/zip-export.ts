/**
 * Empacotamento de exportações num único ZIP: planilha Excel na raiz +
 * ficheiros anexos organizados por tipo/categoria de documento.
 *
 * Estrutura gerada:
 *   _resumo.xlsx
 *   ficheiros/{Categoria}/{numero}_{nome}
 *
 * O `jszip` é importado dinamicamente para lazy-load (fora do bundle inicial).
 */

import { documentTypesRepo } from '@/lib/db';
import { resolveFileUrl } from '@/lib/file-url';
import type { Attachment, DocumentRecord } from '@/types';

const ZIP_MIME = 'application/zip';

/** Normaliza o formato/extensão de um anexo para o padrão ".ext" minúsculo. */
export function normalizeExt(formato: string | undefined, nome: string): string {
  let ext = (formato ?? '').trim().toLowerCase();
  if (!ext && nome.includes('.')) ext = nome.split('.').pop() ?? '';
  ext = ext.replace(/^.*\//, '').replace(/^\./, ''); // 'application/pdf' → 'pdf'
  return ext ? `.${ext}` : '';
}

/** Garante que o nome do ficheiro termina com a extensão. */
export function ensureFileName(nome: string, ext: string): string {
  if (!ext) return nome;
  return nome.toLowerCase().endsWith(ext) ? nome : `${nome}${ext}`;
}

/** Sanitiza um segmento (pasta ou ficheiro) para um caminho de ZIP seguro. */
function sanitizeSegment(value: string): string {
  const clean = value
    .replace(/[\\/:*?"<>|]/g, '-') // caracteres inválidos em nomes de ficheiro
    .replace(/\s+/g, ' ')
    .trim();
  return clean || '_';
}

/** Um URL considera-se "mock"/não descarregável quando não aponta para um ficheiro real. */
function isMockUrl(url: string | undefined): boolean {
  return !url || url.startsWith('/mock/') || url.startsWith('mock/');
}

/** Converte um data URL (base64) num Blob. */
function dataUrlToBlob(dataUrl: string): Blob {
  const [header, base64] = dataUrl.split(',');
  const mime = /data:([^;]+)/.exec(header)?.[1] ?? 'application/octet-stream';
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

/** Obtém o conteúdo de um anexo como Blob, ou `null` se não for descarregável. */
async function fetchAttachmentBlob(anexo: Attachment): Promise<Blob | null> {
  // Ficheiro ainda em memória (upload não persistido).
  if (anexo._file) return anexo._file;

  const url = anexo.url;
  if (isMockUrl(url)) return null;

  if (url!.startsWith('data:')) {
    try {
      return dataUrlToBlob(url!);
    } catch {
      return null;
    }
  }

  const resolved = resolveFileUrl(url);
  if (!resolved) return null;
  try {
    const res = await fetch(resolved, { credentials: 'include' });
    if (!res.ok) return null;
    return await res.blob();
  } catch {
    return null;
  }
}

export interface BuildDocumentsZipOptions {
  /** Nome do ficheiro Excel colocado na raiz do ZIP. */
  xlsxFileName?: string;
}

export interface BuildDocumentsZipResult {
  blob: Blob;
  /** Nomes dos ficheiros que não puderam ser incluídos (mock/indisponíveis). */
  missing: string[];
  /** Total de ficheiros efetivamente adicionados ao ZIP. */
  included: number;
}

/**
 * Constrói um ZIP com a planilha Excel na raiz e os ficheiros anexos dos
 * documentos organizados em `ficheiros/{Categoria}/{numero}_{nome}`.
 */
export async function buildDocumentsZip(
  docs: DocumentRecord[],
  xlsxBuffer: ArrayBuffer,
  opts: BuildDocumentsZipOptions = {},
): Promise<BuildDocumentsZipResult> {
  const JSZip = (await import('jszip')).default;
  const zip = new JSZip();

  zip.file(opts.xlsxFileName ?? '_resumo.xlsx', xlsxBuffer);

  const raiz = zip.folder('ficheiros')!;
  const categoriaDe = (id: string) => documentTypesRepo.getById(id)?.nome ?? 'Sem categoria';

  const missing: string[] = [];
  let included = 0;
  // Evita colisões de nome dentro da mesma pasta de categoria.
  const usados = new Set<string>();

  for (const doc of docs) {
    const categoria = sanitizeSegment(categoriaDe(doc.tipoDocumentoId));
    for (const anexo of doc.anexos ?? []) {
      const ext = normalizeExt(anexo.formato, anexo.nome);
      const base = sanitizeSegment(`${doc.numero}_${ensureFileName(anexo.nome, ext)}`);

      const blob = await fetchAttachmentBlob(anexo);
      if (!blob) {
        missing.push(`${doc.numero} — ${anexo.nome}`);
        continue;
      }

      let nomeFinal = `${categoria}/${base}`;
      let n = 1;
      while (usados.has(nomeFinal)) {
        nomeFinal = `${categoria}/${base.replace(/(\.[^.]+)?$/, ` (${n})$1`)}`;
        n += 1;
      }
      usados.add(nomeFinal);

      raiz.file(nomeFinal, blob);
      included += 1;
    }
  }

  const blob = await zip.generateAsync({ type: 'blob', mimeType: ZIP_MIME });
  return { blob, missing, included };
}

/** Conta os anexos descarregáveis (com ficheiro real) de um conjunto de documentos. */
export function countDownloadableAnexos(docs: DocumentRecord[]): { count: number; bytes: number } {
  let count = 0;
  let bytes = 0;
  for (const doc of docs) {
    for (const anexo of doc.anexos ?? []) {
      if (anexo._file || !isMockUrl(anexo.url)) {
        count += 1;
        bytes += anexo.tamanho ?? 0;
      }
    }
  }
  return { count, bytes };
}

/** Cria um download a partir do Blob do ZIP. */
export function downloadZipBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
