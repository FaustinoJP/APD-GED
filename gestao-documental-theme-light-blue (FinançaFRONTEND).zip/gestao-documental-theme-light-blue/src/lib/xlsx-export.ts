/**
 * Geração de ficheiros Excel (.xlsx) para a página de Exportações.
 *
 * `buildAnexosWorkbook` replica o layout do ficheiro de referência
 * `anexos_organizado.xlsx` (3 folhas: Dados, Resumo, Notas — sem o gráfico,
 * que não é suportado pela biblioteca exceljs no browser).
 *
 * `buildSimpleWorkbook` produz um .xlsx de 1 folha para os restantes recursos.
 *
 * O exceljs é importado dinamicamente nos handlers para fazer lazy-load.
 */

// Tipo mínimo do exceljs que usamos (evita acoplar tipos no topo do bundle).
type ExcelJSModule = typeof import('exceljs');

const XLSX_MIME =
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

/** Chaves esperadas em cada linha de anexo (snake_case, partilhadas com a preview/CSV). */
export const ANEXO_KEYS = [
  'id',
  'nome',
  'tamanho_bytes',
  'tamanho_mb',
  'versao',
  'extensao',
  'tipo_direcao',
  'estado',
  'criado_por',
  'atualizado_por',
  'caminho',
  'categoria',
  'ano',
  'pasta_registo',
  'ficheiro',
] as const;

/** Cabeçalhos exatos das 15 colunas da folha "Dados" (iguais ao ficheiro de referência). */
const DADOS_HEADERS = [
  'ID',
  'Nome do ficheiro',
  'Tamanho (bytes)',
  'Tamanho (MB)',
  'Versão',
  'Extensão',
  'Tipo/Direção',
  'Estado',
  'Criado por',
  'Atualizado por',
  'Caminho',
  'Categoria',
  'Ano',
  'Pasta/Registo',
  'Ficheiro no caminho',
];

const DADOS_WIDTHS = [9, 38, 16, 13, 9, 10, 13, 12, 30, 30, 62, 28, 9, 15, 38];

export interface AnexosExportMeta {
  /** Linhas de descrição dos filtros aplicados (folha Notas + subtítulo). */
  fonte: string;
  escopoLabel: string;
  utilizadorLabel?: string;
  regiaoLabel?: string;
  localizacaoLabel?: string;
  periodoLabel: string;
}

const HEADER_FILL = 'FF4F46E5'; // indigo-600
const TITLE_FILL = 'FF312E81'; // indigo-900
const STRIPE_FILL = 'FFEEF2FF'; // indigo-50

function num(v: unknown): number {
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
}

function str(v: unknown): string {
  return v == null ? '' : String(v);
}

/** Constrói o workbook rico de 3 folhas para os anexos. */
export async function buildAnexosWorkbook(
  rows: Record<string, unknown>[],
  meta: AnexosExportMeta,
): Promise<ArrayBuffer> {
  const ExcelJS: ExcelJSModule = (await import('exceljs')).default;
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Gestão Documental';

  // ─── Folha Dados ──────────────────────────────────────────────────────────
  const dados = wb.addWorksheet('Dados');
  DADOS_WIDTHS.forEach((w, i) => { dados.getColumn(i + 1).width = w; });

  // Título (linha 1) + subtítulo (linha 2), mesclados em A:O.
  dados.mergeCells(1, 1, 1, 15);
  const t1 = dados.getCell('A1');
  t1.value = 'Anexos - Base organizada';
  t1.font = { bold: true, size: 14, color: { argb: 'FFFFFFFF' } };
  t1.alignment = { vertical: 'middle' };
  t1.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: TITLE_FILL } };
  dados.getRow(1).height = 28;

  dados.mergeCells(2, 1, 2, 15);
  const t2 = dados.getCell('A2');
  t2.value = meta.fonte;
  t2.font = { italic: true, size: 10, color: { argb: 'FF475569' } };
  dados.getRow(2).height = 20;

  // Tabela TabelaAnexos: header na linha 4, dados a partir da 5.
  const lastRow = 4 + rows.length;
  dados.addTable({
    name: 'TabelaAnexos',
    ref: 'A4',
    headerRow: true,
    style: { theme: 'TableStyleMedium2', showRowStripes: true },
    columns: DADOS_HEADERS.map((name) => ({ name, filterButton: true })),
    rows: rows.map((r) => [
      num(r.id),
      str(r.nome),
      num(r.tamanho_bytes),
      num(r.tamanho_mb), // substituído por fórmula abaixo
      num(r.versao),
      str(r.extensao),
      str(r.tipo_direcao),
      str(r.estado),
      str(r.criado_por),
      str(r.atualizado_por),
      str(r.caminho),
      str(r.categoria),
      str(r.ano),
      str(r.pasta_registo),
      str(r.ficheiro),
    ]),
  });

  // Estilo do cabeçalho da tabela (linha 4) + fórmula da coluna Tamanho (MB).
  const headerRow = dados.getRow(4);
  headerRow.height = 32;
  headerRow.eachCell((cell) => {
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: HEADER_FILL } };
    cell.alignment = { vertical: 'middle', wrapText: true };
  });
  for (let i = 0; i < rows.length; i++) {
    const excelRow = 5 + i;
    const mb = num(rows[i].tamanho_mb);
    dados.getCell(`D${excelRow}`).value = { formula: `C${excelRow}/1048576`, result: mb };
    dados.getCell(`D${excelRow}`).numFmt = '0.000';
  }

  // ─── Folha Resumo ─────────────────────────────────────────────────────────
  const resumo = wb.addWorksheet('Resumo');
  [32, 14, 16, 4, 36, 14, 16].forEach((w, i) => { resumo.getColumn(i + 1).width = w; });

  resumo.mergeCells(1, 1, 1, 10);
  const r1 = resumo.getCell('A1');
  r1.value = 'Resumo dos anexos';
  r1.font = { bold: true, size: 14, color: { argb: 'FFFFFFFF' } };
  r1.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: TITLE_FILL } };
  resumo.getRow(1).height = 28;

  const dataRef = (col: string) => `Dados!$${col}$5:$${col}$${lastRow}`;

  // Indicadores (A3:B8).
  const indHead = (cell: string, text: string) => {
    const c = resumo.getCell(cell);
    c.value = text;
    c.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: HEADER_FILL } };
  };
  indHead('A3', 'Indicador');
  indHead('B3', 'Valor');

  const extPredominante = modeOf(rows.map((r) => str(r.extensao)).filter(Boolean));
  const indicators: [string, { formula: string; result: number } | string][] = [
    ['Total de anexos', { formula: `COUNTA(${dataRef('A')})`, result: rows.length }],
    ['Tamanho total (MB)', { formula: `SUM(${dataRef('D')})`, result: sum(rows, 'tamanho_mb') }],
    ['Tamanho médio (MB)', { formula: `AVERAGE(${dataRef('D')})`, result: rows.length ? sum(rows, 'tamanho_mb') / rows.length : 0 }],
    ['Maior ficheiro (MB)', { formula: `MAX(${dataRef('D')})`, result: maxOf(rows, 'tamanho_mb') }],
    ['Extensão predominante', extPredominante || '—'],
  ];
  indicators.forEach(([label, value], i) => {
    const row = 4 + i;
    const a = resumo.getCell(`A${row}`);
    a.value = label;
    a.font = { bold: true };
    a.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: STRIPE_FILL } };
    const b = resumo.getCell(`B${row}`);
    b.value = value as never;
    if (typeof value !== 'string') b.numFmt = label === 'Total de anexos' ? '0' : '0.000';
  });

  // Tabela ResumoCategorias (A11:C…) — categorias distintas, ordenadas por contagem desc.
  const categorias = countBy(rows, 'categoria');
  resumo.addTable({
    name: 'ResumoCategorias',
    ref: 'A11',
    headerRow: true,
    style: { theme: 'TableStyleMedium2', showRowStripes: true },
    columns: [{ name: 'Categoria' }, { name: 'Qtd.' }, { name: 'Tamanho (MB)' }],
    rows: categorias.map((c) => [c.key, c.count, c.mb]),
  });
  styleTableHeader(resumo, 11, ['A', 'B', 'C']);
  categorias.forEach((c, i) => {
    const row = 12 + i;
    resumo.getCell(`B${row}`).value = { formula: `COUNTIF(${dataRef('L')},A${row})`, result: c.count };
    resumo.getCell(`C${row}`).value = { formula: `SUMIF(${dataRef('L')},A${row},${dataRef('D')})`, result: c.mb };
    resumo.getCell(`C${row}`).numFmt = '0.000';
  });

  // Tabela ResumoEmails (E11:G…) — "Criado por" distintos.
  const emails = countBy(rows, 'criado_por', 'tamanho_mb');
  resumo.addTable({
    name: 'ResumoEmails',
    ref: 'E11',
    headerRow: true,
    style: { theme: 'TableStyleMedium2', showRowStripes: true },
    columns: [{ name: 'Utilizador / Email' }, { name: 'Qtd.' }, { name: 'Tamanho (MB)' }],
    rows: emails.map((c) => [c.key, c.count, c.mb]),
  });
  styleTableHeader(resumo, 11, ['E', 'F', 'G']);
  emails.forEach((c, i) => {
    const row = 12 + i;
    resumo.getCell(`F${row}`).value = { formula: `COUNTIF(${dataRef('I')},E${row})`, result: c.count };
    resumo.getCell(`G${row}`).value = { formula: `SUMIF(${dataRef('I')},E${row},${dataRef('D')})`, result: c.mb };
    resumo.getCell(`G${row}`).numFmt = '0.000';
  });

  // ─── Folha Notas ──────────────────────────────────────────────────────────
  const notas = wb.addWorksheet('Notas');
  notas.getColumn(1).width = 28;
  notas.getColumn(2).width = 90;
  notas.mergeCells(1, 1, 1, 2);
  const n1 = notas.getCell('A1');
  n1.value = 'Notas de exportação';
  n1.font = { bold: true, size: 14, color: { argb: 'FFFFFFFF' } };
  n1.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: TITLE_FILL } };
  notas.getRow(1).height = 28;

  const filtros = [
    `Escopo: ${meta.escopoLabel}`,
    meta.utilizadorLabel ? `Utilizador: ${meta.utilizadorLabel}` : null,
    meta.regiaoLabel ? `Região: ${meta.regiaoLabel}` : null,
    meta.localizacaoLabel ? `Localização: ${meta.localizacaoLabel}` : null,
    `Período: ${meta.periodoLabel}`,
  ].filter(Boolean).join(' | ');

  notas.addTable({
    name: 'TabelaNotas',
    ref: 'A3',
    headerRow: true,
    style: { theme: 'TableStyleMedium2', showRowStripes: true },
    columns: [{ name: 'Campo' }, { name: 'Descrição' }],
    rows: [
      ['Fonte', 'Aplicação Gestão Documental'],
      ['Registos exportados', String(rows.length)],
      ['Filtros aplicados', filtros],
      ['Coluna Tamanho (MB)', 'Calculada por fórmula: Tamanho (bytes) / 1.048.576.'],
      ['Observação', 'O gráfico de barras do ficheiro original não é incluído; a tabela ResumoCategorias permite inseri-lo manualmente.'],
    ],
  });
  styleTableHeader(notas, 3, ['A', 'B']);

  return wb.xlsx.writeBuffer() as Promise<ArrayBuffer>;
}

/** Workbook simples de 1 folha para os restantes recursos. */
export async function buildSimpleWorkbook(
  rows: Record<string, unknown>[],
  sheetName: string,
): Promise<ArrayBuffer> {
  const ExcelJS: ExcelJSModule = (await import('exceljs')).default;
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Gestão Documental';
  const ws = wb.addWorksheet(sheetName.slice(0, 31));

  const headers = rows.length ? Object.keys(rows[0]) : ['(sem dados)'];
  ws.addTable({
    name: 'Tabela' + sheetName.replace(/[^A-Za-z0-9]/g, '').slice(0, 24),
    ref: 'A1',
    headerRow: true,
    style: { theme: 'TableStyleMedium2', showRowStripes: true },
    columns: headers.map((h) => ({ name: h.replace(/_/g, ' '), filterButton: true })),
    rows: rows.length ? rows.map((r) => headers.map((h) => normalizeCell(r[h]))) : [['']],
  });
  styleTableHeader(ws, 1, headers.map((_, i) => colLetter(i + 1)));
  headers.forEach((_, i) => { ws.getColumn(i + 1).width = 22; });

  return wb.xlsx.writeBuffer() as Promise<ArrayBuffer>;
}

/** Cria um Blob a partir do buffer e dispara o download no browser. */
export function downloadArrayBuffer(buffer: ArrayBuffer, filename: string): void {
  const blob = new Blob([buffer], { type: XLSX_MIME });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// ─── Helpers internos ─────────────────────────────────────────────────────────

function normalizeCell(v: unknown): string | number {
  if (typeof v === 'number') return v;
  return v == null ? '' : String(v);
}

function colLetter(n: number): string {
  let s = '';
  while (n > 0) {
    const m = (n - 1) % 26;
    s = String.fromCharCode(65 + m) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
}

function styleTableHeader(
  ws: import('exceljs').Worksheet,
  rowIndex: number,
  cols: string[],
): void {
  cols.forEach((col) => {
    const cell = ws.getCell(`${col}${rowIndex}`);
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: HEADER_FILL } };
  });
}

function sum(rows: Record<string, unknown>[], key: string): number {
  return rows.reduce((acc, r) => acc + num(r[key]), 0);
}

function maxOf(rows: Record<string, unknown>[], key: string): number {
  return rows.reduce((acc, r) => Math.max(acc, num(r[key])), 0);
}

function modeOf(values: string[]): string {
  const counts = new Map<string, number>();
  for (const v of values) counts.set(v, (counts.get(v) ?? 0) + 1);
  let best = '';
  let bestN = 0;
  for (const [k, n] of counts) {
    if (n > bestN) { best = k; bestN = n; }
  }
  return best;
}

interface GroupCount { key: string; count: number; mb: number; }

/** Agrupa por `key`, soma o `mbKey`, e ordena por contagem desc. */
function countBy(
  rows: Record<string, unknown>[],
  key: string,
  mbKey = 'tamanho_mb',
): GroupCount[] {
  const map = new Map<string, GroupCount>();
  for (const r of rows) {
    const k = str(r[key]) || '—';
    const entry = map.get(k) ?? { key: k, count: 0, mb: 0 };
    entry.count += 1;
    entry.mb += num(r[mbKey]);
    map.set(k, entry);
  }
  return [...map.values()].sort((a, b) => b.count - a.count);
}
