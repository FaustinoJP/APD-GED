import type { Role, Permission } from '@/types';

/** Returns true if the given role includes the requested permission. */
export function hasPermission(role: Role | null | undefined, permission: Permission): boolean {
  if (!role) return false;
  return role.permissions.includes(permission);
}

/** Returns true if the role has at least one of the given permissions. */
export function hasAnyPermission(
  role: Role | null | undefined,
  permissions: Permission[],
): boolean {
  if (!role) return false;
  return permissions.some((p) => role.permissions.includes(p));
}

/** Returns true if the role has all of the given permissions. */
export function hasAllPermissions(
  role: Role | null | undefined,
  permissions: Permission[],
): boolean {
  if (!role) return false;
  return permissions.every((p) => role.permissions.includes(p));
}
