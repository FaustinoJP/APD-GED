/**
 * Funções de API para gestão de anexos de documentos.
 * Usam multipart/form-data — bypass do adapter genérico.
 */

import type { Attachment, DocumentRecord } from '@/types';
import { apiClient } from './client';

/** Adiciona um ficheiro a um documento existente via POST /:id/anexos */
export async function apiAddAnexo(
  docId: string,
  file: File,
  meta: { nome?: string; observacao?: string; versao?: number; estado?: 'check_in' | 'check_out' } = {},
): Promise<DocumentRecord> {
  const formData = new FormData();
  formData.append('file', file, meta.nome ?? file.name);
  if (meta.nome)        formData.append('nome', meta.nome);
  if (meta.observacao)  formData.append('observacao', meta.observacao);
  if (meta.versao != null) formData.append('versao', String(meta.versao));
  if (meta.estado)      formData.append('estado', meta.estado);

  const { data } = await apiClient.post<DocumentRecord>(`/documents/${docId}/anexos`, formData);
  return data;
}

/** Remove um anexo de um documento via DELETE /:id/anexos/:anexoId */
export async function apiRemoveAnexo(docId: string, anexoId: string): Promise<void> {
  await apiClient.delete(`/documents/${docId}/anexos/${anexoId}`);
}

/** Constrói FormData para criar um documento com ficheiros anexados */
export function buildCreateDocumentFormData(
  doc: Omit<DocumentRecord, 'id' | 'criadoEm' | 'atualizadoEm'> & { id?: string; criadoEm?: string; atualizadoEm?: string },
): FormData {
  const formData = new FormData();

  // Metadados do documento: remover _file e base64 dos anexos
  const meta = {
    ...doc,
    anexos: (doc.anexos ?? []).map((a: Attachment) => ({
      nome: a.nome,
      versao: a.versao,
      estado: a.estado,
      observacao: a.observacao,
    })),
  };
  formData.append('data', JSON.stringify(meta));

  // Ficheiros pela mesma ordem dos anexos
  for (const att of doc.anexos ?? []) {
    if (att._file instanceof File) {
      formData.append('files', att._file, att.nome ?? att._file.name);
    }
  }

  return formData;
}
