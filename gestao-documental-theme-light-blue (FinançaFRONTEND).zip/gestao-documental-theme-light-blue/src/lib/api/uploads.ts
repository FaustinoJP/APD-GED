import { apiClient } from './client';

export interface UploadResult {
  /** Nome do ficheiro no servidor (UUID.ext) — usado para DELETE em caso de rollback */
  id: string;
  /** URL pública do ficheiro: /uploads/documents/{id} */
  url: string;
  nome: string;
  tamanho: number;
  formato: string;
}

/** Carrega um ficheiro para o servidor imediatamente. Devolve os metadados para o formulário. */
export async function apiUploadFile(file: File): Promise<UploadResult> {
  const formData = new FormData();
  formData.append('file', file);
  const { data } = await apiClient.post<UploadResult>('/uploads', formData);
  return data;
}

/** Elimina um ficheiro do servidor (rollback quando o registo é abandonado). */
export async function apiDeleteUpload(id: string): Promise<void> {
  await apiClient.delete(`/uploads/${id}`);
}
