/**
 * Token module — armazena o access token em memória (não em localStorage).
 *
 * Razão: o access token (JWT de 15 min) deve ser de curta duração e nunca
 * exposto a scripts de página. O refresh token está em cookie httpOnly.
 * Em modo SSR o token é sempre null — a hidratação ocorre no cliente.
 */

let _accessToken: string | null = null;

export function setToken(token: string | null): void {
  _accessToken = token;
}

export function getToken(): string | null {
  return _accessToken;
}

export function clearToken(): void {
  _accessToken = null;
}
