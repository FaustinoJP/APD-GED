import type { LocationLevel, LocationNode } from '@/types';

export interface LocationTreeNode {
  node: LocationNode;
  children: LocationTreeNode[];
}

/** Monta a árvore a partir dos nós flat (parentId), ordenada por 'ordem' em cada nível. */
export function buildLocationTree(nodes: LocationNode[]): LocationTreeNode[] {
  const byParent = new Map<string | undefined, LocationNode[]>();
  for (const n of nodes) {
    const key = n.parentId;
    if (!byParent.has(key)) byParent.set(key, []);
    byParent.get(key)!.push(n);
  }
  for (const list of byParent.values()) list.sort((a, b) => a.ordem - b.ordem);

  function build(parentId: string | undefined): LocationTreeNode[] {
    return (byParent.get(parentId) ?? []).map((node) => ({
      node,
      children: build(node.id),
    }));
  }

  return build(undefined);
}

export function findLocationTreeNode(tree: LocationTreeNode[], id: string): LocationTreeNode | null {
  for (const t of tree) {
    if (t.node.id === id) return t;
    const found = findLocationTreeNode(t.children, id);
    if (found) return found;
  }
  return null;
}

/** Todos os ids desta subárvore (incluindo o próprio nó) — útil para filtrar documentos por nó intermédio. */
export function collectDescendantIds(tree: LocationTreeNode): string[] {
  return [tree.node.id, ...tree.children.flatMap(collectDescendantIds)];
}

/** Caminho da raiz até ao nó (inclusive), seguindo a cadeia de parentId. */
export function getLocationPath(nodeId: string | undefined, nodes: LocationNode[]): LocationNode[] {
  if (!nodeId) return [];
  const byId = new Map(nodes.map((n) => [n.id, n]));
  const path: LocationNode[] = [];
  let current = byId.get(nodeId);
  while (current) {
    path.unshift(current);
    current = current.parentId ? byId.get(current.parentId) : undefined;
  }
  return path;
}

/** Ex: "Sala A › Corredor 1 › Prateleira 3". */
export function getLocationLabel(nodeId: string | undefined, nodes: LocationNode[]): string {
  return getLocationPath(nodeId, nodes).map((n) => n.nome).join(' › ');
}

export function childrenOf(parentId: string | undefined, nodes: LocationNode[]): LocationNode[] {
  return nodes.filter((n) => n.parentId === parentId).sort((a, b) => a.ordem - b.ordem);
}

export function sortedLevels(levels: LocationLevel[]): LocationLevel[] {
  return [...levels].sort((a, b) => a.ordem - b.ordem);
}

/** Nível a seguir ao de 'parentNivelId' (ou o primeiro nível, se omitido). */
export function nextLevel(parentNivelId: string | undefined, levels: LocationLevel[]): LocationLevel | undefined {
  const sorted = sortedLevels(levels);
  if (!parentNivelId) return sorted[0];
  const idx = sorted.findIndex((l) => l.id === parentNivelId);
  return idx >= 0 ? sorted[idx + 1] : undefined;
}
