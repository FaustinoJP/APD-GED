/**
 * Converte um URL relativo do backend (ex: /uploads/documents/uuid.jpg)
 * num URL absoluto, usando a origem do servidor NestJS.
 *
 * Regras:
 *  - data:   → devolvido tal como está (base64, modo localStorage)
 *  - http(s) → já absoluto, devolvido tal como está
 *  - /...    → prefixado com a origem do backend
 */

const API_ORIGIN = (() => {
  try {
    return new URL(
      process.env.NEXT_PUBLIC_API_BASE_URL ?? 'http://localhost:3001/api/v1',
    ).origin;
  } catch {
    return 'http://localhost:3001';
  }
})();

export function resolveFileUrl(url: string | undefined): string | undefined {
  if (!url) return undefined;
  if (url.startsWith('data:') || url.startsWith('http')) return url;
  return `${API_ORIGIN}${url}`;
}
