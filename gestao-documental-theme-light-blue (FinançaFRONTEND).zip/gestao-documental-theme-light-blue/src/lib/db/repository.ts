/**
 * Generic repository factory backed by a StorageAdapter.
 *
 * Each collection is stored as a JSON array under a single localStorage key
 * (e.g. 'gd:documents'). All serialization lives here — components never
 * touch storage directly.
 *
 * Migration path: implement StorageAdapter with fetch calls (see apiAdapter.ts)
 * and pass it to createRepository() instead of the default LocalStorageAdapter.
 */

import type { StorageAdapter } from './storage';

export interface Repository<T extends { id: string }> {
  list(filter?: Partial<T>): T[];
  getById(id: string): T | undefined;
  create(item: Omit<T, 'id'> & { id?: string }): T;
  update(id: string, changes: Partial<T>): T | undefined;
  remove(id: string): boolean;
  query(predicate: (item: T) => boolean): T[];
}

function generateId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

export function createRepository<T extends { id: string }>(
  collectionKey: string,
  adapter: StorageAdapter,
): Repository<T> {
  function loadAll(): T[] {
    const data = adapter.get<T[]>(collectionKey);
    if (data === null) return [];
    if (!Array.isArray(data)) {
      console.warn(`[gd] Collection "${collectionKey}" contained non-array data — resetting.`);
      adapter.remove(collectionKey);
      return [];
    }
    // Deduplicate by id — guards against corrupted/duplicated storage data
    const seen = new Set<string>();
    return data.filter((item) => {
      if (seen.has(item.id)) return false;
      seen.add(item.id);
      return true;
    });
  }

  function saveAll(items: T[]): void {
    adapter.set(collectionKey, items);
  }

  return {
    list(filter?: Partial<T>): T[] {
      const items = loadAll();
      if (!filter) return items;
      return items.filter((item) =>
        (Object.entries(filter) as [keyof T, unknown][]).every(
          ([key, value]) => item[key] === value,
        ),
      );
    },

    getById(id: string): T | undefined {
      return loadAll().find((item) => item.id === id);
    },

    create(data: Omit<T, 'id'> & { id?: string }): T {
      const items = loadAll();
      const item = { ...data, id: data.id ?? generateId() } as T;
      const existing = items.findIndex((i) => i.id === item.id);
      if (existing !== -1) return items[existing];
      items.push(item);
      saveAll(items);
      return item;
    },

    update(id: string, changes: Partial<T>): T | undefined {
      const items = loadAll();
      const index = items.findIndex((item) => item.id === id);
      if (index === -1) return undefined;
      items[index] = { ...items[index], ...changes };
      saveAll(items);
      return items[index];
    },

    remove(id: string): boolean {
      const items = loadAll();
      const index = items.findIndex((item) => item.id === id);
      if (index === -1) return false;
      items.splice(index, 1);
      saveAll(items);
      return true;
    },

    query(predicate: (item: T) => boolean): T[] {
      return loadAll().filter(predicate);
    },
  };
}
