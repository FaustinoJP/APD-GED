import { storageAdapter, LocalStorageAdapter } from './storage';
import { createRepository } from './repository';
import {
  usersRepo,
  rolesRepo,
  documentTypesRepo,
  entitiesRepo,
  documentsRepo,
  circulationsRepo,
  signaturesRepo,
  auditRepo,
  foldersRepo,
  dossiersRepo,
  notificationsRepo,
  funcionariosRepo,
  templatesRepo,
  locationLevelsRepo,
  locationNodesRepo,
  getCompanySettings,
  setCompanySettings,
  gerarNumeroDocumento,
  lerContadorDocumento,
} from './repositories';

export { storageAdapter, LocalStorageAdapter };
export type { StorageAdapter } from './storage';

export { createRepository };
export type { Repository } from './repository';

export {
  usersRepo,
  rolesRepo,
  documentTypesRepo,
  entitiesRepo,
  documentsRepo,
  circulationsRepo,
  signaturesRepo,
  auditRepo,
  foldersRepo,
  dossiersRepo,
  notificationsRepo,
  funcionariosRepo,
  templatesRepo,
  locationLevelsRepo,
  locationNodesRepo,
  getCompanySettings,
  setCompanySettings,
  gerarNumeroDocumento,
  lerContadorDocumento,
};

/**
 * Wipes all application data keys (prefix 'gd:') from localStorage.
 * Call seedDatabase() and reload after to restore the demo dataset.
 * Does NOT touch non-gd: keys (e.g. third-party libs).
 */
export function clearAppData(): void {
  storageAdapter.clearAppKeys('gd:');
}
