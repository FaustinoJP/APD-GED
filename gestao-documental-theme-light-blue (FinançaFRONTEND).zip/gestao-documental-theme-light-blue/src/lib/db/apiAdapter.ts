/**
 * ApiStorageAdapter — adaptor de cache em memória + sincronização REST.
 *
 * ─── Activação ────────────────────────────────────────────────────────────────
 *   No ficheiro .env.local:
 *     NEXT_PUBLIC_DATA_SOURCE=api
 *     NEXT_PUBLIC_API_BASE_URL=http://localhost:3001/api/v1
 *
 * ─── Funcionamento ────────────────────────────────────────────────────────────
 *   1. Após login, chamar adapter.hydrate() para pré-popular o cache.
 *   2. Os repositórios lêem do cache de forma síncrona (StorageAdapter intacto).
 *   3. Cada set() detecta adições/alterações/remoções via diff no campo "id"
 *      e faz as chamadas POST/PATCH/DELETE correspondentes em background.
 *
 * ─── Chave → Endpoint ────────────────────────────────────────────────────────
 *   gd:users           → /users
 *   gd:roles           → /roles
 *   gd:document_types  → /document-types
 *   gd:entities        → /entities
 *   gd:documents       → /documents
 *   gd:circulations    → /circulations
 *   gd:signatures      → /signatures
 *   gd:audit           → /audit
 *   gd:folders         → /folders
 *   gd:dossiers        → /dossiers
 *   gd:notifications   → /notifications
 *   gd:templates       → /templates
 *   gd:location_levels → /location-levels
 *   gd:location_nodes  → /location-nodes
 *   gd:company         → /company  (singleton: PUT em vez de POST)
 *   gd:counter:*       → gerido pelo servidor (não sincroniza)
 *   gd:session         → estado de autenticação (não sincroniza)
 */

import type { StorageAdapter } from './storage';
import { LocalStorageAdapter } from './storage';
import { apiClient } from '@/lib/api/client';
import { toast } from 'sonner';

/** Evento emitido quando uma escrita na API falha e o cache foi revertido. */
export const GD_WRITE_ERROR_EVENT = 'gd:api-write-error';

const BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL ?? '';

// Chaves que o servidor gere — nunca sincronizar para a API
const SERVER_MANAGED_PREFIXES = ['gd:counter:', 'gd:session'];
// Chaves singleton (valor escalar ou objecto, não array)
const SINGLETON_KEYS = new Set(['gd:company']);

type ItemWithId = Record<string, unknown> & { id: string };

function keyToPath(key: string): string {
  return '/' + key.replace(/^gd:/, '').replace(/_/g, '-');
}

function getResourceLabel(key: string): string {
  const labels: Record<string, string> = {
    'gd:users': 'utilizadores',
    'gd:roles': 'perfis',
    'gd:document_types': 'tipos de documento',
    'gd:entities': 'entidades',
    'gd:documents': 'documentos',
    'gd:circulations': 'circulações',
    'gd:signatures': 'assinaturas',
    'gd:audit': 'auditoria',
    'gd:folders': 'pastas',
    'gd:dossiers': 'dossiês',
    'gd:notifications': 'notificações',
    'gd:funcionarios': 'funcionários',
    'gd:templates': 'modelos',
    'gd:location_levels': 'níveis de localização',
    'gd:location_nodes': 'localizações físicas',
    'gd:company': 'configurações da empresa',
  };
  return labels[key] ?? key;
}

function isServerManaged(key: string): boolean {
  return SERVER_MANAGED_PREFIXES.some((p) => key.startsWith(p));
}

function emitWriteError(key: string): void {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(GD_WRITE_ERROR_EVENT, { detail: { key } }));
  }
}

function extractErrDetail(e: unknown): string {
  const resp = (e as any)?.response;
  if (!resp) return 'Erro de rede — verifique a ligação ao servidor.';
  const msg = resp.data?.message;
  if (Array.isArray(msg)) return msg.join('; ');
  if (typeof msg === 'string') return msg;
  return `HTTP ${resp.status}`;
}

export class ApiStorageAdapter implements StorageAdapter {
  private cache = new Map<string, unknown>();

  /**
   * Pré-popula o cache com dados da API.
   * Chamado após login bem-sucedido. Falhas individuais são ignoradas.
   */
  async hydrate(): Promise<void> {
    const collectionKeys: string[] = [
      'gd:users',
      'gd:roles',
      'gd:document_types',
      'gd:entities',
      'gd:documents',
      'gd:circulations',
      'gd:signatures',
      'gd:audit',
      'gd:folders',
      'gd:dossiers',
      'gd:notifications',
      'gd:funcionarios',
      'gd:templates',
      'gd:location_levels',
      'gd:location_nodes',
      'gd:company',
    ];

    let lastError: Error | null = null;

    await Promise.allSettled(
      collectionKeys.map(async (key) => {
        try {
          const path = keyToPath(key);
          const { data } = await apiClient.get(path);
          this.cache.set(key, data);
        } catch (err: unknown) {
          const status = (err as any)?.response?.status;
          // Erro de rede (sem status), erro do servidor (5xx) ou erro de auth (401)
          if (!status || status >= 500 || status === 401) {
            lastError = err as Error;
          }
        }
      }),
    );

    if (lastError) {
      throw lastError;
    }
  }

  get<T>(key: string): T | null {
    const value = this.cache.get(key);
    return value !== undefined ? (value as T) : null;
  }

  set<T>(key: string, newValue: T): void {
    if (isServerManaged(key)) {
      this.cache.set(key, newValue);
      return;
    }

    const oldValue = this.cache.get(key);
    this.cache.set(key, newValue);

    if (SINGLETON_KEYS.has(key)) {
      void apiClient
        .put(keyToPath(key), newValue)
        .catch((e: unknown) => {
          console.error(`[api] PUT ${key} failed`, e);
          // Revert cache — restaurar valor anterior
          if (oldValue !== undefined) this.cache.set(key, oldValue);
          else this.cache.delete(key);
          const detail = extractErrDetail(e);
          toast.error(`Falha ao atualizar ${getResourceLabel(key)}: ${detail}`);
          emitWriteError(key);
        });
      return;
    }

    if (!Array.isArray(newValue)) return;

    const oldArr = (Array.isArray(oldValue) ? oldValue : []) as ItemWithId[];
    const newArr = newValue as ItemWithId[];
    const path = keyToPath(key);

    const oldById = new Map(oldArr.map((i) => [i.id, i]));
    const newById = new Map(newArr.map((i) => [i.id, i]));

    // Adicionados
    for (const item of newArr) {
      if (!oldById.has(item.id)) {
        let postItem: Record<string, unknown> = item;
        if (key === 'gd:documents') {
          // Ficheiros já pré-carregados via POST /uploads — enviar só JSON com metadados.
          // Remover campos gerados pelo servidor (criadoPor vem do JWT, timestamps do backend).
          const doc = item as Record<string, unknown>;
          const anexos = (doc.anexos as Array<Record<string, unknown>> | undefined) ?? [];
          const cleanAnexos = anexos.map(({ _file: _, ...rest }) => rest);
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          const { criadoPor: _cp, criadoEm: _ce, atualizadoEm: _ae, ...docFields } = doc;
          postItem = { ...docFields, anexos: cleanAnexos };
        } else if (key === 'gd:circulations') {
          // deUserId vem do JWT no backend; status/respostas/criadoEm são inicializados pelo servidor.
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          const { deUserId: _du, status: _st, respostas: _rs, criadoEm: _ce, ...circFields } = item as Record<string, unknown>;
          postItem = circFields;
        } else if (key === 'gd:signatures') {
          // userId vem do JWT no backend; criadoEm é gerado pelo servidor.
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          const { userId: _uid, criadoEm: _ce, ...sigFields } = item as Record<string, unknown>;
          postItem = sigFields;
        } else if (key === 'gd:users') {
          // criadoEm e senhaHash não fazem parte do CreateUserDto — backend gere-os.
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          const { criadoEm: _ce, senhaHash: _sh, ...userFields } = item as Record<string, unknown>;
          postItem = userFields;
        } else if (key === 'gd:templates') {
          // versao é auto-gerida pelo backend (incrementa quando htmlContent muda).
          // criadoEm é gerado pelo servidor.
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          const { versao: _v, criadoEm: _ce, ...tplFields } = item as Record<string, unknown>;
          postItem = tplFields;
        }
        void apiClient
          .post(path, postItem)
          .catch((e: unknown) => {
            console.error(`[api] POST ${key}/${item.id} failed`, e);
            // Revert: repor o cache com os dados anteriores à criação
            this.cache.set(key, oldArr);
            const detail = extractErrDetail(e);
            toast.error(`Falha ao criar ${getResourceLabel(key)}: ${detail}`);
            emitWriteError(key);
          });
      }
    }

    // Alterados
    for (const item of newArr) {
      if (oldById.has(item.id)) {
        const old = oldById.get(item.id)!;
        // Para documentos: excluir anexos do PATCH (geridos por endpoints dedicados)
        // Para notificações: apenas enviar o campo 'lida' no PATCH
        // Para users/templates: excluir campos não presentes nos DTOs do backend
        // Para circulações: detectar operação de "respond" e usar POST /respond
        let patchItem = item as Record<string, unknown>;
        let skipPatch = false;

        if (key === 'gd:documents') {
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          const { anexos: _, ...rest } = patchItem;
          patchItem = rest;
        } else if (key === 'gd:notifications') {
          patchItem = { lida: patchItem.lida };
        } else if (key === 'gd:users') {
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          const { criadoEm: _, senhaHash: __, senha: _s, ...rest } = patchItem;
          patchItem = rest;
        } else if (key === 'gd:templates') {
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          const { versao: _, criadoEm: __, ...rest } = patchItem;
          patchItem = rest;
        } else if (key === 'gd:circulations') {
          // Detectar operação de "respond": nova resposta adicionada ao array respostas
          const oldRespostas = ((old as Record<string, unknown>).respostas ?? []) as Array<Record<string, unknown> & { id: string }>;
          const newRespostas = ((item as Record<string, unknown>).respostas ?? []) as Array<Record<string, unknown> & { id: string }>;
          const newResp = newRespostas.find((r) => !oldRespostas.some((o) => o.id === r.id));

          if (newResp) {
            // Operação de resposta → usar endpoint dedicado com apenas os campos do RespondCirculationDto
            const { decisao, mensagem, assinaturaId, signatureZoneId, allSignedZones, certificadoDigital } = newResp;
            void apiClient
              .post(`${path}/${item.id}/respond`, { decisao, mensagem, assinaturaId, signatureZoneId, allSignedZones, certificadoDigital })
              .then(({ data }: { data: Record<string, unknown> }) => {
                // Actualizar cache com a versão autoritativa do servidor
                const current = this.cache.get(key) as ItemWithId[] | undefined;
                if (Array.isArray(current)) {
                  this.cache.set(key, current.map((c) => c.id === item.id ? { ...c, ...data, id: c.id } : c));
                }
              })
              .catch((e: unknown) => {
                console.error(`[api] POST ${key}/${item.id}/respond failed`, e);
                this.cache.set(key, oldArr);
                const detail = extractErrDetail(e);
                toast.error(`Falha ao responder à circulação: ${detail}`);
                emitWriteError(key);
              });
            skipPatch = true;
          }
          // Se não é um respond (admin a alterar outros campos), cai no PATCH genérico
        }

        if (!skipPatch && JSON.stringify(old) !== JSON.stringify(item)) {
          void apiClient
            .patch(`${path}/${item.id}`, patchItem)
            .catch((e: unknown) => {
              console.error(`[api] PATCH ${key}/${item.id} failed`, e);
              // Revert: repor o cache com os dados anteriores à alteração
              this.cache.set(key, oldArr);
              const detail = extractErrDetail(e);
              toast.error(`Falha ao atualizar ${getResourceLabel(key)}: ${detail}`);
              emitWriteError(key);
            });
        }
      }
    }

    // Removidos
    for (const item of oldArr) {
      if (!newById.has(item.id)) {
        void apiClient
          .delete(`${path}/${item.id}`)
          .catch((e: unknown) => {
            console.error(`[api] DELETE ${key}/${item.id} failed`, e);
            // Revert: repor o cache (item volta a existir localmente)
            this.cache.set(key, oldArr);
            const detail = extractErrDetail(e);
            toast.error(`Falha ao remover ${getResourceLabel(key)}: ${detail}`);
            emitWriteError(key);
          });
      }
    }
  }

  remove(key: string): void {
    this.cache.delete(key);
  }

  getAll(): Record<string, unknown> {
    return Object.fromEntries(this.cache.entries());
  }

  clear(): void {
    this.cache.clear();
  }

  clearAppKeys(_prefix?: string): void {
    // No-op — o servidor gere o seu próprio ciclo de vida
  }
}

// ── Singleton para toda a aplicação ──────────────────────────────────────────
let _adapter: StorageAdapter | null = null;

export function getAdapter(): StorageAdapter {
  if (!_adapter) {
    _adapter =
      process.env.NEXT_PUBLIC_DATA_SOURCE === 'api'
        ? new ApiStorageAdapter()
        : new LocalStorageAdapter();
  }
  return _adapter;
}

void BASE_URL; // referenciado nos comentários acima

export { keyToPath };
