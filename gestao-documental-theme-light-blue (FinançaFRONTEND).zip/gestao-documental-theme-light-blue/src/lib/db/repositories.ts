import type {
  User,
  Role,
  DocumentType,
  Entity,
  DocumentRecord,
  Circulation,
  Signature,
  AuditLog,
  Folder,
  Dossier,
  Notification,
  DocumentTemplate,
  CompanySettings,
  TipoRegistro,
  Funcionario,
  LocationLevel,
  LocationNode,
} from '@/types';

import { getAdapter } from './apiAdapter';
import { createRepository } from './repository';

const storageAdapter = getAdapter();

// ─── Collection keys ──────────────────────────────────────────────────────────

const KEYS = {
  users: 'gd:users',
  roles: 'gd:roles',
  documentTypes: 'gd:document_types',
  entities: 'gd:entities',
  documents: 'gd:documents',
  circulations: 'gd:circulations',
  signatures: 'gd:signatures',
  audit: 'gd:audit',
  folders: 'gd:folders',
  dossiers: 'gd:dossiers',
  notifications: 'gd:notifications',
  funcionarios: 'gd:funcionarios',
  locationLevels: 'gd:location_levels',
  locationNodes: 'gd:location_nodes',
  counterPrefix: 'gd:counter',
} as const;

// ─── Named repositories ───────────────────────────────────────────────────────

export const usersRepo = createRepository<User>(KEYS.users, storageAdapter);
export const rolesRepo = createRepository<Role>(KEYS.roles, storageAdapter);
export const documentTypesRepo = createRepository<DocumentType>(KEYS.documentTypes, storageAdapter);
export const entitiesRepo = createRepository<Entity>(KEYS.entities, storageAdapter);
export const documentsRepo = createRepository<DocumentRecord>(KEYS.documents, storageAdapter);
export const circulationsRepo = createRepository<Circulation>(KEYS.circulations, storageAdapter);
export const signaturesRepo = createRepository<Signature>(KEYS.signatures, storageAdapter);
export const auditRepo = createRepository<AuditLog>(KEYS.audit, storageAdapter);
export const foldersRepo = createRepository<Folder>(KEYS.folders, storageAdapter);
export const dossiersRepo = createRepository<Dossier>(KEYS.dossiers, storageAdapter);
export const notificationsRepo = createRepository<Notification>(KEYS.notifications, storageAdapter);
export const funcionariosRepo = createRepository<Funcionario>(KEYS.funcionarios, storageAdapter);
export const templatesRepo = createRepository<DocumentTemplate>('gd:templates', storageAdapter);
export const locationLevelsRepo = createRepository<LocationLevel>(KEYS.locationLevels, storageAdapter);
export const locationNodesRepo = createRepository<LocationNode>(KEYS.locationNodes, storageAdapter);

// ─── Company settings (singleton) ─────────────────────────────────────────────

const COMPANY_KEY = 'gd:company';

export function getCompanySettings(): CompanySettings {
  return storageAdapter.get<CompanySettings>(COMPANY_KEY) ?? { nome: 'Empresa' };
}

export function setCompanySettings(settings: CompanySettings): void {
  storageAdapter.set(COMPANY_KEY, settings);
}

// ─── Document number generator ────────────────────────────────────────────────

const REGISTRO_PREFIX: Record<TipoRegistro, string> = {
  entrada: 'ENT',
  saida: 'SAI',
  interno: 'INT',
};

/**
 * Generates a sequential document number per tipo de registro per year.
 * Format: {PREFIX}-{YEAR}/{SEQ:05d}  e.g. ENT-2024/00001
 * Counter is persisted in localStorage so it survives page reloads.
 */
export function gerarNumeroDocumento(tipo: TipoRegistro): string {
  const year = new Date().getFullYear();
  const counterKey = `${KEYS.counterPrefix}:${tipo}:${year}`;
  const current = storageAdapter.get<number>(counterKey) ?? 0;
  const next = current + 1;
  storageAdapter.set(counterKey, next);
  const prefix = REGISTRO_PREFIX[tipo];
  return `${prefix}-${year}/${String(next).padStart(5, '0')}`;
}

/**
 * Reads the current counter for a tipo/year without incrementing (for display).
 */
export function lerContadorDocumento(tipo: TipoRegistro, year?: number): number {
  const y = year ?? new Date().getFullYear();
  return storageAdapter.get<number>(`${KEYS.counterPrefix}:${tipo}:${y}`) ?? 0;
}
