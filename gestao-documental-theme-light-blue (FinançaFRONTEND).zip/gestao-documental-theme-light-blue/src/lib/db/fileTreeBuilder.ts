import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import type { DocumentRecord } from '@/types';

export interface FileTreeNode {
  id: string;
  label: string;
  type: 'localidade' | 'ano' | 'mes' | 'dia' | 'document';
  children: FileTreeNode[];
  document?: DocumentRecord;
  count: number;
  path: string[];
}

const MONTHS_PT = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro',
];

export function buildFileTree(documents: DocumentRecord[]): FileTreeNode[] {
  type DayMap = Map<string, DocumentRecord[]>;
  type MonthMap = Map<string, DayMap>;
  type YearMap = Map<string, MonthMap>;
  type LocMap = Map<string, YearMap>;

  const locMap: LocMap = new Map();

  for (const doc of documents) {
    const raw = (doc.regiao?.trim() || doc.localizacao?.trim()) ?? '';
    const loc = raw ? raw.charAt(0).toUpperCase() + raw.slice(1) : 'Sem Localidade';

    const date = new Date(doc.criadoEm);
    const ano = String(date.getFullYear());
    const mesRaw = format(date, 'MMMM', { locale: ptBR });
    const mes = mesRaw.charAt(0).toUpperCase() + mesRaw.slice(1);
    const dia = String(date.getDate()).padStart(2, '0');

    if (!locMap.has(loc)) locMap.set(loc, new Map());
    const yearMap = locMap.get(loc)!;
    if (!yearMap.has(ano)) yearMap.set(ano, new Map());
    const monthMap = yearMap.get(ano)!;
    if (!monthMap.has(mes)) monthMap.set(mes, new Map());
    const dayMap = monthMap.get(mes)!;
    if (!dayMap.has(dia)) dayMap.set(dia, []);
    dayMap.get(dia)!.push(doc);
  }

  const nodes: FileTreeNode[] = [];

  for (const [loc, yearMap] of locMap) {
    const anos = Array.from(yearMap.keys()).sort((a, b) => Number(b) - Number(a));
    let locCount = 0;
    const locChildren: FileTreeNode[] = [];

    for (const ano of anos) {
      const monthMap = yearMap.get(ano)!;
      const meses = Array.from(monthMap.keys()).sort(
        (a, b) => MONTHS_PT.indexOf(b) - MONTHS_PT.indexOf(a),
      );
      let anoCount = 0;
      const anoChildren: FileTreeNode[] = [];

      for (const mes of meses) {
        const dayMap = monthMap.get(mes)!;
        const dias = Array.from(dayMap.keys()).sort((a, b) => Number(b) - Number(a));
        let mesCount = 0;
        const mesChildren: FileTreeNode[] = [];

        for (const dia of dias) {
          const docs = [...dayMap.get(dia)!].sort(
            (a, b) => new Date(b.criadoEm).getTime() - new Date(a.criadoEm).getTime(),
          );
          const diaChildren: FileTreeNode[] = docs.map((doc) => ({
            id: `${loc}/${ano}/${mes}/${dia}/${doc.id}`,
            label: `${doc.numero} — ${doc.assunto}`,
            type: 'document' as const,
            children: [],
            document: doc,
            count: 1,
            path: [loc, ano, mes, dia, doc.numero],
          }));

          mesChildren.push({
            id: `${loc}/${ano}/${mes}/${dia}`,
            label: dia,
            type: 'dia',
            children: diaChildren,
            count: docs.length,
            path: [loc, ano, mes, dia],
          });
          mesCount += docs.length;
        }

        anoChildren.push({
          id: `${loc}/${ano}/${mes}`,
          label: mes,
          type: 'mes',
          children: mesChildren,
          count: mesCount,
          path: [loc, ano, mes],
        });
        anoCount += mesCount;
      }

      locChildren.push({
        id: `${loc}/${ano}`,
        label: ano,
        type: 'ano',
        children: anoChildren,
        count: anoCount,
        path: [loc, ano],
      });
      locCount += anoCount;
    }

    nodes.push({
      id: loc,
      label: loc,
      type: 'localidade',
      children: locChildren,
      count: locCount,
      path: [loc],
    });
  }

  nodes.sort((a, b) => {
    if (a.label === 'Sem Localidade') return 1;
    if (b.label === 'Sem Localidade') return -1;
    return a.label.localeCompare(b.label, 'pt');
  });

  return nodes;
}
