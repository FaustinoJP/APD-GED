/**
 * StorageAdapter abstraction layer.
 *
 * To migrate from localStorage to a REST API, implement StorageAdapter using
 * fetch and swap the adapter instance exported at the bottom of this file.
 * No other file needs to change — repositories only depend on the interface.
 *
 * Environment-based switching (see src/lib/db/apiAdapter.ts for the skeleton):
 *   NEXT_PUBLIC_DATA_SOURCE=local  → LocalStorageAdapter (default)
 *   NEXT_PUBLIC_DATA_SOURCE=api    → ApiStorageAdapter
 */

export interface StorageAdapter {
  get<T>(key: string): T | null;
  set<T>(key: string, value: T): void;
  remove(key: string): void;
  getAll(): Record<string, unknown>;
  clear(): void;
  /** Remove only keys that start with the app prefix (default 'gd:'). */
  clearAppKeys(prefix?: string): void;
}

export class LocalStorageAdapter implements StorageAdapter {
  private isClient(): boolean {
    return typeof window !== 'undefined';
  }

  get<T>(key: string): T | null {
    if (!this.isClient()) return null;
    const raw = window.localStorage.getItem(key);
    if (raw === null) return null;
    try {
      return JSON.parse(raw) as T;
    } catch {
      console.warn(`[gd] Corrupted JSON at key "${key}" — treating as empty.`);
      return null;
    }
  }

  set<T>(key: string, value: T): void {
    if (!this.isClient()) return;
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error(`[gd] Failed to write key "${key}":`, e);
    }
  }

  remove(key: string): void {
    if (!this.isClient()) return;
    window.localStorage.removeItem(key);
  }

  getAll(): Record<string, unknown> {
    if (!this.isClient()) return {};
    const result: Record<string, unknown> = {};
    for (let i = 0; i < window.localStorage.length; i++) {
      const key = window.localStorage.key(i);
      if (key !== null) {
        result[key] = this.get<unknown>(key);
      }
    }
    return result;
  }

  clear(): void {
    if (!this.isClient()) return;
    window.localStorage.clear();
  }

  clearAppKeys(prefix = 'gd:'): void {
    if (!this.isClient()) return;
    const keys: string[] = [];
    for (let i = 0; i < window.localStorage.length; i++) {
      const key = window.localStorage.key(i);
      if (key?.startsWith(prefix)) keys.push(key);
    }
    keys.forEach((k) => window.localStorage.removeItem(k));
  }
}

export const storageAdapter = new LocalStorageAdapter();
