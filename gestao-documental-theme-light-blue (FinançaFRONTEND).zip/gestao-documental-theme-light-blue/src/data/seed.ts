/**
 * Idempotent database seed.
 * Checks for a sentinel key ('gd:seeded') before writing anything.
 * Safe to call multiple times — only runs once per browser session data.
 */

import type {
  Role,
  User,
  DocumentType,
  Entity,
  DocumentRecord,
  Circulation,
  AuditLog,
  Folder,
  Notification,
  Attachment,
  Permission,
  DocumentTemplate,
  LocationLevel,
  LocationNode,
} from '@/types';
import { ALL_PERMISSIONS } from '@/types';
import {
  rolesRepo,
  usersRepo,
  documentTypesRepo,
  entitiesRepo,
  documentsRepo,
  circulationsRepo,
  auditRepo,
  foldersRepo,
  notificationsRepo,
  templatesRepo,
  locationLevelsRepo,
  locationNodesRepo,
  storageAdapter,
} from '@/lib/db';

const SEED_SENTINEL = 'gd:seeded:v2';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function iso(date: string): string {
  return new Date(date).toISOString();
}

// ─── Roles ────────────────────────────────────────────────────────────────────

const GESTAO_PERMISSIONS: Permission[] = [
  'documents.create',
  'documents.read',
  'documents.update',
  'documents.delete',
  'documents.forward',
  'documents.sign',
  'documents.approve',
  'documents.giveOpinion',
  'documents.dispatch',
  'documents.defer',
  'documents.archive',
  'documents.export',
  'config.types.manage',
  'config.entities.manage',
  'config.templates.manage',
  'config.locations.manage',
  'audit.read',
  'exports.run',
  'files.manage',
  'notifications.read',
  'dashboard.view',
];

const COLABORADOR_PERMISSIONS: Permission[] = [
  'documents.create',
  'documents.read',
  'documents.forward',
  'documents.giveOpinion',
  'files.manage',
  'notifications.read',
  'dashboard.view',
];

const ENTIDADE_EXTERNA_PERMISSIONS: Permission[] = [
  'documents.read',
  'notifications.read',
];

const seedRoles: Role[] = [
  {
    id: 'role-admin',
    nome: 'Administrador',
    descricao: 'Acesso total ao sistema, incluindo configurações e gestão de utilizadores.',
    permissions: ALL_PERMISSIONS,
  },
  {
    id: 'role-gestor',
    nome: 'Gestor',
    descricao: 'Gestão documental completa e configuração de tipos e entidades.',
    permissions: GESTAO_PERMISSIONS,
  },
  {
    id: 'role-colaborador',
    nome: 'Colaborador',
    descricao: 'Criação, leitura e encaminhamento de documentos.',
    permissions: COLABORADOR_PERMISSIONS,
  },
  {
    id: 'role-externo',
    nome: 'Entidade Externa',
    descricao: 'Acesso restrito ao portal de consulta.',
    permissions: ENTIDADE_EXTERNA_PERMISSIONS,
  },
];

// ─── Users ────────────────────────────────────────────────────────────────────

const seedUsers: User[] = [
  {
    id: 'user-admin-001',
    nome: 'Admin Utilizador',
    email: 'admin@faustware.ao',
    roleId: 'role-admin',
    ativo: true,
    criadoEm: iso('2024-01-02'),
    senhaHash: '$mock$admin123',
  },
  {
    id: 'user-gestor-001',
    nome: 'Maria Fernanda',
    email: 'gestor@faustware.ao',
    roleId: 'role-gestor',
    ativo: true,
    criadoEm: iso('2024-01-10'),
    senhaHash: '$mock$gestor123',
  },
  {
    id: 'user-colab-001',
    nome: 'João Baptista',
    email: 'colaborador@faustware.ao',
    roleId: 'role-colaborador',
    ativo: true,
    criadoEm: iso('2024-02-05'),
    senhaHash: '$mock$colab123',
  },
];

// ─── Document Types ───────────────────────────────────────────────────────────

const seedDocumentTypes: DocumentType[] = [
  {
    id: 'dtype-contrato-trabalho',
    nome: 'Contrato de Trabalho',
    descricao: 'Contrato de vínculo laboral entre a empresa e colaborador.',
    registro: 'todos',
    campos: [
      {
        id: 'cf-tipo-contrato',
        label: 'Tipo de Contrato',
        key: 'tipoContrato',
        tipo: 'select',
        obrigatorio: true,
        opcoes: ['Efectivo', 'Prazo Certo', 'Prestação de Serviços', 'Estágio'],
        ordem: 1,
      },
      {
        id: 'cf-valor-contrato',
        label: 'Valor Mensal',
        key: 'valorMensal',
        tipo: 'currency',
        obrigatorio: false,
        ordem: 2,
      },
    ],
    ativo: true,
  },
  {
    id: 'dtype-folha-salarial',
    nome: 'Folha Salarial',
    descricao: 'Documento de processamento mensal de salários.',
    registro: 'interno',
    campos: [
      {
        id: 'cf-mes-referencia',
        label: 'Mês de Referência',
        key: 'mesReferencia',
        tipo: 'date',
        obrigatorio: true,
        ordem: 1,
      },
      {
        id: 'cf-total-bruto',
        label: 'Total Bruto',
        key: 'totalBruto',
        tipo: 'currency',
        obrigatorio: true,
        ordem: 2,
      },
    ],
    ativo: true,
  },
  {
    id: 'dtype-impostos',
    nome: 'Impostos',
    descricao: 'Documentos fiscais e declarações de impostos.',
    registro: 'saida',
    campos: [
      {
        id: 'cf-tipo-imposto',
        label: 'Tipo de Imposto',
        key: 'tipoImposto',
        tipo: 'select',
        obrigatorio: true,
        opcoes: ['IRT', 'IVA', 'II', 'IPU', 'Outro'],
        ordem: 1,
      },
      {
        id: 'cf-periodo',
        label: 'Período',
        key: 'periodo',
        tipo: 'text',
        obrigatorio: true,
        ordem: 2,
      },
      {
        id: 'cf-valor-imposto',
        label: 'Valor a Pagar',
        key: 'valorPagar',
        tipo: 'currency',
        obrigatorio: true,
        ordem: 3,
      },
    ],
    ativo: true,
  },
  {
    id: 'dtype-contrato-fornecedor',
    nome: 'Contrato Fornecedor',
    descricao: 'Contrato de prestação de serviços ou fornecimento de bens.',
    registro: 'entrada',
    campos: [
      {
        id: 'cf-valor-fornecedor',
        label: 'Valor do Contrato',
        key: 'valorContrato',
        tipo: 'currency',
        obrigatorio: true,
        ordem: 1,
      },
      {
        id: 'cf-prazo-vigencia',
        label: 'Prazo de Vigência',
        key: 'prazoVigencia',
        tipo: 'date',
        obrigatorio: true,
        ordem: 2,
      },
      {
        id: 'cf-objeto',
        label: 'Objeto do Contrato',
        key: 'objetoContrato',
        tipo: 'textarea',
        obrigatorio: false,
        ordem: 3,
      },
    ],
    ativo: true,
  },
];

// ─── Entities ─────────────────────────────────────────────────────────────────

const seedEntities: Entity[] = [
  {
    id: 'entity-faustware-001',
    nome: 'faustware Formação e Transformação',
    tipo: 'cliente',
    email: 'geral@faustware.ao',
    telefone: '+244 923 456 789',
    endereco: 'Rua dos Coqueiros, 45, Luanda',
    regiao: 'Luanda',
    localizacao: 'Bairro Ingombota',
    criadoEm: iso('2024-01-01'),
  },
  {
    id: 'entity-supplier-001',
    nome: 'TecnoServ Angola Lda',
    tipo: 'fornecedor',
    email: 'comercial@tecnoserv.ao',
    telefone: '+244 912 345 678',
    endereco: 'Rua da Missão, 102, Benguela',
    regiao: 'Benguela',
    localizacao: 'Bairro Restinga',
    criadoEm: iso('2024-01-15'),
  },
  {
    id: 'entity-gov-001',
    nome: 'Ministério das Finanças',
    tipo: 'orgao',
    email: 'protocolo@minfin.gov.ao',
    telefone: '+244 222 395 000',
    endereco: 'Largo da Mutamba, s/n, Luanda',
    regiao: 'Luanda',
    localizacao: 'Mutamba',
    criadoEm: iso('2024-01-20'),
  },
];

// ─── Attachments helpers ──────────────────────────────────────────────────────

function mockAttachment(
  id: string,
  nome: string,
  formato: string,
  adicionadoPor: string,
  criadoEm: string,
): Attachment {
  return {
    id,
    nome,
    versao: 1,
    estado: 'check_in',
    tamanho: Math.floor(Math.random() * 900_000) + 100_000,
    formato,
    url: `/mock/attachments/${id}.${formato}`,
    adicionadoPor,
    criadoEm: iso(criadoEm),
  };
}

// ─── Documents ────────────────────────────────────────────────────────────────

const seedDocuments: DocumentRecord[] = [
  {
    id: 'doc-ent-001',
    numero: 'ENT-2024/00001',
    tipoRegistro: 'entrada',
    tipoDocumentoId: 'dtype-contrato-trabalho',
    assunto: 'Contrato de Trabalho — João Baptista',
    remetenteId: 'entity-faustware-001',
    remetenteTexto: 'faustware Formação e Transformação',
    destinatarios: [{ tipo: 'user', id: 'user-admin-001' }],
    data: iso('2024-03-01'),
    confidencial: false,
    estado: 'aprovado',
    regiao: 'Luanda',
    localizacao: 'Luanda',
    camposValores: { tipoContrato: 'Efectivo', valorMensal: 150000 },
    anexos: [
      mockAttachment('att-001', 'contrato_joao.pdf', 'pdf', 'user-admin-001', '2024-03-01'),
    ],
    criadoPor: 'user-admin-001',
    criadoEm: iso('2024-03-01'),
    atualizadoEm: iso('2024-03-15'),
  },
  {
    id: 'doc-ent-002',
    numero: 'ENT-2024/00002',
    tipoRegistro: 'entrada',
    tipoDocumentoId: 'dtype-folha-salarial',
    assunto: 'Folha Salarial — Março 2024',
    remetenteTexto: 'Departamento de RH',
    destinatarios: [
      { tipo: 'user', id: 'user-admin-001' },
      { tipo: 'user', id: 'user-gestor-001' },
    ],
    data: iso('2024-04-01'),
    confidencial: true,
    estado: 'em_circulacao',
    regiao: 'Luanda',
    localizacao: 'Luanda',
    camposValores: { mesReferencia: '2024-03-01', totalBruto: 4250000 },
    anexos: [
      mockAttachment('att-002', 'folha_marco_2024.xlsx', 'xlsx', 'user-gestor-001', '2024-04-01'),
      mockAttachment('att-003', 'resumo_folha.pdf', 'pdf', 'user-gestor-001', '2024-04-01'),
    ],
    criadoPor: 'user-gestor-001',
    criadoEm: iso('2024-04-01'),
    atualizadoEm: iso('2024-04-01'),
  },
  {
    id: 'doc-sai-001',
    numero: 'SAI-2024/00001',
    tipoRegistro: 'saida',
    tipoDocumentoId: 'dtype-contrato-fornecedor',
    assunto: 'Contrato de Serviços TI — TecnoServ Angola',
    remetenteTexto: 'faustware Systems & Solutions',
    destinatarios: [{ tipo: 'entity', id: 'entity-supplier-001' }],
    data: iso('2024-03-15'),
    confidencial: false,
    estado: 'novo',
    regiao: 'Benguela',
    localizacao: 'Benguela',
    camposValores: {
      valorContrato: 5000000,
      prazoVigencia: '2025-03-15',
      objetoContrato: 'Manutenção e suporte de infraestrutura tecnológica.',
    },
    anexos: [
      mockAttachment('att-004', 'contrato_tecnoserv.pdf', 'pdf', 'user-admin-001', '2024-03-15'),
    ],
    criadoPor: 'user-admin-001',
    criadoEm: iso('2024-03-15'),
    atualizadoEm: iso('2024-03-15'),
  },
  {
    id: 'doc-sai-002',
    numero: 'SAI-2024/00002',
    tipoRegistro: 'saida',
    tipoDocumentoId: 'dtype-impostos',
    assunto: 'Declaração de IVA — 1.º Trimestre 2024',
    remetenteTexto: 'faustware Systems & Solutions',
    destinatarios: [{ tipo: 'entity', id: 'entity-gov-001' }],
    data: iso('2024-04-15'),
    confidencial: true,
    estado: 'em_circulacao',
    regiao: 'Huambo',
    localizacao: 'Huambo',
    camposValores: { tipoImposto: 'IVA', periodo: '1.º Trimestre 2024', valorPagar: 820000 },
    anexos: [
      mockAttachment('att-005', 'declaracao_iva_t1_2024.pdf', 'pdf', 'user-gestor-001', '2024-04-15'),
    ],
    criadoPor: 'user-gestor-001',
    criadoEm: iso('2024-04-15'),
    atualizadoEm: iso('2024-04-15'),
  },
  {
    id: 'doc-int-001',
    numero: 'INT-2024/00001',
    tipoRegistro: 'interno',
    tipoDocumentoId: 'dtype-folha-salarial',
    assunto: 'Folha Salarial — Fevereiro 2024 (Interno)',
    destinatarios: [{ tipo: 'user', id: 'user-gestor-001' }],
    data: iso('2024-03-05'),
    confidencial: true,
    estado: 'deferido',
    regiao: 'Luanda',
    localizacao: '',
    camposValores: { mesReferencia: '2024-02-01', totalBruto: 4180000 },
    anexos: [
      mockAttachment('att-006', 'folha_fev_2024_int.pdf', 'pdf', 'user-gestor-001', '2024-03-05'),
    ],
    criadoPor: 'user-gestor-001',
    criadoEm: iso('2024-03-05'),
    atualizadoEm: iso('2024-03-20'),
  },
  {
    id: 'doc-int-002',
    numero: 'INT-2024/00002',
    tipoRegistro: 'interno',
    tipoDocumentoId: 'dtype-contrato-trabalho',
    assunto: 'Renovação de Contrato — Maria Fernanda',
    destinatarios: [
      { tipo: 'user', id: 'user-admin-001' },
      { tipo: 'user', id: 'user-gestor-001' },
    ],
    data: iso('2024-02-20'),
    confidencial: false,
    estado: 'concluido',
    regiao: 'Cabinda',
    localizacao: 'Cabinda',
    camposValores: { tipoContrato: 'Efectivo', valorMensal: 280000 },
    anexos: [
      mockAttachment('att-007', 'renovacao_maria.pdf', 'pdf', 'user-admin-001', '2024-02-20'),
      mockAttachment('att-008', 'aditamento.pdf', 'pdf', 'user-admin-001', '2024-02-20'),
    ],
    criadoPor: 'user-admin-001',
    criadoEm: iso('2024-02-20'),
    atualizadoEm: iso('2024-03-01'),
  },
];

// ─── Circulations ─────────────────────────────────────────────────────────────

const seedCirculations: Circulation[] = [
  {
    id: 'circ-001',
    documentId: 'doc-ent-002',
    acao: 'aprovar',
    deUserId: 'user-gestor-001',
    paraDestinatarios: [{ tipo: 'user', id: 'user-admin-001' }],
    mensagem: 'Por favor aprove a folha salarial de Março antes do dia 10.',
    dataLimite: iso('2024-04-10'),
    obrigatoriaTodos: false,
    enviarEmail: true,
    receberNotificacao: true,
    status: 'pendente',
    respostas: [],
    criadoEm: iso('2024-04-02'),
  },
  {
    id: 'circ-002',
    documentId: 'doc-int-002',
    acao: 'assinar',
    deUserId: 'user-gestor-001',
    paraDestinatarios: [{ tipo: 'user', id: 'user-admin-001' }],
    mensagem: 'Necessita de assinatura do administrador para formalizar a renovação.',
    dataLimite: iso('2024-04-20'),
    obrigatoriaTodos: true,
    enviarEmail: true,
    receberNotificacao: true,
    status: 'pendente',
    respostas: [],
    criadoEm: iso('2024-04-05'),
  },
];

// ─── Folders ──────────────────────────────────────────────────────────────────

const seedFolders: Folder[] = [
  {
    id: 'folder-contratos-trabalho',
    nome: 'Contratos de Trabalho',
    documentTypeId: 'dtype-contrato-trabalho',
    criadoEm: iso('2024-01-05'),
  },
  {
    id: 'folder-folhas-salariais',
    nome: 'Folhas Salariais',
    documentTypeId: 'dtype-folha-salarial',
    criadoEm: iso('2024-01-05'),
  },
  {
    id: 'folder-fiscal',
    nome: 'Documentos Fiscais',
    documentTypeId: 'dtype-impostos',
    criadoEm: iso('2024-01-10'),
  },
];

// ─── Localização Física (níveis + árvore de exemplo) ──────────────────────────

const seedLocationLevels: LocationLevel[] = [
  { id: 'loclvl-sala', nome: 'Sala', ordem: 0 },
  { id: 'loclvl-corredor', nome: 'Corredor', ordem: 1 },
  { id: 'loclvl-prateleira', nome: 'Prateleira', ordem: 2 },
  { id: 'loclvl-gaveta', nome: 'Gaveta', ordem: 3 },
];

const seedLocationNodes: LocationNode[] = [
  { id: 'locnode-sala-a', nome: 'Sala A', nivelId: 'loclvl-sala', ordem: 0, criadoEm: iso('2024-01-05') },
  { id: 'locnode-corredor-1', nome: 'Corredor 1', nivelId: 'loclvl-corredor', parentId: 'locnode-sala-a', ordem: 0, criadoEm: iso('2024-01-05') },
  { id: 'locnode-prateleira-3', nome: 'Prateleira 3', nivelId: 'loclvl-prateleira', parentId: 'locnode-corredor-1', ordem: 0, criadoEm: iso('2024-01-05') },
  { id: 'locnode-gaveta-4', nome: 'Gaveta 4', nivelId: 'loclvl-gaveta', parentId: 'locnode-prateleira-3', ordem: 0, criadoEm: iso('2024-01-05') },
];

function seedLocations(): void {
  seedLocationLevels.forEach((l) => locationLevelsRepo.create(l));
  seedLocationNodes.forEach((n) => locationNodesRepo.create(n));
}

// ─── Audit Logs ───────────────────────────────────────────────────────────────

const seedAuditLogs: AuditLog[] = [
  { id: 'audit-001', evento: 'login', tabela: 'users', registroId: 'user-admin-001', userId: 'user-admin-001', ip: '192.168.1.10', data: iso('2024-04-15T08:02:00'), detalhe: 'Login via formulário' },
  { id: 'audit-002', evento: 'login', tabela: 'users', registroId: 'user-gestor-001', userId: 'user-gestor-001', ip: '192.168.1.22', data: iso('2024-04-15T08:30:00'), detalhe: 'Login via formulário' },
  { id: 'audit-003', evento: 'cadastrado', tabela: 'documents', registroId: 'doc-ent-001', userId: 'user-admin-001', ip: '192.168.1.10', data: iso('2024-03-01T09:00:00'), detalhe: 'Contrato de Trabalho — João Baptista registado' },
  { id: 'audit-004', evento: 'cadastrado', tabela: 'documents', registroId: 'doc-ent-002', userId: 'user-gestor-001', ip: '192.168.1.22', data: iso('2024-04-01T10:15:00'), detalhe: 'Folha Salarial Março 2024 registada' },
  { id: 'audit-005', evento: 'visualizado', tabela: 'documents', registroId: 'doc-ent-001', userId: 'user-gestor-001', ip: '192.168.1.22', data: iso('2024-03-02T11:00:00') },
  { id: 'audit-006', evento: 'aprovado', tabela: 'documents', registroId: 'doc-ent-001', userId: 'user-admin-001', ip: '192.168.1.10', data: iso('2024-03-15T14:30:00'), detalhe: 'Aprovação final' },
  { id: 'audit-007', evento: 'encaminhado', tabela: 'circulations', registroId: 'circ-001', userId: 'user-gestor-001', ip: '192.168.1.22', data: iso('2024-04-02T09:05:00'), detalhe: 'Enviado para aprovação' },
  { id: 'audit-008', evento: 'encaminhado', tabela: 'circulations', registroId: 'circ-002', userId: 'user-gestor-001', ip: '192.168.1.22', data: iso('2024-04-05T10:00:00'), detalhe: 'Enviado para assinatura' },
  { id: 'audit-009', evento: 'cadastrado', tabela: 'documents', registroId: 'doc-sai-001', userId: 'user-admin-001', ip: '192.168.1.10', data: iso('2024-03-15T15:00:00'), detalhe: 'Contrato Fornecedor registado' },
  { id: 'audit-010', evento: 'cadastrado', tabela: 'documents', registroId: 'doc-sai-002', userId: 'user-gestor-001', ip: '10.0.0.5', data: iso('2024-04-15T16:00:00'), detalhe: 'Declaração IVA T1 registada' },
  { id: 'audit-011', evento: 'atualizado', tabela: 'documents', registroId: 'doc-int-001', userId: 'user-gestor-001', ip: '192.168.1.22', data: iso('2024-03-20T11:30:00'), detalhe: 'Estado alterado para deferido' },
  { id: 'audit-012', evento: 'assinado', tabela: 'documents', registroId: 'doc-int-002', userId: 'user-admin-001', ip: '192.168.1.10', data: iso('2024-03-01T12:00:00'), detalhe: 'Assinatura digital aposta' },
  { id: 'audit-013', evento: 'exportado', tabela: 'documents', registroId: 'doc-ent-001', userId: 'user-admin-001', ip: '192.168.1.10', data: iso('2024-04-10T09:45:00'), detalhe: 'Exportado para PDF' },
  { id: 'audit-014', evento: 'cadastrado', tabela: 'entities', registroId: 'entity-supplier-001', userId: 'user-admin-001', ip: '192.168.1.10', data: iso('2024-01-15T10:00:00'), detalhe: 'Nova entidade fornecedor' },
  { id: 'audit-015', evento: 'login', tabela: 'users', registroId: 'user-colab-001', userId: 'user-colab-001', ip: '10.0.0.12', data: iso('2024-04-15T08:55:00'), detalhe: 'Login via formulário' },
];

// ─── Notifications ────────────────────────────────────────────────────────────

const seedNotifications: Notification[] = [
  {
    id: 'notif-001',
    userId: 'user-admin-001',
    titulo: 'Documento pendente de aprovação',
    mensagem: 'A Folha Salarial de Março 2024 aguarda a sua aprovação.',
    lida: false,
    link: '/pendentes',
    criadoEm: iso('2024-04-02T09:05:00'),
  },
  {
    id: 'notif-002',
    userId: 'user-admin-001',
    titulo: 'Assinatura solicitada',
    mensagem: 'A Renovação de Contrato — Maria Fernanda requer a sua assinatura.',
    lida: false,
    link: '/pendentes',
    criadoEm: iso('2024-04-05T10:00:00'),
  },
  {
    id: 'notif-003',
    userId: 'user-admin-001',
    titulo: 'Novo documento registado',
    mensagem: 'Um novo contrato de fornecedor foi registado no sistema.',
    lida: true,
    link: '/registro/entradas',
    criadoEm: iso('2024-03-15T15:05:00'),
  },
];

// ─── Document Templates ───────────────────────────────────────────────────────

const TEMPLATE_SEED_SENTINEL = 'gd:seeded:templates:v1';

const HTML_CONTRATO_TRABALHO = `<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Times New Roman',Times,serif;font-size:12pt;color:#1a1a2e;background:#fff}
.page{width:794px;min-height:1123px;padding:56px 70px;margin:0 auto;position:relative}
.header{display:flex;align-items:flex-start;gap:20px;margin-bottom:28px;padding-bottom:18px;border-bottom:3px solid #1e3a5f}
.logo img{max-width:80px;max-height:80px;object-fit:contain;border:1px solid #e2e8f0}
.company-info{flex:1}
.company-name{font-size:17pt;font-weight:bold;color:#1e3a5f}
.company-details{font-size:9pt;color:#4a5568;margin-top:5px;line-height:1.7}
.doc-ref{text-align:right;min-width:140px}
.doc-ref .nr{font-size:10pt;font-weight:bold;color:#1e3a5f}
.doc-ref .dt{font-size:9pt;color:#64748b;margin-top:4px}
.title-wrap{text-align:center;margin:28px 0}
.title{font-size:15pt;font-weight:bold;letter-spacing:3px;text-transform:uppercase;color:#1e3a5f;border-bottom:2px solid #1e3a5f;padding-bottom:6px;display:inline-block}
.clause{margin-bottom:17px}
.clause-title{font-weight:bold;font-size:11pt;color:#1e3a5f;margin-bottom:5px}
.clause p{text-align:justify;line-height:1.85;font-size:10.5pt}
.date-line{text-align:center;margin-top:22px;font-size:10pt}
.sigs{margin-top:56px;display:flex;justify-content:space-between}
.sig-col{width:42%;text-align:center}
.sig-line{border-top:1px solid #1a1a2e;padding-top:8px;margin-top:56px}
.sig-label{font-size:9pt;font-weight:bold;color:#1e3a5f}
.sig-name{font-size:9pt;color:#4a5568;margin-top:3px}
.footer{margin-top:36px;padding-top:10px;border-top:1px solid #e2e8f0;text-align:center;font-size:8pt;color:#94a3b8}
@media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
</style></head>
<body><div class="page">
<div class="header">
  <div class="logo"><img src="{{empresa_logo}}" alt="Logo" onerror="this.style.display='none'"/></div>
  <div class="company-info">
    <div class="company-name">{{empresa_nome}}</div>
    <div class="company-details">NIF: {{empresa_nif}}<br>{{empresa_endereco}}</div>
  </div>
  <div class="doc-ref">
    <div class="nr">Ref.: {{nr_documento}}</div>
    <div class="dt">Data: {{data_documento}}</div>
  </div>
</div>
<div class="title-wrap"><div class="title">CONTRATO DE TRABALHO</div></div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 1.&ordf; &mdash; IDENTIFICA&Ccedil;&Atilde;O DAS PARTES</div>
  <p><strong>Empregador:</strong> {{empresa_nome}}, pessoa colectiva com o NIF n.&ordm; {{empresa_nif}}, com sede em {{empresa_endereco}}, neste acto representada pelo seu gerente/director, designada por &ldquo;Empregador&rdquo;.<br><br>
  <strong>Trabalhador:</strong> {{destinatario_nome}}, designado por &ldquo;Trabalhador&rdquo;.</p>
</div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 2.&ordf; &mdash; OBJECTO</div>
  <p>O presente contrato tem por objecto a presta&ccedil;&atilde;o, pelo Trabalhador, da actividade profissional para a qual foi contratado, nos termos e condi&ccedil;&otilde;es aqui estabelecidos, em conformidade com as instru&ccedil;&otilde;es e directivas do Empregador.</p>
</div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 3.&ordf; &mdash; TIPO DE CONTRATO</div>
  <p>O presente contrato &eacute; celebrado a t&iacute;tulo de <strong>{{tipo_contrato}}</strong>, conforme previsto na legisla&ccedil;&atilde;o laboral angolana em vigor.</p>
</div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 4.&ordf; &mdash; REMUNERA&Ccedil;&Atilde;O</div>
  <p>O Trabalhador aufrir&aacute; uma remunera&ccedil;&atilde;o mensal il&iacute;quida no valor de <strong>{{valor}} AOA</strong> (Kwanzas), a pagar at&eacute; ao &uacute;ltimo dia &uacute;til de cada m&ecirc;s, sujeita aos descontos legais aplic&aacute;veis nos termos da lei.</p>
</div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 5.&ordf; &mdash; DURA&Ccedil;&Atilde;O E LOCAL DE TRABALHO</div>
  <p>O presente contrato tem in&iacute;cio na data da sua assinatura. O local de trabalho &eacute; nas instala&ccedil;&otilde;es do Empregador ou em qualquer outro local que este venha a designar para o desempenho das fun&ccedil;&otilde;es contratadas.</p>
</div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 6.&ordf; &mdash; LEGISLA&Ccedil;&Atilde;O APLIC&Aacute;VEL</div>
  <p>O presente contrato rege-se pela Lei Geral do Trabalho de Angola (Lei n.&ordm; 7/15, de 15 de Junho) e demais legisla&ccedil;&atilde;o laboral aplic&aacute;vel, bem como pelos regulamentos internos do Empregador.</p>
</div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 7.&ordf; &mdash; RESCIS&Atilde;O</div>
  <p>A cessa&ccedil;&atilde;o do presente contrato obedece aos requisitos e formalidades previstos na Lei Geral do Trabalho, devendo qualquer das partes comunicar &agrave; outra, com a anteced&ecirc;ncia legalmente prevista, a sua inten&ccedil;&atilde;o de cessar o v&iacute;nculo laboral.</p>
</div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 8.&ordf; &mdash; DISPOSI&Ccedil;&Otilde;ES GERAIS</div>
  <p>Tudo o que n&atilde;o estiver expressamente previsto no presente contrato ser&aacute; regulado pela legisla&ccedil;&atilde;o angolana aplic&aacute;vel. Para quaisquer lit&iacute;gios emergentes do presente contrato, as partes elegem o foro da comarca de Luanda, com expressa ren&uacute;ncia a qualquer outro.</p>
</div>
<p class="date-line">{{empresa_endereco}}, {{data_documento}}</p>
<div class="sigs">
  <div class="sig-col"><div class="sig-line">
    <div class="sig-label">O Empregador</div>
    <div class="sig-name">{{utilizador_nome}}</div>
    <div class="sig-name" style="font-size:8pt;color:#94a3b8">{{utilizador_cargo}}</div>
  </div></div>
  <div class="sig-col"><div class="sig-line">
    <div class="sig-label">O Trabalhador</div>
    <div class="sig-name">{{destinatario_nome}}</div>
  </div></div>
</div>
<div class="footer">{{empresa_nome}} &mdash; NIF: {{empresa_nif}} &mdash; {{empresa_endereco}}<br>Impresso em: {{data_hora_impressao}} | Documento: {{nr_documento}}</div>
</div></body></html>`;

const HTML_FOLHA_SALARIAL = `<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:Arial,Helvetica,sans-serif;font-size:11pt;color:#1a1a2e;background:#fff}
.page{width:794px;min-height:1123px;padding:50px 60px;margin:0 auto;position:relative}
.header{display:flex;align-items:center;gap:20px;margin-bottom:18px;padding-bottom:14px;border-bottom:3px solid #1e3a5f}
.logo img{max-width:70px;max-height:70px;object-fit:contain}
.company-info{flex:1}
.company-name{font-size:16pt;font-weight:bold;color:#1e3a5f}
.company-details{font-size:9pt;color:#4a5568;margin-top:3px}
.title-box{text-align:center;margin:18px 0;background:#1e3a5f;color:#fff;padding:12px;border-radius:4px}
.title-box .title{font-size:13pt;font-weight:bold;letter-spacing:2px}
.title-box .sub{font-size:10pt;margin-top:4px;opacity:.85}
.sec-title{background:#f1f5f9;padding:6px 12px;font-weight:bold;font-size:10pt;color:#1e3a5f;border-left:4px solid #1e3a5f;margin:16px 0 8px}
table{width:100%;border-collapse:collapse;font-size:10pt}
th{background:#1e3a5f;color:#fff;padding:8px 12px;text-align:left;font-size:9pt}
td{padding:7px 12px;border-bottom:1px solid #e2e8f0}
tr:nth-child(even) td{background:#f8fafc}
.val{text-align:right;font-weight:500}
.total-row td{border-top:2px solid #1e3a5f;font-weight:bold;background:#f1f5f9}
.liquido td{background:#d1fae5;font-weight:bold}
.liquido td.val{color:#047857}
.declaration{margin-top:22px;padding:14px;border:1px solid #e2e8f0;border-radius:4px;background:#fafafa;font-size:10pt;line-height:1.75}
.sig-wrap{margin-top:50px;text-align:center}
.sig-line{border-top:1px solid #1a1a2e;padding-top:8px;margin:50px auto 0;width:300px}
.sig-label{font-weight:bold;font-size:9pt;color:#1e3a5f}
.sig-name{font-size:9pt;color:#4a5568;margin-top:3px}
.footer{margin-top:36px;padding-top:10px;border-top:1px solid #e2e8f0;text-align:center;font-size:8pt;color:#94a3b8}
@media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
</style></head>
<body><div class="page">
<div class="header">
  <div class="logo"><img src="{{empresa_logo}}" alt="Logo" onerror="this.style.display='none'"/></div>
  <div class="company-info">
    <div class="company-name">{{empresa_nome}}</div>
    <div class="company-details">NIF: {{empresa_nif}} | {{empresa_endereco}}</div>
  </div>
  <div style="text-align:right">
    <div style="font-size:9pt;font-weight:bold;color:#1e3a5f">Ref: {{nr_documento}}</div>
    <div style="font-size:9pt;color:#64748b">{{data_documento}}</div>
  </div>
</div>
<div class="title-box">
  <div class="title">RECIBO DE REMUNERA&Ccedil;&Atilde;O</div>
  <div class="sub">{{mes_referencia}}</div>
</div>
<div class="sec-title">Dados do Trabalhador</div>
<table><tbody>
  <tr>
    <td style="width:25%;font-weight:bold;color:#4a5568">Nome</td>
    <td>{{destinatario_nome}}</td>
    <td style="width:25%;font-weight:bold;color:#4a5568">Assunto / Fun&ccedil;&atilde;o</td>
    <td>{{assunto}}</td>
  </tr>
  <tr>
    <td style="font-weight:bold;color:#4a5568">Departamento</td>
    <td>{{remetente_nome}}</td>
    <td style="font-weight:bold;color:#4a5568">N.&ordm; Documento</td>
    <td>{{nr_documento}}</td>
  </tr>
</tbody></table>
<div class="sec-title">Componentes Salariais</div>
<table>
  <thead><tr><th style="width:60%">Descri&ccedil;&atilde;o</th><th style="width:40%;text-align:right">Valor (AOA)</th></tr></thead>
  <tbody>
    <tr><td>Sal&aacute;rio Base</td><td class="val">{{salario_base}}</td></tr>
    <tr><td>Subs&iacute;dio de Alimenta&ccedil;&atilde;o</td><td class="val">{{subsidios}}</td></tr>
    <tr><td>Outros Subs&iacute;dios</td><td class="val">&mdash;</td></tr>
    <tr style="color:#c0392b"><td>IRT (Imposto sobre Rendimento do Trabalho)</td><td class="val">- {{descontos}}</td></tr>
    <tr style="color:#c0392b"><td>Seguran&ccedil;a Social (3%)</td><td class="val">&mdash;</td></tr>
  </tbody>
  <tfoot>
    <tr class="total-row"><td><strong>TOTAL BRUTO</strong></td><td class="val"><strong>{{total_bruto}} AOA</strong></td></tr>
    <tr class="liquido"><td><strong>L&Iacute;QUIDO A PAGAR</strong></td><td class="val"><strong>{{liquido_pagar}} AOA</strong></td></tr>
  </tfoot>
</table>
<div class="declaration">
  O trabalhador abaixo assinado declara ter recebido a import&acirc;ncia l&iacute;quida de <strong>{{liquido_pagar}} AOA</strong>, referente &agrave; remunera&ccedil;&atilde;o do m&ecirc;s de <strong>{{mes_referencia}}</strong>, em conformidade com o contrato de trabalho em vigor e a legisla&ccedil;&atilde;o angolana aplic&aacute;vel.
</div>
<div class="sig-wrap">
  <div class="sig-line">
    <div class="sig-label">Assinatura do Trabalhador</div>
    <div class="sig-name">{{destinatario_nome}}</div>
    <div style="font-size:8pt;color:#94a3b8;margin-top:4px">Data: _____ / _____ / _______</div>
  </div>
</div>
<div class="footer">{{empresa_nome}} &mdash; NIF: {{empresa_nif}} &mdash; {{empresa_endereco}}<br>Impresso em: {{data_hora_impressao}} | Documento: {{nr_documento}}</div>
</div></body></html>`;

const HTML_IMPOSTOS = `<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:Arial,Helvetica,sans-serif;font-size:11pt;color:#1a1a2e;background:#fff}
.page{width:794px;min-height:1123px;padding:50px 60px;margin:0 auto;position:relative}
.header{display:flex;align-items:flex-start;gap:20px;margin-bottom:18px;padding-bottom:14px;border-bottom:3px solid #c0392b}
.logo img{max-width:70px;max-height:70px;object-fit:contain}
.company-name{font-size:16pt;font-weight:bold;color:#c0392b}
.company-details{font-size:9pt;color:#4a5568;margin-top:3px}
.title-wrap{text-align:center;margin:20px 0}
.title{font-size:14pt;font-weight:bold;letter-spacing:3px;color:#c0392b;border-bottom:2px solid #c0392b;padding-bottom:6px;display:inline-block}
.subtitle{font-size:10pt;color:#4a5568;margin-top:8px}
.sec-box{border:1px solid #e2e8f0;border-radius:4px;margin:16px 0;overflow:hidden}
.sec-hd{background:#c0392b;color:#fff;padding:7px 14px;font-weight:bold;font-size:10pt}
.sec-bd{padding:14px}
.info-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:10pt}
.info-item label{display:block;font-size:8pt;color:#64748b;font-weight:600;text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px}
table{width:100%;border-collapse:collapse;font-size:10pt}
th{background:#c0392b;color:#fff;padding:8px 12px;font-size:9pt}
td{padding:7px 12px;border-bottom:1px solid #e2e8f0;text-align:center}
tr:nth-child(even) td{background:#fef2f2}
.total-row td{border-top:2px solid #c0392b;font-weight:bold;background:#fee2e2}
.declaration{margin-top:20px;padding:14px;border:1px dashed #c0392b;border-radius:4px;font-size:10pt;line-height:1.75;color:#4a5568}
.sigs{margin-top:50px;display:flex;justify-content:space-around}
.sig-col{width:40%;text-align:center}
.sig-line{border-top:1px solid #1a1a2e;padding-top:8px;margin-top:50px}
.sig-label{font-weight:bold;font-size:9pt;color:#c0392b}
.sig-name{font-size:9pt;color:#4a5568;margin-top:3px}
.footer{margin-top:36px;padding-top:10px;border-top:1px solid #e2e8f0;text-align:center;font-size:8pt;color:#94a3b8}
@media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
</style></head>
<body><div class="page">
<div class="header">
  <div><img src="{{empresa_logo}}" alt="Logo" onerror="this.style.display='none'" style="max-width:70px;max-height:70px;object-fit:contain"/></div>
  <div style="flex:1">
    <div class="company-name">{{empresa_nome}}</div>
    <div class="company-details">NIF: {{empresa_nif}} | {{empresa_endereco}}</div>
  </div>
  <div style="text-align:right">
    <div style="font-size:9pt;font-weight:bold;color:#c0392b">Ref: {{nr_documento}}</div>
    <div style="font-size:9pt;color:#64748b">{{data_documento}}</div>
  </div>
</div>
<div class="title-wrap">
  <div class="title">DECLARA&Ccedil;&Atilde;O FISCAL</div>
  <div class="subtitle">Per&iacute;odo: {{periodo}} | Tipo de Imposto: {{tipo_imposto}}</div>
</div>
<div class="sec-box">
  <div class="sec-hd">Dados da Entidade Declarante</div>
  <div class="sec-bd">
    <div class="info-grid">
      <div class="info-item"><label>Denomina&ccedil;&atilde;o Social</label><span>{{empresa_nome}}</span></div>
      <div class="info-item"><label>NIF</label><span>{{empresa_nif}}</span></div>
      <div class="info-item"><label>Endere&ccedil;o</label><span>{{empresa_endereco}}</span></div>
      <div class="info-item"><label>Per&iacute;odo de Refer&ecirc;ncia</label><span>{{periodo}}</span></div>
    </div>
  </div>
</div>
<div class="sec-box">
  <div class="sec-hd">Valores Declarados</div>
  <div class="sec-bd">
    <table>
      <thead><tr>
        <th style="text-align:left">Tipo de Imposto</th>
        <th>Base Tribut&aacute;vel (AOA)</th>
        <th>Taxa (%)</th>
        <th>Valor a Pagar (AOA)</th>
      </tr></thead>
      <tbody><tr>
        <td style="text-align:left">{{tipo_imposto}}</td>
        <td>{{base_tributavel}}</td>
        <td>{{taxa}}</td>
        <td><strong>{{valor_pagar}}</strong></td>
      </tr></tbody>
      <tfoot><tr class="total-row">
        <td colspan="3" style="text-align:right"><strong>TOTAL A PAGAR</strong></td>
        <td><strong>{{valor_pagar}} AOA</strong></td>
      </tr></tfoot>
    </table>
  </div>
</div>
<div class="declaration">
  <strong>Declara&ccedil;&atilde;o de Veracidade:</strong> O(s) abaixo assinado(s), na qualidade de representante(s) da entidade declarante, declara(m) que as informa&ccedil;&otilde;es prestadas na presente declara&ccedil;&atilde;o s&atilde;o verdadeiras e completas, assumindo as responsabilidades legais decorrentes de qualquer inexactid&atilde;o, nos termos do C&oacute;digo Geral Tribut&aacute;rio da Rep&uacute;blica de Angola.
</div>
<div class="sigs">
  <div class="sig-col"><div class="sig-line">
    <div class="sig-label">O Declarante</div>
    <div class="sig-name">{{utilizador_nome}}</div>
    <div class="sig-name" style="font-size:8pt;color:#94a3b8">{{utilizador_cargo}}</div>
  </div></div>
  <div class="sig-col"><div class="sig-line">
    <div class="sig-label">Respons&aacute;vel Fiscal</div>
    <div class="sig-name">{{remetente_nome}}</div>
  </div></div>
</div>
<div class="footer">{{empresa_nome}} &mdash; NIF: {{empresa_nif}} &mdash; {{empresa_endereco}}<br>Impresso em: {{data_hora_impressao}} | Documento: {{nr_documento}}</div>
</div></body></html>`;

const HTML_CONTRATO_FORNECEDOR = `<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Times New Roman',Times,serif;font-size:12pt;color:#1a1a2e;background:#fff}
.page{width:794px;min-height:1123px;padding:56px 70px;margin:0 auto;position:relative}
.header{display:flex;align-items:flex-start;gap:20px;margin-bottom:28px;padding-bottom:18px;border-bottom:3px solid #1e5f4e}
.logo img{max-width:80px;max-height:80px;object-fit:contain;border:1px solid #e2e8f0}
.company-name{font-size:17pt;font-weight:bold;color:#1e5f4e}
.company-details{font-size:9pt;color:#4a5568;margin-top:5px;line-height:1.7}
.doc-ref{text-align:right;min-width:140px}
.doc-ref .nr{font-size:10pt;font-weight:bold;color:#1e5f4e}
.doc-ref .dt{font-size:9pt;color:#64748b;margin-top:4px}
.title-wrap{text-align:center;margin:28px 0}
.title{font-size:15pt;font-weight:bold;letter-spacing:3px;text-transform:uppercase;color:#1e5f4e;border-bottom:2px solid #1e5f4e;padding-bottom:6px;display:inline-block}
.clause{margin-bottom:17px}
.clause-title{font-weight:bold;font-size:11pt;color:#1e5f4e;margin-bottom:5px}
.clause p{text-align:justify;line-height:1.85;font-size:10.5pt}
.date-line{text-align:center;margin-top:22px;font-size:10pt}
.sigs{margin-top:56px;display:flex;justify-content:space-between}
.sig-col{width:42%;text-align:center}
.sig-line{border-top:1px solid #1a1a2e;padding-top:8px;margin-top:56px}
.sig-label{font-size:9pt;font-weight:bold;color:#1e5f4e}
.sig-name{font-size:9pt;color:#4a5568;margin-top:3px}
.footer{margin-top:36px;padding-top:10px;border-top:1px solid #e2e8f0;text-align:center;font-size:8pt;color:#94a3b8}
@media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
</style></head>
<body><div class="page">
<div class="header">
  <div class="logo"><img src="{{empresa_logo}}" alt="Logo" onerror="this.style.display='none'"/></div>
  <div style="flex:1">
    <div class="company-name">{{empresa_nome}}</div>
    <div class="company-details">NIF: {{empresa_nif}}<br>{{empresa_endereco}}</div>
  </div>
  <div class="doc-ref">
    <div class="nr">Ref.: {{nr_documento}}</div>
    <div class="dt">Data: {{data_documento}}</div>
  </div>
</div>
<div class="title-wrap"><div class="title">CONTRATO DE FORNECIMENTO</div></div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 1.&ordf; &mdash; IDENTIFICA&Ccedil;&Atilde;O DAS PARTES</div>
  <p><strong>Contratante:</strong> {{empresa_nome}}, pessoa colectiva com o NIF n.&ordm; {{empresa_nif}}, com sede em {{empresa_endereco}}, designada por &ldquo;Contratante&rdquo;.<br><br>
  <strong>Fornecedor:</strong> {{destinatario_nome}}, designado por &ldquo;Fornecedor&rdquo;.</p>
</div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 2.&ordf; &mdash; OBJECTO DO FORNECIMENTO</div>
  <p>{{objeto_contrato}}</p>
</div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 3.&ordf; &mdash; PRE&Ccedil;O</div>
  <p>O pre&ccedil;o global acordado para o fornecimento objecto do presente contrato &eacute; de <strong>{{valor}} AOA</strong> (Kwanzas), sujeito &agrave;s condi&ccedil;&otilde;es de pagamento estabelecidas na Cl&aacute;usula 5.&ordf;.</p>
</div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 4.&ordf; &mdash; PRAZO DE ENTREGA</div>
  <p>O Fornecedor obriga-se a realizar o fornecimento at&eacute; ao dia <strong>{{prazo_vigencia}}</strong>, salvo acordo escrito em contr&aacute;rio celebrado entre as partes.</p>
</div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 5.&ordf; &mdash; CONDI&Ccedil;&Otilde;ES DE PAGAMENTO</div>
  <p>O pagamento ser&aacute; efectuado pelo Contratante ao Fornecedor mediante transfer&ecirc;ncia banc&aacute;ria, em 30 (trinta) dias ap&oacute;s a recep&ccedil;&atilde;o e aceita&ccedil;&atilde;o do fornecimento acompanhado da respectiva factura.</p>
</div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 6.&ordf; &mdash; GARANTIAS</div>
  <p>O Fornecedor garante que os bens ou servi&ccedil;os fornecidos s&atilde;o de boa qualidade, isentos de defeitos, e conformes com as especifica&ccedil;&otilde;es t&eacute;cnicas acordadas. O prazo de garantia &eacute; de 12 (doze) meses a contar da data de entrega.</p>
</div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 7.&ordf; &mdash; PENALIDADES</div>
  <p>Em caso de incumprimento injustificado dos prazos estabelecidos, o Fornecedor ficar&aacute; sujeito a penalidades nos termos da legisla&ccedil;&atilde;o comercial angolana, podendo o Contratante proceder &agrave; rescis&atilde;o do contrato com perda das garantias prestadas.</p>
</div>
<div class="clause">
  <div class="clause-title">CL&Aacute;USULA 8.&ordf; &mdash; FORO</div>
  <p>Para a resolu&ccedil;&atilde;o de quaisquer lit&iacute;gios emergentes do presente contrato, as partes elegem o foro da comarca de Luanda, Angola, com expressa ren&uacute;ncia a qualquer outro.</p>
</div>
<p class="date-line">{{empresa_endereco}}, {{data_documento}}</p>
<div class="sigs">
  <div class="sig-col"><div class="sig-line">
    <div class="sig-label">O Contratante</div>
    <div class="sig-name">{{utilizador_nome}}</div>
    <div class="sig-name" style="font-size:8pt;color:#94a3b8">{{utilizador_cargo}}</div>
  </div></div>
  <div class="sig-col"><div class="sig-line">
    <div class="sig-label">O Fornecedor</div>
    <div class="sig-name">{{destinatario_nome}}</div>
  </div></div>
</div>
<div class="footer">{{empresa_nome}} &mdash; NIF: {{empresa_nif}} &mdash; {{empresa_endereco}}<br>Impresso em: {{data_hora_impressao}} | Documento: {{nr_documento}}</div>
</div></body></html>`;

const DEFAULT_WATERMARK = {
  incluirNomeUtilizador: true,
  incluirDataHora: true,
  incluirEstadoDocumento: true,
  opacidade: 0.08,
};

const seedTemplatesData: DocumentTemplate[] = [
  {
    id: 'tpl-contrato-trabalho',
    nome: 'Contrato de Trabalho',
    descricao: 'Template oficial para contratos laborais com cláusulas da Lei Geral do Trabalho de Angola.',
    documentTypeId: 'dtype-contrato-trabalho',
    htmlContent: HTML_CONTRATO_TRABALHO,
    variaveis: [
      '{{empresa_nome}}', '{{empresa_nif}}', '{{empresa_endereco}}', '{{empresa_logo}}',
      '{{nr_documento}}', '{{data_documento}}', '{{assunto}}', '{{remetente_nome}}',
      '{{destinatario_nome}}', '{{utilizador_nome}}', '{{utilizador_cargo}}',
      '{{data_hora_impressao}}', '{{tipo_contrato}}', '{{valor}}',
    ],
    signatureZones: [
      { id: 'sz-empregador', label: 'Assinatura do Empregador', x: 5, y: 82, width: 38, height: 10, obrigatoria: true, assignedRole: 'Gestor Documental' },
      { id: 'sz-trabalhador', label: 'Assinatura do Trabalhador', x: 57, y: 82, width: 38, height: 10, obrigatoria: true, assignedRole: 'Técnico' },
    ],
    watermark: { ...DEFAULT_WATERMARK },
    versao: 1,
    ativo: true,
    criadoEm: iso('2024-01-05'),
  },
  {
    id: 'tpl-folha-salarial',
    nome: 'Folha Salarial',
    descricao: 'Recibo de remuneração mensal com componentes salariais e declaração de recebimento.',
    documentTypeId: 'dtype-folha-salarial',
    htmlContent: HTML_FOLHA_SALARIAL,
    variaveis: [
      '{{empresa_nome}}', '{{empresa_nif}}', '{{empresa_endereco}}', '{{empresa_logo}}',
      '{{nr_documento}}', '{{data_documento}}', '{{assunto}}', '{{remetente_nome}}',
      '{{destinatario_nome}}', '{{utilizador_nome}}', '{{data_hora_impressao}}',
      '{{mes_referencia}}', '{{total_bruto}}', '{{salario_base}}',
      '{{subsidios}}', '{{descontos}}', '{{liquido_pagar}}',
    ],
    signatureZones: [
      { id: 'sz-trabalhador-fs', label: 'Assinatura do Trabalhador', x: 30, y: 85, width: 40, height: 8, obrigatoria: true, assignedRole: 'Técnico' },
    ],
    watermark: { ...DEFAULT_WATERMARK, texto: 'CONFIDENCIAL' },
    versao: 1,
    ativo: true,
    criadoEm: iso('2024-01-05'),
  },
  {
    id: 'tpl-impostos',
    nome: 'Declaração Fiscal',
    descricao: 'Template para declarações fiscais (IRT, IVA, II, IPU) com tabela de valores e zonas de assinatura.',
    documentTypeId: 'dtype-impostos',
    htmlContent: HTML_IMPOSTOS,
    variaveis: [
      '{{empresa_nome}}', '{{empresa_nif}}', '{{empresa_endereco}}', '{{empresa_logo}}',
      '{{nr_documento}}', '{{data_documento}}', '{{assunto}}', '{{remetente_nome}}',
      '{{utilizador_nome}}', '{{utilizador_cargo}}', '{{data_hora_impressao}}',
      '{{tipo_imposto}}', '{{periodo}}', '{{valor_pagar}}', '{{base_tributavel}}', '{{taxa}}',
    ],
    signatureZones: [
      { id: 'sz-declarante', label: 'Assinatura do Declarante', x: 5, y: 82, width: 38, height: 10, obrigatoria: true, assignedRole: 'Gestor Documental' },
      { id: 'sz-fiscal', label: 'Responsável Fiscal', x: 57, y: 82, width: 38, height: 10, obrigatoria: true, assignedRole: 'Gestor Documental' },
    ],
    watermark: { ...DEFAULT_WATERMARK, texto: 'CONFIDENCIAL' },
    versao: 1,
    ativo: true,
    criadoEm: iso('2024-01-10'),
  },
  {
    id: 'tpl-contrato-fornecedor',
    nome: 'Contrato de Fornecimento',
    descricao: 'Template para contratos de fornecimento de bens ou serviços com cláusulas de garantia e penalidades.',
    documentTypeId: 'dtype-contrato-fornecedor',
    htmlContent: HTML_CONTRATO_FORNECEDOR,
    variaveis: [
      '{{empresa_nome}}', '{{empresa_nif}}', '{{empresa_endereco}}', '{{empresa_logo}}',
      '{{nr_documento}}', '{{data_documento}}', '{{assunto}}', '{{remetente_nome}}',
      '{{destinatario_nome}}', '{{utilizador_nome}}', '{{utilizador_cargo}}',
      '{{data_hora_impressao}}', '{{valor}}', '{{prazo_vigencia}}', '{{objeto_contrato}}',
    ],
    signatureZones: [
      { id: 'sz-contratante', label: 'Assinatura do Contratante', x: 5, y: 84, width: 38, height: 10, obrigatoria: true, assignedRole: 'Gestor Documental' },
      { id: 'sz-fornecedor', label: 'Assinatura do Fornecedor', x: 57, y: 84, width: 38, height: 10, obrigatoria: true, assignedRole: 'Técnico' },
    ],
    watermark: { ...DEFAULT_WATERMARK },
    versao: 1,
    ativo: true,
    criadoEm: iso('2024-01-15'),
  },
];

function seedTemplates(): void {
  const done = storageAdapter.get<boolean>(TEMPLATE_SEED_SENTINEL);
  if (done) return;
  seedTemplatesData.forEach((t) => templatesRepo.create(t));
  storageAdapter.set(TEMPLATE_SEED_SENTINEL, true);
}

// ─── Counter seeds (pre-populate counters to match seeded document numbers) ───

function seedCounters(): void {
  storageAdapter.set('gd:counter:entrada:2024', 2);
  storageAdapter.set('gd:counter:saida:2024', 2);
  storageAdapter.set('gd:counter:interno:2024', 2);
}

// ─── Main seed function ───────────────────────────────────────────────────────

export function seedDatabase(): void {
  // Em modo API os dados vêm do backend — não seeds o adaptador local.
  // O SeedProvider continua a existir no layout mas não faz nada em modo API.
  if (process.env.NEXT_PUBLIC_DATA_SOURCE === 'api') return;

  const alreadySeeded = storageAdapter.get<boolean>(SEED_SENTINEL);
  if (alreadySeeded) {
    seedTemplates();
    return;
  }

  seedRoles.forEach((r) => rolesRepo.create(r));
  seedUsers.forEach((u) => usersRepo.create(u));
  seedDocumentTypes.forEach((dt) => documentTypesRepo.create(dt));
  seedEntities.forEach((e) => entitiesRepo.create(e));
  seedDocuments.forEach((d) => documentsRepo.create(d));
  seedCirculations.forEach((c) => circulationsRepo.create(c));
  seedFolders.forEach((f) => foldersRepo.create(f));
  seedLocations();
  seedAuditLogs.forEach((a) => auditRepo.create(a));
  seedNotifications.forEach((n) => notificationsRepo.create(n));

  seedCounters();

  storageAdapter.set(SEED_SENTINEL, true);
  seedTemplates();
}

