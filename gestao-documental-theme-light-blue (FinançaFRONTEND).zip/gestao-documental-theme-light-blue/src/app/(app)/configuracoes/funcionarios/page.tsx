'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Plus, Pencil, Trash2, Contact } from 'lucide-react';
import { toast } from 'sonner';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from '@/components/ui/sheet';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
  DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { PageHeader } from '@/components/common/page-header';
import { SectionCard } from '@/components/common/section-card';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { useFuncionariosStore } from '@/store/funcionarios-store';
import type { EstadoFuncionario, Funcionario } from '@/types';

const schema = z
  .object({
    nome: z.string().min(2, 'Nome obrigatório'),
    apelido: z.string().min(2, 'Apelido obrigatório'),
    numeroProcesso: z.string().min(1, 'Nº de processo obrigatório'),
    estado: z.enum([
      'ativo', 'reforma', 'licenca', 'suspenso', 'exonerado', 'falecido',
    ]),
    dataNascimento: z.string().min(1, 'Data de nascimento obrigatória'),
    dataInicioFuncoes: z.string().min(1, 'Data de início obrigatória'),
    dataFimFuncoes: z.string().optional(),
  })
  .refine(
    (v) => !v.dataFimFuncoes || v.dataFimFuncoes >= v.dataInicioFuncoes,
    { path: ['dataFimFuncoes'], message: 'A data de fim não pode ser anterior ao início.' },
  );
type FormValues = z.infer<typeof schema>;

export const ESTADO_LABELS: Record<EstadoFuncionario, string> = {
  ativo: 'Ativo',
  reforma: 'Reforma',
  licenca: 'Licença',
  suspenso: 'Suspenso',
  exonerado: 'Exonerado',
  falecido: 'Falecido',
};

const ESTADO_BADGE: Record<EstadoFuncionario, string> = {
  ativo: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  reforma: 'bg-sky-50 text-sky-700 border-sky-200',
  licenca: 'bg-amber-50 text-amber-700 border-amber-200',
  suspenso: 'bg-orange-50 text-orange-700 border-orange-200',
  exonerado: 'bg-slate-50 text-slate-500 border-slate-200',
  falecido: 'bg-red-50 text-red-700 border-red-200',
};

export function EstadoBadge({ estado }: { estado: EstadoFuncionario }) {
  return (
    <Badge variant="outline" className={`text-xs ${ESTADO_BADGE[estado]}`}>
      {ESTADO_LABELS[estado]}
    </Badge>
  );
}

export default function FuncionariosPage() {
  const { funcionarios, loaded, load, create, update, remove } = useFuncionariosStore();

  useEffect(() => { if (!loaded) load(); }, [loaded, load]);

  const [search, setSearch] = useState('');
  const [sheetOpen, setSheetOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Funcionario | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Funcionario | null>(null);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return funcionarios;
    return funcionarios.filter((f) =>
      `${f.nome} ${f.apelido}`.toLowerCase().includes(q) ||
      f.numeroProcesso.toLowerCase().includes(q),
    );
  }, [funcionarios, search]);

  const { register, handleSubmit, reset, setValue, watch, formState: { errors } } =
    useForm<FormValues>({
      resolver: zodResolver(schema),
      defaultValues: {
        nome: '', apelido: '', numeroProcesso: '', estado: 'ativo',
        dataNascimento: '', dataInicioFuncoes: '', dataFimFuncoes: '',
      },
    });
  const estado = watch('estado');

  function openCreate() {
    setEditTarget(null);
    reset({
      nome: '', apelido: '', numeroProcesso: '', estado: 'ativo',
      dataNascimento: '', dataInicioFuncoes: '', dataFimFuncoes: '',
    });
    setSheetOpen(true);
  }

  function openEdit(f: Funcionario) {
    setEditTarget(f);
    reset({
      nome: f.nome,
      apelido: f.apelido,
      numeroProcesso: f.numeroProcesso,
      estado: f.estado,
      dataNascimento: f.dataNascimento,
      dataInicioFuncoes: f.dataInicioFuncoes,
      dataFimFuncoes: f.dataFimFuncoes ?? '',
    });
    setSheetOpen(true);
  }

  function onSubmit(values: FormValues) {
    const data = { ...values, dataFimFuncoes: values.dataFimFuncoes || undefined };
    if (editTarget) {
      update(editTarget.id, data);
      toast.success('Funcionário atualizado.');
    } else {
      create(data);
      toast.success('Funcionário criado.');
    }
    setSheetOpen(false);
  }

  function confirmDelete() {
    if (!deleteTarget) return;
    remove(deleteTarget.id);
    toast.success('Funcionário eliminado.');
    setDeleteTarget(null);
  }

  const fmt = (iso?: string) =>
    iso ? format(parseISO(iso), 'dd/MM/yyyy', { locale: ptBR }) : '—';

  return (
    <PermissionGuard required="config.users.manage">
      <div className="p-6 space-y-5">
        <PageHeader
          title="Funcionários"
          description="Gerencie os funcionários e vincule os seus processos e documentos."
          primaryAction={{ label: 'Novo Funcionário', icon: <Plus className="h-4 w-4" />, onClick: openCreate }}
        />

        <div className="flex items-center gap-3">
          <input type="search" placeholder="Pesquisar por nome, apelido ou nº de processo..." value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-9 w-full max-w-sm rounded-md border border-input bg-white px-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1" />
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-xs">
          <table className="w-full text-sm">
            <thead className="border-b border-slate-200 bg-slate-50">
              <tr>
                {['Funcionário', 'Nº Processo', 'Estado', 'Início Funções', 'Fim Funções', 'Ações'].map((h) => (
                  <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-slate-500 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr><td colSpan={6} className="py-10 text-center text-sm text-slate-400">Nenhum funcionário encontrado.</td></tr>
              ) : filtered.map((f) => (
                <tr key={f.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3">
                    <Link href={`/configuracoes/funcionarios/${f.id}`} className="flex items-center gap-2.5 group">
                      <div className="h-8 w-8 rounded-full bg-sky-100 text-sky-700 flex items-center justify-center text-xs font-bold shrink-0">
                        {f.nome.charAt(0).toUpperCase()}
                      </div>
                      <span className="font-semibold text-slate-800 group-hover:text-sky-600 group-hover:underline">
                        {f.nome} {f.apelido}
                      </span>
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-slate-500 text-xs font-mono">{f.numeroProcesso}</td>
                  <td className="px-4 py-3 text-xs"><EstadoBadge estado={f.estado} /></td>
                  <td className="px-4 py-3 text-slate-500 text-xs whitespace-nowrap">{fmt(f.dataInicioFuncoes)}</td>
                  <td className="px-4 py-3 text-slate-500 text-xs whitespace-nowrap">{fmt(f.dataFimFuncoes)}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="icon-xs" onClick={() => openEdit(f)}><Pencil className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon-xs" onClick={() => setDeleteTarget(f)} className="text-slate-400 hover:text-red-500"><Trash2 className="h-3.5 w-3.5" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
        <SheetContent className="sm:max-w-md overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <Contact className="h-4 w-4 text-sky-600" />
              {editTarget ? `Editar: ${editTarget.nome} ${editTarget.apelido}` : 'Novo Funcionário'}
            </SheetTitle>
          </SheetHeader>
          <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4 px-3">
            <SectionCard title="Identificação">
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium text-slate-600">Nome <span className="text-red-500">*</span></Label>
                    <Input {...register('nome')} className="text-sm" />
                    {errors.nome && <p className="text-xs text-red-500">{errors.nome.message}</p>}
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium text-slate-600">Apelido <span className="text-red-500">*</span></Label>
                    <Input {...register('apelido')} className="text-sm" />
                    {errors.apelido && <p className="text-xs text-red-500">{errors.apelido.message}</p>}
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Nº de Processo <span className="text-red-500">*</span></Label>
                  <Input {...register('numeroProcesso')} className="text-sm" placeholder="Ex: PROC-2024/00123" />
                  {errors.numeroProcesso && <p className="text-xs text-red-500">{errors.numeroProcesso.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Estado <span className="text-red-500">*</span></Label>
                  <Select value={estado} onValueChange={(v) => setValue('estado', v as EstadoFuncionario)}>
                    <SelectTrigger className="h-9"><SelectValue placeholder="Selecionar estado" /></SelectTrigger>
                    <SelectContent>
                      {(Object.keys(ESTADO_LABELS) as EstadoFuncionario[]).map((e) => (
                        <SelectItem key={e} value={e}>{ESTADO_LABELS[e]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Data de Nascimento <span className="text-red-500">*</span></Label>
                  <Input {...register('dataNascimento')} type="date" className="text-sm" />
                  {errors.dataNascimento && <p className="text-xs text-red-500">{errors.dataNascimento.message}</p>}
                </div>
              </div>
            </SectionCard>

            <SectionCard title="Funções">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Início <span className="text-red-500">*</span></Label>
                  <Input {...register('dataInicioFuncoes')} type="date" className="text-sm" />
                  {errors.dataInicioFuncoes && <p className="text-xs text-red-500">{errors.dataInicioFuncoes.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Fim (opcional)</Label>
                  <Input {...register('dataFimFuncoes')} type="date" className="text-sm" />
                  {errors.dataFimFuncoes && <p className="text-xs text-red-500">{errors.dataFimFuncoes.message}</p>}
                </div>
              </div>
            </SectionCard>

            <SheetFooter className="mt-4 pt-4 border-t border-slate-100 gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setSheetOpen(false)}>Cancelar</Button>
              <Button type="submit" size="sm">{editTarget ? 'Guardar' : 'Criar Funcionário'}</Button>
            </SheetFooter>
          </form>
        </SheetContent>
      </Sheet>

      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Eliminar funcionário?</DialogTitle>
            <DialogDescription>&ldquo;{deleteTarget?.nome} {deleteTarget?.apelido}&rdquo; será eliminado permanentemente. Os documentos vinculados não serão apagados.</DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setDeleteTarget(null)}>Cancelar</Button>
            <Button variant="destructive" size="sm" onClick={confirmDelete}>Eliminar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PermissionGuard>
  );
}
