'use client';

import { useEffect, useMemo } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ArrowLeft, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/common/page-header';
import { SectionCard } from '@/components/common/section-card';
import { StatusBadge } from '@/components/common/status-badge';
import { EmptyState } from '@/components/common/empty-state';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { useFuncionariosStore } from '@/store/funcionarios-store';
import { useDocumentsStore } from '@/store/documents-store';
import { useConfigStore } from '@/store/config-store';
import { EstadoBadge } from '../page';

export default function FuncionarioDetailPage() {
  const params = useParams();
  const id = String(params.id);

  const { loaded: funcLoaded, load: loadFuncionarios, getById } = useFuncionariosStore();
  const docs = useDocumentsStore((s) => s.documents);
  const docsLoaded = useDocumentsStore((s) => s.loaded);
  const loadDocs = useDocumentsStore((s) => s.load);
  const { documentTypes, loaded: configLoaded, loadAll } = useConfigStore();

  useEffect(() => {
    if (!funcLoaded) loadFuncionarios();
    if (!docsLoaded) loadDocs();
    if (!configLoaded) loadAll();
  }, [funcLoaded, loadFuncionarios, docsLoaded, loadDocs, configLoaded, loadAll]);

  const funcionario = getById(id);

  const relatedDocs = useMemo(
    () => docs.filter((d) => d.funcionarioId === id),
    [docs, id],
  );

  const fmt = (iso?: string) =>
    iso ? format(parseISO(iso), 'dd/MM/yyyy', { locale: ptBR }) : '—';

  return (
    <PermissionGuard required="config.users.manage">
      <div className="p-6 space-y-5">
        <Button asChild variant="ghost" size="sm" className="gap-1.5 -ml-2 text-slate-500">
          <Link href="/configuracoes/funcionarios">
            <ArrowLeft className="h-4 w-4" /> Voltar aos funcionários
          </Link>
        </Button>

        {!funcionario ? (
          <EmptyState
            title="Funcionário não encontrado"
            description="O funcionário pode ter sido eliminado ou o link é inválido."
          />
        ) : (
          <>
            <PageHeader
              title={`${funcionario.nome} ${funcionario.apelido}`}
              description={`Nº de processo: ${funcionario.numeroProcesso}`}
            />

            <SectionCard title="Dados do Funcionário">
              <dl className="grid grid-cols-2 gap-4 sm:grid-cols-3">
                <div>
                  <dt className="text-xs text-slate-500 mb-0.5">Estado</dt>
                  <dd><EstadoBadge estado={funcionario.estado} /></dd>
                </div>
                <div>
                  <dt className="text-xs text-slate-500 mb-0.5">Nº de Processo</dt>
                  <dd className="text-sm text-slate-800 font-mono">{funcionario.numeroProcesso}</dd>
                </div>
                <div>
                  <dt className="text-xs text-slate-500 mb-0.5">Data de Nascimento</dt>
                  <dd className="text-sm text-slate-800">{fmt(funcionario.dataNascimento)}</dd>
                </div>
                <div>
                  <dt className="text-xs text-slate-500 mb-0.5">Início de Funções</dt>
                  <dd className="text-sm text-slate-800">{fmt(funcionario.dataInicioFuncoes)}</dd>
                </div>
                <div>
                  <dt className="text-xs text-slate-500 mb-0.5">Fim de Funções</dt>
                  <dd className="text-sm text-slate-800">{fmt(funcionario.dataFimFuncoes)}</dd>
                </div>
              </dl>
            </SectionCard>

            <SectionCard
              title={`Documentos relacionados (${relatedDocs.length})`}
              description="Processos e documentos vinculados a este funcionário."
            >
              {relatedDocs.length === 0 ? (
                <div className="py-8 text-center text-sm text-slate-400">
                  Nenhum documento vinculado. Edite um documento e selecione este funcionário para o vincular.
                </div>
              ) : (
                <div className="overflow-x-auto rounded-lg border border-slate-200">
                  <table className="w-full text-sm">
                    <thead className="border-b border-slate-200 bg-slate-50">
                      <tr>
                        {['Nº Documento', 'Tipo', 'Assunto', 'Estado', 'Data'].map((h) => (
                          <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-slate-500 whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {relatedDocs.map((d) => {
                        const dt = documentTypes.find((t) => t.id === d.tipoDocumentoId);
                        return (
                          <tr key={d.id} className="hover:bg-slate-50">
                            <td className="px-4 py-3">
                              <Link href={`/documentos/${d.id}`} className="flex items-center gap-2 font-semibold text-sky-700 hover:underline">
                                <FileText className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                                {d.numero}
                              </Link>
                            </td>
                            <td className="px-4 py-3 text-xs text-slate-600">{dt?.nome ?? '—'}</td>
                            <td className="px-4 py-3">
                              <span className="block max-w-70 truncate text-sm text-slate-700" title={d.assunto}>{d.assunto}</span>
                            </td>
                            <td className="px-4 py-3"><StatusBadge status={d.estado} /></td>
                            <td className="px-4 py-3 text-xs text-slate-600 whitespace-nowrap">{fmt(d.data)}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </SectionCard>
          </>
        )}
      </div>
    </PermissionGuard>
  );
}

