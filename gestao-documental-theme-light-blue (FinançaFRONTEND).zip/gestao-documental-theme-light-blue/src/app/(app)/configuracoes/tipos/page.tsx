﻿'use client';

import { useEffect, useMemo, useState } from 'react';
import {
  Plus, Pencil, Trash2, GripVertical, Eye, Tag, ToggleLeft, Copy,
} from 'lucide-react';
import { toast } from 'sonner';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  KeyboardSensor,
  closestCenter,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
} from '@dnd-kit/core';
import {
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
  arrayMove,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from '@/components/ui/sheet';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
  DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PageHeader } from '@/components/common/page-header';
import { FieldRenderer } from '@/components/common/field-renderer';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { useConfigStore } from '@/store/config-store';
import { useAuthStore } from '@/store/auth-store';
import { auditRepo, documentsRepo } from '@/lib/db';
import type { CustomField, DocumentType, FieldType } from '@/types';

function slugify(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
}

const FIELD_TYPE_LABEL: Record<FieldType, string> = {
  text: 'Texto', number: 'Número', date: 'Data', select: 'Seleção',
  textarea: 'Área de texto', boolean: 'Sim/Não', currency: 'Moeda',
};

const REGISTRO_OPTIONS = [
  { value: 'todos', label: 'Todos' },
  { value: 'entrada', label: 'Entradas' },
  { value: 'saida', label: 'Saídas' },
  { value: 'interno', label: 'Internos' },
] as const;

const schema = z.object({
  nome: z.string().min(2, 'Nome obrigatório'),
  descricao: z.string().optional(),
  registro: z.enum(['todos', 'entrada', 'saida', 'interno']),
  ativo: z.boolean(),
});
type FormValues = z.infer<typeof schema>;

// ─── SortableFieldRow ─────────────────────────────────────────────────────────

function SortableFieldRow({
  field,
  isOnly,
  isDropTarget,
  onEdit,
  onRemove,
  onDuplicate,
}: {
  field: CustomField;
  isOnly: boolean;
  isDropTarget: boolean;
  onEdit: () => void;
  onRemove: () => void;
  onDuplicate: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id: field.id });

  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition: transition ?? undefined,
    opacity: isDragging ? 0.4 : undefined,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      data-field-id={field.id}
      className={[
        'flex items-center gap-2 rounded-lg border bg-white px-3 py-2.5',
        isDropTarget && !isDragging
          ? 'border-t-2 border-t-sky-500 border-x border-x-slate-200 border-b border-b-slate-200'
          : 'border-slate-200',
      ].join(' ')}
    >
      {!isOnly ? (
        <button
          type="button"
          {...attributes}
          {...listeners}
          className="shrink-0 touch-none cursor-grab active:cursor-grabbing text-slate-300 hover:text-slate-500 rounded p-0.5"
          aria-label="Arrastar para reordenar"
        >
          <GripVertical className="h-4 w-4" />
        </button>
      ) : (
        <div className="w-5 shrink-0" />
      )}
      <div className="flex-1 min-w-0">
        {field.label
          ? <p className="text-sm font-medium text-slate-800 truncate">{field.label}</p>
          : <p className="text-sm italic text-slate-400 truncate">Sem etiqueta</p>
        }
        <p className="text-[10px] text-slate-400 font-mono truncate">{field.key}</p>
      </div>
      <Badge variant="outline" className="text-[10px] shrink-0">{FIELD_TYPE_LABEL[field.tipo]}</Badge>
      {field.obrigatorio && (
        <Badge className="text-[10px] bg-red-50 text-red-600 border border-red-200 shrink-0">Req.</Badge>
      )}
      <div className="flex items-center gap-0.5 shrink-0">
        <Button type="button" variant="ghost" size="icon-xs" onClick={onEdit} title="Editar campo">
          <Pencil className="h-3.5 w-3.5" />
        </Button>
        <Button type="button" variant="ghost" size="icon-xs" onClick={onDuplicate} title="Duplicar campo">
          <Copy className="h-3.5 w-3.5" />
        </Button>
        <Button
          type="button" variant="ghost" size="icon-xs"
          onClick={onRemove}
          className="text-slate-400 hover:text-red-500"
          title="Remover campo"
        >
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>
    </div>
  );
}

// ─── FieldEditDialog ──────────────────────────────────────────────────────────

function FieldEditDialog({
  field,
  open,
  onClose,
  onChange,
}: {
  field: CustomField | null;
  open: boolean;
  onClose: () => void;
  onChange: (f: CustomField) => void;
}) {
  const [optionInput, setOptionInput] = useState('');

  useEffect(() => {
    if (!open) setOptionInput('');
  }, [open]);

  if (!field) return null;

  const update = (changes: Partial<CustomField>) => onChange({ ...field, ...changes });

  const addOption = () => {
    if (!optionInput.trim()) return;
    update({ opcoes: [...(field.opcoes ?? []), optionInput.trim()] });
    setOptionInput('');
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Editar Campo</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-1">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-slate-600">Etiqueta *</Label>
              <Input
                value={field.label}
                onChange={(e) => {
                  const label = e.target.value;
                  update({ label, key: slugify(label) });
                }}
                className="h-8 text-sm"
                placeholder="Nome do campo"
                autoFocus
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-slate-600">Chave (slug)</Label>
              <Input
                value={field.key}
                onChange={(e) => update({ key: slugify(e.target.value) })}
                className="h-8 font-mono text-xs"
                placeholder="chave_slug"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-medium text-slate-600">Tipo</Label>
            <Select
              value={field.tipo}
              onValueChange={(v) => update({ tipo: v as FieldType, opcoes: [] })}
            >
              <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
              <SelectContent>
                {(Object.keys(FIELD_TYPE_LABEL) as FieldType[]).map((t) => (
                  <SelectItem key={t} value={t} className="text-sm">{FIELD_TYPE_LABEL[t]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-3 rounded-lg border border-slate-100 bg-slate-50 px-3 py-2.5">
            <Switch
              checked={field.obrigatorio}
              onCheckedChange={(v) => update({ obrigatorio: v })}
            />
            <Label className="text-sm text-slate-700 cursor-pointer">Campo obrigatório</Label>
          </div>
          {field.tipo === 'select' && (
            <div className="space-y-2">
              <Label className="text-xs font-medium text-slate-600">Opções de seleção</Label>
              <div className="flex gap-2">
                <Input
                  value={optionInput}
                  onChange={(e) => setOptionInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addOption(); } }}
                  placeholder="Nova opção..."
                  className="h-7 text-xs"
                />
                <Button type="button" size="sm" variant="outline" onClick={addOption} className="h-7 px-2 text-xs">Add</Button>
              </div>
              <div className="flex flex-wrap gap-1">
                {field.opcoes?.map((opt, i) => (
                  <Badge key={i} variant="secondary" className="text-xs pr-1">
                    {opt}
                    <button
                      type="button"
                      onClick={() => update({ opcoes: field.opcoes?.filter((_, j) => j !== i) })}
                      className="ml-1 hover:text-red-500"
                    >×</button>
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" size="sm" onClick={onClose}>Fechar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── DndFieldList ─────────────────────────────────────────────────────────────

function DndFieldList({
  campos,
  onChange,
  onEdit,
  onRemove,
  onDuplicate,
}: {
  campos: CustomField[];
  onChange: (campos: CustomField[]) => void;
  onEdit: (id: string) => void;
  onRemove: (id: string) => void;
  onDuplicate: (id: string) => void;
}) {
  const [activeId, setActiveId] = useState<string | null>(null);
  const [overId, setOverId] = useState<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  function handleDragStart({ active }: DragStartEvent) {
    setActiveId(active.id as string);
  }

  function handleDragOver({ over }: { over: { id: string | number } | null }) {
    setOverId(over ? String(over.id) : null);
  }

  function handleDragEnd({ active, over }: DragEndEvent) {
    setActiveId(null);
    setOverId(null);
    if (!over || active.id === over.id) return;
    const oldIdx = campos.findIndex((c) => c.id === active.id);
    const newIdx = campos.findIndex((c) => c.id === over.id);
    if (oldIdx < 0 || newIdx < 0) return;
    onChange(arrayMove(campos, oldIdx, newIdx).map((c, i) => ({ ...c, ordem: i })));
  }

  function handleDragCancel() {
    setActiveId(null);
    setOverId(null);
  }

  const activeField = campos.find((c) => c.id === activeId) ?? null;
  const isOnly = campos.length === 1;

  if (campos.length === 0) {
    return (
      <div className="py-10 text-center rounded-lg border border-dashed border-slate-200">
        <p className="text-sm text-slate-400">Ainda sem campos. Adicione o primeiro →</p>
      </div>
    );
  }

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragStart={handleDragStart}
      onDragOver={handleDragOver}
      onDragEnd={handleDragEnd}
      onDragCancel={handleDragCancel}
    >
      <SortableContext items={campos.map((c) => c.id)} strategy={verticalListSortingStrategy}>
        <div className="space-y-2">
          {campos.map((field) => (
            <SortableFieldRow
              key={field.id}
              field={field}
              isOnly={isOnly}
              isDropTarget={overId === field.id && activeId !== field.id}
              onEdit={() => onEdit(field.id)}
              onRemove={() => onRemove(field.id)}
              onDuplicate={() => onDuplicate(field.id)}
            />
          ))}
        </div>
      </SortableContext>
      <DragOverlay>
        {activeField && (
          <div className="flex items-center gap-2 rounded-lg border border-sky-300 bg-white shadow-xl px-3 py-2.5 cursor-grabbing ring-1 ring-sky-200">
            <GripVertical className="h-4 w-4 text-sky-400 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-slate-800 truncate">{activeField.label}</p>
              <p className="text-[10px] text-slate-400 font-mono truncate">{activeField.key}</p>
            </div>
            <Badge variant="outline" className="text-[10px] shrink-0">{FIELD_TYPE_LABEL[activeField.tipo]}</Badge>
          </div>
        )}
      </DragOverlay>
    </DndContext>
  );
}

// ─── TiposPage ────────────────────────────────────────────────────────────────

export default function TiposPage() {
  const { documentTypes, loaded, loadAll, createDocumentType, updateDocumentType, removeDocumentType } = useConfigStore();
  const currentUser = useAuthStore((s) => s.currentUser);

  useEffect(() => { if (!loaded) loadAll(); }, [loaded, loadAll]);

  const [search, setSearch] = useState('');
  const [sheetOpen, setSheetOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<DocumentType | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<DocumentType | null>(null);
  const [campos, setCampos] = useState<CustomField[]>([]);
  const [previewValues, setPreviewValues] = useState<Record<string, unknown>>({});
  const [editingFieldId, setEditingFieldId] = useState<string | null>(null);
  const [pendingScrollId, setPendingScrollId] = useState<string | null>(null);
  const [removeConfirmField, setRemoveConfirmField] = useState<{ id: string; label: string } | null>(null);

  const filtered = useMemo(() =>
    documentTypes.filter((dt) => !search || dt.nome.toLowerCase().includes(search.toLowerCase())),
    [documentTypes, search]);

  const { register, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { nome: '', descricao: '', registro: 'todos', ativo: true },
  });
  const ativo = watch('ativo');
  const registro = watch('registro');

  // After addField / duplicate, scroll to the new row and open its editor
  useEffect(() => {
    if (!pendingScrollId) return;
    const timer = setTimeout(() => {
      document.querySelector(`[data-field-id="${pendingScrollId}"]`)
        ?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      setEditingFieldId(pendingScrollId);
      setPendingScrollId(null);
    }, 80);
    return () => clearTimeout(timer);
  }, [pendingScrollId]);

  function openCreate() {
    setEditTarget(null);
    setCampos([]);
    setPreviewValues({});
    setEditingFieldId(null);
    reset({ nome: '', descricao: '', registro: 'todos', ativo: true });
    setSheetOpen(true);
  }

  function openEdit(dt: DocumentType) {
    setEditTarget(dt);
    setCampos([...dt.campos].sort((a, b) => a.ordem - b.ordem));
    setPreviewValues({});
    setEditingFieldId(null);
    reset({ nome: dt.nome, descricao: dt.descricao, registro: dt.registro, ativo: dt.ativo });
    setSheetOpen(true);
  }

  function addField() {
    const newId = crypto.randomUUID();
    setCampos((prev) => [
      ...prev,
      { id: newId, label: '', key: `campo_${prev.length + 1}`, tipo: 'text', obrigatorio: false, ordem: prev.length },
    ]);
    setPendingScrollId(newId);
  }

  function handleFieldChange(f: CustomField) {
    setCampos((prev) => prev.map((c) => (c.id === f.id ? f : c)));
  }

  function handleDuplicate(id: string) {
    const original = campos.find((c) => c.id === id);
    if (!original) return;
    const newId = crypto.randomUUID();
    setCampos((prev) => [
      ...prev,
      {
        ...original,
        id: newId,
        label: `Cópia de ${original.label}`,
        key: slugify(`copia_${original.key}`),
        ordem: prev.length,
      },
    ]);
    setPendingScrollId(newId);
  }

  function handleRemove(id: string) {
    const field = campos.find((c) => c.id === id);
    if (!field) return;
    const hasValues = editTarget
      ? documentsRepo.list().some(
          (d) =>
            d.tipoDocumentoId === editTarget.id &&
            d.camposValores[field.key] != null &&
            d.camposValores[field.key] !== '',
        )
      : false;
    if (hasValues) {
      setRemoveConfirmField({ id, label: field.label });
    } else {
      setCampos((prev) => prev.filter((c) => c.id !== id).map((c, i) => ({ ...c, ordem: i })));
    }
  }

  function onSubmit(values: FormValues) {
    if (campos.some((c) => !c.label.trim() || !c.key.trim())) {
      toast.error('Todos os campos precisam de etiqueta e chave.'); return;
    }
    const now = new Date().toISOString();
    const camposWithOrder = campos.map((c, i) => ({ ...c, ordem: i }));
    if (editTarget) {
      updateDocumentType(editTarget.id, { ...values, descricao: values.descricao ?? '', campos: camposWithOrder });
      auditRepo.create({ evento: 'atualizado', tabela: 'document_types', registroId: editTarget.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: now, detalhe: `Tipo "${values.nome}" atualizado` });
      toast.success('Tipo atualizado.');
    } else {
      const dt = createDocumentType({ ...values, descricao: values.descricao ?? '', campos: camposWithOrder });
      auditRepo.create({ evento: 'cadastrado', tabela: 'document_types', registroId: dt.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: now, detalhe: `Tipo "${values.nome}" criado` });
      toast.success('Tipo criado.');
    }
    setSheetOpen(false);
    setEditingFieldId(null);
  }

  function confirmDelete() {
    if (!deleteTarget) return;
    removeDocumentType(deleteTarget.id);
    auditRepo.create({ evento: 'eliminado', tabela: 'document_types', registroId: deleteTarget.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: new Date().toISOString(), detalhe: `Tipo "${deleteTarget.nome}" eliminado` });
    toast.success('Tipo eliminado.');
    setDeleteTarget(null);
  }

  const editingField = campos.find((c) => c.id === editingFieldId) ?? null;

  return (
    <PermissionGuard required="config.types.manage">
      <div className="p-6 space-y-5">
        <PageHeader
          title="Tipos de Documento"
          description="Defina os tipos e os campos dinâmicos dos formulários de registo."
          primaryAction={{ label: 'Novo Tipo', icon: <Plus className="h-4 w-4" />, onClick: openCreate }}
        />
        <input
          type="search"
          placeholder="Pesquisar tipos..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="h-9 w-full max-w-sm rounded-md border border-input bg-white px-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1"
        />

        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-xs">
          <table className="w-full text-sm">
            <thead className="border-b border-slate-200 bg-slate-50">
              <tr>
                {['Nome', 'Registo', 'Campos', 'Ativo', 'Ações'].map((h) => (
                  <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-slate-500 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr><td colSpan={5} className="py-10 text-center text-sm text-slate-400">Nenhum tipo encontrado.</td></tr>
              ) : filtered.map((dt) => (
                <tr key={dt.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3">
                    <p className="font-semibold text-slate-800">{dt.nome}</p>
                    {dt.descricao && <p className="text-xs text-slate-400 truncate max-w-xs">{dt.descricao}</p>}
                  </td>
                  <td className="px-4 py-3">
                    <Badge variant="outline" className="text-xs">{REGISTRO_OPTIONS.find((r) => r.value === dt.registro)?.label}</Badge>
                  </td>
                  <td className="px-4 py-3 text-slate-600">{dt.campos.length}</td>
                  <td className="px-4 py-3">
                    {dt.ativo ? <Badge className="bg-emerald-500 text-white text-xs">Ativo</Badge>
                      : <Badge variant="outline" className="text-xs text-slate-400">Inativo</Badge>}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="icon-xs" onClick={() => openEdit(dt)}><Pencil className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon-xs" onClick={() => setDeleteTarget(dt)} className="text-slate-400 hover:text-red-500"><Trash2 className="h-3.5 w-3.5" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Sheet open={sheetOpen} onOpenChange={(o) => { setSheetOpen(o); if (!o) { setEditingFieldId(null); setRemoveConfirmField(null); } }}>
        <SheetContent className="sm:max-w-2xl overflow-y-auto flex flex-col">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <Tag className="h-4 w-4 text-sky-600" />
              {editTarget ? `Editar: ${editTarget.nome}` : 'Novo Tipo de Documento'}
            </SheetTitle>
          </SheetHeader>
          <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col flex-1 min-h-0 px-3">
            <Tabs defaultValue="info" className="flex-1 flex flex-col mt-4">
              <TabsList>
                <TabsTrigger value="info">Informações</TabsTrigger>
                <TabsTrigger value="campos">
                  Campos {campos.length > 0 && (
                    <span className="ml-1 rounded-full bg-sky-100 px-1.5 text-[10px] font-bold text-sky-700">{campos.length}</span>
                  )}
                </TabsTrigger>
                <TabsTrigger value="preview"><Eye className="h-3.5 w-3.5 mr-1" />Preview</TabsTrigger>
              </TabsList>

              <TabsContent value="info" className="mt-4 space-y-4">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Nome <span className="text-red-500">*</span></Label>
                  <Input {...register('nome')} className="text-sm" />
                  {errors.nome && <p className="text-xs text-red-500">{errors.nome.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Descrição</Label>
                  <Textarea {...register('descricao')} rows={2} className="text-sm resize-none" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Registo aplicável</Label>
                  <Select value={registro} onValueChange={(v) => setValue('registro', v as typeof registro)}>
                    <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {REGISTRO_OPTIONS.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between rounded-lg border border-slate-100 bg-slate-50 px-4 py-3">
                  <div className="flex items-center gap-2">
                    <ToggleLeft className="h-4 w-4 text-slate-400" />
                    <div>
                      <p className="text-sm font-medium text-slate-700">Ativo</p>
                      <p className="text-xs text-slate-500">Disponível nos formulários de registo</p>
                    </div>
                  </div>
                  <Switch checked={ativo} onCheckedChange={(v) => setValue('ativo', v)} />
                </div>
              </TabsContent>

              <TabsContent value="campos" className="mt-4 space-y-3">
                <p className="text-xs text-slate-500">
                  Campos adicionais do formulário de registo.
                  {campos.length > 1 && ' Arraste para reordenar.'}
                </p>
                <DndFieldList
                  campos={campos}
                  onChange={setCampos}
                  onEdit={setEditingFieldId}
                  onRemove={handleRemove}
                  onDuplicate={handleDuplicate}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addField}
                  className="gap-1.5 w-full border-dashed"
                >
                  <Plus className="h-3.5 w-3.5" />Adicionar Campo
                </Button>
              </TabsContent>

              <TabsContent value="preview" className="mt-4">
                {campos.length === 0 ? (
                  <div className="py-10 text-center text-sm text-slate-400">Adicione campos para ver a pré-visualização.</div>
                ) : (
                  <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 space-y-4">
                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Pré-visualização do formulário</p>
                    {[...campos].sort((a, b) => a.ordem - b.ordem).map((campo) => (
                      <div key={campo.id} className="space-y-1.5">
                        <Label className="text-xs font-medium">
                          {campo.label}
                          {campo.obrigatorio && <span className="text-red-500 ml-0.5">*</span>}
                        </Label>
                        <FieldRenderer
                          field={campo}
                          value={previewValues[campo.key]}
                          onChange={(v) => setPreviewValues((prev) => ({ ...prev, [campo.key]: v }))}
                        />
                      </div>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
            <SheetFooter className="mt-4 pt-4 border-t border-slate-100 gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setSheetOpen(false)}>Cancelar</Button>
              <Button type="submit" size="sm">{editTarget ? 'Guardar' : 'Criar Tipo'}</Button>
            </SheetFooter>
          </form>
        </SheetContent>
      </Sheet>

      {/* Field editor – opens as Dialog on top of the Sheet */}
      <FieldEditDialog
        field={editingField}
        open={!!editingFieldId}
        onClose={() => setEditingFieldId(null)}
        onChange={handleFieldChange}
      />

      {/* Confirm removal when field already has data in existing documents */}
      <Dialog open={!!removeConfirmField} onOpenChange={(o) => !o && setRemoveConfirmField(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Remover campo?</DialogTitle>
            <DialogDescription>
              O campo &ldquo;{removeConfirmField?.label}&rdquo; tem dados preenchidos em documentos
              existentes. Removê-lo não apaga esses dados, mas o campo deixará de aparecer nos
              formulários.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setRemoveConfirmField(null)}>Cancelar</Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => {
                if (!removeConfirmField) return;
                setCampos((prev) =>
                  prev.filter((c) => c.id !== removeConfirmField.id).map((c, i) => ({ ...c, ordem: i })),
                );
                setRemoveConfirmField(null);
              }}
            >
              Remover mesmo assim
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete document type confirm */}
      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Eliminar tipo?</DialogTitle>
            <DialogDescription>&ldquo;{deleteTarget?.nome}&rdquo; será eliminado permanentemente.</DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setDeleteTarget(null)}>Cancelar</Button>
            <Button variant="destructive" size="sm" onClick={confirmDelete}>Eliminar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PermissionGuard>
  );
}
