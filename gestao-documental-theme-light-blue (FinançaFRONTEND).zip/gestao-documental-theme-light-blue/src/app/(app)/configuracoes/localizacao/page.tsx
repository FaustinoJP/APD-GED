'use client';

import { useEffect, useMemo, useState } from 'react';
import { Plus, Pencil, Trash2, GripVertical, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';
import {
  DndContext,
  PointerSensor,
  KeyboardSensor,
  closestCenter,
  useSensor,
  useSensors,
  type DragEndEvent,
} from '@dnd-kit/core';
import {
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
  arrayMove,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { PageHeader } from '@/components/common/page-header';
import { SectionCard } from '@/components/common/section-card';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { useConfigStore } from '@/store/config-store';
import { buildLocationTree, nextLevel, sortedLevels, type LocationTreeNode } from '@/lib/locations/locationTree';
import type { LocationLevel } from '@/types';
import { cn } from '@/lib/utils';

// ─── Sortable level row ───────────────────────────────────────────────────────

function SortableLevelRow({
  level, isOnly, onEdit, onRemove,
}: {
  level: LocationLevel;
  isOnly: boolean;
  onEdit: () => void;
  onRemove: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id: level.id });

  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition: transition ?? undefined,
    opacity: isDragging ? 0.4 : undefined,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2.5"
    >
      {!isOnly ? (
        <button
          type="button"
          {...attributes}
          {...listeners}
          className="shrink-0 touch-none cursor-grab active:cursor-grabbing text-slate-300 hover:text-slate-500 rounded p-0.5"
          aria-label="Arrastar para reordenar"
        >
          <GripVertical className="h-4 w-4" />
        </button>
      ) : (
        <div className="w-5 shrink-0" />
      )}
      <span className="flex-1 text-sm font-medium text-slate-800">{level.nome}</span>
      <div className="flex items-center gap-0.5 shrink-0">
        <Button type="button" variant="ghost" size="icon-xs" onClick={onEdit} title="Editar nível">
          <Pencil className="h-3.5 w-3.5" />
        </Button>
        <Button
          type="button" variant="ghost" size="icon-xs" onClick={onRemove}
          className="text-slate-400 hover:text-red-500" title="Remover nível"
        >
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>
    </div>
  );
}

// ─── Levels editor ────────────────────────────────────────────────────────────

function LevelsEditor() {
  const {
    locationLevels, locationNodes, createLocationLevel, updateLocationLevel, removeLocationLevel,
  } = useConfigStore();

  const levels = useMemo(() => sortedLevels(locationLevels), [locationLevels]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<LocationLevel | null>(null);
  const [nomeInput, setNomeInput] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<LocationLevel | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  function handleDragEnd({ active, over }: DragEndEvent) {
    if (!over || active.id === over.id) return;
    const oldIdx = levels.findIndex((l) => l.id === active.id);
    const newIdx = levels.findIndex((l) => l.id === over.id);
    if (oldIdx < 0 || newIdx < 0) return;
    const reordered = arrayMove(levels, oldIdx, newIdx);
    reordered.forEach((l, i) => {
      if (l.ordem !== i) updateLocationLevel(l.id, { ordem: i });
    });
  }

  function openCreate() {
    setEditTarget(null);
    setNomeInput('');
    setDialogOpen(true);
  }

  function openEdit(level: LocationLevel) {
    setEditTarget(level);
    setNomeInput(level.nome);
    setDialogOpen(true);
  }

  function handleSave() {
    if (!nomeInput.trim()) {
      toast.error('Indique um nome para o nível.');
      return;
    }
    if (editTarget) {
      updateLocationLevel(editTarget.id, { nome: nomeInput.trim() });
      toast.success('Nível atualizado.');
    } else {
      createLocationLevel({ nome: nomeInput.trim(), ordem: levels.length });
      toast.success('Nível criado.');
    }
    setDialogOpen(false);
  }

  function handleRemove(level: LocationLevel) {
    const hasNodes = locationNodes.some((n) => n.nivelId === level.id);
    if (hasNodes) {
      toast.error('Existem localizações criadas neste nível — remova-as primeiro.');
      return;
    }
    setDeleteTarget(level);
  }

  return (
    <SectionCard
      title="Níveis da hierarquia"
      description="Defina os 'andares' do arquivo físico (ex: Sala, Corredor, Prateleira, Nível, Gaveta) e a sua ordem."
      actions={
        <Button size="sm" className="gap-1.5 text-xs" onClick={openCreate}>
          <Plus className="h-3.5 w-3.5" /> Novo Nível
        </Button>
      }
    >
      {levels.length === 0 ? (
        <div className="py-8 text-center rounded-lg border border-dashed border-slate-200">
          <p className="text-sm text-slate-400">Ainda sem níveis definidos. Adicione o primeiro →</p>
        </div>
      ) : (
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
          <SortableContext items={levels.map((l) => l.id)} strategy={verticalListSortingStrategy}>
            <div className="space-y-2">
              {levels.map((level) => (
                <SortableLevelRow
                  key={level.id}
                  level={level}
                  isOnly={levels.length === 1}
                  onEdit={() => openEdit(level)}
                  onRemove={() => handleRemove(level)}
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>{editTarget ? 'Editar Nível' : 'Novo Nível'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-1.5 py-1">
            <Label className="text-xs font-medium text-slate-600">Nome</Label>
            <Input
              value={nomeInput}
              onChange={(e) => setNomeInput(e.target.value)}
              placeholder="Ex: Sala"
              autoFocus
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleSave(); } }}
            />
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setDialogOpen(false)}>Cancelar</Button>
            <Button size="sm" onClick={handleSave}>Guardar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Remover nível?</DialogTitle>
            <DialogDescription>
              &ldquo;{deleteTarget?.nome}&rdquo; será removido permanentemente da hierarquia.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setDeleteTarget(null)}>Cancelar</Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => {
                if (!deleteTarget) return;
                removeLocationLevel(deleteTarget.id);
                toast.success('Nível removido.');
                setDeleteTarget(null);
              }}
            >
              Remover
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SectionCard>
  );
}

// ─── Node tree row ────────────────────────────────────────────────────────────

function NodeRow({
  tree, depth, onAddChild, onEdit, onRemove,
}: {
  tree: LocationTreeNode;
  depth: number;
  onAddChild: (parent: LocationTreeNode) => void;
  onEdit: (tree: LocationTreeNode) => void;
  onRemove: (tree: LocationTreeNode) => void;
}) {
  const [expanded, setExpanded] = useState(true);
  const hasKids = tree.children.length > 0;

  return (
    <div>
      <div
        className="group flex items-center gap-1.5 rounded-md py-1.5 pr-2 hover:bg-slate-50"
        style={{ paddingLeft: `${8 + depth * 20}px` }}
      >
        <button
          type="button"
          onClick={() => setExpanded((e) => !e)}
          className="shrink-0 text-slate-400"
        >
          {hasKids ? (
            <ChevronRight className={cn('h-3.5 w-3.5 transition-transform', expanded && 'rotate-90')} />
          ) : (
            <span className="block h-3.5 w-3.5" />
          )}
        </button>
        <span className="flex-1 truncate text-sm text-slate-700">{tree.node.nome}</span>
        <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 shrink-0">
          <Button
            type="button" variant="ghost" size="icon-xs" title="Adicionar filho"
            onClick={() => onAddChild(tree)}
          >
            <Plus className="h-3.5 w-3.5" />
          </Button>
          <Button type="button" variant="ghost" size="icon-xs" title="Editar" onClick={() => onEdit(tree)}>
            <Pencil className="h-3.5 w-3.5" />
          </Button>
          <Button
            type="button" variant="ghost" size="icon-xs" title="Remover"
            className="text-slate-400 hover:text-red-500"
            onClick={() => onRemove(tree)}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
      {expanded && hasKids && tree.children.map((child) => (
        <NodeRow
          key={child.node.id}
          tree={child}
          depth={depth + 1}
          onAddChild={onAddChild}
          onEdit={onEdit}
          onRemove={onRemove}
        />
      ))}
    </div>
  );
}

// ─── Nodes tree manager ───────────────────────────────────────────────────────

function NodesTree() {
  const {
    locationLevels, locationNodes, createLocationNode, updateLocationNode, removeLocationNode,
  } = useConfigStore();

  const levels = useMemo(() => sortedLevels(locationLevels), [locationLevels]);
  const tree = useMemo(() => buildLocationTree(locationNodes), [locationNodes]);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<LocationTreeNode | null>(null);
  const [parentTarget, setParentTarget] = useState<LocationTreeNode | null>(null);
  const [nomeInput, setNomeInput] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<LocationTreeNode | null>(null);

  const firstLevel = levels[0];
  const targetLevel = editTarget
    ? levels.find((l) => l.id === editTarget.node.nivelId)
    : nextLevel(parentTarget?.node.nivelId, levels);

  function openCreateRoot() {
    if (!firstLevel) {
      toast.error('Defina primeiro pelo menos um nível na hierarquia.');
      return;
    }
    setEditTarget(null);
    setParentTarget(null);
    setNomeInput('');
    setDialogOpen(true);
  }

  function openAddChild(parent: LocationTreeNode) {
    if (!nextLevel(parent.node.nivelId, levels)) {
      toast.error('Não há mais nenhum nível configurado abaixo deste.');
      return;
    }
    setEditTarget(null);
    setParentTarget(parent);
    setNomeInput('');
    setDialogOpen(true);
  }

  function openEdit(tree: LocationTreeNode) {
    setEditTarget(tree);
    setParentTarget(null);
    setNomeInput(tree.node.nome);
    setDialogOpen(true);
  }

  function handleSave() {
    if (!nomeInput.trim()) {
      toast.error('Indique um nome.');
      return;
    }
    if (editTarget) {
      updateLocationNode(editTarget.node.id, { nome: nomeInput.trim() });
      toast.success('Localização atualizada.');
    } else if (targetLevel) {
      const siblings = parentTarget ? parentTarget.children : tree;
      createLocationNode({
        nome: nomeInput.trim(),
        nivelId: targetLevel.id,
        parentId: parentTarget?.node.id,
        ordem: siblings.length,
      });
      toast.success('Localização criada.');
    }
    setDialogOpen(false);
  }

  function handleRemove(t: LocationTreeNode) {
    if (t.children.length > 0) {
      toast.error('Remova primeiro as localizações dentro desta.');
      return;
    }
    setDeleteTarget(t);
  }

  return (
    <SectionCard
      title="Localizações"
      description="A árvore real do arquivo físico da entidade (as salas, corredores, prateleiras concretas)."
      actions={
        <Button size="sm" className="gap-1.5 text-xs" onClick={openCreateRoot}>
          <Plus className="h-3.5 w-3.5" /> Nova Localização
        </Button>
      }
    >
      {tree.length === 0 ? (
        <div className="py-8 text-center rounded-lg border border-dashed border-slate-200">
          <p className="text-sm text-slate-400">Ainda sem localizações. Adicione a primeira →</p>
        </div>
      ) : (
        <div className="space-y-0.5">
          {tree.map((t) => (
            <NodeRow
              key={t.node.id}
              tree={t}
              depth={0}
              onAddChild={openAddChild}
              onEdit={openEdit}
              onRemove={handleRemove}
            />
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>
              {editTarget ? 'Editar Localização' : `Nova Localização${targetLevel ? ` — ${targetLevel.nome}` : ''}`}
            </DialogTitle>
            {parentTarget && !editTarget && (
              <DialogDescription>Dentro de &ldquo;{parentTarget.node.nome}&rdquo;.</DialogDescription>
            )}
          </DialogHeader>
          <div className="space-y-1.5 py-1">
            <Label className="text-xs font-medium text-slate-600">Nome</Label>
            <Input
              value={nomeInput}
              onChange={(e) => setNomeInput(e.target.value)}
              placeholder="Ex: Sala A"
              autoFocus
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleSave(); } }}
            />
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setDialogOpen(false)}>Cancelar</Button>
            <Button size="sm" onClick={handleSave}>Guardar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Remover localização?</DialogTitle>
            <DialogDescription>
              &ldquo;{deleteTarget?.node.nome}&rdquo; será removida permanentemente.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setDeleteTarget(null)}>Cancelar</Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => {
                if (!deleteTarget) return;
                removeLocationNode(deleteTarget.node.id);
                toast.success('Localização removida.');
                setDeleteTarget(null);
              }}
            >
              Remover
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SectionCard>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function LocalizacaoFisicaConfigPage() {
  const { loaded, loadAll } = useConfigStore();
  useEffect(() => { if (!loaded) loadAll(); }, [loaded, loadAll]);

  return (
    <PermissionGuard required="config.locations.manage">
      <div className="p-6 space-y-5">
        <PageHeader
          title="Localização Física"
          description="Configure a hierarquia de arquivo físico dos documentos (ex: Sala > Corredor > Prateleira > Nível > Gaveta)."
        />
        <div className="grid gap-5 lg:grid-cols-2 items-start">
          <LevelsEditor />
          <NodesTree />
        </div>
      </div>
    </PermissionGuard>
  );
}
