﻿'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Plus, Pencil, Trash2, User2, KeyRound, Upload } from 'lucide-react';
import { toast } from 'sonner';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from '@/components/ui/sheet';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
  DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { PageHeader } from '@/components/common/page-header';
import { SectionCard } from '@/components/common/section-card';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { useConfigStore } from '@/store/config-store';
import { useAuthStore } from '@/store/auth-store';
import { auditRepo } from '@/lib/db';
import { apiUploadFile } from '@/lib/api/uploads';
import { apiClient } from '@/lib/api/client';
import { resolveFileUrl } from '@/lib/file-url';
import type { User } from '@/types';

const schema = z.object({
  nome: z.string().min(2, 'Nome obrigatório'),
  email: z.string().email('E-mail inválido'),
  roleId: z.string().min(1, 'Perfil obrigatório'),
  ativo: z.boolean(),
  avatarUrl: z.string().optional(),
  senha: z.string().min(4, 'Senha deve ter pelo menos 4 caracteres').optional().or(z.literal('')),
});
type FormValues = z.infer<typeof schema>;

const IS_API_MODE = process.env.NEXT_PUBLIC_DATA_SOURCE === 'api';

export default function UtilizadoresPage() {
  const { users, roles, loaded, loadAll, createUser, updateUser, removeUser } = useConfigStore();
  const currentUser = useAuthStore((s) => s.currentUser);

  useEffect(() => { if (!loaded) loadAll(); }, [loaded, loadAll]);

  const [search, setSearch] = useState('');
  const [sheetOpen, setSheetOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<User | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<User | null>(null);
  const [resetTarget, setResetTarget] = useState<User | null>(null);
  const [novaSenha, setNovaSenha] = useState('');
  const [uploading, setUploading] = useState(false);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  const filtered = useMemo(() =>
    users.filter((u) =>
      !search || u.nome.toLowerCase().includes(search.toLowerCase()) || u.email.includes(search)
    ),
    [users, search]);

  const { register, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { nome: '', email: '', roleId: '', ativo: true, avatarUrl: '' },
  });
  const ativo = watch('ativo');
  const avatarUrl = watch('avatarUrl');
  const roleId = watch('roleId');

  function openCreate() {
    setEditTarget(null);
    reset({ nome: '', email: '', roleId: roles[0]?.id ?? '', ativo: true, avatarUrl: '', senha: '' });
    setSheetOpen(true);
  }

  function openEdit(u: User) {
    setEditTarget(u);
    reset({ nome: u.nome, email: u.email, roleId: u.roleId, ativo: u.ativo, avatarUrl: u.avatarUrl ?? '' });
    setSheetOpen(true);
  }

  async function handleAvatarFile(file: File) {
    if (IS_API_MODE) {
      setUploading(true);
      try {
        const result = await apiUploadFile(file);
        setValue('avatarUrl', result.url);
        toast.success('Imagem carregada.');
      } catch (err) {
        console.error('[avatar] upload failed', err);
        toast.error('Erro ao carregar a imagem de perfil.');
      } finally {
        setUploading(false);
      }
    } else {
      const reader = new FileReader();
      reader.onload = (e) => setValue('avatarUrl', e.target?.result as string);
      reader.readAsDataURL(file);
    }
  }

  function onSubmit(values: FormValues) {
    const now = new Date().toISOString();
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { senha: _s, ...baseData } = values;
    const data = { ...baseData, avatarUrl: values.avatarUrl || undefined };
    if (editTarget) {
      updateUser(editTarget.id, data);
      auditRepo.create({ evento: 'atualizado', tabela: 'users', registroId: editTarget.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: now, detalhe: `Utilizador "${values.nome}" atualizado` });
      toast.success('Utilizador atualizado.');
    } else {
      if (IS_API_MODE && (!values.senha || values.senha.length < 4)) {
        toast.error('Senha obrigatória (mínimo 4 caracteres).');
        return;
      }
      // senha é incluída no user object; apiAdapter envia-a no POST e strip-a nos PATCHs
      const user = createUser({ ...data, senhaHash: 'changeme', senha: values.senha || undefined });
      auditRepo.create({ evento: 'cadastrado', tabela: 'users', registroId: user.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: now, detalhe: `Utilizador "${values.nome}" criado` });
      toast.success('Utilizador criado.');
    }
    setSheetOpen(false);
  }

  function confirmDelete() {
    if (!deleteTarget) return;
    removeUser(deleteTarget.id);
    auditRepo.create({ evento: 'eliminado', tabela: 'users', registroId: deleteTarget.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: new Date().toISOString(), detalhe: `Utilizador "${deleteTarget.nome}" eliminado` });
    toast.success('Utilizador eliminado.');
    setDeleteTarget(null);
  }

  async function confirmResetPassword() {
    if (!resetTarget) return;
    if (novaSenha.length < 4) {
      toast.error('Nova senha deve ter pelo menos 4 caracteres.');
      return;
    }
    if (IS_API_MODE) {
      try {
        await apiClient.patch(`/users/${resetTarget.id}`, { senha: novaSenha });
      } catch (err) {
        console.error('[reset-senha]', err);
        toast.error('Erro ao redefinir senha.');
        return;
      }
    }
    auditRepo.create({ evento: 'atualizado', tabela: 'users', registroId: resetTarget.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: new Date().toISOString(), detalhe: `Senha de "${resetTarget.nome}" redefinida` });
    toast.success(`Senha de "${resetTarget.nome}" redefinida.`);
    setResetTarget(null);
    setNovaSenha('');
  }

  const roleLabel = (id: string) => roles.find((r) => r.id === id)?.nome ?? '—';

  return (
    <PermissionGuard required="config.users.manage">
      <div className="p-6 space-y-5">
        <PageHeader
          title="Utilizadores"
          description="Gerencie os utilizadores do sistema e os seus perfis de acesso."
          primaryAction={{ label: 'Novo Utilizador', icon: <Plus className="h-4 w-4" />, onClick: openCreate }}
        />

        <div className="flex items-center gap-3">
          <input type="search" placeholder="Pesquisar utilizadores..." value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-9 w-full max-w-sm rounded-md border border-input bg-white px-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1" />
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-xs">
          <table className="w-full text-sm">
            <thead className="border-b border-slate-200 bg-slate-50">
              <tr>
                {['Utilizador', 'E-mail', 'Perfil', 'Estado', 'Criado em', 'Ações'].map((h) => (
                  <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-slate-500 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr><td colSpan={6} className="py-10 text-center text-sm text-slate-400">Nenhum utilizador encontrado.</td></tr>
              ) : filtered.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      {u.avatarUrl
                        ? <img src={resolveFileUrl(u.avatarUrl)} alt={u.nome} className="h-8 w-8 rounded-full object-cover shrink-0" />
                        : <div className="h-8 w-8 rounded-full bg-sky-100 text-sky-700 flex items-center justify-center text-xs font-bold shrink-0">{u.nome.charAt(0).toUpperCase()}</div>
                      }
                      <span className="font-semibold text-slate-800">{u.nome}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-slate-500 text-xs">{u.email}</td>
                  <td className="px-4 py-3 text-xs">
                    <Badge variant="outline" className="text-xs bg-sky-50 text-sky-700 border-sky-200">{roleLabel(u.roleId)}</Badge>
                  </td>
                  <td className="px-4 py-3 text-xs">
                    {u.ativo
                      ? <Badge variant="outline" className="text-xs bg-emerald-50 text-emerald-700 border-emerald-200">Ativo</Badge>
                      : <Badge variant="outline" className="text-xs bg-slate-50 text-slate-500 border-slate-200">Inativo</Badge>
                    }
                  </td>
                  <td className="px-4 py-3 text-slate-500 text-xs whitespace-nowrap">
                    {format(parseISO(u.criadoEm), 'dd/MM/yyyy', { locale: ptBR })}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="icon-xs" onClick={() => openEdit(u)}><Pencil className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon-xs" onClick={() => setResetTarget(u)} title="Redefinir senha"><KeyRound className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon-xs" onClick={() => setDeleteTarget(u)} className="text-slate-400 hover:text-red-500"><Trash2 className="h-3.5 w-3.5" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
        <SheetContent className="sm:max-w-md overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <User2 className="h-4 w-4 text-sky-600" />
              {editTarget ? `Editar: ${editTarget.nome}` : 'Novo Utilizador'}
            </SheetTitle>
          </SheetHeader>
          <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4 px-3">
            <div className="flex items-center gap-4 px-1">
              <div className="shrink-0">
                {avatarUrl
                  ? <img src={resolveFileUrl(avatarUrl)} alt="avatar" className="h-16 w-16 rounded-full object-cover border-2 border-slate-200" />
                  : <div className="h-16 w-16 rounded-full bg-sky-100 text-sky-700 flex items-center justify-center text-xl font-bold border-2 border-slate-200">
                      {watch('nome')?.charAt(0).toUpperCase() || '?'}
                    </div>
                }
              </div>
              <div>
                <p className="text-xs font-medium text-slate-700 mb-1.5">Foto de perfil</p>
                <input ref={avatarInputRef} type="file" accept="image/*" className="hidden"
                  onChange={(e) => { const f = e.target.files?.[0]; if (f) handleAvatarFile(f); }} />
                <Button type="button" variant="outline" size="sm" className="text-xs gap-1"
                  onClick={() => avatarInputRef.current?.click()} disabled={uploading}>
                  <Upload className="h-3 w-3" /> {uploading ? 'A carregar...' : 'Carregar imagem'}
                </Button>
                {avatarUrl && (
                  <button type="button" onClick={() => setValue('avatarUrl', '')} disabled={uploading}
                    className="ml-2 text-xs text-slate-400 hover:text-red-500 disabled:opacity-50">Remover</button>
                )}
              </div>
            </div>

            <SectionCard title="Informações" description="Dados de identificação e acesso">
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Nome <span className="text-red-500">*</span></Label>
                  <Input {...register('nome')} className="text-sm" />
                  {errors.nome && <p className="text-xs text-red-500">{errors.nome.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">E-mail <span className="text-red-500">*</span></Label>
                  <Input {...register('email')} type="email" className="text-sm" />
                  {errors.email && <p className="text-xs text-red-500">{errors.email.message}</p>}
                </div>
                {!editTarget && (
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium text-slate-600">
                      Senha {IS_API_MODE && <span className="text-red-500">*</span>}
                    </Label>
                    <Input {...register('senha')} type="password" className="text-sm" placeholder="Mínimo 4 caracteres" />
                    {errors.senha && <p className="text-xs text-red-500">{errors.senha.message}</p>}
                  </div>
                )}
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Perfil <span className="text-red-500">*</span></Label>
                  <Select value={roleId} onValueChange={(v) => setValue('roleId', v)}>
                    <SelectTrigger className="h-9"><SelectValue placeholder="Selecionar perfil" /></SelectTrigger>
                    <SelectContent>
                      {roles.map((r) => <SelectItem key={r.id} value={r.id}>{r.nome}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  {errors.roleId && <p className="text-xs text-red-500">{errors.roleId.message}</p>}
                </div>
              </div>
            </SectionCard>

            <SectionCard title="Estado">
              <div className="flex items-center gap-3 rounded-lg border border-slate-100 bg-slate-50 px-4 py-3">
                <Switch checked={ativo} onCheckedChange={(v) => setValue('ativo', v)} />
                <div>
                  <p className="text-xs font-medium">Utilizador ativo</p>
                  <p className="text-xs text-slate-400">Utilizadores inativos não podem autenticar-se.</p>
                </div>
              </div>
            </SectionCard>

            <SheetFooter className="mt-4 pt-4 border-t border-slate-100 gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setSheetOpen(false)} disabled={uploading}>Cancelar</Button>
              <Button type="submit" size="sm" disabled={uploading}>{editTarget ? 'Guardar' : 'Criar Utilizador'}</Button>
            </SheetFooter>
          </form>
        </SheetContent>
      </Sheet>

      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Eliminar utilizador?</DialogTitle>
            <DialogDescription>&ldquo;{deleteTarget?.nome}&rdquo; será eliminado permanentemente.</DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setDeleteTarget(null)}>Cancelar</Button>
            <Button variant="destructive" size="sm" onClick={confirmDelete}>Eliminar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!resetTarget} onOpenChange={(o) => { if (!o) { setResetTarget(null); setNovaSenha(''); } }}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Redefinir senha</DialogTitle>
            <DialogDescription>
              Definir nova senha para &ldquo;{resetTarget?.nome}&rdquo;.
            </DialogDescription>
          </DialogHeader>
          <div className="py-2">
            <Label className="text-xs font-medium text-slate-600">Nova senha <span className="text-red-500">*</span></Label>
            <Input
              type="password"
              value={novaSenha}
              onChange={(e) => setNovaSenha(e.target.value)}
              placeholder="Mínimo 4 caracteres"
              className="mt-1.5 text-sm"
            />
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => { setResetTarget(null); setNovaSenha(''); }}>Cancelar</Button>
            <Button size="sm" onClick={confirmResetPassword} className="gap-1">
              <KeyRound className="h-3.5 w-3.5" /> Redefinir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PermissionGuard>
  );
}
