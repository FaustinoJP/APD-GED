﻿'use client';

import { useEffect, useMemo, useState } from 'react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  Plus, Pencil, Trash2, LayoutTemplate, Eye, Copy, PenLine,
  Droplets, AlignLeft, ChevronRight,
} from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from '@/components/ui/sheet';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
  DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PageHeader } from '@/components/common/page-header';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { DocumentRenderer } from '@/components/documentos/document-renderer';
import { useConfigStore } from '@/store/config-store';
import { useAuthStore } from '@/store/auth-store';
import { auditRepo } from '@/lib/db';
import type { DocumentTemplate, SignatureZone, WatermarkConfig, DocumentRecord } from '@/types';

// ── Placeholder catalogue ──────────────────────────────────────────────────────

const PLACEHOLDERS = [
  { key: '{{empresa_nome}}', desc: 'Nome da empresa' },
  { key: '{{empresa_nif}}', desc: 'NIF da empresa' },
  { key: '{{empresa_endereco}}', desc: 'Endereço da empresa' },
  { key: '{{empresa_logo}}', desc: 'Logo (src da imagem)' },
  { key: '{{nr_documento}}', desc: 'Número do documento' },
  { key: '{{data_documento}}', desc: 'Data do documento' },
  { key: '{{assunto}}', desc: 'Assunto' },
  { key: '{{remetente_nome}}', desc: 'Remetente' },
  { key: '{{destinatario_nome}}', desc: 'Destinatário' },
  { key: '{{utilizador_nome}}', desc: 'Utilizador autenticado' },
  { key: '{{utilizador_cargo}}', desc: 'Cargo do utilizador' },
  { key: '{{data_hora_impressao}}', desc: 'Data/hora de impressão' },
  { key: '{{estado_documento}}', desc: 'Estado do documento' },
  { key: '{{tipo_contrato}}', desc: '[Contrato Trabalho] Tipo' },
  { key: '{{valor}}', desc: '[Contrato] Valor em AOA' },
  { key: '{{mes_referencia}}', desc: '[Folha Salarial] Mês de referência' },
  { key: '{{total_bruto}}', desc: '[Folha Salarial] Total bruto' },
  { key: '{{salario_base}}', desc: '[Folha Salarial] Salário base' },
  { key: '{{subsidios}}', desc: '[Folha Salarial] Subsídios' },
  { key: '{{descontos}}', desc: '[Folha Salarial] Descontos' },
  { key: '{{liquido_pagar}}', desc: '[Folha Salarial] Líquido a pagar' },
  { key: '{{tipo_imposto}}', desc: '[Impostos] Tipo de imposto' },
  { key: '{{periodo}}', desc: '[Impostos] Período fiscal' },
  { key: '{{valor_pagar}}', desc: '[Impostos] Valor a pagar' },
  { key: '{{base_tributavel}}', desc: '[Impostos] Base tributável' },
  { key: '{{taxa}}', desc: '[Impostos] Taxa (%)' },
  { key: '{{prazo_vigencia}}', desc: '[Fornecedor] Prazo de vigência' },
  { key: '{{objeto_contrato}}', desc: '[Fornecedor] Objecto do contrato' },
];

const DEFAULT_WATERMARK: WatermarkConfig = {
  incluirNomeUtilizador: true,
  incluirDataHora: true,
  incluirEstadoDocumento: true,
  opacidade: 0.08,
};

// ── Mock document for preview ──────────────────────────────────────────────────

function buildMockDoc(documentTypeId: string): DocumentRecord {
  return {
    id: 'mock-preview',
    numero: 'ENT-2025/00001',
    tipoRegistro: 'entrada',
    tipoDocumentoId: documentTypeId,
    assunto: 'Exemplo de Assunto para Visualização',
    remetenteTexto: 'Departamento de Recursos Humanos',
    destinatarios: [{ tipo: 'user', id: 'mock' }],
    data: new Date().toISOString(),
    confidencial: false,
    estado: 'novo',
    camposValores: {
      tipoContrato: 'Efectivo',
      valorMensal: 250000,
      mesReferencia: '2025-01-01',
      totalBruto: 4500000,
      tipoImposto: 'IVA',
      periodo: '1.º Trimestre 2025',
      valorPagar: 900000,
      valorContrato: 6000000,
      prazoVigencia: '2026-01-15',
      objetoContrato: 'Fornecimento de equipamentos e serviços de tecnologia.',
    },
    anexos: [],
    criadoPor: 'mock',
    criadoEm: new Date().toISOString(),
    atualizadoEm: new Date().toISOString(),
  };
}

const MOCK_USER = {
  id: 'mock',
  nome: 'Maria Fernanda',
  email: 'gestor@empresa.ao',
  roleId: 'role-gestor',
  ativo: true,
  criadoEm: new Date().toISOString(),
};

// ── Signature zones editor ─────────────────────────────────────────────────────

function newZone(): SignatureZone {
  return {
    id: `sz-${Date.now()}`,
    label: 'Nova Zona de Assinatura',
    x: 5, y: 80, width: 38, height: 10,
    obrigatoria: true,
  };
}

interface ZonesEditorProps {
  zones: SignatureZone[];
  onChange: (zones: SignatureZone[]) => void;
}

function ZonesEditor({ zones, onChange }: ZonesEditorProps) {
  function update(id: string, patch: Partial<SignatureZone>) {
    onChange(zones.map((z) => z.id === id ? { ...z, ...patch } : z));
  }
  function remove(id: string) { onChange(zones.filter((z) => z.id !== id)); }
  function add() { onChange([...zones, newZone()]); }

  return (
    <div className="space-y-3">
      {zones.length === 0 ? (
        <p className="text-xs text-slate-400 italic">Sem zonas de assinatura definidas.</p>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-slate-200">
          <table className="w-full text-xs">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                {['Label', 'X%', 'Y%', 'W%', 'H%', 'Obrig.', 'Role', ''].map((h) => (
                  <th key={h} className="px-2 py-2 text-left font-semibold text-slate-500 uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {zones.map((z) => (
                <tr key={z.id} className="hover:bg-slate-50">
                  <td className="px-2 py-1.5">
                    <Input value={z.label} onChange={(e) => update(z.id, { label: e.target.value })}
                      className="h-7 text-xs w-36" />
                  </td>
                  {(['x', 'y', 'width', 'height'] as const).map((field) => (
                    <td key={field} className="px-2 py-1.5">
                      <Input
                        type="number" min={0} max={100}
                        value={z[field]}
                        onChange={(e) => update(z.id, { [field]: Number(e.target.value) })}
                        className="h-7 text-xs w-14"
                      />
                    </td>
                  ))}
                  <td className="px-2 py-1.5 text-center">
                    <Switch checked={z.obrigatoria} onCheckedChange={(v) => update(z.id, { obrigatoria: v })} />
                  </td>
                  <td className="px-2 py-1.5">
                    <Input value={z.assignedRole ?? ''} onChange={(e) => update(z.id, { assignedRole: e.target.value || undefined })}
                      placeholder="Qualquer" className="h-7 text-xs w-28" />
                  </td>
                  <td className="px-2 py-1.5">
                    <Button type="button" variant="ghost" size="icon-xs" onClick={() => remove(z.id)}
                      className="text-red-400 hover:text-red-600">
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Button type="button" variant="outline" size="sm" onClick={add} className="gap-1.5">
        <Plus className="h-3.5 w-3.5" />
        Adicionar Zona
      </Button>
    </div>
  );
}

// ── Watermark config editor ───────────────────────────────────────────────────

interface WatermarkEditorProps {
  config: WatermarkConfig;
  onChange: (c: WatermarkConfig) => void;
}

function WatermarkEditor({ config, onChange }: WatermarkEditorProps) {
  function patch(changes: Partial<WatermarkConfig>) {
    onChange({ ...config, ...changes });
  }

  return (
    <div className="space-y-4">
      <p className="text-xs text-slate-500">
        A marca de água é sobreposta em diagonal sobre o documento durante a visualização e impressão.
      </p>

      <div className="space-y-3 rounded-lg border border-slate-100 bg-slate-50 p-4">
        {[
          { key: 'incluirNomeUtilizador', label: 'Nome do utilizador autenticado' },
          { key: 'incluirDataHora', label: 'Data e hora actuais' },
          { key: 'incluirEstadoDocumento', label: 'Estado do documento (ex.: EM CIRCULAÇÃO)' },
        ].map(({ key, label }) => (
          <div key={key} className="flex items-center justify-between">
            <Label className="text-sm text-slate-700 cursor-pointer">{label}</Label>
            <Switch
              checked={config[key as keyof WatermarkConfig] as boolean}
              onCheckedChange={(v) => patch({ [key]: v })}
            />
          </div>
        ))}

        <div className="space-y-1.5 pt-2 border-t border-slate-200">
          <Label className="text-xs font-medium text-slate-600">Texto adicional (opcional)</Label>
          <Input
            value={config.texto ?? ''}
            onChange={(e) => patch({ texto: e.target.value || undefined })}
            placeholder="Ex.: CONFIDENCIAL"
            className="text-sm"
          />
        </div>

        <div className="space-y-2 pt-2 border-t border-slate-200">
          <div className="flex items-center justify-between">
            <Label className="text-xs font-medium text-slate-600">
              Opacidade: <span className="text-sky-600 font-bold">{Math.round((config.opacidade ?? 0.08) * 100)}%</span>
            </Label>
          </div>
          <input
            type="range" min={1} max={30} step={1}
            value={Math.round((config.opacidade ?? 0.08) * 100)}
            onChange={(e) => patch({ opacidade: Number(e.target.value) / 100 })}
            className="w-full accent-sky-600"
          />
          <div className="flex justify-between text-xs text-slate-400">
            <span>Subtil (1%)</span><span>Visível (30%)</span>
          </div>
        </div>
      </div>

      <div className="rounded-md border border-dashed border-slate-300 bg-white p-3 flex items-center gap-3">
        <div
          className="relative rounded border border-slate-200 bg-slate-50 flex items-center justify-center"
          style={{ width: 100, height: 60, overflow: 'hidden' }}
        >
          <span className="text-xs text-slate-400 absolute" style={{ opacity: config.opacidade ?? 0.08, transform: 'rotate(-35deg)', fontWeight: 700, fontSize: 9, whiteSpace: 'nowrap' }}>
            {[
              config.incluirNomeUtilizador ? 'Maria Fernanda' : null,
              config.incluirDataHora ? '18/05/2025 10:30' : null,
              config.incluirEstadoDocumento ? 'NOVO' : null,
              config.texto || null,
            ].filter(Boolean).join(' · ')}
          </span>
          <span className="text-[9px] text-slate-300">pré-visualização</span>
        </div>
        <p className="text-xs text-slate-500">
          Pré-visualização aproximada da marca de água. A opacidade real é visível no renderer do documento.
        </p>
      </div>
    </div>
  );
}

// ── Main page ──────────────────────────────────────────────────────────────────

export default function TemplatesPage() {
  const { templates, documentTypes, company, loaded, loadAll, createTemplate, updateTemplate, removeTemplate } = useConfigStore();
  const currentUser = useAuthStore((s) => s.currentUser);

  useEffect(() => { if (!loaded) loadAll(); }, [loaded, loadAll]);

  const [search, setSearch] = useState('');
  const [sheetOpen, setSheetOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<DocumentTemplate | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<DocumentTemplate | null>(null);

  // Form state
  const [nome, setNome] = useState('');
  const [descricao, setDescricao] = useState('');
  const [documentTypeId, setDocumentTypeId] = useState('');
  const [htmlContent, setHtmlContent] = useState('');
  const [ativo, setAtivo] = useState(true);
  const [zones, setZones] = useState<SignatureZone[]>([]);
  const [watermark, setWatermark] = useState<WatermarkConfig>(DEFAULT_WATERMARK);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const filtered = useMemo(
    () => templates.filter((t) => !search || t.nome.toLowerCase().includes(search.toLowerCase())),
    [templates, search],
  );

  function resetForm(t?: DocumentTemplate) {
    setNome(t?.nome ?? '');
    setDescricao(t?.descricao ?? '');
    setDocumentTypeId(t?.documentTypeId ?? '');
    setHtmlContent(t?.htmlContent ?? '');
    setAtivo(t?.ativo ?? true);
    setZones(t?.signatureZones ?? []);
    setWatermark(t?.watermark ?? DEFAULT_WATERMARK);
    setErrors({});
  }

  function openCreate() {
    setEditTarget(null);
    resetForm();
    setSheetOpen(true);
  }

  function openEdit(t: DocumentTemplate) {
    setEditTarget(t);
    resetForm(t);
    setSheetOpen(true);
  }

  function validate() {
    const errs: Record<string, string> = {};
    if (!nome.trim() || nome.length < 2) errs.nome = 'Nome obrigatório (mín. 2 caracteres)';
    if (!htmlContent.trim() || htmlContent.length < 10) errs.htmlContent = 'Conteúdo HTML obrigatório';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  function onSubmit() {
    if (!validate()) return;
    const now = new Date().toISOString();

    const data: Omit<DocumentTemplate, 'id' | 'criadoEm'> = {
      nome: nome.trim(),
      descricao: descricao.trim() || undefined,
      documentTypeId: documentTypeId || undefined,
      htmlContent,
      variaveis: PLACEHOLDERS.filter((p) => htmlContent.includes(p.key)).map((p) => p.key),
      signatureZones: zones,
      watermark,
      versao: editTarget ? (editTarget.versao ?? 1) + 1 : 1,
      ativo,
    };

    if (editTarget) {
      updateTemplate(editTarget.id, data);
      auditRepo.create({ evento: 'atualizado', tabela: 'templates', registroId: editTarget.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: now, detalhe: `Template "${nome}" v${data.versao} guardado` });
      toast.success('Template atualizado.');
    } else {
      const t = createTemplate(data);
      auditRepo.create({ evento: 'cadastrado', tabela: 'templates', registroId: t.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: now, detalhe: `Template "${nome}" criado` });
      toast.success('Template criado.');
    }
    setSheetOpen(false);
  }

  function confirmDelete() {
    if (!deleteTarget) return;
    removeTemplate(deleteTarget.id);
    auditRepo.create({ evento: 'eliminado', tabela: 'templates', registroId: deleteTarget.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: new Date().toISOString(), detalhe: `Template "${deleteTarget.nome}" eliminado` });
    toast.success('Template eliminado.');
    setDeleteTarget(null);
  }

  const previewTemplate: DocumentTemplate | null = useMemo(() => {
    if (!htmlContent.trim()) return null;
    return {
      id: 'preview',
      nome,
      documentTypeId: documentTypeId || undefined,
      htmlContent,
      variaveis: [],
      signatureZones: zones,
      watermark,
      versao: 1,
      ativo: true,
      criadoEm: new Date().toISOString(),
    };
  }, [htmlContent, nome, documentTypeId, zones, watermark]);

  const mockDoc = useMemo(() => buildMockDoc(documentTypeId || 'dtype-contrato-trabalho'), [documentTypeId]);

  function insertPlaceholder(ph: string) {
    const ta = document.getElementById('html-editor') as HTMLTextAreaElement | null;
    if (!ta) { setHtmlContent((h) => h + ph); return; }
    const start = ta.selectionStart;
    const end = ta.selectionEnd;
    const newVal = ta.value.slice(0, start) + ph + ta.value.slice(end);
    setHtmlContent(newVal);
    requestAnimationFrame(() => {
      ta.selectionStart = ta.selectionEnd = start + ph.length;
      ta.focus();
    });
  }

  return (
    <PermissionGuard required="config.templates.manage">
      <div className="p-6 space-y-5">
        <PageHeader
          title="Templates de Documento"
          description="Modelos HTML profissionais com placeholders, zonas de assinatura posicionadas e marca de água."
          primaryAction={{ label: 'Novo Template', icon: <Plus className="h-4 w-4" />, onClick: openCreate }}
        />

        <input
          type="search" placeholder="Pesquisar templates…" value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="h-9 w-full max-w-sm rounded-md border border-input bg-white px-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1"
        />

        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-xs">
          <table className="w-full text-sm">
            <thead className="border-b border-slate-200 bg-slate-50">
              <tr>
                {['Nome', 'Tipo de Documento', 'Versão', 'Zonas', 'Ativo', 'Criado em', 'Ações'].map((h) => (
                  <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-slate-500 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr><td colSpan={7} className="py-10 text-center text-sm text-slate-400">Nenhum template encontrado.</td></tr>
              ) : filtered.map((t) => {
                const dt = documentTypes.find((d) => d.id === t.documentTypeId);
                return (
                  <tr key={t.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <LayoutTemplate className="h-4 w-4 text-sky-400 shrink-0" />
                        <span className="font-semibold text-slate-800">{t.nome}</span>
                      </div>
                      {t.descricao && <p className="text-xs text-slate-400 mt-0.5 max-w-xs truncate">{t.descricao}</p>}
                    </td>
                    <td className="px-4 py-3">
                      {dt ? (
                        <Badge variant="outline" className="text-xs gap-1">
                          <ChevronRight className="h-2.5 w-2.5" />{dt.nome}
                        </Badge>
                      ) : <span className="text-slate-400 text-xs">—</span>}
                    </td>
                    <td className="px-4 py-3 text-slate-600 text-xs font-mono">v{t.versao ?? 1}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <PenLine className="h-3 w-3 text-slate-400" />
                        <span className="text-xs text-slate-600">{(t.signatureZones ?? []).length}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      {t.ativo
                        ? <Badge className="bg-emerald-500 text-white text-xs">Ativo</Badge>
                        : <Badge variant="outline" className="text-xs text-slate-400">Inativo</Badge>}
                    </td>
                    <td className="px-4 py-3 text-slate-500 text-xs whitespace-nowrap">
                      {format(parseISO(t.criadoEm), 'dd/MM/yyyy', { locale: ptBR })}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon-xs" onClick={() => openEdit(t)} title="Editar">
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon-xs" onClick={() => setDeleteTarget(t)}
                          className="text-slate-400 hover:text-red-500" title="Eliminar">
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ── Editor Sheet ──────────────────────────────────────────────────────── */}
      <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
        <SheetContent className="sm:max-w-4xl overflow-y-auto flex flex-col">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <LayoutTemplate className="h-4 w-4 text-sky-600" />
              {editTarget ? `Editar: ${editTarget.nome}` : 'Novo Template'}
              {editTarget && (
                <Badge variant="outline" className="text-xs font-mono ml-1">
                  v{(editTarget.versao ?? 1) + 1} (próxima)
                </Badge>
              )}
            </SheetTitle>
          </SheetHeader>

          <div className="flex flex-col flex-1 min-h-0 px-3 mt-4 gap-4">
            {/* Basic fields */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-slate-600">Nome <span className="text-red-500">*</span></Label>
                <Input value={nome} onChange={(e) => setNome(e.target.value)} className="text-sm" />
                {errors.nome && <p className="text-xs text-red-500">{errors.nome}</p>}
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-slate-600">Tipo de Documento</Label>
                <Select value={documentTypeId || '__none__'} onValueChange={(v) => setDocumentTypeId(v === '__none__' ? '' : v)}>
                  <SelectTrigger className="text-sm h-9">
                    <SelectValue placeholder="Selecionar tipo…" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">— Genérico (sem tipo) —</SelectItem>
                    {documentTypes.filter((d) => d.ativo).map((d) => (
                      <SelectItem key={d.id} value={d.id}>{d.nome}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-slate-600">Descrição</Label>
              <Input value={descricao} onChange={(e) => setDescricao(e.target.value)} className="text-sm" />
            </div>

            {/* Tabs */}
            <Tabs defaultValue="editor" className="flex-1 flex flex-col">
              <TabsList>
                <TabsTrigger value="editor" className="gap-1.5 text-xs">
                  <AlignLeft className="h-3.5 w-3.5" />Editor HTML
                </TabsTrigger>
                <TabsTrigger value="vars" className="text-xs">Variáveis</TabsTrigger>
                <TabsTrigger value="zones" className="gap-1.5 text-xs">
                  <PenLine className="h-3.5 w-3.5" />Zonas de Assinatura
                </TabsTrigger>
                <TabsTrigger value="watermark" className="gap-1.5 text-xs">
                  <Droplets className="h-3.5 w-3.5" />Marca de Água
                </TabsTrigger>
                <TabsTrigger value="preview" className="gap-1.5 text-xs">
                  <Eye className="h-3.5 w-3.5" />Pré-visualização
                </TabsTrigger>
              </TabsList>

              {/* ── HTML Editor ─────────────────────────────────────────────── */}
              <TabsContent value="editor" className="mt-4 space-y-3">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">
                    Conteúdo HTML <span className="text-red-500">*</span>
                    <span className="ml-2 text-slate-400 font-normal">(use os placeholders da aba Variáveis)</span>
                  </Label>
                  <Textarea
                    id="html-editor"
                    value={htmlContent}
                    onChange={(e) => setHtmlContent(e.target.value)}
                    rows={20}
                    className="font-mono text-xs resize-y bg-slate-950 text-emerald-400 border-slate-700 focus:border-sky-500"
                    spellCheck={false}
                  />
                  {errors.htmlContent && <p className="text-xs text-red-500">{errors.htmlContent}</p>}
                </div>
                <div className="flex items-center justify-between rounded-lg border border-slate-100 bg-slate-50 px-4 py-3">
                  <div>
                    <p className="text-sm font-medium text-slate-700">Ativo</p>
                    <p className="text-xs text-slate-500">Disponível para associar a documentos</p>
                  </div>
                  <Switch checked={ativo} onCheckedChange={setAtivo} />
                </div>
              </TabsContent>

              {/* ── Variables ───────────────────────────────────────────────── */}
              <TabsContent value="vars" className="mt-4">
                <p className="text-xs text-slate-500 mb-3">
                  Clique num placeholder para o inserir no cursor do editor. Use estes valores dentro do HTML do template.
                </p>
                <div className="rounded-lg border border-slate-200 overflow-hidden max-h-96 overflow-y-auto">
                  {PLACEHOLDERS.map((p, i) => (
                    <div key={p.key}
                      className={`flex items-center justify-between px-4 py-2.5 hover:bg-sky-50 cursor-pointer transition-colors ${i < PLACEHOLDERS.length - 1 ? 'border-b border-slate-100' : ''}`}
                      onClick={() => insertPlaceholder(p.key)}
                    >
                      <div>
                        <code className="text-xs font-mono text-sky-700 bg-sky-50 px-1.5 py-0.5 rounded">{p.key}</code>
                        <span className="ml-3 text-xs text-slate-600">{p.desc}</span>
                      </div>
                      <Button type="button" variant="ghost" size="icon-xs"
                        onClick={(e) => { e.stopPropagation(); navigator.clipboard.writeText(p.key); toast.success('Copiado!'); }}
                        title="Copiar para clipboard">
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              </TabsContent>

              {/* ── Signature Zones ─────────────────────────────────────────── */}
              <TabsContent value="zones" className="mt-4 space-y-3">
                <div className="rounded-md border border-sky-100 bg-sky-50 px-3 py-2 text-xs text-sky-700">
                  As coordenadas são percentagens relativas ao contentor do documento A4 (794px × altura do documento).
                  X=0 é o limite esquerdo, Y=0 é o topo. Use Y entre 75-90 para a zona de assinaturas típica.
                </div>
                <ZonesEditor zones={zones} onChange={setZones} />
              </TabsContent>

              {/* ── Watermark ───────────────────────────────────────────────── */}
              <TabsContent value="watermark" className="mt-4">
                <WatermarkEditor config={watermark} onChange={setWatermark} />
              </TabsContent>

              {/* ── Preview ─────────────────────────────────────────────────── */}
              <TabsContent value="preview" className="mt-4">
                {previewTemplate ? (
                  <div className="rounded-lg border border-slate-200 overflow-auto bg-slate-100 p-4">
                    <div className="mb-3 flex items-center gap-2">
                      <Eye className="h-3.5 w-3.5 text-slate-400" />
                      <span className="text-xs text-slate-500">Pré-visualização com dados de demonstração</span>
                    </div>
                    <div style={{ transform: 'scale(0.7)', transformOrigin: 'top center', marginBottom: -250 }}>
                      <DocumentRenderer
                        doc={mockDoc}
                        template={previewTemplate}
                        mode="preview"
                        company={company.nome ? company : { nome: 'Empresa Demonstração Lda', nif: '5001234567', endereco: 'Rua dos Coqueiros, 45, Luanda' }}
                        currentUser={MOCK_USER}
                        currentUserRoleName="Gestor Documental"
                        users={[{ ...MOCK_USER, nome: 'Maria Fernanda' }]}
                        entities={[]}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-40 text-sm text-slate-400">
                    Adicione conteúdo HTML no editor para ver a pré-visualização.
                  </div>
                )}
              </TabsContent>
            </Tabs>

            <SheetFooter className="pt-4 border-t border-slate-100 gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setSheetOpen(false)}>Cancelar</Button>
              <Button type="button" size="sm" onClick={onSubmit}>
                {editTarget ? 'Guardar nova versão' : 'Criar Template'}
              </Button>
            </SheetFooter>
          </div>
        </SheetContent>
      </Sheet>

      {/* ── Delete confirm ────────────────────────────────────────────────────── */}
      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Eliminar template?</DialogTitle>
            <DialogDescription>
              &ldquo;{deleteTarget?.nome}&rdquo; (v{deleteTarget?.versao ?? 1}) será eliminado permanentemente.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setDeleteTarget(null)}>Cancelar</Button>
            <Button variant="destructive" size="sm" onClick={confirmDelete}>Eliminar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PermissionGuard>
  );
}
