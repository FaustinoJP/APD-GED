﻿'use client';

import { useEffect, useRef, useState } from 'react';
import { Plus, Pencil, Copy, Trash2, Shield, Check } from 'lucide-react';
import { toast } from 'sonner';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from '@/components/ui/sheet';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
  DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { PageHeader } from '@/components/common/page-header';
import { SectionCard } from '@/components/common/section-card';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { useConfigStore } from '@/store/config-store';
import { useAuthStore } from '@/store/auth-store';
import { auditRepo } from '@/lib/db';
import { ALL_PERMISSIONS } from '@/types';
import type { Permission, Role } from '@/types';

const PERMISSION_GROUPS: { label: string; permissions: Permission[] }[] = [
  {
    label: 'Documentos',
    permissions: [
      'documents.read', 'documents.create', 'documents.update', 'documents.delete',
      'documents.forward', 'documents.sign', 'documents.approve', 'documents.giveOpinion',
      'documents.dispatch', 'documents.defer', 'documents.archive', 'documents.export',
    ],
  },
  {
    label: 'Configurações',
    permissions: [
      'config.types.manage', 'config.users.manage', 'config.permissions.manage',
      'config.entities.manage', 'config.templates.manage', 'config.company.manage',
      'config.locations.manage',
    ],
  },
  {
    label: 'Sistema',
    permissions: ['audit.read', 'exports.run', 'files.manage', 'notifications.read', 'dashboard.view'],
  },
];

const PERMISSION_LABEL: Record<Permission, string> = {
  'documents.create': 'Criar',
  'documents.read': 'Visualizar',
  'documents.update': 'Editar',
  'documents.delete': 'Eliminar',
  'documents.forward': 'Encaminhar',
  'documents.sign': 'Assinar',
  'documents.approve': 'Aprovar',
  'documents.giveOpinion': 'Dar parecer',
  'documents.dispatch': 'Despachar',
  'documents.defer': 'Deferir',
  'documents.archive': 'Arquivar',
  'documents.export': 'Exportar',
  'config.types.manage': 'Tipos de doc.',
  'config.users.manage': 'Utilizadores',
  'config.permissions.manage': 'Permissões',
  'config.entities.manage': 'Entidades',
  'config.templates.manage': 'Templates',
  'config.company.manage': 'Empresa',
  'config.locations.manage': 'Localização Física',
  'audit.read': 'Ver auditoria',
  'exports.run': 'Executar exportações',
  'files.manage': 'Gerir ficheiros',
  'notifications.read': 'Notificações',
  'dashboard.view': 'Dashboard',
};

// Exhaustive check to ensure all permissions are labelled
const _exhaustive: Record<Permission, string> = PERMISSION_LABEL;
void _exhaustive;
void ALL_PERMISSIONS;

const schema = z.object({
  nome: z.string().min(2, 'Nome obrigatório'),
  descricao: z.string().min(1, 'Descrição obrigatória'),
});
type FormValues = z.infer<typeof schema>;

function IndeterminateCheckbox({ checked, indeterminate, onChange }: {
  checked: boolean; indeterminate: boolean; onChange: (v: boolean) => void;
}) {
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => { if (ref.current) ref.current.indeterminate = indeterminate; }, [indeterminate]);
  return (
    <input ref={ref} type="checkbox" checked={checked}
      onChange={(e) => onChange(e.target.checked)}
      className="h-3.5 w-3.5 accent-sky-600 cursor-pointer" />
  );
}

export default function PermissoesPage() {
  const { roles, users, loaded, loadAll, createRole, updateRole, removeRole } = useConfigStore();
  const currentUser = useAuthStore((s) => s.currentUser);

  useEffect(() => { if (!loaded) loadAll(); }, [loaded, loadAll]);

  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Role | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Role | null>(null);
  const [editingPerms, setEditingPerms] = useState<Set<Permission>>(new Set());
  const [permsChanged, setPermsChanged] = useState(false);

  useEffect(() => {
    if (roles.length > 0 && !selectedRole) setSelectedRole(roles[0]);
  }, [roles, selectedRole]);

  useEffect(() => {
    if (selectedRole) {
      setEditingPerms(new Set(selectedRole.permissions));
      setPermsChanged(false);
    }
  }, [selectedRole]);

  const { register, handleSubmit, reset, formState: { errors } } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { nome: '', descricao: '' },
  });

  useEffect(() => {
    if (sheetOpen) {
      reset(editTarget ? { nome: editTarget.nome, descricao: editTarget.descricao } : { nome: '', descricao: '' });
    }
  }, [sheetOpen, editTarget, reset]);

  function openCreate() { setEditTarget(null); setSheetOpen(true); }
  function openEdit(r: Role) { setEditTarget(r); setSheetOpen(true); }

  function duplicateRole(r: Role) {
    const newRole = createRole({ nome: `${r.nome} (Cópia)`, descricao: r.descricao, permissions: [...r.permissions] });
    auditRepo.create({ evento: 'cadastrado', tabela: 'roles', registroId: newRole.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: new Date().toISOString(), detalhe: `Role "${newRole.nome}" duplicada` });
    toast.success('Perfil duplicado.');
  }

  function onSubmit(values: FormValues) {
    const now = new Date().toISOString();
    if (editTarget) {
      updateRole(editTarget.id, values);
      if (selectedRole?.id === editTarget.id) setSelectedRole({ ...selectedRole, ...values });
      auditRepo.create({ evento: 'atualizado', tabela: 'roles', registroId: editTarget.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: now, detalhe: `Role "${values.nome}" atualizada` });
      toast.success('Perfil atualizado.');
    } else {
      const role = createRole({ ...values, permissions: [] });
      auditRepo.create({ evento: 'cadastrado', tabela: 'roles', registroId: role.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: now, detalhe: `Role "${values.nome}" criada` });
      toast.success('Perfil criado.');
    }
    setSheetOpen(false);
  }

  function togglePerm(perm: Permission) {
    setEditingPerms((prev) => {
      const next = new Set(prev);
      if (next.has(perm)) next.delete(perm); else next.add(perm);
      return next;
    });
    setPermsChanged(true);
  }

  function toggleGroup(perms: Permission[], on: boolean) {
    setEditingPerms((prev) => {
      const next = new Set(prev);
      perms.forEach((p) => { if (on) next.add(p); else next.delete(p); });
      return next;
    });
    setPermsChanged(true);
  }

  function savePermissions() {
    if (!selectedRole) return;
    const permsArray = Array.from(editingPerms);
    updateRole(selectedRole.id, { permissions: permsArray });
    setSelectedRole({ ...selectedRole, permissions: permsArray });
    setPermsChanged(false);
    auditRepo.create({ evento: 'atualizado', tabela: 'roles', registroId: selectedRole.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: new Date().toISOString(), detalhe: `Permissões de "${selectedRole.nome}" atualizadas` });
    toast.success('Permissões guardadas.');
  }

  function confirmDelete() {
    if (!deleteTarget) return;
    const inUse = users.some((u) => u.roleId === deleteTarget.id);
    if (inUse) {
      toast.error('Este perfil está atribuído a utilizadores. Reatribua-os antes de eliminar.');
      setDeleteTarget(null);
      return;
    }
    removeRole(deleteTarget.id);
    auditRepo.create({ evento: 'eliminado', tabela: 'roles', registroId: deleteTarget.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: new Date().toISOString(), detalhe: `Role "${deleteTarget.nome}" eliminada` });
    toast.success('Perfil eliminado.');
    if (selectedRole?.id === deleteTarget.id) setSelectedRole(null);
    setDeleteTarget(null);
  }

  return (
    <PermissionGuard required="config.permissions.manage">
      <div className="p-6 space-y-5">
        <PageHeader
          title="Permissões"
          description="Gerencie perfis de acesso e atribua permissões granulares a cada um."
          primaryAction={{ label: 'Novo Perfil', icon: <Plus className="h-4 w-4" />, onClick: openCreate }}
        />

        <div className="flex gap-5 items-start">
          {/* Roles sidebar */}
          <div className="w-60 shrink-0 space-y-1.5">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 px-1 mb-2">Perfis</p>
            {roles.length === 0 && (
              <p className="text-xs text-slate-400 px-1">Nenhum perfil criado.</p>
            )}
            {roles.map((r) => (
              <div key={r.id}
                onClick={() => setSelectedRole(r)}
                className={`group flex items-center justify-between gap-2 rounded-lg border px-3 py-2.5 cursor-pointer transition-colors ${selectedRole?.id === r.id ? 'border-sky-300 bg-sky-50' : 'border-slate-200 bg-white hover:bg-slate-50'}`}>
                <div className="flex items-center gap-2 min-w-0">
                  <Shield className={`h-4 w-4 shrink-0 ${selectedRole?.id === r.id ? 'text-sky-600' : 'text-slate-400'}`} />
                  <div className="min-w-0">
                    <p className={`text-sm font-medium truncate ${selectedRole?.id === r.id ? 'text-sky-800' : 'text-slate-700'}`}>{r.nome}</p>
                    <p className="text-xs text-slate-400">{r.permissions.length} permissões</p>
                  </div>
                </div>
                <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity shrink-0" onClick={(e) => e.stopPropagation()}>
                  <Button variant="ghost" size="icon-xs" title="Editar" onClick={() => openEdit(r)}><Pencil className="h-3 w-3" /></Button>
                  <Button variant="ghost" size="icon-xs" title="Duplicar" onClick={() => duplicateRole(r)}><Copy className="h-3 w-3" /></Button>
                  <Button variant="ghost" size="icon-xs" title="Eliminar" onClick={() => setDeleteTarget(r)} className="hover:text-red-500"><Trash2 className="h-3 w-3" /></Button>
                </div>
              </div>
            ))}
          </div>

          {/* Permission matrix */}
          <div className="flex-1 min-w-0">
            {!selectedRole ? (
              <div className="flex items-center justify-center h-48 rounded-xl border border-dashed border-slate-200 text-sm text-slate-400">
                Selecione um perfil para editar as permissões
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-semibold text-slate-800">{selectedRole.nome}</h3>
                    <p className="text-xs text-slate-400">{selectedRole.descricao}</p>
                  </div>
                  {permsChanged && (
                    <Button size="sm" onClick={savePermissions} className="gap-1.5">
                      <Check className="h-3.5 w-3.5" /> Guardar permissões
                    </Button>
                  )}
                </div>

                {PERMISSION_GROUPS.map((group) => {
                  const allChecked = group.permissions.every((p) => editingPerms.has(p));
                  const someChecked = group.permissions.some((p) => editingPerms.has(p));
                  return (
                    <div key={group.label} className="rounded-xl border border-slate-200 bg-white overflow-hidden">
                      <div className="flex items-center gap-3 px-4 py-2.5 bg-slate-50 border-b border-slate-200">
                        <IndeterminateCheckbox
                          checked={allChecked}
                          indeterminate={!allChecked && someChecked}
                          onChange={(v) => toggleGroup(group.permissions, v)}
                        />
                        <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">{group.label}</span>
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4">
                        {group.permissions.map((perm) => (
                          <label key={perm} className="flex items-center gap-2 px-4 py-2.5 cursor-pointer hover:bg-slate-50 transition-colors border-b border-r border-slate-100 last:border-b-0">
                            <input type="checkbox" checked={editingPerms.has(perm)} onChange={() => togglePerm(perm)}
                              className="h-3.5 w-3.5 accent-sky-600 cursor-pointer" />
                            <span className="text-xs text-slate-700">{PERMISSION_LABEL[perm]}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      <Sheet open={sheetOpen} onOpenChange={(o) => { setSheetOpen(o); if (!o) setEditTarget(null); }}>
        <SheetContent className="sm:max-w-sm">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-sky-600" />
              {editTarget ? 'Editar Perfil' : 'Novo Perfil'}
            </SheetTitle>
          </SheetHeader>
          <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4 px-3">
            <SectionCard title="Dados do Perfil">
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Nome <span className="text-red-500">*</span></Label>
                  <Input {...register('nome')} className="text-sm" />
                  {errors.nome && <p className="text-xs text-red-500">{errors.nome.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Descrição <span className="text-red-500">*</span></Label>
                  <Textarea {...register('descricao')} className="text-sm resize-none" rows={3} />
                  {errors.descricao && <p className="text-xs text-red-500">{errors.descricao.message}</p>}
                </div>
              </div>
            </SectionCard>
            <SheetFooter className="mt-4 pt-4 border-t border-slate-100 gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setSheetOpen(false)}>Cancelar</Button>
              <Button type="submit" size="sm">{editTarget ? 'Guardar' : 'Criar Perfil'}</Button>
            </SheetFooter>
          </form>
        </SheetContent>
      </Sheet>

      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Eliminar perfil?</DialogTitle>
            <DialogDescription>
              &ldquo;{deleteTarget?.nome}&rdquo; será eliminado permanentemente. Certifique-se de que não há utilizadores com este perfil.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setDeleteTarget(null)}>Cancelar</Button>
            <Button variant="destructive" size="sm" onClick={confirmDelete}>Eliminar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PermissionGuard>
  );
}
