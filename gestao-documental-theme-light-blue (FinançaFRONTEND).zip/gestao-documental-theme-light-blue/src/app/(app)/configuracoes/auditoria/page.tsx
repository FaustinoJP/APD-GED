﻿'use client';

import { useEffect, useMemo, useState } from 'react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Filter, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import { DataTable, type ColumnDef } from '@/components/common/data-table';
import { PageHeader } from '@/components/common/page-header';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { auditRepo, usersRepo } from '@/lib/db';
import type { AuditLog, EventoAuditoria, User } from '@/types';

const EVENTO_OPTIONS: EventoAuditoria[] = [
  'visualizado', 'cadastrado', 'atualizado', 'eliminado',
  'encaminhado', 'assinado', 'aprovado', 'rejeitado', 'exportado', 'login',
];

const EVENTO_LABEL: Record<EventoAuditoria, string> = {
  visualizado: 'Visualizado',
  cadastrado: 'Cadastrado',
  atualizado: 'Atualizado',
  eliminado: 'Eliminado',
  encaminhado: 'Encaminhado',
  assinado: 'Assinado',
  aprovado: 'Aprovado',
  rejeitado: 'Rejeitado',
  exportado: 'Exportado',
  login: 'Login',
};

const EVENTO_COLOR: Record<EventoAuditoria, string> = {
  visualizado: 'bg-amber-50 text-amber-700 border-amber-200',
  cadastrado: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  atualizado: 'bg-blue-50 text-blue-700 border-blue-200',
  eliminado: 'bg-red-50 text-red-700 border-red-200',
  encaminhado: 'bg-sky-50 text-sky-700 border-sky-200',
  assinado: 'bg-purple-50 text-purple-700 border-purple-200',
  aprovado: 'bg-teal-50 text-teal-700 border-teal-200',
  rejeitado: 'bg-rose-50 text-rose-700 border-rose-200',
  exportado: 'bg-slate-50 text-slate-600 border-slate-200',
  login: 'bg-sky-50 text-sky-700 border-sky-200',
};

const TABELA_LABEL: Record<string, string> = {
  users: 'Utilizadores',
  roles: 'Perfis',
  documents: 'Documentos',
  document_types: 'Tipos de Doc.',
  entities: 'Entidades',
  circulations: 'Circulações',
  audit: 'Auditoria',
  company: 'Empresa',
};

type AuditRow = AuditLog & { nr: number; userNome: string };

interface AppliedFilters {
  startDate: string;
  endDate: string;
  evento: EventoAuditoria | 'todos';
  userId: string;
}

export default function AuditoriaPage() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [detailLog, setDetailLog] = useState<AuditRow | null>(null);
  const [rev, setRev] = useState(0);

  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [eventoFilter, setEventoFilter] = useState<EventoAuditoria | 'todos'>('todos');
  const [userFilter, setUserFilter] = useState('todos');

  const [applied, setApplied] = useState<AppliedFilters>({
    startDate: '', endDate: '', evento: 'todos', userId: 'todos',
  });

  useEffect(() => {
    setLogs(auditRepo.list().sort((a, b) => b.data.localeCompare(a.data)));
    setUsers(usersRepo.list());
  }, [rev]);

  function applyFilters() {
    setApplied({ startDate, endDate, evento: eventoFilter, userId: userFilter });
  }

  function clearFilters() {
    setStartDate(''); setEndDate('');
    setEventoFilter('todos'); setUserFilter('todos');
    setApplied({ startDate: '', endDate: '', evento: 'todos', userId: 'todos' });
  }

  const hasActive = applied.startDate || applied.endDate || applied.evento !== 'todos' || applied.userId !== 'todos';

  const rows = useMemo<AuditRow[]>(() => {
    const filtered = logs.filter((log) => {
      if (applied.evento !== 'todos' && log.evento !== applied.evento) return false;
      if (applied.userId !== 'todos' && log.userId !== applied.userId) return false;
      if (applied.startDate && log.data < applied.startDate) return false;
      if (applied.endDate && log.data > `${applied.endDate}T23:59:59`) return false;
      return true;
    });
    return filtered.map((log, i) => ({
      ...log,
      nr: i + 1,
      userNome: users.find((u) => u.id === log.userId)?.nome ?? log.userId,
    }));
  }, [logs, users, applied]);

  const columns = useMemo<ColumnDef<AuditRow>[]>(() => [
    { id: 'nr', header: 'Nr.', accessor: 'nr', width: 52, align: 'center' },
    {
      id: 'evento',
      header: 'Evento',
      cell: (row) => (
        <Badge variant="outline" className={`text-xs ${EVENTO_COLOR[row.evento]}`}>
          {EVENTO_LABEL[row.evento]}
        </Badge>
      ),
    },
    {
      id: 'tabela',
      header: 'Tabela',
      cell: (row) => <span className="text-xs text-slate-600">{TABELA_LABEL[row.tabela] ?? row.tabela}</span>,
    },
    {
      id: 'userNome',
      header: 'Utilizador',
      cell: (row) => <span className="text-xs font-medium text-slate-700">{row.userNome}</span>,
    },
    {
      id: 'ip',
      header: 'IP',
      cell: (row) => <span className="text-xs font-mono text-slate-400">{row.ip}</span>,
    },
    {
      id: 'data',
      header: 'Data / Hora',
      cell: (row) => (
        <span className="text-xs text-slate-500 whitespace-nowrap">
          {format(parseISO(row.data), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
        </span>
      ),
    },
    {
      id: 'acao',
      header: 'Ação',
      cell: (row) => (
        <Button variant="ghost" size="sm" className="h-7 text-xs px-2"
          onClick={() => setDetailLog(row)}>
          Ver detalhe
        </Button>
      ),
    },
  ], []);

  const toolbar = (
    <div className="flex items-end gap-3 flex-wrap pb-3 border-b border-slate-100">
      <div className="space-y-1">
        <Label className="text-xs font-medium">Data início</Label>
        <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)}
          className="h-9 rounded-md border border-input bg-white px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1" />
      </div>
      <div className="space-y-1">
        <Label className="text-xs font-medium">Data fim</Label>
        <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)}
          className="h-9 rounded-md border border-input bg-white px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1" />
      </div>
      <div className="space-y-1">
        <Label className="text-xs font-medium">Selecione o evento</Label>
        <Select value={eventoFilter} onValueChange={(v) => setEventoFilter(v as EventoAuditoria | 'todos')}>
          <SelectTrigger className="h-9 w-44 text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos os eventos</SelectItem>
            {EVENTO_OPTIONS.map((e) => (
              <SelectItem key={e} value={e}>{EVENTO_LABEL[e]}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-1">
        <Label className="text-xs font-medium">Selecione o utilizador</Label>
        <Select value={userFilter} onValueChange={setUserFilter}>
          <SelectTrigger className="h-9 w-48 text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos os utilizadores</SelectItem>
            {users.map((u) => (
              <SelectItem key={u.id} value={u.id}>{u.nome}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="flex items-center gap-2 pb-px">
        <Button size="sm" onClick={applyFilters} className="gap-1.5">
          <Filter className="h-3.5 w-3.5" /> Filtrar
        </Button>
        {hasActive && (
          <Button size="sm" variant="ghost" onClick={clearFilters} className="gap-1 text-slate-500">
            <X className="h-3.5 w-3.5" /> Limpar
          </Button>
        )}
      </div>
    </div>
  );

  return (
    <PermissionGuard required="audit.read">
      <div className="p-6 space-y-5">
        <PageHeader
          title="Auditoria"
          description="Registo de todas as atividades e eventos do sistema."
          onRefresh={() => setRev((n) => n + 1)}
        />

        <DataTable
          columns={columns}
          data={rows}
          toolbar={toolbar}
          defaultPageSize={15}
          compact
          emptyState={
            <div className="py-10 text-center text-sm text-slate-400">
              Nenhum registo encontrado para os filtros aplicados.
            </div>
          }
        />
      </div>

      <Dialog open={!!detailLog} onOpenChange={(o) => !o && setDetailLog(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Detalhe do Evento</DialogTitle>
            <DialogDescription asChild>
              <span>
                {detailLog && (
                  <span className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className={`text-xs ${EVENTO_COLOR[detailLog.evento]}`}>
                      {EVENTO_LABEL[detailLog.evento]}
                    </Badge>
                    <span className="text-xs text-slate-400">
                      {format(parseISO(detailLog.data), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                    </span>
                  </span>
                )}
              </span>
            </DialogDescription>
          </DialogHeader>
          {detailLog && (
            <div className="space-y-3 text-sm mt-1">
              <DetailRow label="Tabela" value={TABELA_LABEL[detailLog.tabela] ?? detailLog.tabela} />
              {detailLog.registroId && <DetailRow label="ID do Registo" value={detailLog.registroId} mono />}
              <DetailRow label="Utilizador" value={detailLog.userNome} />
              <DetailRow label="Endereço IP" value={detailLog.ip} mono />
              {detailLog.detalhe && (
                <div className="rounded-lg bg-slate-50 border border-slate-100 p-3">
                  <p className="text-xs font-medium text-slate-500 mb-1">Descrição</p>
                  <p className="text-sm text-slate-700">{detailLog.detalhe}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </PermissionGuard>
  );
}

function DetailRow({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-start gap-3">
      <span className="w-32 shrink-0 text-xs font-medium text-slate-500">{label}</span>
      <span className={`text-slate-800 break-all ${mono ? 'font-mono text-xs' : 'text-sm'}`}>{value}</span>
    </div>
  );
}
