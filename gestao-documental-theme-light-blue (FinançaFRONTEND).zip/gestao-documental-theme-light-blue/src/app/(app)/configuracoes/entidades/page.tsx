﻿'use client';

import { useEffect, useMemo, useState } from 'react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Plus, Pencil, Trash2, Building2, MapPin } from 'lucide-react';
import { toast } from 'sonner';
import { z } from 'zod';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter,
} from '@/components/ui/sheet';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
  DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { PageHeader } from '@/components/common/page-header';
import { SectionCard } from '@/components/common/section-card';
import { ProvinceSelect } from '@/components/common/province-select';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { useConfigStore } from '@/store/config-store';
import { useAuthStore } from '@/store/auth-store';
import { auditRepo } from '@/lib/db';
import type { Entity, TipoEntidade } from '@/types';

const TIPO_OPTIONS: { value: TipoEntidade; label: string }[] = [
  { value: 'cliente', label: 'Cliente' },
  { value: 'fornecedor', label: 'Fornecedor' },
  { value: 'parceiro', label: 'Parceiro' },
  { value: 'orgao', label: 'Órgão Público' },
  { value: 'outro', label: 'Outro' },
];

const TIPO_COLOR: Record<TipoEntidade, string> = {
  cliente: 'bg-blue-50 text-blue-700 border-blue-200',
  fornecedor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  parceiro: 'bg-sky-50 text-sky-700 border-sky-200',
  orgao: 'bg-amber-50 text-amber-700 border-amber-200',
  outro: 'bg-slate-50 text-slate-600 border-slate-200',
};

const schema = z.object({
  nome: z.string().min(2, 'Nome obrigatório'),
  tipo: z.enum(['cliente', 'fornecedor', 'parceiro', 'orgao', 'outro']),
  email: z.string().email('E-mail inválido').optional().or(z.literal('')),
  telefone: z.string().optional(),
  endereco: z.string().optional(),
  regiao: z.string().optional(),
  localizacao: z.string().optional(),
});
type FormValues = z.infer<typeof schema>;

export default function EntidadesPage() {
  const { entities, loaded, loadAll, createEntity, updateEntity, removeEntity } = useConfigStore();
  const currentUser = useAuthStore((s) => s.currentUser);

  useEffect(() => { if (!loaded) loadAll(); }, [loaded, loadAll]);

  const [search, setSearch] = useState('');
  const [tipoFilter, setTipoFilter] = useState<TipoEntidade | 'todos'>('todos');
  const [sheetOpen, setSheetOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Entity | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Entity | null>(null);

  const filtered = useMemo(() =>
    entities.filter((e) => {
      const matchSearch = !search || e.nome.toLowerCase().includes(search.toLowerCase()) || e.email?.includes(search);
      const matchTipo = tipoFilter === 'todos' || e.tipo === tipoFilter;
      return matchSearch && matchTipo;
    }),
    [entities, search, tipoFilter]);

  const { register, handleSubmit, reset, setValue, watch, control, formState: { errors } } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { nome: '', tipo: 'cliente', email: '', telefone: '', endereco: '', regiao: '', localizacao: '' },
  });
  const tipo = watch('tipo');

  function openCreate() {
    setEditTarget(null);
    reset({ nome: '', tipo: 'cliente', email: '', telefone: '', endereco: '', regiao: '', localizacao: '' });
    setSheetOpen(true);
  }

  function openEdit(e: Entity) {
    setEditTarget(e);
    reset({ nome: e.nome, tipo: e.tipo, email: e.email ?? '', telefone: e.telefone ?? '', endereco: e.endereco ?? '', regiao: e.regiao ?? '', localizacao: e.localizacao ?? '' });
    setSheetOpen(true);
  }

  function onSubmit(values: FormValues) {
    const now = new Date().toISOString();
    const data = { ...values, email: values.email || undefined };
    if (editTarget) {
      updateEntity(editTarget.id, data);
      auditRepo.create({ evento: 'atualizado', tabela: 'entities', registroId: editTarget.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: now, detalhe: `Entidade "${values.nome}" atualizada` });
      toast.success('Entidade atualizada.');
    } else {
      const entity = createEntity(data);
      auditRepo.create({ evento: 'cadastrado', tabela: 'entities', registroId: entity.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: now, detalhe: `Entidade "${values.nome}" criada` });
      toast.success('Entidade criada.');
    }
    setSheetOpen(false);
  }

  function confirmDelete() {
    if (!deleteTarget) return;
    removeEntity(deleteTarget.id);
    auditRepo.create({ evento: 'eliminado', tabela: 'entities', registroId: deleteTarget.id, userId: currentUser?.id ?? 'system', ip: '127.0.0.1', data: new Date().toISOString(), detalhe: `Entidade "${deleteTarget.nome}" eliminada` });
    toast.success('Entidade eliminada.'); setDeleteTarget(null);
  }

  return (
    <PermissionGuard required="config.entities.manage">
      <div className="p-6 space-y-5">
        <PageHeader
          title="Entidades"
          description="Clientes, fornecedores, parceiros e órgãos. Essenciais para exportações segmentadas."
          primaryAction={{ label: 'Nova Entidade', icon: <Plus className="h-4 w-4" />, onClick: openCreate }}
        />

        <div className="flex items-center gap-3 flex-wrap">
          <input type="search" placeholder="Pesquisar entidades..." value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-9 w-full max-w-sm rounded-md border border-input bg-white px-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1" />
          <Select value={tipoFilter} onValueChange={(v) => setTipoFilter(v as typeof tipoFilter)}>
            <SelectTrigger className="h-9 w-40 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos os tipos</SelectItem>
              {TIPO_OPTIONS.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-xs">
          <table className="w-full text-sm">
            <thead className="border-b border-slate-200 bg-slate-50">
              <tr>
                {['Nome', 'Tipo', 'E-mail', 'Telefone', 'Região', 'Criada em', 'Ações'].map((h) => (
                  <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-slate-500 whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr><td colSpan={7} className="py-10 text-center text-sm text-slate-400">Nenhuma entidade encontrada.</td></tr>
              ) : filtered.map((e) => (
                <tr key={e.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Building2 className="h-4 w-4 text-slate-300 shrink-0" />
                      <span className="font-semibold text-slate-800">{e.nome}</span>
                    </div>
                    {e.endereco && <p className="text-xs text-slate-400 ml-6 truncate max-w-xs">{e.endereco}</p>}
                  </td>
                  <td className="px-4 py-3">
                    <Badge variant="outline" className={`text-xs ${TIPO_COLOR[e.tipo]}`}>
                      {TIPO_OPTIONS.find((o) => o.value === e.tipo)?.label}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 text-slate-500 text-xs">{e.email ?? '—'}</td>
                  <td className="px-4 py-3 text-slate-500 text-xs whitespace-nowrap">{e.telefone ?? '—'}</td>
                  <td className="px-4 py-3 text-xs">
                    {(e.regiao || e.localizacao) ? (
                      <span className="flex items-center gap-1 text-slate-600">
                        <MapPin className="h-3 w-3 text-slate-300" />
                        {[e.regiao, e.localizacao].filter(Boolean).join(' · ')}
                      </span>
                    ) : <span className="text-slate-400">—</span>}
                  </td>
                  <td className="px-4 py-3 text-slate-500 text-xs whitespace-nowrap">
                    {format(parseISO(e.criadoEm), 'dd/MM/yyyy', { locale: ptBR })}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="icon-xs" onClick={() => openEdit(e)}><Pencil className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon-xs" onClick={() => setDeleteTarget(e)} className="text-slate-400 hover:text-red-500"><Trash2 className="h-3.5 w-3.5" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
        <SheetContent className="sm:max-w-lg overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-sky-600" />
              {editTarget ? `Editar: ${editTarget.nome}` : 'Nova Entidade'}
            </SheetTitle>
          </SheetHeader>
          <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4  px-3">
            <SectionCard title="Dados da Entidade">
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Nome <span className="text-red-500">*</span></Label>
                  <Input {...register('nome')} className="text-sm" />
                  {errors.nome && <p className="text-xs text-red-500">{errors.nome.message}</p>}
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Tipo <span className="text-red-500">*</span></Label>
                  <Select value={tipo} onValueChange={(v) => setValue('tipo', v as TipoEntidade)}>
                    <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {TIPO_OPTIONS.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium text-slate-600">E-mail</Label>
                    <Input {...register('email')} type="email" className="text-sm" />
                    {errors.email && <p className="text-xs text-red-500">{errors.email.message}</p>}
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs font-medium text-slate-600">Telefone</Label>
                    <Input {...register('telefone')} className="text-sm" />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Endereço</Label>
                  <Input {...register('endereco')} className="text-sm" />
                </div>
              </div>
            </SectionCard>

            <SectionCard title="Localização" description="Para segmentação em exportações">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Região</Label>
                  <Controller
                    control={control}
                    name="regiao"
                    render={({ field }) => (
                      <ProvinceSelect
                        value={field.value ?? ''}
                        onChange={field.onChange}
                        placeholder="Selecionar província..."
                      />
                    )}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Localização</Label>
                  <Input {...register('localizacao')} placeholder="Ex: Bairro Miramar" className="text-sm" />
                </div>
              </div>
            </SectionCard>

            <SheetFooter className="mt-4 pt-4 border-t border-slate-100 gap-2">
              <Button type="button" variant="outline" size="sm" onClick={() => setSheetOpen(false)}>Cancelar</Button>
              <Button type="submit" size="sm">{editTarget ? 'Guardar' : 'Criar Entidade'}</Button>
            </SheetFooter>
          </form>
        </SheetContent>
      </Sheet>

      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Eliminar entidade?</DialogTitle>
            <DialogDescription>&ldquo;{deleteTarget?.nome}&rdquo; será eliminada permanentemente.</DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => setDeleteTarget(null)}>Cancelar</Button>
            <Button variant="destructive" size="sm" onClick={confirmDelete}>Eliminar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PermissionGuard>
  );
}
