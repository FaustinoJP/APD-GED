﻿'use client';

import { useEffect, useRef, useState } from 'react';
import { Building2, Upload, Trash2, AlertTriangle, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { PageHeader } from '@/components/common/page-header';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { ConfirmDialog } from '@/components/common/confirm-dialog';
import { useConfigStore } from '@/store/config-store';
import { useAuthStore } from '@/store/auth-store';
import { auditRepo, clearAppData } from '@/lib/db';
import { seedDatabase } from '@/data/seed';
import { resolveFileUrl } from '@/lib/file-url';
import { apiUploadFile } from '@/lib/api/uploads';

const IS_API_MODE = process.env.NEXT_PUBLIC_DATA_SOURCE === 'api';

const schema = z.object({
  nome: z.string().min(2, 'Nome obrigatório'),
  nif: z.string().optional(),
  email: z.string().email('E-mail inválido').optional().or(z.literal('')),
  telefone: z.string().optional(),
  website: z.string().optional(),
  endereco: z.string().optional(),
  logoUrl: z.string().optional(),
});
type FormValues = z.infer<typeof schema>;

export default function EmpresaPage() {
  const { company, loaded, loadAll, saveCompany } = useConfigStore();
  const currentUser = useAuthStore((s) => s.currentUser);

  useEffect(() => { if (!loaded) loadAll(); }, [loaded, loadAll]);

  const logoInputRef = useRef<HTMLInputElement>(null);
  const [logoPreview, setLogoPreview] = useState('');
  const [resetOpen, setResetOpen] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [uploading, setUploading] = useState(false);

  const { register, handleSubmit, setValue, watch, formState: { errors, isDirty } } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { nome: '', nif: '', email: '', telefone: '', website: '', endereco: '', logoUrl: '' },
  });

  useEffect(() => {
    if (loaded) {
      setValue('nome', company.nome);
      setValue('nif', company.nif ?? '');
      setValue('email', company.email ?? '');
      setValue('telefone', company.telefone ?? '');
      setValue('website', company.website ?? '');
      setValue('endereco', company.endereco ?? '');
      setValue('logoUrl', company.logoUrl ?? '');
      setLogoPreview(company.logoUrl ?? '');
    }
  }, [loaded, company, setValue]);

  async function handleLogoFile(file: File) {
    if (IS_API_MODE) {
      setUploading(true);
      try {
        const result = await apiUploadFile(file);
        setLogoPreview(result.url);
        setValue('logoUrl', result.url, { shouldDirty: true });
        toast.success('Logótipo carregado.');
      } catch (err) {
        console.error('Erro ao carregar o logótipo:', err);
        toast.error('Erro ao carregar o logótipo no servidor.');
      } finally {
        setUploading(false);
      }
    } else {
      const reader = new FileReader();
      reader.onload = (e) => {
        const url = e.target?.result as string;
        setLogoPreview(url);
        setValue('logoUrl', url, { shouldDirty: true });
      };
      reader.readAsDataURL(file);
    }
  }

  function removeLogo() {
    setLogoPreview('');
    setValue('logoUrl', '', { shouldDirty: true });
  }

  function onSubmit(values: FormValues) {
    saveCompany({
      nome: values.nome,
      nif: values.nif || undefined,
      email: values.email || undefined,
      telefone: values.telefone || undefined,
      website: values.website || undefined,
      endereco: values.endereco || undefined,
      logoUrl: values.logoUrl || undefined,
    });
    auditRepo.create({
      evento: 'atualizado',
      tabela: 'company',
      userId: currentUser?.id ?? 'system',
      ip: '127.0.0.1',
      data: new Date().toISOString(),
      detalhe: `Configurações da empresa "${values.nome}" atualizadas`,
    });
    toast.success('Configurações guardadas.');
  }

  function handleResetDemo() {
    setResetting(true);
    try {
      clearAppData();
      seedDatabase();
      toast.success('Dados de demonstração repostos. A recarregar…', { duration: 2000 });
      setTimeout(() => window.location.reload(), 1800);
    } catch {
      toast.error('Erro ao repor dados. Tente limpar o localStorage manualmente.');
      setResetting(false);
    }
  }

  const nome = watch('nome');

  return (
    <PermissionGuard required="config.company.manage">
      <div className="p-6 space-y-5">
        <PageHeader
          title="Empresa"
          description="Configurações gerais da organização, usadas em templates e cabeçalhos de documentos."
        />

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-5 max-w-2xl">
          {/* Logo */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
            <h3 className="text-sm font-semibold text-slate-800 flex items-center gap-2">
              <Building2 className="h-4 w-4 text-sky-600" /> Logótipo
            </h3>
            <div className="flex items-center gap-5">
              <div className="h-20 w-44 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-center overflow-hidden shrink-0">
                {logoPreview
                  ? <img src={resolveFileUrl(logoPreview)} alt="logótipo" className="h-full w-full object-contain p-2" />
                  : <Building2 className="h-8 w-8 text-slate-300" />
                }
              </div>
              <div className="space-y-2">
                <p className="text-xs text-slate-500">
                  Formato PNG ou SVG recomendado. Máximo 1 MB.<br />
                  Exibido em cabeçalhos de templates e exportações PDF.
                </p>
                <div className="flex items-center gap-2">
                  <input ref={logoInputRef} type="file" accept="image/*" className="hidden"
                    onChange={(e) => { const f = e.target.files?.[0]; if (f) handleLogoFile(f); }} />
                  <Button type="button" variant="outline" size="sm" className="gap-1.5"
                    onClick={() => logoInputRef.current?.click()} disabled={uploading}>
                    <Upload className="h-3.5 w-3.5" /> {uploading ? 'A carregar...' : 'Carregar logótipo'}
                  </Button>
                  {logoPreview && (
                    <Button type="button" variant="ghost" size="sm" className="gap-1.5 text-slate-400 hover:text-red-500"
                      onClick={removeLogo} disabled={uploading}>
                      <Trash2 className="h-3.5 w-3.5" /> Remover
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Identificação */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
            <h3 className="text-sm font-semibold text-slate-800">Identificação</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2 space-y-1.5">
                <Label className="text-xs font-medium text-slate-600">
                  Nome da organização <span className="text-red-500">*</span>
                </Label>
                <Input {...register('nome')} className="text-sm" placeholder={nome || 'Ex: Watchalla Lda.'} />
                {errors.nome && <p className="text-xs text-red-500">{errors.nome.message}</p>}
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-slate-600">NIF / NIPC</Label>
                <Input {...register('nif')} className="text-sm" placeholder="Ex: 5000000000" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-slate-600">Website</Label>
                <Input {...register('website')} className="text-sm" placeholder="https://..." />
              </div>
            </div>
          </div>

          {/* Contactos */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
            <h3 className="text-sm font-semibold text-slate-800">Contactos</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-slate-600">E-mail</Label>
                <Input {...register('email')} type="email" className="text-sm" />
                {errors.email && <p className="text-xs text-red-500">{errors.email.message}</p>}
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-slate-600">Telefone</Label>
                <Input {...register('telefone')} className="text-sm" />
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="text-xs font-medium text-slate-600">Endereço</Label>
                <Textarea {...register('endereco')} className="text-sm resize-none" rows={2} />
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <Button type="submit" size="sm" disabled={!isDirty || uploading}>
              Guardar alterações
            </Button>
          </div>
        </form>

        {/* Danger zone */}
        <div className="max-w-2xl rounded-xl border border-red-200 bg-red-50 p-5 space-y-3">
          <h3 className="text-sm font-semibold text-red-800 flex items-center gap-2">
            <AlertTriangle className="h-4 w-4" />
            Zona de risco
          </h3>
          <p className="text-xs text-red-700 leading-relaxed">
            Repõe todos os dados de demonstração no localStorage. Útil quando os dados
            ficam corrompidos ou quando quer recomeçar com o dataset inicial.{' '}
            <strong>Esta acção não pode ser desfeita</strong> — quaisquer documentos,
            utilizadores ou configurações criados serão perdidos.
          </p>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="gap-2 border-red-300 text-red-700 hover:bg-red-100 hover:border-red-400"
            onClick={() => setResetOpen(true)}
            disabled={resetting}
          >
            <RefreshCw className={`h-3.5 w-3.5 ${resetting ? 'animate-spin' : ''}`} />
            Repor dados de demonstração
          </Button>
        </div>

        <ConfirmDialog
          open={resetOpen}
          onOpenChange={setResetOpen}
          title="Repor dados de demonstração?"
          description="Todos os documentos, utilizadores, configurações e registos actuais serão apagados e substituídos pelos dados de demonstração originais. Esta acção é irreversível."
          confirmLabel="Sim, repor dados"
          variant="destructive"
          loading={resetting}
          onConfirm={handleResetDemo}
        />
      </div>
    </PermissionGuard>
  );
}
