﻿'use client';

import { useEffect, useMemo, useState } from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import Link from 'next/link';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell,
} from 'recharts';
import {
  Clock, Plus, Search, ArrowRight, FileText, CheckCircle, Activity, AlertCircle,
} from 'lucide-react';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { StatPill } from '@/components/common/stat-pill';
import { useAuthStore } from '@/store/auth-store';
import { documentsRepo, circulationsRepo } from '@/lib/db';
import type { DocumentRecord, EstadoDocumento } from '@/types';

const MONTHS = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

export default function DashboardPage() {
  const currentUser = useAuthStore((s) => s.currentUser);
  const currentRole = useAuthStore((s) => s.currentRole);

  const [docs, setDocs] = useState<DocumentRecord[]>([]);
  const [mounted, setMounted] = useState(false);
  const [chartYear, setChartYear] = useState(String(new Date().getFullYear()));

  useEffect(() => {
    setDocs(documentsRepo.list());
    setMounted(true);
  }, []);

  const canRead = currentRole?.permissions.includes('documents.read') ?? false;
  const isAdmin = currentRole?.permissions.includes('config.users.manage') ?? false;

  const visibleDocs = useMemo(() => {
    if (!canRead) return [];
    return docs.filter((d) => !d.confidencial || isAdmin || d.criadoPor === currentUser?.id);
  }, [docs, canRead, isAdmin, currentUser]);

  const pendingCount = useMemo(() => {
    if (!currentUser) return 0;
    return circulationsRepo.query(
      (c) => c.status === 'pendente' &&
        c.paraDestinatarios.some((d) => d.tipo === 'user' && d.id === currentUser.id),
    ).length;
  }, [currentUser]);

  const kpis = useMemo(() => {
    const total = visibleDocs.length;
    const classified = visibleDocs.filter((d) => d.estado !== 'novo').length;
    const unclassified = total - classified;
    const emCirculacao = visibleDocs.filter((d) => d.estado === 'em_circulacao').length;
    const aprovados = visibleDocs.filter((d) => d.estado === 'aprovado').length;
    return { total, classified, unclassified, emCirculacao, aprovados };
  }, [visibleDocs]);

  const years = useMemo(() => {
    const cur = new Date().getFullYear();
    const ys = new Set([...visibleDocs.map((d) => new Date(d.criadoEm).getFullYear()), cur]);
    return Array.from(ys).sort((a, b) => b - a);
  }, [visibleDocs]);

  const chartData = useMemo(() => {
    const yr = parseInt(chartYear, 10);
    return MONTHS.map((month, i) => {
      const inMonth = visibleDocs.filter((d) => {
        const dt = new Date(d.criadoEm);
        return dt.getFullYear() === yr && dt.getMonth() === i;
      });
      return {
        month,
        Entradas: inMonth.filter((d) => d.tipoRegistro === 'entrada').length,
        'Saídas': inMonth.filter((d) => d.tipoRegistro === 'saida').length,
        Internos: inMonth.filter((d) => d.tipoRegistro === 'interno').length,
      };
    });
  }, [visibleDocs, chartYear]);

  const tipoRegistroStats = useMemo(() => {
    const total = visibleDocs.length;
    const defs: { label: string; tipo: string; color: string }[] = [
      { label: 'Entradas', tipo: 'entrada', color: '#6366f1' },
      { label: 'Saídas', tipo: 'saida', color: '#f59e0b' },
      { label: 'Internos', tipo: 'interno', color: '#10b981' },
    ];
    return defs.map((d) => {
      const value = visibleDocs.filter((doc) => doc.tipoRegistro === d.tipo).length;
      return { ...d, value, pct: total > 0 ? (value / total) * 100 : 0 };
    });
  }, [visibleDocs]);

  const estadoStats = useMemo(() => {
    const defs: { label: string; estado: EstadoDocumento; color: string }[] = [
      { label: 'Novo', estado: 'novo', color: '#94a3b8' },
      { label: 'Em Circulação', estado: 'em_circulacao', color: '#f59e0b' },
      { label: 'Aprovado', estado: 'aprovado', color: '#10b981' },
      { label: 'Rejeitado', estado: 'rejeitado', color: '#ef4444' },
      { label: 'Deferido', estado: 'deferido', color: '#6366f1' },
      { label: 'Arquivado', estado: 'arquivado', color: '#64748b' },
      { label: 'Concluído', estado: 'concluido', color: '#0ea5e9' },
    ];
    return defs
      .map((d) => ({
        label: d.label,
        color: d.color,
        value: visibleDocs.filter((doc) => doc.estado === d.estado).length,
      }))
      .filter((d) => d.value > 0);
  }, [visibleDocs]);

  const firstName = currentUser?.nome.split(' ')[0] ?? 'Utilizador';
  const todayFmt = format(new Date(), "EEEE, d 'de' MMMM 'de' yyyy", { locale: ptBR });

  return (
    <div className="p-6 space-y-6">
      {/* Greeting */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Bem-vindo de volta, {firstName}!</h1>
          <p className="mt-0.5 text-sm text-slate-500 capitalize">{todayFmt}</p>
          {pendingCount > 0 && (
            <Link href="/pendentes"
              className="inline-flex items-center gap-1.5 mt-2 text-xs font-medium text-amber-700 bg-amber-50 border border-amber-200 rounded-full px-3 py-1 hover:bg-amber-100 transition-colors">
              <Clock className="h-3 w-3" />
              {pendingCount} {pendingCount === 1 ? 'documento pendente' : 'documentos pendentes'} à sua espera
              <ArrowRight className="h-3 w-3" />
            </Link>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Link href="/pesquisas/documentos"
            className="inline-flex items-center gap-1.5 h-9 px-3 rounded-md border border-slate-200 bg-white text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors">
            <Search className="h-4 w-4" /> Pesquisar
          </Link>
          <Link href="/registro/entradas"
            className="inline-flex items-center gap-1.5 h-9 px-3 rounded-md bg-sky-600 text-sm font-medium text-white hover:bg-sky-700 transition-colors">
            <Plus className="h-4 w-4" /> Registar
          </Link>
        </div>
      </div>

      {/* StatPill KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Link href="/documentos" className="block focus:outline-none focus:ring-2 focus:ring-sky-500 rounded-lg group">
          <StatPill
            value={kpis.total}
            label="Quantidade de Documentos"
            format="number"
            trend="neutral"
            className="hover:border-sky-300 hover:shadow-md transition-all cursor-pointer group-hover:scale-[1.02] duration-200"
          />
        </Link>
        <Link href="/documentos?classificado=true" className="block focus:outline-none focus:ring-2 focus:ring-sky-500 rounded-lg group">
          <StatPill
            value={kpis.classified}
            target={kpis.total}
            label="Documentos Classificados"
            format="number"
            trend={kpis.total > 0 && kpis.classified >= kpis.total ? 'up' : 'neutral'}
            className="hover:border-sky-300 hover:shadow-md transition-all cursor-pointer group-hover:scale-[1.02] duration-200"
          />
        </Link>
        <Link href="/documentos?estado=novo" className="block focus:outline-none focus:ring-2 focus:ring-sky-500 rounded-lg group">
          <StatPill
            value={kpis.unclassified}
            label="Documentos Não Classificados"
            format="number"
            trend={kpis.unclassified === 0 ? 'neutral' : 'down'}
            className="hover:border-sky-300 hover:shadow-md transition-all cursor-pointer group-hover:scale-[1.02] duration-200"
          />
        </Link>
      </div>

      {/* Mini KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Link href="/documentos" className="block focus:outline-none focus:ring-2 focus:ring-sky-500 rounded-xl">
          <MiniKpi icon={<FileText className="h-4 w-4" />} label="Total" value={kpis.total} color="indigo" interactive />
        </Link>
        <Link href="/documentos?estado=em_circulacao" className="block focus:outline-none focus:ring-2 focus:ring-sky-500 rounded-xl">
          <MiniKpi icon={<Activity className="h-4 w-4" />} label="Em Circulação" value={kpis.emCirculacao} color="amber" interactive />
        </Link>
        <Link href="/documentos?estado=aprovado" className="block focus:outline-none focus:ring-2 focus:ring-sky-500 rounded-xl">
          <MiniKpi icon={<CheckCircle className="h-4 w-4" />} label="Aprovados" value={kpis.aprovados} color="emerald" interactive />
        </Link>
        <Link href="/pendentes" className="block focus:outline-none focus:ring-2 focus:ring-sky-500 rounded-xl">
          <MiniKpi icon={<AlertCircle className="h-4 w-4" />} label="Pendentes (meus)" value={pendingCount} color="rose" interactive />
        </Link>
      </div>

      {/* Charts grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Chart */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-2">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-sm font-semibold text-slate-800">Classificação dos Documentos</h2>
            <p className="text-xs text-slate-400 mt-0.5">Entradas, saídas e internos por mês</p>
          </div>
          <Select value={chartYear} onValueChange={setChartYear}>
            <SelectTrigger className="h-8 w-24 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              {years.map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="h-[280px]">
          {mounted ? (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={chartData} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94a3b8' }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={{ borderRadius: '8px', fontSize: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '12px' }} />
                <Bar dataKey="Entradas" fill="#6366f1" radius={[3, 3, 0, 0]} maxBarSize={28} />
                <Bar dataKey="Saídas" fill="#f59e0b" radius={[3, 3, 0, 0]} maxBarSize={28} />
                <Bar dataKey="Internos" fill="#10b981" radius={[3, 3, 0, 0]} maxBarSize={28} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full rounded-lg bg-slate-50 animate-pulse" />
          )}
        </div>
      </div>

      {/* Percentage comparison by type */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-1">
        <div className="mb-5">
          <h2 className="text-sm font-semibold text-slate-800">Comparação por Tipo</h2>
          <p className="text-xs text-slate-400 mt-0.5">Distribuição percentual do total</p>
        </div>
        <div className="space-y-4">
          {tipoRegistroStats.map((s) => (
            <div key={s.label}>
              <div className="flex items-center justify-between mb-1.5">
                <span className="flex items-center gap-2 text-sm text-slate-600">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: s.color }} />
                  {s.label}
                </span>
                <span className="text-sm font-semibold text-slate-900">
                  {s.pct.toFixed(1)}%
                  <span className="ml-1.5 text-xs font-normal text-slate-400">({s.value})</span>
                </span>
              </div>
              <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{ width: `${s.pct}%`, backgroundColor: s.color }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
      </div>

      {/* Document states pie chart */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="mb-5">
          <h2 className="text-sm font-semibold text-slate-800">Estados dos Documentos</h2>
          <p className="text-xs text-slate-400 mt-0.5">Proporção de documentos por estado</p>
        </div>
        <div className="h-[280px]">
          {mounted ? (
            estadoStats.length > 0 ? (
              <ResponsiveContainer width="100%" height={280}>
                <PieChart>
                  <Pie
                    data={estadoStats}
                    dataKey="value"
                    nameKey="label"
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={2}
                  >
                    {estadoStats.map((s) => (
                      <Cell key={s.label} fill={s.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ borderRadius: '8px', fontSize: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '12px' }} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-sm text-slate-400">
                Sem documentos para exibir
              </div>
            )
          ) : (
            <div className="h-full rounded-lg bg-slate-50 animate-pulse" />
          )}
        </div>
      </div>

      {/* Quick links */}
      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-400 mb-3">Atalhos rápidos</p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <QuickLink href="/pendentes" icon={<Clock className="h-5 w-5 text-amber-600" />}
            label="Pendentes" desc={pendingCount > 0 ? `${pendingCount} à espera da sua ação` : 'Sem pendentes'} />
          <QuickLink href="/registro/entradas" icon={<Plus className="h-5 w-5 text-sky-600" />}
            label="Registar Entrada" desc="Novo documento de entrada" />
          <QuickLink href="/pesquisas/documentos" icon={<Search className="h-5 w-5 text-emerald-600" />}
            label="Pesquisar" desc="Busca avançada de documentos" />
        </div>
      </div>
    </div>
  );
}

function MiniKpi({ icon, label, value, color, interactive = false }: {
  icon: React.ReactNode;
  label: string;
  value: number;
  color: 'indigo' | 'amber' | 'emerald' | 'rose';
  interactive?: boolean;
}) {
  const cls: Record<typeof color, string> = {
    indigo: 'bg-sky-50 text-sky-600',
    amber: 'bg-amber-50 text-amber-600',
    emerald: 'bg-emerald-50 text-emerald-600',
    rose: 'bg-rose-50 text-rose-600',
  };
  return (
    <div className={`rounded-xl border border-slate-200 bg-white p-4 flex items-center gap-3 ${
      interactive 
        ? 'hover:border-sky-300 hover:shadow-md hover:scale-[1.02] cursor-pointer transition-all duration-200' 
        : ''
    }`}>
      <div className={`h-9 w-9 rounded-lg flex items-center justify-center shrink-0 ${cls[color]}`}>{icon}</div>
      <div>
        <p className="text-xl font-bold text-slate-900">{value.toLocaleString('pt')}</p>
        <p className="text-xs text-slate-500">{label}</p>
      </div>
    </div>
  );
}

function QuickLink({ href, icon, label, desc }: {
  href: string; icon: React.ReactNode; label: string; desc: string;
}) {
  return (
    <Link href={href}
      className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-4 hover:bg-slate-50 transition-colors group">
      <div className="h-10 w-10 rounded-lg bg-slate-50 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">{icon}</div>
      <div className="min-w-0">
        <p className="text-sm font-semibold text-slate-800">{label}</p>
        <p className="text-xs text-slate-400 truncate">{desc}</p>
      </div>
      <ArrowRight className="h-4 w-4 text-slate-300 ml-auto shrink-0 group-hover:text-slate-500 transition-colors" />
    </Link>
  );
}
