'use client';

import { Fragment, useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  Archive, ChevronRight, Home, Menu, X, Search, FolderOpen, HelpCircle,
} from 'lucide-react';
import { Sheet, SheetContent } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { DataTable, type ColumnDef } from '@/components/common/data-table';
import { StatusBadge } from '@/components/common/status-badge';
import { EmptyState } from '@/components/common/empty-state';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { useDocumentsStore } from '@/store/documents-store';
import { useConfigStore } from '@/store/config-store';
import {
  buildLocationTree, collectDescendantIds, getLocationPath, type LocationTreeNode,
} from '@/lib/locations/locationTree';
import type { DocumentRecord } from '@/types';
import { cn } from '@/lib/utils';

const SEM_LOCALIZACAO_ID = '__sem_localizacao__';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function countDocs(t: LocationTreeNode, docs: DocumentRecord[]): number {
  const ids = new Set(collectDescendantIds(t));
  return docs.filter((d) => d.localizacaoFisicaId && ids.has(d.localizacaoFisicaId)).length;
}

function filterTree(
  nodes: LocationTreeNode[],
  query: string,
): { filtered: LocationTreeNode[]; matchedIds: Set<string> } {
  const matchedIds = new Set<string>();
  if (!query.trim()) return { filtered: nodes, matchedIds };
  const q = query.toLowerCase();

  function walk(t: LocationTreeNode): LocationTreeNode | null {
    const self = t.node.nome.toLowerCase().includes(q);
    const kids = t.children.map(walk).filter((n): n is LocationTreeNode => n !== null);
    if (self || kids.length > 0) {
      matchedIds.add(t.node.id);
      return { ...t, children: kids };
    }
    return null;
  }

  return { filtered: nodes.map(walk).filter((n): n is LocationTreeNode => n !== null), matchedIds };
}

function findTreeNode(nodes: LocationTreeNode[], id: string): LocationTreeNode | null {
  for (const t of nodes) {
    if (t.node.id === id) return t;
    const found = findTreeNode(t.children, id);
    if (found) return found;
  }
  return null;
}

// ─── Sidebar tree row ─────────────────────────────────────────────────────────

function TreeRow({
  tree, depth, expandedIds, onToggle, selectedId, onSelect, docs,
}: {
  tree: LocationTreeNode;
  depth: number;
  expandedIds: Set<string>;
  onToggle: (id: string) => void;
  selectedId: string | null;
  onSelect: (id: string) => void;
  docs: DocumentRecord[];
}) {
  const isExpanded = expandedIds.has(tree.node.id);
  const isSelected = selectedId === tree.node.id;
  const hasKids = tree.children.length > 0;
  const count = countDocs(tree, docs);

  return (
    <div>
      <button
        className={cn(
          'flex w-full items-center gap-1.5 rounded-md py-1 pr-2 text-left text-xs transition-colors hover:bg-slate-100',
          isSelected && 'bg-indigo-50 text-indigo-700 hover:bg-indigo-50',
        )}
        style={{ paddingLeft: `${8 + depth * 16}px` }}
        onClick={() => { onToggle(tree.node.id); onSelect(tree.node.id); }}
      >
        {hasKids ? (
          <ChevronRight className={cn('h-3 w-3 shrink-0 transition-transform', isExpanded && 'rotate-90')} />
        ) : (
          <span className="w-3 shrink-0" />
        )}
        <Archive className="h-3.5 w-3.5 shrink-0 opacity-60" />
        <span className="flex-1 truncate">{tree.node.nome}</span>
        <span className="ml-1 shrink-0 rounded-full bg-slate-100 px-1.5 text-[10px] text-slate-500 tabular-nums">
          {count}
        </span>
      </button>
      {isExpanded && hasKids && tree.children.map((child) => (
        <TreeRow
          key={child.node.id}
          tree={child}
          depth={depth + 1}
          expandedIds={expandedIds}
          onToggle={onToggle}
          selectedId={selectedId}
          onSelect={onSelect}
          docs={docs}
        />
      ))}
    </div>
  );
}

// ─── Sidebar content ──────────────────────────────────────────────────────────

function SidebarContent({
  tree, expandedIds, onToggle, selectedId, onSelect, docs, semLocalizacaoCount, onClose,
}: {
  tree: LocationTreeNode[];
  expandedIds: Set<string>;
  onToggle: (id: string) => void;
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  docs: DocumentRecord[];
  semLocalizacaoCount: number;
  onClose?: () => void;
}) {
  const [q, setQ] = useState('');
  const { filtered, matchedIds } = useMemo(() => filterTree(tree, q), [tree, q]);
  const effectiveExpanded = q.trim() ? matchedIds : expandedIds;

  return (
    <div className="flex h-full flex-col">
      <div className="space-y-2 border-b border-slate-200 px-3 py-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-slate-800">Localização Física</h2>
          {onClose && (
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
          <input
            type="search"
            placeholder="Pesquisar…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="h-8 w-full rounded-md border border-slate-200 bg-slate-50 pl-8 pr-3 text-xs placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto py-1.5 px-1">
        {filtered.length === 0 ? (
          <p className="px-3 py-4 text-xs text-slate-400">Nenhum resultado.</p>
        ) : (
          filtered.map((t) => (
            <TreeRow
              key={t.node.id}
              tree={t}
              depth={0}
              expandedIds={effectiveExpanded}
              onToggle={onToggle}
              selectedId={selectedId}
              onSelect={onSelect}
              docs={docs}
            />
          ))
        )}
        {!q.trim() && semLocalizacaoCount > 0 && (
          <button
            className={cn(
              'mt-1 flex w-full items-center gap-1.5 rounded-md py-1 pr-2 pl-2 text-left text-xs transition-colors hover:bg-slate-100',
              selectedId === SEM_LOCALIZACAO_ID && 'bg-indigo-50 text-indigo-700 hover:bg-indigo-50',
            )}
            onClick={() => onSelect(SEM_LOCALIZACAO_ID)}
          >
            <HelpCircle className="h-3.5 w-3.5 shrink-0 opacity-60" />
            <span className="flex-1 truncate">Sem localização física</span>
            <span className="ml-1 shrink-0 rounded-full bg-slate-100 px-1.5 text-[10px] text-slate-500 tabular-nums">
              {semLocalizacaoCount}
            </span>
          </button>
        )}
      </div>
    </div>
  );
}

// ─── Breadcrumb ───────────────────────────────────────────────────────────────

function BreadcrumbNav({
  path, onNavigate, isSemLocalizacao,
}: {
  path: string[];
  onNavigate: (id: string | null) => void;
  isSemLocalizacao: boolean;
}) {
  return (
    <nav className="flex flex-wrap items-center gap-1 text-xs">
      <button onClick={() => onNavigate(null)} className="flex items-center gap-1 text-slate-500 hover:text-indigo-600 transition-colors">
        <Home className="h-3.5 w-3.5" /><span>Início</span>
      </button>
      {path.map((seg, i) => (
        <Fragment key={i}>
          <ChevronRight className="h-3 w-3 shrink-0 text-slate-300" />
          <span className={cn('text-slate-500', i === path.length - 1 && 'font-semibold text-slate-800')}>
            {seg}
          </span>
        </Fragment>
      ))}
      {isSemLocalizacao && (
        <>
          <ChevronRight className="h-3 w-3 shrink-0 text-slate-300" />
          <span className="font-semibold text-slate-800">Sem localização física</span>
        </>
      )}
    </nav>
  );
}

// ─── Subfolder grid ───────────────────────────────────────────────────────────

function SubfolderGrid({
  nodes, docs, onSelect,
}: {
  nodes: LocationTreeNode[];
  docs: DocumentRecord[];
  onSelect: (id: string) => void;
}) {
  if (nodes.length === 0) return null;
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
      {nodes.map((t) => (
        <button
          key={t.node.id}
          onClick={() => onSelect(t.node.id)}
          className="group flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-4 text-left transition-colors hover:border-indigo-300 hover:bg-indigo-50/40"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600 transition-transform group-hover:scale-110">
            <FolderOpen className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-slate-800">{t.node.nome}</p>
            <p className="mt-0.5 text-xs text-slate-400">
              {countDocs(t, docs)} {countDocs(t, docs) === 1 ? 'documento' : 'documentos'}
            </p>
          </div>
        </button>
      ))}
    </div>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function LocalizacaoFisicaPage() {
  const router = useRouter();

  const docs = useDocumentsStore((s) => s.documents);
  const docsLoaded = useDocumentsStore((s) => s.loaded);
  const loadDocs = useDocumentsStore((s) => s.load);
  const {
    locationLevels, locationNodes, documentTypes, entities, loaded: configLoaded, loadAll,
  } = useConfigStore();

  useEffect(() => {
    if (!configLoaded) loadAll();
    if (!docsLoaded) loadDocs();
  }, [configLoaded, loadAll, docsLoaded, loadDocs]);

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());

  const tree = useMemo(() => buildLocationTree(locationNodes), [locationNodes]);
  const semLocalizacaoDocs = useMemo(() => docs.filter((d) => !d.localizacaoFisicaId), [docs]);

  const selectedTree = useMemo(
    () => (selectedId && selectedId !== SEM_LOCALIZACAO_ID ? findTreeNode(tree, selectedId) : null),
    [tree, selectedId],
  );
  const isSemLocalizacao = selectedId === SEM_LOCALIZACAO_ID;

  const breadcrumbPath = useMemo(
    () => getLocationPath(selectedTree?.node.id, locationNodes).map((n) => n.nome),
    [selectedTree, locationNodes],
  );

  function toggle(id: string) {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  function handleSelect(id: string | null) {
    setSelectedId(id);
    setSidebarOpen(false);
    if (id && id !== SEM_LOCALIZACAO_ID) {
      setExpandedIds((prev) => new Set(prev).add(id));
    }
  }

  const docTypeName = (id: string) => documentTypes.find((t) => t.id === id)?.nome ?? '—';
  const remetenteName = (doc: DocumentRecord) => {
    if (doc.remetenteTexto) return doc.remetenteTexto;
    if (doc.remetenteId) return entities.find((e) => e.id === doc.remetenteId)?.nome ?? '—';
    return '—';
  };

  const directDocs = useMemo(() => {
    if (isSemLocalizacao) return semLocalizacaoDocs;
    if (!selectedTree) return [];
    return docs.filter((d) => d.localizacaoFisicaId === selectedTree.node.id);
  }, [isSemLocalizacao, semLocalizacaoDocs, selectedTree, docs]);

  const columns = useMemo<ColumnDef<DocumentRecord>[]>(() => [
    { id: 'numero', header: 'Nr. Documento', accessor: 'numero', width: 150, cell: (r) => <span className="font-mono text-xs font-semibold text-indigo-700">{r.numero}</span> },
    { id: 'tipo', header: 'Tipo', width: 160, cell: (r) => <span className="text-xs text-slate-600">{docTypeName(r.tipoDocumentoId)}</span> },
    { id: 'assunto', header: 'Assunto', accessor: 'assunto', cell: (r) => <span className="block max-w-70 truncate text-sm text-slate-700">{r.assunto}</span> },
    { id: 'estado', header: 'Estado', width: 130, cell: (r) => <StatusBadge status={r.estado} /> },
    { id: 'data', header: 'Data', accessor: 'data', width: 100, cell: (r) => <span className="text-xs text-slate-600">{format(parseISO(r.data), 'dd/MM/yyyy', { locale: ptBR })}</span> },
    { id: 'remetente', header: 'Remetente', width: 160, cell: (r) => <span className="block max-w-35 truncate text-xs text-slate-600">{remetenteName(r)}</span> },
    // eslint-disable-next-line react-hooks/exhaustive-deps
  ], [documentTypes, entities]);

  const panelLabel = isSemLocalizacao
    ? 'Sem localização física'
    : selectedTree?.node.nome ?? 'Todas as Localizações';
  const panelCount = isSemLocalizacao
    ? semLocalizacaoDocs.length
    : selectedTree
      ? countDocs(selectedTree, docs)
      : docs.filter((d) => d.localizacaoFisicaId).length + semLocalizacaoDocs.length;

  const sidebarProps = {
    tree, expandedIds, onToggle: toggle, selectedId, onSelect: handleSelect, docs,
    semLocalizacaoCount: semLocalizacaoDocs.length,
  };

  function renderContent() {
    if (locationLevels.length === 0) {
      return (
        <EmptyState
          title="Nenhuma hierarquia configurada"
          description="Configure os níveis e localizações em Configurações → Localização Física."
        />
      );
    }
    if (isSemLocalizacao) {
      return (
        <DataTable
          columns={columns}
          data={directDocs}
          onRowClick={(row) => router.push(`/documentos/${row.id}`)}
          emptyState={<EmptyState title="Nenhum documento" description="Sem documentos sem localização física." />}
        />
      );
    }
    if (!selectedTree) {
      return <SubfolderGrid nodes={tree} docs={docs} onSelect={(id) => handleSelect(id)} />;
    }
    return (
      <div className="space-y-5">
        <SubfolderGrid nodes={selectedTree.children} docs={docs} onSelect={(id) => handleSelect(id)} />
        <DataTable
          columns={columns}
          data={directDocs}
          onRowClick={(row) => router.push(`/documentos/${row.id}`)}
          emptyState={<EmptyState title="Nenhum documento" description="Sem documentos diretamente nesta localização." />}
        />
      </div>
    );
  }

  return (
    <PermissionGuard required="files.manage">
    <div className="-m-6 flex overflow-hidden" style={{ height: 'calc(100vh - 56px)' }}>
      <aside className="hidden w-70 shrink-0 flex-col border-r border-slate-200 bg-white lg:flex">
        <SidebarContent {...sidebarProps} />
      </aside>

      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="w-70 p-0">
          <SidebarContent {...sidebarProps} onClose={() => setSidebarOpen(false)} />
        </SheetContent>
      </Sheet>

      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <div className="flex items-center gap-3 border-b border-slate-200 bg-white px-4 py-3 lg:hidden">
          <button
            onClick={() => setSidebarOpen(true)}
            className="flex h-8 w-8 items-center justify-center rounded-md border border-slate-200 text-slate-500 hover:bg-slate-50"
          >
            <Menu className="h-4 w-4" />
          </button>
          <span className="truncate text-sm font-semibold text-slate-700">{panelLabel}</span>
        </div>

        <div className="flex-1 overflow-y-auto">
          <div className="mx-auto max-w-screen-2xl space-y-5 p-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="space-y-1">
                <BreadcrumbNav path={breadcrumbPath} onNavigate={handleSelect} isSemLocalizacao={isSemLocalizacao} />
                <div className="flex items-center gap-2">
                  <h1 className="text-lg font-semibold text-slate-900">{panelLabel}</h1>
                  <span className="text-xs text-slate-400">
                    ({panelCount} {panelCount === 1 ? 'documento' : 'documentos'})
                  </span>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-xs"
                onClick={() => { useDocumentsStore.setState({ loaded: false }); loadDocs(); setSelectedId(null); }}
              >
                Atualizar
              </Button>
            </div>

            {renderContent()}
          </div>
        </div>
      </div>
    </div>
    </PermissionGuard>
  );
}
