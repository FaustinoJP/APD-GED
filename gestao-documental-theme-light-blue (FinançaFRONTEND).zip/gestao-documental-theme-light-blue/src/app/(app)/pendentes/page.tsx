﻿'use client';

import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { format, parseISO, isPast } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Clock } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { PageHeader } from '@/components/common/page-header';
import { DataTable } from '@/components/common/data-table';
import { StatusBadge } from '@/components/common/status-badge';
import { EmptyState } from '@/components/common/empty-state';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { useCirculationStore } from '@/store/circulation-store';
import { useDocumentsStore } from '@/store/documents-store';
import { useConfigStore } from '@/store/config-store';
import { useAuthStore } from '@/store/auth-store';
import { cn } from '@/lib/utils';
import type { ColumnDef } from '@/components/common/data-table';
import type { AcaoCirculacao, Circulation } from '@/types';

const ACAO_LABEL: Record<AcaoCirculacao, string> = {
  aprovar:            'Aprovar',
  assinar:            'Assinar',
  parecer:            'Parecer',
  despachar:          'Despachar',
  deferir:            'Deferir',
  verificar:          'Verificar',
  encaminhar_interno: 'Encaminhar',
  encaminhar_externo: 'Para exterior',
};

const ACAO_COLOR: Record<AcaoCirculacao, string> = {
  aprovar:            'border-emerald-300 bg-emerald-50 text-emerald-700',
  assinar:            'border-sky-300  bg-sky-50  text-sky-700',
  parecer:            'border-blue-300    bg-blue-50    text-blue-700',
  despachar:          'border-violet-300  bg-violet-50  text-violet-700',
  deferir:            'border-teal-300    bg-teal-50    text-teal-700',
  verificar:          'border-amber-300   bg-amber-50   text-amber-700',
  encaminhar_interno: 'border-slate-300   bg-slate-50   text-slate-600',
  encaminhar_externo: 'border-orange-300  bg-orange-50  text-orange-700',
};

interface PendingRow {
  circ: Circulation;
  nr: number;
  docNumero: string;
  docTipo: string;
  docAssunto: string;
  docEstado: string;
  deNome: string;
  paraNomes: string;
  dataLimite?: string;
  isOverdue: boolean;
}

export default function PendentesPage() {
  const router = useRouter();
  const currentUser = useAuthStore((s) => s.currentUser);
  const { pendingCirculations, loaded, loadPending } = useCirculationStore();
  const { documents, load: loadDocs, loaded: docsLoaded } = useDocumentsStore();
  const { users, entities, documentTypes, loaded: configLoaded, loadAll } = useConfigStore();
  const [query, setQuery] = useState('');

  useEffect(() => {
    if (!configLoaded) loadAll();
    if (!docsLoaded) loadDocs();
    if (!loaded && currentUser) loadPending(currentUser.id);
  }, [configLoaded, loadAll, docsLoaded, loadDocs, loaded, loadPending, currentUser]);

  function refresh() {
    if (currentUser) loadPending(currentUser.id);
  }

  function resolveUserName(id: string) {
    return users.find((u) => u.id === id)?.nome ?? entities.find((e) => e.id === id)?.nome ?? id;
  }

  const rows = useMemo<PendingRow[]>(() => {
    return pendingCirculations
      .map((circ, i) => {
        const doc = documents.find((d) => d.id === circ.documentId);
        const docType = documentTypes.find((dt) => dt.id === doc?.tipoDocumentoId);
        const paraNomes = circ.paraDestinatarios
          .map((d) => resolveUserName(d.id))
          .join(', ');
        const overdue = !!circ.dataLimite && isPast(parseISO(circ.dataLimite));
        return {
          circ,
          nr: i + 1,
          docNumero: doc?.numero ?? circ.documentId,
          docTipo: docType?.nome ?? '—',
          docAssunto: doc?.assunto ?? '—',
          docEstado: doc?.estado ?? '—',
          deNome: resolveUserName(circ.deUserId),
          paraNomes,
          dataLimite: circ.dataLimite,
          isOverdue: overdue,
        };
      })
      .filter((r) => {
        if (!query) return true;
        const q = query.toLowerCase();
        return (
          r.docNumero.toLowerCase().includes(q) ||
          r.docAssunto.toLowerCase().includes(q) ||
          r.docTipo.toLowerCase().includes(q) ||
          r.deNome.toLowerCase().includes(q) ||
          r.paraNomes.toLowerCase().includes(q)
        );
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingCirculations, documents, documentTypes, users, entities, query]);

  const columns = useMemo<ColumnDef<PendingRow>[]>(() => [
    {
      id:'nr',
      header: 'Nr.',
      cell: (r) => <span className="text-xs text-slate-400">{r.nr}</span>,
      width: '48px',
    },
    {
      id:'docNumero',
      header: 'Nº Documento',
      cell: (r) => (
        <span className="font-semibold text-sm text-slate-800">{r.docNumero}</span>
      ),
    },
    {
      id:'docTipo',
      header: 'Tipo de Documento',
      cell: (r) => <span className="text-sm text-slate-600">{r.docTipo}</span>,
    },
    {
      id:'docAssunto',
      header: 'Assunto',
      cell: (r) => (
        <span className="text-sm text-slate-700 max-w-[200px] truncate block">{r.docAssunto}</span>
      ),
    },
    {
      id:'acao',
      header: 'Tipo de Circulação',
      cell: (r) => (
        <Badge
          variant="outline"
          className={cn('text-xs font-semibold uppercase', ACAO_COLOR[r.circ.acao])}
        >
          {ACAO_LABEL[r.circ.acao]}
        </Badge>
      ),
    },
    {
      id:'dataLimite',
      header: 'Prazo',
      cell: (r) =>
        r.dataLimite ? (
          <span
            className={cn(
              'text-xs font-medium',
              r.isOverdue ? 'text-red-600' : 'text-slate-600',
            )}
          >
            {format(parseISO(r.dataLimite), 'dd/MM/yyyy', { locale: ptBR })}
            {r.isOverdue && (
              <span className="ml-1 rounded bg-red-100 px-1 py-0.5 text-[10px] text-red-700">
                Vencido
              </span>
            )}
          </span>
        ) : (
          <span className="text-xs text-slate-400">—</span>
        ),
    },
    {
      id:'deNome',
      header: 'De',
      cell: (r) => <span className="text-sm text-slate-600">{r.deNome}</span>,
    },
    {
      id:'paraNomes',
      header: 'Para',
      cell: (r) => (
        <span className="text-sm text-slate-600 max-w-[140px] truncate block">
          {r.paraNomes}
        </span>
      ),
    },
    {
      id:'docEstado',
      header: 'Estado',
      cell: (r) => <StatusBadge status={r.docEstado as never} />,
    },
  ], []);

  return (
    <PermissionGuard required="documents.read">
      <div className="p-6 space-y-5">
        <PageHeader
          title="Documentos Pendentes"
          description="Acções de circulação que aguardam a sua resposta."
          onRefresh={refresh}
        />

        {/* Search */}
        <div className="flex items-center gap-3">
          <input
            type="search"
            placeholder="Pesquisar por número, assunto, tipo ou remetente..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="h-9 w-full max-w-sm rounded-md border border-input bg-white px-3 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1"
          />
          {rows.length > 0 && (
            <Badge className="bg-amber-500 text-white gap-1">
              <Clock className="h-3 w-3" />
              {rows.length} pendente{rows.length > 1 ? 's' : ''}
            </Badge>
          )}
        </div>

        {!loaded ? (
          <div className="flex h-40 items-center justify-center">
            <div className="h-6 w-6 animate-spin rounded-full border-2 border-sky-600 border-t-transparent" />
          </div>
        ) : rows.length === 0 ? (
          <EmptyState
            title="Sem pendências"
            description={
              query
                ? 'Nenhuma circulação encontrada para a pesquisa.'
                : 'Não tem acções pendentes de circulação neste momento.'
            }
          />
        ) : (
          <DataTable
            data={rows}
            columns={columns}
            onRowClick={(row) => {
              router.push(`/documentos/${row.circ.documentId}#circulacoes`);
            }}
            rowClassName={(row) => (row.isOverdue ? 'bg-red-50/50 hover:bg-red-50' : '')}
          />
        )}
      </div>
    </PermissionGuard>
  );
}
