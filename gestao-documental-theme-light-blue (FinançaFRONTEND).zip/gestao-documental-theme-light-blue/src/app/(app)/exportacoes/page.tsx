'use client';

import { useMemo, useState } from 'react';
import {
  format, subDays, startOfMonth, startOfYear, parseISO,
  isAfter, isBefore, endOfDay,
} from 'date-fns';
import { Eye, FileJson, FileSpreadsheet, FileText, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { PageHeader } from '@/components/common/page-header';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { ANGOLA_PROVINCES, findProvince } from '@/components/common/province-select';
import { useAuthStore } from '@/store/auth-store';
import {
  documentsRepo, circulationsRepo, auditRepo, entitiesRepo,
  documentTypesRepo, usersRepo,
} from '@/lib/db';
import type { DocumentRecord, EstadoDocumento, TipoRegistro } from '@/types';
import {
  buildAnexosWorkbook, buildSimpleWorkbook, downloadArrayBuffer,
  type AnexosExportMeta,
} from '@/lib/xlsx-export';
import {
  buildDocumentsZip, countDownloadableAnexos, downloadZipBlob,
  normalizeExt, ensureFileName,
} from '@/lib/zip-export';
import { IncluirFicheirosDialog } from '@/components/exportacoes/incluir-ficheiros-dialog';

type Recurso = 'documentos' | 'circulacoes' | 'auditoria' | 'entidades' | 'anexos';
type Escopo = 'utilizador' | 'generico' | 'sistema';
type Preset = 'hoje' | 'semana' | 'mes' | 'ano' | 'personalizado';

const RECURSO_LABEL: Record<Recurso, string> = {
  documentos: 'Documentos',
  circulacoes: 'Circulações',
  auditoria: 'Auditoria',
  entidades: 'Entidades',
  anexos: 'Anexos',
};

const ESTADO_LABEL: Record<EstadoDocumento, string> = {
  novo: 'Novo',
  em_circulacao: 'Em circulação',
  aprovado: 'Aprovado',
  rejeitado: 'Rejeitado',
  deferido: 'Deferido',
  arquivado: 'Arquivado',
  concluido: 'Concluído',
};

const DIRECAO_LABEL: Record<TipoRegistro, string> = {
  entrada: 'IN',
  saida: 'OUT',
  interno: 'INT',
};

const ESCOPO_LABEL: Record<Escopo, string> = {
  utilizador: 'Por utilizador',
  generico: 'Genérico',
  sistema: 'Sistema todo',
};

const PRESETS: { id: Preset; label: string }[] = [
  { id: 'hoje', label: 'Hoje' },
  { id: 'semana', label: 'Semana' },
  { id: 'mes', label: 'Mês' },
  { id: 'ano', label: 'Ano' },
  { id: 'personalizado', label: 'Personalizado' },
];

function getDateRange(
  preset: Preset,
  customFrom: string,
  customTo: string,
): { from: Date; to: Date } {
  const now = new Date();
  const to = endOfDay(now);
  switch (preset) {
    case 'hoje':
      return { from: new Date(now.getFullYear(), now.getMonth(), now.getDate()), to };
    case 'semana':
      return { from: subDays(now, 7), to };
    case 'mes':
      return { from: startOfMonth(now), to };
    case 'ano':
      return { from: startOfYear(now), to };
    case 'personalizado': {
      const from = customFrom ? parseISO(customFrom) : subDays(now, 30);
      const toCustom = customTo ? endOfDay(parseISO(customTo)) : to;
      return { from, to: toCustom };
    }
  }
}

function inRange(dateStr: string, from: Date, to: Date): boolean {
  try {
    const d = parseISO(dateStr);
    return !isBefore(d, from) && !isAfter(d, to);
  } catch {
    return false;
  }
}

function toCSV(rows: Record<string, unknown>[]): string {
  if (!rows.length) return '';
  const headers = Object.keys(rows[0]);
  const esc = (v: unknown): string => {
    const s = v == null ? '' : String(v);
    return s.includes(',') || s.includes('"') || s.includes('\n')
      ? `"${s.replace(/"/g, '""')}"`
      : s;
  };
  const lines = [headers.join(','), ...rows.map(r => headers.map(h => esc(r[h])).join(','))];
  return '﻿' + lines.join('\n');
}

function downloadBlob(content: string, filename: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function ExportacoesContent() {
  const currentUser = useAuthStore(s => s.currentUser)!;
  const currentRole = useAuthStore(s => s.currentRole);
  const isAdmin = currentRole?.permissions.includes('config.users.manage') ?? false;

  const users = useMemo(() => usersRepo.list(), []);

  const [recurso, setRecurso] = useState<Recurso>('documentos');
  const [escopo, setEscopo] = useState<Escopo>('generico');
  const [selectedUserId, setSelectedUserId] = useState(currentUser.id);
  const [regiao, setRegiao] = useState('');
  const [localizacao, setLocalizacao] = useState('');
  const [preset, setPreset] = useState<Preset>('mes');
  const [customFrom, setCustomFrom] = useState('');
  const [customTo, setCustomTo] = useState('');
  const [preview, setPreview] = useState<Record<string, unknown>[] | null>(null);
  const [allRows, setAllRows] = useState<Record<string, unknown>[]>([]);
  // Documentos (com anexos já filtrados) correspondentes à pré-visualização —
  // usados para empacotar os ficheiros anexos num ZIP.
  const [docsForZip, setDocsForZip] = useState<DocumentRecord[]>([]);
  const [zipDialogOpen, setZipDialogOpen] = useState(false);
  const [zipLoading, setZipLoading] = useState(false);

  // Admins podem exportar por qualquer utilizador; os restantes ficam no próprio.
  const userId = isAdmin ? selectedUserId : currentUser.id;

  function buildRows(): Record<string, unknown>[] {
    const { from, to } = getDateRange(preset, customFrom, customTo);
    const effectiveEscopo = escopo === 'sistema' && !isAdmin ? 'utilizador' : escopo;

    // Resolve um id de utilizador para "Nome · email" (ou o próprio id se desconhecido).
    const resolveUser = (id?: string): string => {
      if (!id) return '';
      const u = usersRepo.getById(id);
      return u ? (u.email || u.nome) : id;
    };

    if (recurso === 'documentos') {
      let docs = documentsRepo.list();
      if (effectiveEscopo === 'utilizador') {
        docs = docs.filter(
          d => d.criadoPor === userId ||
               d.destinatarios.some(dest => dest.id === userId),
        );
      } else if (effectiveEscopo === 'generico') {
        docs = docs.filter(d => !d.confidencial);
      }
      if (regiao === '__outros__') {
        docs = docs.filter(d => d.regiao && !findProvince(ANGOLA_PROVINCES, d.regiao));
      } else if (regiao) {
        docs = docs.filter(d => !!d.regiao && findProvince(ANGOLA_PROVINCES, d.regiao) === regiao);
      }
      if (localizacao) docs = docs.filter(d => d.localizacao?.toLowerCase().includes(localizacao.toLowerCase()));
      docs = docs.filter(d => inRange(d.criadoEm, from, to));
      return docs.map(d => ({
        numero: d.numero,
        tipo_registro: d.tipoRegistro,
        assunto: d.assunto,
        data: d.data,
        estado: d.estado,
        confidencial: d.confidencial ? 'Sim' : 'Não',
        regiao: d.regiao ?? '',
        localizacao: d.localizacao ?? '',
        criado_por: resolveUser(d.criadoPor),
        atualizado_por: resolveUser(d.criadoPor),
        criado_em: d.criadoEm,
        atualizado_em: d.atualizadoEm,
      }));
    }

    if (recurso === 'circulacoes') {
      let circs = circulationsRepo.list();
      if (effectiveEscopo === 'utilizador') {
        circs = circs.filter(
          c => c.deUserId === userId ||
               c.paraDestinatarios.some(d => d.id === userId),
        );
      }
      circs = circs.filter(c => inRange(c.criadoEm, from, to));
      return circs.map(c => ({
        id: c.id,
        documento_id: c.documentId,
        acao: c.acao,
        status: c.status,
        data_limite: c.dataLimite ?? '',
        num_respostas: c.respostas.length,
        criado_por: resolveUser(c.deUserId),
        atualizado_por: resolveUser(c.deUserId),
        criado_em: c.criadoEm,
      }));
    }

    if (recurso === 'auditoria') {
      let logs = auditRepo.list();
      if (effectiveEscopo !== 'sistema') {
        logs = logs.filter(l => l.userId === userId);
      }
      logs = logs.filter(l => inRange(l.data, from, to));
      return logs.map(l => ({
        evento: l.evento,
        tabela: l.tabela,
        registro_id: l.registroId ?? '',
        usuario_id: l.userId,
        criado_por: resolveUser(l.userId),
        atualizado_por: resolveUser(l.userId),
        ip: l.ip,
        data: l.data,
        detalhe: l.detalhe ?? '',
      }));
    }

    if (recurso === 'entidades') {
      let entities = entitiesRepo.list();
      if (regiao === '__outros__') {
        entities = entities.filter(e => e.regiao && !findProvince(ANGOLA_PROVINCES, e.regiao));
      } else if (regiao) {
        entities = entities.filter(e => !!e.regiao && findProvince(ANGOLA_PROVINCES, e.regiao) === regiao);
      }
      if (localizacao) entities = entities.filter(e => e.localizacao?.toLowerCase().includes(localizacao.toLowerCase()));
      entities = entities.filter(e => inRange(e.criadoEm, from, to));
      return entities.map(e => ({
        nome: e.nome,
        tipo: e.tipo,
        email: e.email ?? '',
        telefone: e.telefone ?? '',
        regiao: e.regiao ?? '',
        localizacao: e.localizacao ?? '',
        criado_por: '',
        atualizado_por: '',
        criado_em: e.criadoEm,
      }));
    }

    if (recurso === 'anexos') {
      let docs = documentsRepo.list();
      if (effectiveEscopo === 'generico') {
        docs = docs.filter(d => !d.confidencial);
      }
      if (regiao === '__outros__') {
        docs = docs.filter(d => d.regiao && !findProvince(ANGOLA_PROVINCES, d.regiao));
      } else if (regiao) {
        docs = docs.filter(d => !!d.regiao && findProvince(ANGOLA_PROVINCES, d.regiao) === regiao);
      }
      if (localizacao) docs = docs.filter(d => d.localizacao?.toLowerCase().includes(localizacao.toLowerCase()));

      const categoriaDe = (id: string) => documentTypesRepo.getById(id)?.nome ?? '—';

      const rows: Record<string, unknown>[] = [];
      let seq = 0;
      for (const d of docs) {
        const categoria = categoriaDe(d.tipoDocumentoId);
        for (const a of d.anexos) {
          if (effectiveEscopo === 'utilizador' && a.adicionadoPor !== userId) continue;
          if (!inRange(a.criadoEm, from, to)) continue;
          const ext = normalizeExt(a.formato, a.nome);
          const ficheiro = ensureFileName(a.nome, ext);
          const ano = String(new Date(a.criadoEm).getFullYear());
          const criadoPor = resolveUser(a.adicionadoPor);
          seq += 1;
          rows.push({
            id: seq,
            nome: a.nome,
            tamanho_bytes: a.tamanho,
            tamanho_mb: a.tamanho / 1048576,
            versao: a.versao,
            extensao: ext,
            tipo_direcao: DIRECAO_LABEL[d.tipoRegistro] ?? d.tipoRegistro,
            estado: ESTADO_LABEL[d.estado] ?? d.estado,
            criado_por: criadoPor,
            atualizado_por: criadoPor,
            caminho: a.url ?? `uploads/registos/documentos/${categoria}/${ano}/${d.numero}/${ficheiro}`,
            categoria,
            ano,
            pasta_registo: d.numero,
            ficheiro,
          });
        }
      }
      return rows;
    }

    return [];
  }

  /**
   * Documentos correspondentes à exportação atual, com os anexos já reduzidos
   * ao subconjunto que passou nos filtros. Só relevante para `documentos`/`anexos`.
   */
  function collectDocsForZip(): DocumentRecord[] {
    if (recurso !== 'documentos' && recurso !== 'anexos') return [];
    const { from, to } = getDateRange(preset, customFrom, customTo);
    const effectiveEscopo = escopo === 'sistema' && !isAdmin ? 'utilizador' : escopo;

    const bySegmento = (d: DocumentRecord): boolean => {
      if (regiao === '__outros__') {
        if (!(d.regiao && !findProvince(ANGOLA_PROVINCES, d.regiao))) return false;
      } else if (regiao) {
        if (!(d.regiao && findProvince(ANGOLA_PROVINCES, d.regiao) === regiao)) return false;
      }
      if (localizacao && !d.localizacao?.toLowerCase().includes(localizacao.toLowerCase())) {
        return false;
      }
      return true;
    };

    let docs = documentsRepo.list().filter(bySegmento);

    if (recurso === 'documentos') {
      if (effectiveEscopo === 'utilizador') {
        docs = docs.filter(
          d => d.criadoPor === userId || d.destinatarios.some(dest => dest.id === userId),
        );
      } else if (effectiveEscopo === 'generico') {
        docs = docs.filter(d => !d.confidencial);
      }
      docs = docs.filter(d => inRange(d.criadoEm, from, to));
      return docs.filter(d => d.anexos?.length);
    }

    // recurso === 'anexos' — reduz cada documento aos anexos filtrados.
    if (effectiveEscopo === 'generico') docs = docs.filter(d => !d.confidencial);
    return docs
      .map(d => ({
        ...d,
        anexos: d.anexos.filter(
          a => (effectiveEscopo !== 'utilizador' || a.adicionadoPor === userId) &&
               inRange(a.criadoEm, from, to),
        ),
      }))
      .filter(d => d.anexos.length);
  }

  function handlePreview() {
    const rows = buildRows();
    setAllRows(rows);
    setPreview(rows.slice(0, 50));
    setDocsForZip(collectDocsForZip());
    if (!rows.length) {
      toast.info('Nenhum registo encontrado com os filtros aplicados.');
    } else {
      toast.success(`${rows.length} registo(s) encontrado(s).`);
    }
  }

  function logExport(fmt: 'csv' | 'json' | 'xlsx' | 'xlsx+zip') {
    auditRepo.create({
      evento: 'exportado',
      tabela: recurso,
      userId: currentUser.id,
      ip: '127.0.0.1',
      data: new Date().toISOString(),
      detalhe: JSON.stringify({
        recurso, escopo, preset,
        utilizador: escopo === 'utilizador' ? userId : undefined,
        regiao: regiao === '__outros__' ? 'outros' : (regiao || undefined),
        localizacao: localizacao || undefined,
        formato: fmt,
        total: allRows.length,
      }),
    });
  }

  function periodoLabel(): string {
    const base = PRESETS.find(p => p.id === preset)?.label ?? preset;
    if (preset === 'personalizado') {
      return `${customFrom || '…'} a ${customTo || '…'}`;
    }
    return base;
  }

  function handleDownloadCSV() {
    if (!allRows.length) { toast.error('Gere uma pré-visualização primeiro.'); return; }
    const filename = `${recurso}_${format(new Date(), 'yyyyMMdd_HHmm')}.csv`;
    downloadBlob(toCSV(allRows), filename, 'text/csv;charset=utf-8;');
    logExport('csv');
    toast.success(`Ficheiro ${filename} transferido.`);
  }

  function handleDownloadJSON() {
    if (!allRows.length) { toast.error('Gere uma pré-visualização primeiro.'); return; }
    const filename = `${recurso}_${format(new Date(), 'yyyyMMdd_HHmm')}.json`;
    downloadBlob(JSON.stringify(allRows, null, 2), filename, 'application/json');
    logExport('json');
    toast.success(`Ficheiro ${filename} transferido.`);
  }

  /** Gera o buffer do Excel + o nome-base do ficheiro (sem extensão de container). */
  async function generateXlsxBuffer(): Promise<{ buffer: ArrayBuffer; baseName: string }> {
    const stamp = format(new Date(), 'yyyyMMdd_HHmm');
    if (recurso === 'anexos') {
      const effectiveEscopo = escopo === 'sistema' && !isAdmin ? 'utilizador' : escopo;
      const selectedUser = users.find(u => u.id === userId);
      const meta: AnexosExportMeta = {
        fonte: `Fonte: Gestão Documental | Registos exportados: ${allRows.length}`,
        escopoLabel: ESCOPO_LABEL[effectiveEscopo],
        utilizadorLabel: effectiveEscopo === 'utilizador'
          ? (selectedUser ? `${selectedUser.nome} (${selectedUser.email})` : userId)
          : undefined,
        regiaoLabel: regiao === '__outros__' ? 'Outros (não provinciais)' : (regiao || undefined),
        localizacaoLabel: localizacao || undefined,
        periodoLabel: periodoLabel(),
      };
      return { buffer: await buildAnexosWorkbook(allRows, meta), baseName: `anexos_organizado_${stamp}` };
    }
    return {
      buffer: await buildSimpleWorkbook(allRows, RECURSO_LABEL[recurso]),
      baseName: `${recurso}_${stamp}`,
    };
  }

  /** Descarrega apenas a planilha Excel. */
  async function downloadExcelOnly() {
    try {
      const { buffer, baseName } = await generateXlsxBuffer();
      downloadArrayBuffer(buffer, `${baseName}.xlsx`);
      logExport('xlsx');
      toast.success(`Ficheiro ${baseName}.xlsx transferido.`);
    } catch (err) {
      console.error(err);
      toast.error('Falha ao gerar o ficheiro Excel.');
    }
  }

  /** Descarrega um ZIP com a planilha Excel + os ficheiros anexos. */
  async function downloadExcelWithFiles() {
    setZipLoading(true);
    try {
      const { buffer, baseName } = await generateXlsxBuffer();
      const { blob, missing, included } = await buildDocumentsZip(docsForZip, buffer, {
        xlsxFileName: `${baseName}.xlsx`,
      });
      downloadZipBlob(blob, `${baseName}.zip`);
      logExport('xlsx+zip');
      if (missing.length) {
        toast.warning(
          `${baseName}.zip transferido com ${included} ficheiro(s). ${missing.length} indisponível(is) e não incluído(s).`,
        );
      } else {
        toast.success(`${baseName}.zip transferido com ${included} ficheiro(s).`);
      }
    } catch (err) {
      console.error(err);
      toast.error('Falha ao gerar o ficheiro ZIP.');
    } finally {
      setZipLoading(false);
      setZipDialogOpen(false);
    }
  }

  function handleDownloadXLSX() {
    if (!allRows.length) { toast.error('Gere uma pré-visualização primeiro.'); return; }
    // Recursos com ficheiros anexos → oferecer o download conjunto (ZIP).
    if ((recurso === 'documentos' || recurso === 'anexos') &&
        countDownloadableAnexos(docsForZip).count > 0) {
      setZipDialogOpen(true);
      return;
    }
    void downloadExcelOnly();
  }

  const previewCols = preview && preview.length > 0 ? Object.keys(preview[0]) : [];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Exportações"
        description="Exporte dados do sistema para CSV ou JSON."
      />

      {/* Filter card */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-5">
        <p className="text-sm font-semibold text-slate-700">Filtros de exportação</p>

        {/* Recurso + Escopo */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label className="text-xs font-medium">Recurso</Label>
            <Select
              value={recurso}
              onValueChange={v => { setRecurso(v as Recurso); setPreview(null); }}
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {(Object.keys(RECURSO_LABEL) as Recurso[]).map(r => (
                  <SelectItem key={r} value={r}>{RECURSO_LABEL[r]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-medium">Escopo</Label>
            <Select
              value={escopo}
              onValueChange={v => { setEscopo(v as Escopo); setPreview(null); }}
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {(Object.keys(ESCOPO_LABEL) as Escopo[]).map(e => (
                  <SelectItem key={e} value={e}>{ESCOPO_LABEL[e]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Utilizador — apenas no escopo "Por utilizador" */}
        {escopo === 'utilizador' && (
          <div className="space-y-1.5 sm:max-w-md">
            <Label className="text-xs font-medium">Utilizador</Label>
            {isAdmin ? (
              <Select
                value={userId}
                onValueChange={v => { setSelectedUserId(v); setPreview(null); }}
              >
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {users.map(u => (
                    <SelectItem key={u.id} value={u.id}>
                      {u.nome}{u.email ? ` · ${u.email}` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <Input value={`${currentUser.nome}${currentUser.email ? ` · ${currentUser.email}` : ''}`} disabled />
            )}
            {!isAdmin && (
              <p className="text-xs text-slate-400">
                Apenas administradores podem exportar dados de outros utilizadores.
              </p>
            )}
          </div>
        )}

        {/* Segmentação — only for docs / entities / anexos */}
        {(recurso === 'documentos' || recurso === 'entidades' || recurso === 'anexos') && (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Região</Label>
              <Select
                value={regiao || '__all__'}
                onValueChange={v => { setRegiao(v === '__all__' ? '' : v); setPreview(null); }}
              >
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Todas as regiões" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__all__">Todas as regiões</SelectItem>
                  {ANGOLA_PROVINCES.map((p) => (
                    <SelectItem key={p} value={p}>{p}</SelectItem>
                  ))}
                  <SelectItem value="__outros__">Outros (não provinciais)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Localização</Label>
              <Input
                value={localizacao}
                onChange={e => { setLocalizacao(e.target.value); setPreview(null); }}
                placeholder="Ex: Sede"
              />
            </div>
          </div>
        )}

        {/* Period presets */}
        <div className="space-y-2">
          <Label className="text-xs font-medium">Período</Label>
          <div className="flex flex-wrap gap-2">
            {PRESETS.map(p => (
              <button
                key={p.id}
                type="button"
                onClick={() => { setPreset(p.id); setPreview(null); }}
                className={`rounded-lg px-3 py-1.5 text-xs font-medium border transition-colors ${
                  preset === p.id
                    ? 'bg-sky-600 text-white border-sky-600'
                    : 'bg-white text-slate-600 border-slate-200 hover:border-sky-300 hover:text-sky-600'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
          {preset === 'personalizado' && (
            <div className="grid grid-cols-2 gap-4 mt-2">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">De</Label>
                <Input type="date" value={customFrom} onChange={e => setCustomFrom(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium">Até</Label>
                <Input type="date" value={customTo} onChange={e => setCustomTo(e.target.value)} />
              </div>
            </div>
          )}
        </div>

        {escopo === 'sistema' && !isAdmin && (
          <div className="flex items-start gap-2 rounded-lg bg-amber-50 border border-amber-200 px-3 py-2 text-xs text-amber-700">
            <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
            <span>
              O escopo &ldquo;Sistema todo&rdquo; requer permissões de administrador.
              O resultado será limitado ao seu utilizador.
            </span>
          </div>
        )}

        <Button onClick={handlePreview} className="gap-2">
          <Eye className="h-4 w-4" />
          Pré-visualizar
        </Button>
      </div>

      {/* Preview */}
      {preview !== null && (
        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
            <div>
              <p className="text-sm font-semibold text-slate-700">
                Pré-visualização — {RECURSO_LABEL[recurso]}
              </p>
              <p className="text-xs text-slate-500 mt-0.5">
                {allRows.length} registo(s) encontrado(s)
                {allRows.length > 50 && ' · mostrando primeiros 50'}
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleDownloadXLSX}
                disabled={!allRows.length}
                className="gap-1.5"
              >
                <FileSpreadsheet className="h-4 w-4" />
                Excel
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleDownloadCSV}
                disabled={!allRows.length}
                className="gap-1.5"
              >
                <FileText className="h-4 w-4" />
                CSV
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleDownloadJSON}
                disabled={!allRows.length}
                className="gap-1.5"
              >
                <FileJson className="h-4 w-4" />
                JSON
              </Button>
            </div>
          </div>

          {preview.length === 0 ? (
            <div className="px-6 py-12 text-center text-sm text-slate-400">
              Nenhum registo encontrado com os filtros aplicados.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-100">
                    {previewCols.map(col => (
                      <th
                        key={col}
                        className="px-4 py-2.5 text-left font-semibold text-slate-600 whitespace-nowrap"
                      >
                        {col.replace(/_/g, ' ')}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {preview.map((row, i) => (
                    <tr key={i} className="border-b border-slate-50 hover:bg-slate-50/50">
                      {previewCols.map(col => (
                        <td
                          key={col}
                          className="px-4 py-2 text-slate-700 max-w-[200px] truncate"
                          title={row[col] == null ? '' : String(row[col])}
                        >
                          {row[col] == null ? '—' : String(row[col])}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      <IncluirFicheirosDialog
        open={zipDialogOpen}
        onOpenChange={setZipDialogOpen}
        count={countDownloadableAnexos(docsForZip).count}
        bytes={countDownloadableAnexos(docsForZip).bytes}
        loading={zipLoading}
        onlyExcel={() => { setZipDialogOpen(false); void downloadExcelOnly(); }}
        withFiles={() => { void downloadExcelWithFiles(); }}
      />
    </div>
  );
}

export default function ExportacoesPage() {
  return (
    <PermissionGuard required="exports.run">
      <ExportacoesContent />
    </PermissionGuard>
  );
}
