﻿'use client';

import { useEffect, useMemo, useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { format, parseISO, isWithinInterval } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  FileText,
  Lock,
  X,
  ChevronRight,
  Download,
  Paperclip,
  Calendar,
  User,
  Archive,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { PageHeader } from '@/components/common/page-header';
import { SearchFilters } from '@/components/common/search-filters';
import { DataTable } from '@/components/common/data-table';
import { StatusBadge } from '@/components/common/status-badge';
import { EmptyState } from '@/components/common/empty-state';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { useDocumentsStore } from '@/store/documents-store';
import { useConfigStore } from '@/store/config-store';
import { useAuthStore } from '@/store/auth-store';
import { hasPermission } from '@/lib/permissions';
import { getLocationLabel } from '@/lib/locations/locationTree';
import type { ColumnDef } from '@/components/common/data-table';
import type { DocumentRecord, LocationNode, Role } from '@/types';
import type { SearchParams } from '@/components/common/search-filters';
import type { AdvancedSearchParams } from '@/components/common/advanced-search-dialog';

// ─── Confidentiality filter ───────────────────────────────────────────────────

function canViewDoc(
  doc: DocumentRecord,
  userId: string | undefined,
  roleId: string | undefined,
  allRoles: Role[],
): boolean {
  if (!doc.confidencial) return true;
  const role = allRoles.find((r) => r.id === roleId);
  if (hasPermission(role ?? null, 'config.permissions.manage')) return true;
  if (doc.criadoPor === userId) return true;
  if (doc.remetenteId === userId) return true;
  if (doc.destinatarios.some((d) => d.tipo === 'user' && d.id === userId)) return true;
  return false;
}

// ─── Preview Panel ────────────────────────────────────────────────────────────

interface PreviewPanelProps {
  doc: DocumentRecord;
  onClose: () => void;
  documentTypes: { id: string; nome: string }[];
  users: { id: string; nome: string }[];
  entities: { id: string; nome: string }[];
  locationNodes: LocationNode[];
}

function DocumentPreviewPanel({
  doc,
  onClose,
  documentTypes,
  users,
  entities,
  locationNodes,
}: PreviewPanelProps) {
  const localizacaoFisicaLabel = getLocationLabel(doc.localizacaoFisicaId, locationNodes);
  const docType = documentTypes.find((d) => d.id === doc.tipoDocumentoId);
  const remetente =
    doc.remetenteTexto ??
    users.find((u) => u.id === doc.remetenteId)?.nome ??
    entities.find((e) => e.id === doc.remetenteId)?.nome ??
    '—';

  function getDestLabel(tipo: string, id: string) {
    if (tipo === 'user') return users.find((u) => u.id === id)?.nome ?? id;
    if (tipo === 'entity') return entities.find((e) => e.id === id)?.nome ?? id;
    return id;
  }

  return (
    <div className="flex h-full flex-col rounded-xl border border-slate-200 bg-white shadow-xs overflow-hidden">
      {/* Header */}
      <div className="flex shrink-0 items-start justify-between gap-3 border-b border-slate-100 bg-slate-50 px-4 py-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="font-semibold text-slate-900 text-sm">{doc.numero}</span>
            {doc.confidencial && (
              <Lock className="h-3 w-3 text-amber-500" aria-label="Confidencial" />
            )}
          </div>
          <StatusBadge status={doc.estado} className="mt-1" />
        </div>
        <Button
          variant="ghost"
          size="icon-xs"
          onClick={onClose}
          aria-label="Fechar pré-visualização"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Assunto */}
        <div>
          <p className="text-xs font-medium text-slate-500 mb-0.5">Assunto</p>
          <p className="text-sm text-slate-800">{doc.assunto}</p>
        </div>

        {/* Meta grid */}
        <dl className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <dt className="flex items-center gap-1 text-xs text-slate-500 mb-0.5">
              <FileText className="h-3 w-3" /> Tipo
            </dt>
            <dd className="text-slate-700 text-xs">{docType?.nome ?? '—'}</dd>
          </div>
          <div>
            <dt className="flex items-center gap-1 text-xs text-slate-500 mb-0.5">
              <Calendar className="h-3 w-3" /> Data
            </dt>
            <dd className="text-slate-700 text-xs">
              {format(parseISO(doc.data), 'dd/MM/yyyy', { locale: ptBR })}
            </dd>
          </div>
          <div className="col-span-2">
            <dt className="flex items-center gap-1 text-xs text-slate-500 mb-0.5">
              <User className="h-3 w-3" /> Remetente
            </dt>
            <dd className="text-slate-700 text-xs">{remetente}</dd>
          </div>
          {localizacaoFisicaLabel && (
            <div className="col-span-2">
              <dt className="flex items-center gap-1 text-xs text-slate-500 mb-0.5">
                <Archive className="h-3 w-3" /> Localização Física
              </dt>
              <dd className="text-slate-700 text-xs">{localizacaoFisicaLabel}</dd>
            </div>
          )}
          <div className="col-span-2">
            <dt className="text-xs text-slate-500 mb-1">Destinatários</dt>
            <dd className="flex flex-wrap gap-1">
              {doc.destinatarios.length === 0 ? (
                <span className="text-xs text-slate-400">—</span>
              ) : (
                doc.destinatarios.slice(0, 4).map((d, i) => (
                  <Badge key={i} variant="secondary" className="text-xs">
                    {getDestLabel(d.tipo, d.id)}
                  </Badge>
                ))
              )}
              {doc.destinatarios.length > 4 && (
                <Badge variant="outline" className="text-xs">
                  +{doc.destinatarios.length - 4}
                </Badge>
              )}
            </dd>
          </div>
        </dl>

        {/* Anexos */}
        {doc.anexos.length > 0 && (
          <div>
            <p className="flex items-center gap-1 text-xs font-medium text-slate-500 mb-1.5">
              <Paperclip className="h-3 w-3" />
              Anexos ({doc.anexos.length})
            </p>
            <ul className="space-y-1">
              {doc.anexos.slice(0, 5).map((att) => (
                <li
                  key={att.id}
                  className="flex items-center gap-2 rounded-md border border-slate-100 px-2 py-1.5 text-xs"
                >
                  <FileText className="h-3 w-3 shrink-0 text-slate-400" />
                  <span className="min-w-0 flex-1 truncate text-slate-700">{att.nome}</span>
                  {att.url && (
                    <a
                      href={att.url}
                      download={att.nome}
                      className="shrink-0 text-slate-400 hover:text-sky-600"
                      title="Descarregar"
                    >
                      <Download className="h-3 w-3" />
                    </a>
                  )}
                </li>
              ))}
              {doc.anexos.length > 5 && (
                <p className="px-2 text-xs text-slate-400">
                  +{doc.anexos.length - 5} mais...
                </p>
              )}
            </ul>
          </div>
        )}
      </div>

      {/* Footer CTA */}
      <div className="shrink-0 border-t border-slate-100 p-3">
        <Button asChild size="sm" className="w-full gap-1.5">
          <Link href={`/documentos/${doc.id}`}>
            Ver Ficha Completa
            <ChevronRight className="h-3.5 w-3.5" />
          </Link>
        </Button>
      </div>
    </div>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────

function DocumentosContent() {
  const docs = useDocumentsStore((s) => s.documents);
  const docsLoaded = useDocumentsStore((s) => s.loaded);
  const docsLoading = useDocumentsStore((s) => s.loading);
  const loadDocs = useDocumentsStore((s) => s.load);

  const {
    documentTypes, users, entities, roles, funcionarios, locationNodes,
    loaded: configLoaded, loadAll,
  } = useConfigStore();
  const currentUser = useAuthStore((s) => s.currentUser);
  const currentRole = useAuthStore((s) => s.currentRole);

  useEffect(() => {
    if (!configLoaded) loadAll();
    if (!docsLoaded) loadDocs();
  }, [configLoaded, loadAll, docsLoaded, loadDocs]);

  // ── Search state ─────────────────────────────────────────────────────────
  const searchParams = useSearchParams();
  const initialEstado = searchParams.get('estado') || '';
  const initialClassificado = searchParams.get('classificado') || '';

  const [searchQuery, setSearchQuery] = useState('');
  const [searchDate, setSearchDate] = useState('');
  const [searchType, setSearchType] = useState('');
  const [searchState, setSearchState] = useState(initialEstado);
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [searchParticipant, setSearchParticipant] = useState('');
  const [classifiedOnly, setClassifiedOnly] = useState(initialClassificado === 'true');

  const initialParams = useMemo(() => {
    return {
      estado: initialEstado as any,
    };
  }, [initialEstado]);

  function handleSearch(params: SearchParams & AdvancedSearchParams) {
    setSearchQuery(params.query ?? '');
    setSearchDate(params.data ?? '');
    setSearchType(params.tipoDocumentoId ?? '');
    setSearchState((params.estado as string) ?? '');
    setDateFrom(params.dataInicial ?? '');
    setDateTo(params.dataFinal ?? '');
    setSearchParticipant(params.participantes ?? '');
    setClassifiedOnly(false);
  }

  // ── Preview state ─────────────────────────────────────────────────────────
  const [previewDoc, setPreviewDoc] = useState<DocumentRecord | null>(null);

  // ── Filtered + confidentiality ─────────────────────────────────────────
  const funcMap = useMemo(
    () => Object.fromEntries(funcionarios.map((f) => [f.id, f])),
    [funcionarios],
  );

  const filteredDocs = useMemo(() => {
    return docs
      .filter((d) =>
        canViewDoc(d, currentUser?.id, currentUser?.roleId, roles),
      )
      .filter((d) => {
        if (!searchQuery) return true;
        const q = searchQuery.toLowerCase();
        const func = d.funcionarioId ? funcMap[d.funcionarioId] : undefined;
        return (
          d.numero.toLowerCase().includes(q) ||
          d.assunto.toLowerCase().includes(q) ||
          (d.remetenteTexto ?? '').toLowerCase().includes(q) ||
          (!!func && `${func.nome} ${func.apelido}`.toLowerCase().includes(q)) ||
          (!!func && func.numeroProcesso.toLowerCase().includes(q))
        );
      })
      .filter((d) => !searchDate || d.data === searchDate)
      .filter((d) => !searchType || d.tipoDocumentoId === searchType)
      .filter((d) => {
        if (classifiedOnly) {
          return d.estado !== 'novo';
        }
        return true;
      })
      .filter((d) => !searchState || d.estado === searchState)
      .filter((d) => {
        if (!dateFrom && !dateTo) return true;
        try {
          const docDate = parseISO(d.data);
          const from = dateFrom ? parseISO(dateFrom) : new Date(0);
          const to = dateTo ? parseISO(dateTo) : new Date(8640000000000000);
          return isWithinInterval(docDate, { start: from, end: to });
        } catch {
          return true;
        }
      })
      .filter((d) => {
        if (!searchParticipant) return true;
        return (
          d.remetenteId === searchParticipant ||
          d.destinatarios.some((dest) => dest.id === searchParticipant)
        );
      });
  }, [
    docs,
    currentUser,
    roles,
    searchQuery,
    searchDate,
    searchType,
    searchState,
    classifiedOnly,
    dateFrom,
    dateTo,
    searchParticipant,
    funcMap,
  ]);

  // ── DataTable columns ────────────────────────────────────────────────────
  const columns = useMemo<ColumnDef<DocumentRecord>[]>(() => {
    return [
      {
        id: 'ord',
        header: 'Nr. Ord',
        width: 72,
        align: 'center',
        cell: (_row) => {
          const idx = filteredDocs.indexOf(_row);
          return (
            <span className="text-xs text-slate-400 font-mono">{idx + 1}</span>
          );
        },
      },
      {
        id: 'numero',
        header: 'Nr. Documento',
        accessor: 'numero',
        sortable: true,
        width: 160,
        cell: (row) => (
          <span className="font-semibold text-sky-700 text-sm">{row.numero}</span>
        ),
      },
      {
        id: 'tipo',
        header: 'Tipo de Documento',
        width: 170,
        cell: (row) => {
          const dt = documentTypes.find((d) => d.id === row.tipoDocumentoId);
          return <span className="text-xs text-slate-600">{dt?.nome ?? '—'}</span>;
        },
      },
      {
        id: 'assunto',
        header: 'Assunto',
        accessor: 'assunto',
        sortable: true,
        cell: (row) => (
          <span
            className="block max-w-[240px] truncate text-sm text-slate-700"
            title={row.assunto}
          >
            {row.assunto}
          </span>
        ),
      },
      {
        id: 'estado',
        header: 'Estado',
        width: 130,
        cell: (row) => <StatusBadge status={row.estado} />,
      },
      {
        id: 'data',
        header: 'Data',
        accessor: 'data',
        sortable: true,
        width: 95,
        cell: (row) => (
          <span className="text-xs text-slate-600">
            {format(parseISO(row.data), 'dd/MM/yyyy', { locale: ptBR })}
          </span>
        ),
      },
      {
        id: 'remetente',
        header: 'Remetente',
        width: 150,
        cell: (row) => {
          const label =
            row.remetenteTexto ??
            users.find((u) => u.id === row.remetenteId)?.nome ??
            '—';
          return (
            <span className="block max-w-[130px] truncate text-xs text-slate-600">
              {label}
            </span>
          );
        },
      },
      {
        id: 'destinatario',
        header: 'Destinatário',
        width: 150,
        cell: (row) => {
          if (row.destinatarios.length === 0)
            return <span className="text-xs text-slate-400">—</span>;
          const first = row.destinatarios[0];
          const label =
            first.tipo === 'user'
              ? users.find((u) => u.id === first.id)?.nome ?? first.id
              : entities.find((e) => e.id === first.id)?.nome ?? first.id;
          return (
            <span className="block max-w-[130px] truncate text-xs text-slate-600">
              {label}
              {row.destinatarios.length > 1 && (
                <span className="ml-1 text-slate-400">+{row.destinatarios.length - 1}</span>
              )}
            </span>
          );
        },
      },
      {
        id: 'confidencial',
        header: '',
        width: 32,
        align: 'center',
        cell: (row) =>
          row.confidencial ? (
            <Lock className="h-3.5 w-3.5 text-amber-500" aria-label="Confidencial" />
          ) : null,
      },
    ];
  }, [documentTypes, users, entities, filteredDocs]);

  const hasPreview = !!previewDoc;

  function handleExport() {
    const csv = [
      ['Número', 'Tipo', 'Assunto', 'Estado', 'Data', 'Remetente'].join(','),
      ...filteredDocs.map((d) =>
        [
          d.numero,
          documentTypes.find((t) => t.id === d.tipoDocumentoId)?.nome ?? '',
          `"${d.assunto.replace(/"/g, '""')}"`,
          d.estado,
          d.data,
          d.remetenteTexto ?? '',
        ].join(','),
      ),
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `documentos_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <PermissionGuard required="documents.read">
      <div className="space-y-6 p-6">
        {/* Header */}
        <PageHeader
          title="Documentos"
          description={`${filteredDocs.length} documento(s) encontrado(s)`}
          onRefresh={() => {
            useDocumentsStore.setState({ loaded: false });
            loadDocs();
          }}
          onExport={handleExport}
        />

        {/* Filters */}
        <SearchFilters
          onSearch={handleSearch}
          documentTypes={documentTypes}
          users={users}
          initialParams={initialParams}
        />

        {/* Split layout */}
        <div
          className={`flex gap-4 transition-all duration-300 ${
            hasPreview ? 'items-start' : ''
          }`}
        >
          {/* DataTable */}
          <div
            className={`min-w-0 flex-1 transition-all duration-300 ${
              hasPreview ? 'max-w-[58%]' : 'w-full'
            }`}
          >
            <DataTable
              columns={columns}
              data={filteredDocs}
              loading={docsLoading}
              defaultPageSize={15}
              compact
              onRowClick={(row) =>
                setPreviewDoc((prev) => (prev?.id === row.id ? null : row))
              }
              rowClassName={(row) =>
                previewDoc?.id === row.id
                  ? 'bg-sky-50 ring-1 ring-inset ring-sky-200'
                  : ''
              }
              emptyState={
                <EmptyState
                  title="Nenhum documento encontrado"
                  description="Ajuste os filtros ou registe um novo documento."
                />
              }
            />
          </div>

          {/* Preview panel */}
          {hasPreview && (
            <div className="w-[42%] shrink-0 sticky top-6 max-h-[calc(100vh-8rem)]">
              <DocumentPreviewPanel
                doc={previewDoc}
                onClose={() => setPreviewDoc(null)}
                documentTypes={documentTypes}
                users={users}
                entities={entities}
                locationNodes={locationNodes}
              />
            </div>
          )}
        </div>
      </div>
    </PermissionGuard>
  );
}

export default function DocumentosPage() {
  return (
    <Suspense fallback={<div className="p-6 text-center text-slate-500">A carregar documentos...</div>}>
      <DocumentosContent />
    </Suspense>
  );
}
