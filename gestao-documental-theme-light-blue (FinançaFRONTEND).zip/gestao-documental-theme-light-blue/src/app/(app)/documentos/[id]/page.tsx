﻿'use client';

import { use, useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  ArrowLeft,
  Calendar,
  Lock,
  MapPin,
  Users,
  Building2,
  MoreVertical,
  Pencil,
  RefreshCcw,
  Send,
  ShieldCheck,
  ClipboardList,
  CheckCircle2,
  PenLine,
  SearchCheck,
  ArrowRightCircle,
  Globe,
  History,
  Clock,
  User,
  Contact,
  LayoutTemplate,
  Printer,
  Archive,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';
import { SectionCard } from '@/components/common/section-card';
import { Timeline } from '@/components/common/timeline';
import { StatusBadge } from '@/components/common/status-badge';
import { EmptyState } from '@/components/common/empty-state';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { Can } from '@/components/auth/can';
import { AttachmentManager } from '@/components/documentos/attachment-manager';
import { StateChangeDialog } from '@/components/documentos/state-change-dialog';
import { ForwardDialog } from '@/components/documentos/forward-dialog';
import { EditDocumentSheet } from '@/components/documentos/edit-document-sheet';
import { OpenedDocsSidebar } from '@/components/documentos/opened-docs-sidebar';
import { DocumentRenderer } from '@/components/documentos/document-renderer';
import { CirculationResponsePanel } from '@/components/circulacao/circulation-response-panel';
import { useDocumentsStore } from '@/store/documents-store';
import { useConfigStore } from '@/store/config-store';
import { useFuncionariosStore } from '@/store/funcionarios-store';
import { useAuthStore } from '@/store/auth-store';
import { useOpenedDocsStore } from '@/store/opened-docs-store';
import { useCirculationStore } from '@/store/circulation-store';
import { auditRepo, circulationsRepo } from '@/lib/db';
import { getLocationLabel } from '@/lib/locations/locationTree';
import type { AcaoCirculacao, AuditLog, Circulation, DocumentTemplate } from '@/types';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface PageProps {
  params: Promise<{ id: string }>;
}

const TIPO_REGISTRO_LABEL: Record<string, string> = {
  entrada: 'Entrada',
  saida: 'Saída',
  interno: 'Interno',
};

export default function DocumentoPage({ params }: PageProps) {
  const { id } = use(params);
  const router = useRouter();

  // ── Stores ──────────────────────────────────────────────────────────────
  const docs = useDocumentsStore((s) => s.documents);
  const docsLoaded = useDocumentsStore((s) => s.loaded);
  const loadDocs = useDocumentsStore((s) => s.load);
  const updateDoc = useDocumentsStore((s) => s.update);

  const {
    documentTypes, users, entities, templates, company, locationNodes,
    loaded: configLoaded, loadAll,
  } = useConfigStore();
  const funcionarios = useFuncionariosStore((s) => s.funcionarios);
  const funcLoaded = useFuncionariosStore((s) => s.loaded);
  const loadFuncionarios = useFuncionariosStore((s) => s.load);
  const addOpened = useOpenedDocsStore((s) => s.add);
  const loadPending = useCirculationStore((s) => s.loadPending);
  const currentUser = useAuthStore((s) => s.currentUser);
  const [circRefresh, setCircRefresh] = useState(0);

  useEffect(() => {
    if (!configLoaded) loadAll();
    if (!docsLoaded) loadDocs();
    if (!funcLoaded) loadFuncionarios();
  }, [configLoaded, loadAll, docsLoaded, loadDocs, funcLoaded, loadFuncionarios]);

  // Register this doc as opened in the session
  useEffect(() => {
    if (id) addOpened(id);
  }, [id, addOpened]);

  // Reactive doc from store (updates after state changes, attachment adds, etc.)
  const doc = useMemo(() => docs.find((d) => d.id === id), [docs, id]);

  // Redirect if not found after load
  useEffect(() => {
    if (docsLoaded && !doc) router.replace('/documentos');
  }, [docsLoaded, doc, router]);

  // ── Dialog state ─────────────────────────────────────────────────────────
  const [stateDialogOpen, setStateDialogOpen] = useState(false);
  const [editDocOpen, setEditDocOpen] = useState(false);
  const [forwardOpen, setForwardOpen] = useState<{
    open: boolean;
    defaultAction?: AcaoCirculacao;
  }>({ open: false });
  const [templateDialogOpen, setTemplateDialogOpen] = useState<false | 'preview' | 'print'>(false);

  // ── Template lookup ──────────────────────────────────────────────────────
  const docTemplate: DocumentTemplate | undefined = useMemo(
    () => templates.find((t) => t.documentTypeId === doc?.tipoDocumentoId && t.ativo),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [templates, doc?.tipoDocumentoId],
  );

  const currentRole = useAuthStore((s) => s.currentRole);

  // ── Doc-specific data ────────────────────────────────────────────────────
  const circulations = useMemo(
    () => (doc ? circulationsRepo.query((c) => c.documentId === doc.id) : []),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [doc?.id, doc?.estado, circRefresh],
  );

  const auditLogs = useMemo(
    () =>
      doc
        ? auditRepo.query((l) => l.registroId === doc.id).sort(
          (a, b) => new Date(b.data).getTime() - new Date(a.data).getTime(),
        )
        : [],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [doc?.id, doc?.atualizadoEm],
  );

  const pendingCircs = circulations.filter((c) => c.status === 'pendente');

  // ── Derived helpers ──────────────────────────────────────────────────────
  if (!docsLoaded || !doc) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="h-6 w-6 animate-spin rounded-full border-2 border-sky-600 border-t-transparent" />
      </div>
    );
  }

  const localizacaoFisicaLabel = getLocationLabel(doc.localizacaoFisicaId, locationNodes);

  const docType = documentTypes.find((dt) => dt.id === doc.tipoDocumentoId);
  const remetenteUser = users.find((u) => u.id === doc.remetenteId);
  const remetenteEntity = entities.find((e) => e.id === doc.remetenteId);
  const remetenteLabel =
    doc.remetenteTexto ?? remetenteUser?.nome ?? remetenteEntity?.nome ?? '—';
  const funcionario = funcionarios.find((f) => f.id === doc.funcionarioId);

  function getDestinatarioLabel(tipo: string, rid: string): string {
    if (tipo === 'user') return users.find((u) => u.id === rid)?.nome ?? rid;
    if (tipo === 'entity') return entities.find((e) => e.id === rid)?.nome ?? rid;
    return rid;
  }

  const backHref =
    doc.tipoRegistro === 'entrada'
      ? '/registro/entradas'
      : doc.tipoRegistro === 'saida'
        ? '/registro/saidas'
        : '/registro/internos';

  // ── Circulation helpers ──────────────────────────────────────────────────
  function CirculationRow({ circ }: { circ: Circulation }) {
    const fromUser = users.find((u) => u.id === circ.deUserId);
    return (
      <div className="rounded-lg border border-slate-100 bg-white p-4 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Badge
                variant="outline"
                className={cn(
                  'text-xs',
                  circ.status === 'pendente'
                    ? 'border-amber-300 bg-amber-50 text-amber-700'
                    : circ.status === 'respondido'
                      ? 'border-emerald-300 bg-emerald-50 text-emerald-700'
                      : 'border-slate-300 bg-slate-50 text-slate-600',
                )}
              >
                {circ.status === 'pendente'
                  ? 'Pendente'
                  : circ.status === 'respondido'
                    ? 'Respondido'
                    : 'Expirado'}
              </Badge>
              <span className="text-xs font-medium text-slate-700 capitalize">
                {circ.acao.replace('_', ' ')}
              </span>
            </div>
            <p className="mt-1 text-xs text-slate-500">
              De: <span className="font-medium">{fromUser?.nome ?? circ.deUserId}</span>
            </p>
            {circ.mensagem && (
              <p className="mt-1 text-sm text-slate-600 italic">&ldquo;{circ.mensagem}&rdquo;</p>
            )}
          </div>
          <time className="shrink-0 text-xs text-slate-400">
            {format(parseISO(circ.criadoEm), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
          </time>
        </div>

        {/* Destinatários */}
        <div className="flex flex-wrap gap-1">
          {circ.paraDestinatarios.map((d, i) => (
            <Badge key={i} variant="secondary" className="gap-1 text-xs">
              {d.tipo === 'user' ? (
                <Users className="h-2.5 w-2.5" />
              ) : (
                <Building2 className="h-2.5 w-2.5" />
              )}
              {getDestinatarioLabel(d.tipo, d.id)}
            </Badge>
          ))}
        </div>

        {/* Respostas */}
        {circ.respostas.length > 0 && (
          <div className="border-t border-slate-100 pt-3 space-y-2">
            <p className="text-xs font-medium text-slate-500">Respostas:</p>
            {circ.respostas.map((r) => {
              const respUser = users.find((u) => u.id === r.userId);
              return (
                <div key={r.id} className="flex items-start gap-2 text-xs">
                  <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" />
                  <div>
                    <span className="font-medium text-slate-700">
                      {respUser?.nome ?? r.userId}
                    </span>{' '}
                    <span className="text-slate-500 capitalize">{r.decisao.replace('_', ' ')}</span>
                    {r.mensagem && (
                      <p className="mt-0.5 text-slate-500 italic">&ldquo;{r.mensagem}&rdquo;</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {circ.dataLimite && (
          <p className="flex items-center gap-1 text-xs text-slate-400">
            <Clock className="h-3 w-3" />
            Prazo: {format(parseISO(circ.dataLimite), 'dd/MM/yyyy', { locale: ptBR })}
          </p>
        )}
      </div>
    );
  }

  function AuditLogRow({ log }: { log: AuditLog }) {
    const logUser = users.find((u) => u.id === log.userId);
    return (
      <div className="flex items-start gap-3 py-3 border-b border-slate-100 last:border-0">
        <div className="mt-0.5 h-7 w-7 shrink-0 rounded-full bg-sky-50 flex items-center justify-center">
          <History className="h-3.5 w-3.5 text-sky-500" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-baseline gap-1.5">
            <span className="text-sm font-medium text-slate-700 capitalize">
              {log.evento}
            </span>
            <span className="text-xs text-slate-500">
              por <span className="font-medium">{logUser?.nome ?? log.userId}</span>
            </span>
            {log.ip && (
              <span className="text-xs text-slate-400">({log.ip})</span>
            )}
          </div>
          {log.detalhe && (
            <p className="mt-0.5 text-xs text-slate-500">{log.detalhe}</p>
          )}
        </div>
        <time className="shrink-0 text-xs text-slate-400 whitespace-nowrap">
          {format(parseISO(log.data), "dd/MM 'às' HH:mm", { locale: ptBR })}
        </time>
      </div>
    );
  }

  return (
    <PermissionGuard required="documents.read">
      <div className="flex gap-4 p-6">
        {/* ── Main content ────────────────────────────────────────────────── */}
        <div className="min-w-0 flex-1 space-y-4">
          {/* Top bar */}
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <Button variant="outline" size="icon-sm" asChild className="mt-0.5 shrink-0">
                <Link href={backHref}>
                  <ArrowLeft className="h-4 w-4" />
                  
                </Link>
              </Button>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <h1 className="text-xl font-bold tracking-tight text-slate-900">
                    {doc.numero}
                  </h1>
                  <Badge variant="outline" className="text-xs">
                    {TIPO_REGISTRO_LABEL[doc.tipoRegistro] ?? doc.tipoRegistro}
                  </Badge>
                  {doc.confidencial && (
                    <Badge
                      variant="outline"
                      className="gap-1 border-amber-300 bg-amber-50 text-amber-700 text-xs"
                    >
                      <Lock className="h-2.5 w-2.5" />
                      Confidencial
                    </Badge>
                  )}
                  {pendingCircs.length > 0 && (
                    <Badge className="bg-amber-500 text-white text-xs">
                      {pendingCircs.length} pendente{pendingCircs.length > 1 ? 's' : ''}
                    </Badge>
                  )}
                </div>
                <p className="mt-1 max-w-2xl text-sm text-slate-500">{doc.assunto}</p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 shrink-0">
              <StatusBadge status={doc.estado} />

              {docTemplate && (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-1.5"
                    onClick={() => setTemplateDialogOpen('preview')}
                  >
                    <LayoutTemplate className="h-3.5 w-3.5" />
                    Ver Template
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-1.5"
                    onClick={() => setTemplateDialogOpen('print')}
                  >
                    <Printer className="h-3.5 w-3.5" />
                    Imprimir
                  </Button>
                </>
              )}

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-1.5">
                    <MoreVertical className="h-3.5 w-3.5" />
                    Opções
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel className="text-xs text-slate-500">
                    Documento
                  </DropdownMenuLabel>

                  <Can permission="documents.update">
                    <DropdownMenuItem
                      className="gap-2"
                      onClick={() => setStateDialogOpen(true)}
                    >
                      <RefreshCcw className="h-4 w-4" />
                      Alterar Estado
                    </DropdownMenuItem>
                  </Can>

                  <Can permission="documents.update">
                    <DropdownMenuItem
                      className="gap-2"
                      onClick={() => setEditDocOpen(true)}
                    >
                      <Pencil className="h-4 w-4" />
                      Editar
                    </DropdownMenuItem>
                  </Can>

                  <DropdownMenuSeparator />
                  <DropdownMenuLabel className="text-xs text-slate-500">
                    Encaminhar
                  </DropdownMenuLabel>

                  {/* Ação Pendência submenu */}
                  <Can permission="documents.forward">
                    <DropdownMenuSub>
                      <DropdownMenuSubTrigger className="gap-2">
                        <Send className="h-4 w-4" />
                        Com Ação Pendência
                      </DropdownMenuSubTrigger>
                      <DropdownMenuSubContent>
                        <DropdownMenuItem
                          className="gap-2"
                          onClick={() =>
                            setForwardOpen({ open: true, defaultAction: 'aprovar' })
                          }
                        >
                          <CheckCircle2 className="h-4 w-4" />
                          Aprovar
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          className="gap-2"
                          onClick={() =>
                            setForwardOpen({ open: true, defaultAction: 'assinar' })
                          }
                        >
                          <PenLine className="h-4 w-4" />
                          Assinar CC
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          className="gap-2"
                          onClick={() =>
                            setForwardOpen({ open: true, defaultAction: 'verificar' })
                          }
                        >
                          <SearchCheck className="h-4 w-4" />
                          Verificar
                        </DropdownMenuItem>
                      </DropdownMenuSubContent>
                    </DropdownMenuSub>
                  </Can>

                  <Can permission="documents.forward">
                    <DropdownMenuItem
                      className="gap-2"
                      onClick={() =>
                        setForwardOpen({ open: true, defaultAction: 'encaminhar_interno' })
                      }
                    >
                      <ArrowRightCircle className="h-4 w-4" />
                      Dentro da instituição
                    </DropdownMenuItem>
                  </Can>

                  <Can permission="documents.forward">
                    <DropdownMenuItem
                      className="gap-2"
                      onClick={() =>
                        setForwardOpen({ open: true, defaultAction: 'encaminhar_externo' })
                      }
                    >
                      <Globe className="h-4 w-4" />
                      Documento para exterior
                    </DropdownMenuItem>
                  </Can>

                  <DropdownMenuSeparator />

                  <Can permission="audit.read">
                    <DropdownMenuItem className="gap-2" disabled>
                      <ShieldCheck className="h-4 w-4" />
                      Permissões
                    </DropdownMenuItem>
                  </Can>

                  <Can permission="audit.read">
                    <DropdownMenuItem
                      className="gap-2"
                      onClick={() => {
                        const tab = document.querySelector<HTMLButtonElement>(
                          '[data-value="auditoria"]',
                        );
                        tab?.click();
                      }}
                    >
                      <ClipboardList className="h-4 w-4" />
                      Auditoria do documento
                    </DropdownMenuItem>
                  </Can>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="documento">
            <TabsList>
              <TabsTrigger value="documento">Documento</TabsTrigger>
              <TabsTrigger value="circulacoes">
                Circulações
                {pendingCircs.length > 0 && (
                  <span className="ml-1.5 rounded-full bg-amber-500 px-1.5 py-0.5 text-[10px] font-bold text-white">
                    {pendingCircs.length}
                  </span>
                )}
              </TabsTrigger>
              <TabsTrigger value="auditoria" data-value="auditoria">
                Auditoria
              </TabsTrigger>
            </TabsList>

            {/* ── Tab: Documento ─────────────────────────────────────────── */}
            <TabsContent value="documento" className="space-y-4 mt-4">
              {/* Info grid */}
              <SectionCard title="Informações do Documento">
                <dl className="grid grid-cols-2 gap-x-6 gap-y-4 text-sm lg:grid-cols-3">
                  <div>
                    <dt className="text-xs font-medium text-slate-500">Número</dt>
                    <dd className="mt-1 font-semibold text-slate-900">{doc.numero}</dd>
                  </div>
                  <div>
                    <dt className="text-xs font-medium text-slate-500">Tipo de Registo</dt>
                    <dd className="mt-1 text-slate-800">
                      {TIPO_REGISTRO_LABEL[doc.tipoRegistro]}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs font-medium text-slate-500">Tipo de Documento</dt>
                    <dd className="mt-1 text-slate-800">{docType?.nome ?? '—'}</dd>
                  </div>
                  <div className="col-span-2 lg:col-span-3">
                    <dt className="text-xs font-medium text-slate-500">Assunto</dt>
                    <dd className="mt-1 text-slate-800">{doc.assunto}</dd>
                  </div>
                  <div>
                    <dt className="flex items-center gap-1 text-xs font-medium text-slate-500">
                      <Calendar className="h-3 w-3" /> Data
                    </dt>
                    <dd className="mt-1 text-slate-800">
                      {format(parseISO(doc.data), "dd 'de' MMMM 'de' yyyy", {
                        locale: ptBR,
                      })}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs font-medium text-slate-500">Estado</dt>
                    <dd className="mt-1">
                      <StatusBadge status={doc.estado} />
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs font-medium text-slate-500">Confidencial</dt>
                    <dd className="mt-1">
                      {doc.confidencial ? (
                        <Badge
                          variant="outline"
                          className="gap-1 border-amber-300 bg-amber-50 text-amber-700 text-xs"
                        >
                          <Lock className="h-2.5 w-2.5" /> Sim
                        </Badge>
                      ) : (
                        <span className="text-sm text-slate-500">Não</span>
                      )}
                    </dd>
                  </div>
                  <div>
                    <dt className="flex items-center gap-1 text-xs font-medium text-slate-500">
                      <User className="h-3 w-3" /> Remetente
                    </dt>
                    <dd className="mt-1 text-slate-800">{remetenteLabel}</dd>
                  </div>
                  {funcionario && (
                    <div>
                      <dt className="flex items-center gap-1 text-xs font-medium text-slate-500">
                        <Contact className="h-3 w-3" /> Funcionário
                      </dt>
                      <dd className="mt-1">
                        <Link
                          href={`/configuracoes/funcionarios/${funcionario.id}`}
                          className="font-medium text-sky-700 hover:underline"
                        >
                          {funcionario.nome} {funcionario.apelido}
                        </Link>
                        <span className="ml-1 text-xs text-slate-400">
                          — {funcionario.numeroProcesso}
                        </span>
                      </dd>
                    </div>
                  )}
                  <div className="col-span-2">
                    <dt className="text-xs font-medium text-slate-500">Destinatários</dt>
                    <dd className="mt-1 flex flex-wrap gap-1.5">
                      {doc.destinatarios.length === 0 ? (
                        <span className="text-sm text-slate-400">—</span>
                      ) : (
                        doc.destinatarios.map((d, i) => (
                          <Badge key={i} variant="secondary" className="gap-1 text-xs">
                            {d.tipo === 'user' ? (
                              <Users className="h-2.5 w-2.5" />
                            ) : (
                              <Building2 className="h-2.5 w-2.5" />
                            )}
                            {getDestinatarioLabel(d.tipo, d.id)}
                          </Badge>
                        ))
                      )}
                    </dd>
                  </div>
                  {(doc.regiao || doc.localizacao) && (
                    <div className="col-span-2 lg:col-span-3">
                      <dt className="flex items-center gap-1 text-xs font-medium text-slate-500">
                        <MapPin className="h-3 w-3" /> Localização
                      </dt>
                      <dd className="mt-1 text-slate-800">
                        {[doc.regiao, doc.localizacao].filter(Boolean).join(' · ')}
                      </dd>
                    </div>
                  )}
                  {localizacaoFisicaLabel && (
                    <div className="col-span-2 lg:col-span-3">
                      <dt className="flex items-center gap-1 text-xs font-medium text-slate-500">
                        <Archive className="h-3 w-3" /> Localização Física
                      </dt>
                      <dd className="mt-1 text-slate-800">{localizacaoFisicaLabel}</dd>
                    </div>
                  )}
                  <div>
                    <dt className="text-xs font-medium text-slate-500">Registado em</dt>
                    <dd className="mt-1 text-slate-800">
                      {format(parseISO(doc.criadoEm), "dd/MM/yyyy 'às' HH:mm", {
                        locale: ptBR,
                      })}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs font-medium text-slate-500">Última actualização</dt>
                    <dd className="mt-1 text-slate-800">
                      {format(parseISO(doc.atualizadoEm), "dd/MM/yyyy 'às' HH:mm", {
                        locale: ptBR,
                      })}
                    </dd>
                  </div>
                </dl>
              </SectionCard>

              {/* Custom campos */}
              {docType && docType.campos.length > 0 && (
                <SectionCard title={`Campos: ${docType.nome}`}>
                  <dl className="grid grid-cols-2 gap-x-6 gap-y-4 text-sm lg:grid-cols-3">
                    {docType.campos.map((campo) => {
                      const val = doc.camposValores[campo.key];
                      return (
                        <div
                          key={campo.key}
                          className={campo.tipo === 'textarea' ? 'col-span-full' : ''}
                        >
                          <dt className="text-xs font-medium text-slate-500">
                            {campo.label}
                          </dt>
                          <dd className="mt-1 text-slate-800">
                            {val == null || val === '' ? (
                              <span className="text-slate-400">—</span>
                            ) : campo.tipo === 'boolean' ? (
                              String(val) === 'true' ? 'Sim' : 'Não'
                            ) : campo.tipo === 'currency' ? (
                              `${Number(val).toLocaleString('pt-AO', {
                                minimumFractionDigits: 2,
                              })} AOA`
                            ) : (
                              String(val)
                            )}
                          </dd>
                        </div>
                      );
                    })}
                  </dl>
                </SectionCard>
              )}

              {/* Attachments */}
              <SectionCard
                title="Anexos"
                description={`${doc.anexos.length} ficheiro(s)`}
                actions={
                  <Badge variant="outline" className="text-xs">
                    Opções Anexos
                  </Badge>
                }
              >
                <Can permission="files.manage" fallback={
                  <AttachmentManager doc={doc} readonly />
                }>
                  <AttachmentManager
                    doc={doc}
                    onUpdate={() => {
                      /* reactive via store */
                    }}
                  />
                </Can>
              </SectionCard>
            </TabsContent>

            {/* ── Tab: Circulações ────────────────────────────────────────── */}
            <TabsContent value="circulacoes" className="space-y-4 mt-4">
              <Tabs defaultValue="pendentes">
                <TabsList variant="line">
                  <TabsTrigger value="pendentes" className="gap-1.5">
                    Circulação
                    {pendingCircs.length > 0 && (
                      <span className="ml-0.5 rounded-full bg-amber-500 px-1.5 py-0.5 text-[10px] font-bold text-white">
                        {pendingCircs.length}
                      </span>
                    )}
                  </TabsTrigger>
                  <TabsTrigger value="historico">Histórico</TabsTrigger>
                </TabsList>

                {/* Pending — show CirculationResponsePanel for each */}
                <TabsContent value="pendentes" className="mt-4 space-y-4">
                  {pendingCircs.length === 0 ? (
                    <EmptyState
                      title="Sem pendências"
                      description="Não existem acções pendentes para este documento."
                    />
                  ) : (
                    pendingCircs.map((c) => (
                      <CirculationResponsePanel
                        key={c.id}
                        circ={c}
                        users={users}
                        entities={entities}
                        docRecord={doc}
                        template={docTemplate}
                        company={company}
                        currentUserRoleName={currentRole?.nome}
                        onResponded={() => {
                          setCircRefresh((n) => n + 1);
                          if (currentUser) loadPending(currentUser.id);
                          useDocumentsStore.setState({ loaded: false });
                          loadDocs();
                        }}
                      />
                    ))
                  )}
                </TabsContent>

                {/* History — Timeline view */}
                <TabsContent value="historico" className="mt-4">
                  {circulations.length === 0 ? (
                    <EmptyState
                      title="Sem histórico"
                      description="Este documento ainda não foi encaminhado."
                    />
                  ) : (
                    <Timeline
                      items={circulations
                        .slice()
                        .sort(
                          (a, b) =>
                            new Date(b.criadoEm).getTime() -
                            new Date(a.criadoEm).getTime(),
                        )
                        .map((c) => {
                          const fromUser = users.find((u) => u.id === c.deUserId);
                          const acaoLabel: Record<string, string> = {
                            aprovar: 'Aprovação', assinar: 'Assinatura',
                            parecer: 'Parecer', despachar: 'Despacho',
                            deferir: 'Deferimento', verificar: 'Verificação',
                            encaminhar_interno: 'Encaminh. interno',
                            encaminhar_externo: 'Encaminh. externo',
                          };
                          return {
                            id: c.id,
                            date: c.criadoEm,
                            label: `${acaoLabel[c.acao] ?? c.acao} — ${c.status === 'respondido' ? 'Concluído' : c.status === 'expirado' ? 'Expirado' : 'Pendente'}`,
                            description: [
                              `De: ${fromUser?.nome ?? c.deUserId}`,
                              c.mensagem ? `"${c.mensagem}"` : null,
                              c.respostas.length > 0
                                ? `${c.respostas.length} resposta(s)`
                                : null,
                            ]
                              .filter(Boolean)
                              .join(' · '),
                            variant:
                              c.status === 'respondido'
                                ? ('success' as const)
                                : c.status === 'expirado'
                                  ? ('error' as const)
                                  : ('default' as const),
                          };
                        })}
                    />
                  )}
                </TabsContent>
              </Tabs>
            </TabsContent>

            {/* ── Tab: Auditoria ──────────────────────────────────────────── */}
            <TabsContent value="auditoria" className="mt-4">
              <SectionCard title="Registo de Auditoria" description={`${auditLogs.length} evento(s)`}>
                {auditLogs.length === 0 ? (
                  <EmptyState
                    title="Sem eventos de auditoria"
                    description="Não foram registados eventos para este documento."
                  />
                ) : (
                  <div className="divide-y divide-slate-100">
                    {auditLogs.map((log) => (
                      <AuditLogRow key={log.id} log={log} />
                    ))}
                  </div>
                )}
              </SectionCard>
            </TabsContent>
          </Tabs>
        </div>

        {/* ── Opened docs sidebar ───────────────────────────────────────── */}
        <div className="hidden xl:block w-60 shrink-0">
          <div className="sticky top-6">
            <OpenedDocsSidebar currentDocId={doc.id} />
          </div>
        </div>
      </div>

      {/* ── Dialogs ──────────────────────────────────────────────────────── */}
      <EditDocumentSheet
        doc={doc}
        open={editDocOpen}
        onOpenChange={setEditDocOpen}
      />

      <StateChangeDialog
        doc={doc}
        open={stateDialogOpen}
        onOpenChange={setStateDialogOpen}
      />

      <ForwardDialog
        doc={doc}
        template={docTemplate}
        open={forwardOpen.open}
        onOpenChange={(open) => setForwardOpen((s) => ({ ...s, open }))}
        defaultAction={forwardOpen.defaultAction}
        onForwarded={() => {
          setCircRefresh((n) => n + 1);
          if (currentUser) loadPending(currentUser.id);
          useDocumentsStore.setState({ loaded: false });
          loadDocs();
        }}
      />

      {/* ── Template viewer / print dialog ───────────────────────────────── */}
      {docTemplate && (
        <Dialog open={!!templateDialogOpen} onOpenChange={(o) => !o && setTemplateDialogOpen(false)}>
          <DialogContent
            className="
    w-[95vw]
    !max-w-[75vw]
    h-[90vh]
    flex
    flex-col
    gap-0
    p-0
    overflow-hidden
  "
          >
            <DialogHeader className="px-6 pt-5 pb-3 border-b border-slate-100 shrink-0">
              <DialogTitle className="flex items-center gap-2 text-base">
                <LayoutTemplate className="h-4 w-4 text-sky-600" />
                {templateDialogOpen === 'print' ? 'Impressão do Documento' : 'Visualização do Documento'}
                <span className="text-slate-400 font-normal text-sm ml-1">— {doc.numero}</span>
              </DialogTitle>
            </DialogHeader>
            <div className="flex-1 overflow-y-auto bg-slate-100 p-4">
              <DocumentRenderer
                doc={doc}
                template={docTemplate}
                mode={templateDialogOpen === 'print' ? 'print' : 'preview'}
                company={company}
                currentUser={currentUser}
                currentUserRoleName={currentRole?.nome}
                users={users}
                entities={entities}
              />
            </div>
          </DialogContent>
        </Dialog>
      )}
    </PermissionGuard>
  );
}
