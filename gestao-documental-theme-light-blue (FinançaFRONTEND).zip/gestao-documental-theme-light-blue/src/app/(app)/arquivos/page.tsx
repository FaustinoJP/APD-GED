﻿'use client';

import { Fragment, useCallback, useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  Folder, CalendarDays, Calendar, Clock, FileText, FileImage,
  FileSpreadsheet, FileArchive, File, ChevronRight, Home, Menu, X,
  Download, Eye, Search, ExternalLink,
} from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent } from '@/components/ui/sheet';
import { StatusBadge } from '@/components/common/status-badge';
import { FilePreview } from '@/components/common/file-preview';
import { buildFileTree, FileTreeNode } from '@/lib/db/fileTreeBuilder';
import { documentTypesRepo, entitiesRepo } from '@/lib/db';
import { useDocumentsStore } from '@/store/documents-store';
import type { Attachment, DocumentRecord } from '@/types';
import { cn } from '@/lib/utils';

// ─── Attachment helpers ──────────────────────────────────────────────────────

const FORMAT_COLOR: Record<string, string> = {
  pdf: 'bg-red-50 text-red-600 border-red-200',
  doc: 'bg-blue-50 text-blue-700 border-blue-200',
  docx: 'bg-blue-50 text-blue-700 border-blue-200',
  xls: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  xlsx: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  csv: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  png: 'bg-violet-50 text-violet-700 border-violet-200',
  jpg: 'bg-violet-50 text-violet-700 border-violet-200',
  jpeg: 'bg-violet-50 text-violet-700 border-violet-200',
  svg: 'bg-violet-50 text-violet-700 border-violet-200',
  zip: 'bg-amber-50 text-amber-700 border-amber-200',
  rar: 'bg-amber-50 text-amber-700 border-amber-200',
};

function fmtColor(ext: string) {
  return FORMAT_COLOR[ext.toLowerCase()] ?? 'bg-slate-50 text-slate-600 border-slate-200';
}

function fmtBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1_048_576) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1_048_576).toFixed(1)} MB`;
}

function AttachmentIcon({ formato, size = 'md' }: { formato: string; size?: 'sm' | 'md' | 'lg' }) {
  const ext = formato.toLowerCase();
  const cls = size === 'sm' ? 'h-4 w-4' : size === 'lg' ? 'h-10 w-10' : 'h-7 w-7';
  if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp'].includes(ext)) return <FileImage className={cls} />;
  if (ext === 'pdf') return <FileText className={cls} />;
  if (['xls', 'xlsx', 'ods', 'csv'].includes(ext)) return <FileSpreadsheet className={cls} />;
  if (['zip', 'rar', '7z', 'tar'].includes(ext)) return <FileArchive className={cls} />;
  return <File className={cls} />;
}

// ─── Tree node icons ─────────────────────────────────────────────────────────

const NODE_ICON = {
  localidade: Folder,
  ano: CalendarDays,
  mes: Calendar,
  dia: Clock,
  document: FileText,
} as const;

// ─── Tree filter ─────────────────────────────────────────────────────────────

function filterTree(nodes: FileTreeNode[], query: string): { filtered: FileTreeNode[]; matchedIds: Set<string> } {
  const matchedIds = new Set<string>();
  if (!query.trim()) return { filtered: nodes, matchedIds };
  const q = query.toLowerCase();

  function walk(node: FileTreeNode): FileTreeNode | null {
    const self = node.label.toLowerCase().includes(q);
    const kids = node.children.map(walk).filter((n): n is FileTreeNode => n !== null);
    if (self || kids.length > 0) {
      matchedIds.add(node.id);
      return { ...node, children: kids };
    }
    return null;
  }

  return { filtered: nodes.map(walk).filter((n): n is FileTreeNode => n !== null), matchedIds };
}

// ─── Find node by id ─────────────────────────────────────────────────────────

function findNode(nodes: FileTreeNode[], id: string): FileTreeNode | null {
  for (const n of nodes) {
    if (n.id === id) return n;
    const found = findNode(n.children, id);
    if (found) return found;
  }
  return null;
}

// ─── TreeNode ────────────────────────────────────────────────────────────────

function TreeNode({
  node, depth, expandedIds, onToggle, selectedId, onSelect,
}: {
  node: FileTreeNode;
  depth: number;
  expandedIds: Set<string>;
  onToggle: (id: string) => void;
  selectedId: string | null;
  onSelect: (node: FileTreeNode) => void;
}) {
  const isExpanded = expandedIds.has(node.id);
  const isSelected = selectedId === node.id;
  const Icon = NODE_ICON[node.type];
  const hasKids = node.children.length > 0;

  return (
    <div>
      <button
        className={cn(
          'flex w-full items-center gap-1.5 rounded-md py-1 pr-2 text-left text-xs transition-colors hover:bg-slate-100',
          isSelected && 'bg-sky-50 text-sky-700 hover:bg-sky-50',
        )}
        style={{ paddingLeft: `${8 + depth * 16}px` }}
        onClick={() => {
          if (node.type !== 'document') onToggle(node.id);
          onSelect(node);
        }}
      >
        {hasKids && node.type !== 'document' ? (
          <ChevronRight className={cn('h-3 w-3 shrink-0 transition-transform', isExpanded && 'rotate-90')} />
        ) : (
          <span className="w-3 shrink-0" />
        )}
        <Icon className="h-3.5 w-3.5 shrink-0 opacity-60" />
        <span className="flex-1 truncate">{node.label}</span>
        {node.type !== 'document' && (
          <span className="ml-1 shrink-0 rounded-full bg-slate-100 px-1.5 text-[10px] text-slate-500 tabular-nums">
            {node.count}
          </span>
        )}
      </button>
      {isExpanded && hasKids && node.children.map((child) => (
        <TreeNode
          key={child.id}
          node={child}
          depth={depth + 1}
          expandedIds={expandedIds}
          onToggle={onToggle}
          selectedId={selectedId}
          onSelect={onSelect}
        />
      ))}
    </div>
  );
}

// ─── SidebarContent ──────────────────────────────────────────────────────────

function SidebarContent({
  tree, expandedIds, onToggle, selectedId, onSelect, onClose,
}: {
  tree: FileTreeNode[];
  expandedIds: Set<string>;
  onToggle: (id: string) => void;
  selectedId: string | null;
  onSelect: (node: FileTreeNode | null) => void;
  onClose?: () => void;
}) {
  const [q, setQ] = useState('');
  const { filtered, matchedIds } = useMemo(() => filterTree(tree, q), [tree, q]);
  const effectiveExpanded = q.trim() ? matchedIds : expandedIds;

  return (
    <div className="flex h-full flex-col">
      <div className="space-y-2 border-b border-slate-200 px-3 py-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-slate-800">Gerenciador de Arquivos</h2>
          {onClose && (
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
          <input
            type="search"
            placeholder="Pesquisar…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="h-8 w-full rounded-md border border-slate-200 bg-slate-50 pl-8 pr-3 text-xs placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500"
          />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto py-1.5 px-1">
        {filtered.length === 0 ? (
          <p className="px-3 py-4 text-xs text-slate-400">Nenhum resultado.</p>
        ) : (
          filtered.map((node) => (
            <TreeNode
              key={node.id}
              node={node}
              depth={0}
              expandedIds={effectiveExpanded}
              onToggle={onToggle}
              selectedId={selectedId}
              onSelect={onSelect}
            />
          ))
        )}
      </div>
    </div>
  );
}

// ─── BreadcrumbNav ────────────────────────────────────────────────────────────

function BreadcrumbNav({ node, onNavigate }: { node: FileTreeNode | null; onNavigate: (id: string | null) => void }) {
  const navPath = node?.type === 'document' ? node.path.slice(0, 4) : (node?.path ?? []);

  return (
    <nav className="flex flex-wrap items-center gap-1 text-xs">
      <button onClick={() => onNavigate(null)} className="flex items-center gap-1 text-slate-500 hover:text-sky-600 transition-colors">
        <Home className="h-3.5 w-3.5" /><span>Início</span>
      </button>
      {navPath.map((seg, i) => (
        <Fragment key={i}>
          <ChevronRight className="h-3 w-3 shrink-0 text-slate-300" />
          <button
            onClick={() => onNavigate(navPath.slice(0, i + 1).join('/'))}
            className={cn(
              'transition-colors',
              i === navPath.length - 1 && node?.type !== 'document'
                ? 'font-semibold text-slate-800'
                : 'text-slate-500 hover:text-sky-600',
            )}
          >{seg}</button>
        </Fragment>
      ))}
      {node?.type === 'document' && (
        <>
          <ChevronRight className="h-3 w-3 shrink-0 text-slate-300" />
          <span className="max-w-50 truncate font-semibold text-slate-800">{node.document?.numero}</span>
        </>
      )}
    </nav>
  );
}

// ─── SubfolderGrid ────────────────────────────────────────────────────────────

function SubfolderGrid({ nodes, onSelect }: { nodes: FileTreeNode[]; onSelect: (n: FileTreeNode) => void }) {
  if (nodes.length === 0) {
    return <p className="py-10 text-center text-sm text-slate-400">Sem subpastas.</p>;
  }
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
      {nodes.map((node) => {
        const Icon = NODE_ICON[node.type];
        return (
          <button
            key={node.id}
            onClick={() => onSelect(node)}
            className="group flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-4 text-left transition-colors hover:border-sky-300 hover:bg-sky-50/40"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-sky-50 text-sky-600 transition-transform group-hover:scale-110">
              <Icon className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold text-slate-800">{node.label}</p>
              <p className="mt-0.5 text-xs text-slate-400">
                {node.count} {node.count === 1 ? 'documento' : 'documentos'}
              </p>
            </div>
          </button>
        );
      })}
    </div>
  );
}

// ─── DocumentTable ────────────────────────────────────────────────────────────

function DocumentTable({
  docs, docTypeName, remetenteName, onRowClick,
}: {
  docs: DocumentRecord[];
  docTypeName: (id: string) => string;
  remetenteName: (doc: DocumentRecord) => string;
  onRowClick: (id: string) => void;
}) {
  if (docs.length === 0) {
    return <p className="py-10 text-center text-sm text-slate-400">Nenhum documento.</p>;
  }
  return (
    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
      <table className="w-full text-sm">
        <thead className="border-b border-slate-200 bg-slate-50">
          <tr>
            {['Nr. Documento', 'Tipo', 'Assunto', 'Estado', 'Hora', 'Remetente'].map((h) => (
              <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {docs.map((doc) => (
            <tr
              key={doc.id}
              onClick={() => onRowClick(doc.id)}
              className="cursor-pointer transition-colors hover:bg-slate-50"
            >
              <td className="px-4 py-3 font-mono text-xs font-semibold text-slate-700">{doc.numero}</td>
              <td className="px-4 py-3 text-xs text-slate-600">{docTypeName(doc.tipoDocumentoId)}</td>
              <td className="max-w-50 px-4 py-3 text-xs text-slate-700">
                <span className="block truncate">{doc.assunto}</span>
              </td>
              <td className="px-4 py-3"><StatusBadge status={doc.estado} /></td>
              <td className="px-4 py-3 tabular-nums text-xs text-slate-500">
                {format(parseISO(doc.criadoEm), 'HH:mm', { locale: ptBR })}
              </td>
              <td className="max-w-37.5 px-4 py-3 text-xs text-slate-600">
                <span className="block truncate">{remetenteName(doc)}</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── DocumentDetail ───────────────────────────────────────────────────────────

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-slate-400">{label}</span>
      <span className="text-right font-medium text-slate-700">{value}</span>
    </div>
  );
}

function DocumentDetail({ doc, docTypeName }: { doc: DocumentRecord; docTypeName: (id: string) => string }) {
  const [selectedAtt, setSelectedAtt] = useState<Attachment | null>(null);
  const [previewAtt, setPreviewAtt] = useState<Attachment | null>(null);

  return (
    <div className="space-y-4">
      <div className="flex items-start gap-3 rounded-xl border border-slate-200 bg-white p-4">
        <FileText className="mt-0.5 h-5 w-5 shrink-0 text-sky-500" />
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="text-sm font-semibold text-slate-800">{doc.numero}</p>
              <p className="mt-0.5 text-xs text-slate-500">{doc.assunto}</p>
            </div>
            <StatusBadge status={doc.estado} />
          </div>
          <p className="mt-1.5 text-xs text-slate-400">
            Tipo: {docTypeName(doc.tipoDocumentoId)} · Registado em{' '}
            {format(parseISO(doc.criadoEm), 'dd/MM/yyyy', { locale: ptBR })}
          </p>
        </div>
      </div>

      {doc.anexos.length === 0 ? (
        <div className="rounded-xl border border-dashed border-slate-200 py-10 text-center text-sm text-slate-400">
          Este documento não tem ficheiros anexados.
        </div>
      ) : (
        <div className="flex items-start gap-4">
          <div className="flex-1 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {doc.anexos.map((att) => (
              <button
                key={att.id}
                onClick={() => setSelectedAtt(att)}
                className={cn(
                  'group flex flex-col gap-3 rounded-xl border p-4 text-left transition-colors',
                  selectedAtt?.id === att.id
                    ? 'border-sky-400 bg-sky-50'
                    : 'border-slate-200 bg-white hover:border-sky-300 hover:bg-sky-50/40',
                )}
              >
                <div className={cn(
                  'flex h-10 w-10 items-center justify-center rounded-lg transition-transform group-hover:scale-110',
                  selectedAtt?.id === att.id ? 'bg-sky-100 text-sky-600' : 'bg-slate-100 text-slate-500',
                )}>
                  <AttachmentIcon formato={att.formato} />
                </div>
                <div className="min-w-0">
                  <p className="truncate text-xs font-medium text-slate-700">{att.nome}</p>
                  <div className="mt-1 flex items-center gap-1.5">
                    <Badge variant="outline" className={cn('px-1.5 py-0 text-[10px]', fmtColor(att.formato))}>
                      {att.formato.toUpperCase()}
                    </Badge>
                    <span className="text-[10px] text-slate-400">{fmtBytes(att.tamanho)}</span>
                  </div>
                </div>
              </button>
            ))}
          </div>

          {selectedAtt && (
            <div className="w-60 shrink-0 overflow-hidden rounded-xl border border-slate-200 bg-white">
              <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
                <p className="text-xs font-semibold text-slate-700">Detalhes</p>
                <button onClick={() => setSelectedAtt(null)} className="text-slate-400 hover:text-slate-600">
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="flex min-h-30 items-center justify-center bg-slate-50 p-4">
                <FilePreview attachment={selectedAtt} maxHeight="100px" />
              </div>
              <div className="space-y-3 p-4">
                <div>
                  <p className="wrap-break-word text-sm font-semibold text-slate-800">{selectedAtt.nome}</p>
                  <Badge variant="outline" className={cn('mt-1 text-xs', fmtColor(selectedAtt.formato))}>
                    {selectedAtt.formato.toUpperCase()}
                  </Badge>
                </div>
                <div className="space-y-1.5 text-xs">
                  <InfoRow label="Tamanho" value={fmtBytes(selectedAtt.tamanho)} />
                  <InfoRow label="Versão" value={`v${selectedAtt.versao}`} />
                  <InfoRow label="Estado" value={selectedAtt.estado === 'check_in' ? 'Disponível' : 'Em edição'} />
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1 gap-1 text-xs"
                    onClick={() => toast.info('Disponível com armazenamento real.')}>
                    <Download className="h-3.5 w-3.5" /> Baixar
                  </Button>
                  <Button size="sm" className="flex-1 gap-1 text-xs" onClick={() => setPreviewAtt(selectedAtt)}>
                    <Eye className="h-3.5 w-3.5" /> Ver
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      <Sheet open={!!previewAtt} onOpenChange={(o) => !o && setPreviewAtt(null)}>
        <SheetContent className="overflow-y-auto sm:max-w-2xl">
          <div className="flex items-center gap-2 pb-4 border-b border-slate-200">
            {previewAtt && <AttachmentIcon formato={previewAtt.formato} size="sm" />}
            <span className="text-sm font-semibold">{previewAtt?.nome}</span>
          </div>
          {previewAtt && (
            <div className="mt-4">
              <FilePreview attachment={previewAtt} maxHeight="60vh" />
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function ArquivosPage() {
  const router = useRouter();

  const docs = useDocumentsStore((s) => s.documents);
  const docsLoaded = useDocumentsStore((s) => s.loaded);
  const loadDocs = useDocumentsStore((s) => s.load);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [expandedIds, setExpandedIds] = useState<Set<string>>(() => {
    if (typeof window === 'undefined') return new Set();
    try {
      const stored = sessionStorage.getItem('gd:filetree:expanded');
      return stored ? new Set<string>(JSON.parse(stored)) : new Set();
    } catch { return new Set(); }
  });

  useEffect(() => {
    if (!docsLoaded) loadDocs();
  }, [docsLoaded, loadDocs]);

  // Read URL param for topbar navigation (once on mount)
  useEffect(() => {
    const nodeParam = new URLSearchParams(window.location.search).get('node');
    if (!nodeParam) return;
    setSelectedNodeId(decodeURIComponent(nodeParam));
    setExpandedIds((prev) => {
      const next = new Set(prev);
      const parts = decodeURIComponent(nodeParam).split('/');
      for (let i = 1; i <= parts.length; i++) next.add(parts.slice(0, i).join('/'));
      try { sessionStorage.setItem('gd:filetree:expanded', JSON.stringify(Array.from(next))); } catch { /* */ }
      return next;
    });
  }, []);

  const tree = useMemo(() => buildFileTree(docs), [docs]);
  const docTypes = useMemo(() => documentTypesRepo.list(), []);
  const entities = useMemo(() => entitiesRepo.list(), []);

  const docTypeName = useCallback(
    (id: string) => docTypes.find((t) => t.id === id)?.nome ?? '—',
    [docTypes],
  );
  const remetenteName = useCallback((doc: DocumentRecord) => {
    if (doc.remetenteTexto) return doc.remetenteTexto;
    if (doc.remetenteId) return entities.find((e) => e.id === doc.remetenteId)?.nome ?? '—';
    return '—';
  }, [entities]);

  const selectedNode = useMemo(
    () => (selectedNodeId ? findNode(tree, selectedNodeId) : null),
    [tree, selectedNodeId],
  );

  function toggle(id: string) {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      try { sessionStorage.setItem('gd:filetree:expanded', JSON.stringify(Array.from(next))); } catch { /* */ }
      return next;
    });
  }

  function handleNodeSelect(node: FileTreeNode) {
    if (selectedNodeId === node.id) {
      setSelectedNodeId(null);
      setExpandedIds((prev) => {
        const next = new Set(prev);
        next.delete(node.id);
        try { sessionStorage.setItem('gd:filetree:expanded', JSON.stringify(Array.from(next))); } catch { /* */ }
        return next;
      });
      return;
    }

    setSelectedNodeId(node.id);
    setSidebarOpen(false);
    if (node.type !== 'document') {
      setExpandedIds((prev) => {
        const next = new Set(prev);
        next.add(node.id);
        try { sessionStorage.setItem('gd:filetree:expanded', JSON.stringify(Array.from(next))); } catch { /* */ }
        return next;
      });
    }
  }

  function handleNavigate(id: string | null) {
    setSelectedNodeId(id);
  }

  function buildExportUrl(): string {
    if (!selectedNode) return '/exportacoes';
    const src = selectedNode.type === 'document' ? selectedNode.path.slice(0, 4) : selectedNode.path;
    const params = new URLSearchParams();
    const labels = ['localidade', 'ano', 'mes', 'dia'] as const;
    src.forEach((v, i) => { if (labels[i] && v) params.set(labels[i], v); });
    return `/exportacoes?${params.toString()}`;
  }

  // ─── Right-panel content ───────────────────────────────────────────────────

  function renderContent() {
    if (!selectedNode) {
      return (
        <SubfolderGrid
          nodes={tree}
          onSelect={handleNodeSelect}
        />
      );
    }
    if (['localidade', 'ano', 'mes'].includes(selectedNode.type)) {
      return (
        <SubfolderGrid
          nodes={selectedNode.children}
          onSelect={handleNodeSelect}
        />
      );
    }
    if (selectedNode.type === 'dia') {
      const dayDocs = selectedNode.children
        .filter((c) => c.type === 'document' && c.document)
        .map((c) => c.document!);
      return (
        <DocumentTable
          docs={dayDocs}
          docTypeName={docTypeName}
          remetenteName={remetenteName}
          onRowClick={(id) => router.push(`/documentos/${id}`)}
        />
      );
    }
    if (selectedNode.type === 'document' && selectedNode.document) {
      return <DocumentDetail doc={selectedNode.document} docTypeName={docTypeName} />;
    }
    return null;
  }

  const panelLabel = selectedNode?.label ?? 'Todos os Arquivos';
  const panelCount = selectedNode?.count ?? docs.length;

  const sidebarProps = {
    tree,
    expandedIds,
    onToggle: toggle,
    selectedId: selectedNodeId,
    onSelect: (n: FileTreeNode | null) => (n ? handleNodeSelect(n) : handleNavigate(null)),
  };

  return (
    <div className="-m-6 flex overflow-hidden" style={{ height: 'calc(100vh - 56px)' }}>

      {/* ── Desktop sidebar ────────────────────────────────────────────────── */}
      <aside className="hidden w-70 shrink-0 flex-col border-r border-slate-200 bg-white lg:flex">
        <SidebarContent {...sidebarProps} />
      </aside>

      {/* ── Mobile / tablet sidebar (Sheet from left) ──────────────────────── */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="w-70 p-0">
          <SidebarContent {...sidebarProps} onClose={() => setSidebarOpen(false)} />
        </SheetContent>
      </Sheet>

      {/* ── Main content ────────────────────────────────────────────────────── */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">

        {/* Mobile/tablet topbar */}
        <div className="flex items-center gap-3 border-b border-slate-200 bg-white px-4 py-3 lg:hidden">
          <button
            onClick={() => setSidebarOpen(true)}
            className="flex h-8 w-8 items-center justify-center rounded-md border border-slate-200 text-slate-500 hover:bg-slate-50"
          >
            <Menu className="h-4 w-4" />
          </button>
          <span className="truncate text-sm font-semibold text-slate-700">{panelLabel}</span>
        </div>

        {/* Content area */}
        <div className="flex-1 overflow-y-auto">
          <div className="mx-auto max-w-screen-2xl space-y-5 p-6">

            {/* Header row */}
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="space-y-1">
                <BreadcrumbNav node={selectedNode} onNavigate={handleNavigate} />
                <div className="flex items-center gap-2">
                  <h1 className="text-lg font-semibold text-slate-900">{panelLabel}</h1>
                  <span className="text-xs text-slate-400">
                    ({panelCount} {panelCount === 1 ? 'documento' : 'documentos'})
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {selectedNode && selectedNode.type !== 'document' && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-1.5 text-xs"
                    onClick={() => router.push(buildExportUrl())}
                  >
                    <ExternalLink className="h-3.5 w-3.5" />
                    Exportar esta pasta
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs"
                  onClick={() => { useDocumentsStore.setState({ loaded: false }); loadDocs(); setSelectedNodeId(null); }}
                >
                  Atualizar
                </Button>
              </div>
            </div>

            {/* Dynamic content */}
            {renderContent()}

          </div>
        </div>
      </div>
    </div>
  );
}
