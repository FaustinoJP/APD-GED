﻿'use client';

import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { FileSearch, ExternalLink, Lock, FolderArchive } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/common/page-header';
import { SearchFilters, type SearchParams } from '@/components/common/search-filters';
import type { AdvancedSearchParams } from '@/components/common/advanced-search-dialog';
import { DataTable, type ColumnDef } from '@/components/common/data-table';
import { StatusBadge } from '@/components/common/status-badge';
import { EmptyState } from '@/components/common/empty-state';
import { PermissionGuard } from '@/components/auth/permission-guard';
import { useAuthStore } from '@/store/auth-store';
import {
  documentsRepo,
  documentTypesRepo,
  funcionariosRepo,
  usersRepo,
  auditRepo,
} from '@/lib/db';
import { buildSimpleWorkbook, downloadArrayBuffer } from '@/lib/xlsx-export';
import {
  buildDocumentsZip, countDownloadableAnexos, downloadZipBlob,
} from '@/lib/zip-export';
import { IncluirFicheirosDialog } from '@/components/exportacoes/incluir-ficheiros-dialog';
import type { DocumentRecord, DocumentType, Funcionario, User } from '@/types';

// ─── Types ────────────────────────────────────────────────────────────────────

type CombinedParams = SearchParams & AdvancedSearchParams;

type DocRow = DocumentRecord & { tipoNome: string };

// ─── Filter logic ─────────────────────────────────────────────────────────────

function applyFilters(
  docs: DocumentRecord[],
  params: CombinedParams,
  types: DocumentType[],
  users: User[],
  funcionarios: Funcionario[],
  currentUserId: string,
  isAdmin: boolean,
): DocRow[] {
  const typeMap = Object.fromEntries(types.map((t) => [t.id, t.nome]));
  const funcMap = Object.fromEntries(funcionarios.map((f) => [f.id, f]));

  // Algum critério de funcionário está ativo?
  const funcFilterActive = Boolean(
    params.funcNome ||
      params.funcNumeroProcesso ||
      params.funcEstado ||
      params.funcNascimentoInicio ||
      params.funcNascimentoFim ||
      params.funcInicioFuncoesInicio ||
      params.funcInicioFuncoesFim ||
      params.funcFimFuncoesInicio ||
      params.funcFimFuncoesFim,
  );

  return docs
    .filter((doc) => {
      // Confidentiality — hide from non-admins who aren't the creator/recipient
      if (doc.confidencial && !isAdmin && doc.criadoPor !== currentUserId) {
        const isRecipient = doc.destinatarios.some((d) => d.id === currentUserId);
        if (!isRecipient) return false;
      }

      // Basic query: nº / assunto / remetente / funcionário (nome ou nº de processo)
      if (params.query) {
        const q = params.query.toLowerCase();
        const func = doc.funcionarioId ? funcMap[doc.funcionarioId] : undefined;
        const hit =
          doc.numero.toLowerCase().includes(q) ||
          doc.assunto.toLowerCase().includes(q) ||
          (doc.remetenteTexto ?? '').toLowerCase().includes(q) ||
          (!!func && `${func.nome} ${func.apelido}`.toLowerCase().includes(q)) ||
          (!!func && func.numeroProcesso.toLowerCase().includes(q));
        if (!hit) return false;
      }

      // Advanced: número específico
      if (params.numero) {
        if (!doc.numero.toLowerCase().includes(params.numero.toLowerCase())) return false;
      }

      // Advanced: assunto keyword
      if (params.assunto) {
        if (!doc.assunto.toLowerCase().includes(params.assunto.toLowerCase())) return false;
      }

      // Tipo de documento (basic ou advanced — advanced prevalece)
      const tipoId = params.tipoDocumentoId;
      if (tipoId) {
        if (doc.tipoDocumentoId !== tipoId) return false;
      }

      // Estado
      if (params.estado) {
        if (doc.estado !== params.estado) return false;
      }

      // Data exacta (campo "data do documento")
      if (params.data) {
        if (doc.data !== params.data) return false;
      }

      // Intervalo de datas (campo criadoEm)
      if (params.dataInicial) {
        if (doc.criadoEm < params.dataInicial) return false;
      }
      if (params.dataFinal) {
        // extend to end-of-day by comparing prefix
        if (doc.criadoEm.slice(0, 10) > params.dataFinal) return false;
      }

      // Participante (user ID — basic quick filter)
      if (params.participantes) {
        const uid = params.participantes;
        const match =
          doc.criadoPor === uid ||
          doc.remetenteId === uid ||
          doc.destinatarios.some((d) => d.id === uid);
        if (!match) return false;
      }

      // Remetente texto (advanced)
      if (params.remetente) {
        const r = params.remetente.toLowerCase();
        if (!(doc.remetenteTexto ?? '').toLowerCase().includes(r)) return false;
      }

      // Destinatário nome (advanced — lookup)
      if (params.destinatario) {
        const dt = params.destinatario.toLowerCase();
        const destNames = doc.destinatarios.map((d) => {
          const u = users.find((u) => u.id === d.id);
          return (u?.nome ?? d.id).toLowerCase();
        });
        if (!destNames.some((n) => n.includes(dt))) return false;
      }

      // Tags / palavras-chave — corresponde se o doc tiver pelo menos uma das tags pesquisadas
      if (params.tags && params.tags.length > 0) {
        const docTags = (doc.tags ?? []).map((t) => t.toLowerCase());
        const hit = params.tags.some((t) => docTags.includes(t.toLowerCase()));
        if (!hit) return false;
      }

      // Funcionário vinculado — resolve o funcionarioId e compara os critérios ativos (AND)
      if (funcFilterActive) {
        const f = doc.funcionarioId ? funcMap[doc.funcionarioId] : undefined;
        if (!f) return false;

        if (params.funcNome) {
          const q = params.funcNome.toLowerCase();
          if (!`${f.nome} ${f.apelido}`.toLowerCase().includes(q)) return false;
        }
        if (params.funcNumeroProcesso) {
          if (!f.numeroProcesso.toLowerCase().includes(params.funcNumeroProcesso.toLowerCase()))
            return false;
        }
        if (params.funcEstado) {
          if (f.estado !== params.funcEstado) return false;
        }
        if (params.funcNascimentoInicio && f.dataNascimento < params.funcNascimentoInicio) return false;
        if (params.funcNascimentoFim && f.dataNascimento > params.funcNascimentoFim) return false;
        if (params.funcInicioFuncoesInicio && f.dataInicioFuncoes < params.funcInicioFuncoesInicio) return false;
        if (params.funcInicioFuncoesFim && f.dataInicioFuncoes > params.funcInicioFuncoesFim) return false;
        if (params.funcFimFuncoesInicio && (!f.dataFimFuncoes || f.dataFimFuncoes < params.funcFimFuncoesInicio)) return false;
        if (params.funcFimFuncoesFim && (!f.dataFimFuncoes || f.dataFimFuncoes > params.funcFimFuncoesFim)) return false;
      }

      return true;
    })
    .map((doc) => ({ ...doc, tipoNome: typeMap[doc.tipoDocumentoId] ?? '—' }));
}

// ─── Badge helpers ────────────────────────────────────────────────────────────

const TIPO_REGISTRO_LABEL: Record<string, string> = {
  entrada: 'Entrada',
  saida: 'Saída',
  interno: 'Interno',
};

const TIPO_REGISTRO_COLOR: Record<string, string> = {
  entrada: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  saida: 'bg-rose-50 text-rose-700 border-rose-200',
  interno: 'bg-sky-50 text-sky-700 border-sky-200',
};

// ─── Page ─────────────────────────────────────────────────────────────────────

function PesquisaContent() {
  const router = useRouter();
  const currentUser = useAuthStore((s) => s.currentUser)!;
  const currentRole = useAuthStore((s) => s.currentRole);
  const isAdmin =
    (currentRole?.permissions.includes('config.users.manage') ||
      currentRole?.permissions.includes('config.permissions.manage')) ??
    false;

  const [types, setTypes] = useState<DocumentType[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>([]);
  const [allDocs, setAllDocs] = useState<DocumentRecord[]>([]);
  const [results, setResults] = useState<DocRow[] | null>(null);
  const [lastParams, setLastParams] = useState<CombinedParams | null>(null);
  const [loading, setLoading] = useState(false);
  const [zipDialogOpen, setZipDialogOpen] = useState(false);
  const [zipLoading, setZipLoading] = useState(false);

  useEffect(() => {
    setTypes(documentTypesRepo.list().filter((t) => t.ativo));
    setUsers(usersRepo.list().filter((u) => u.ativo));
    setFuncionarios(funcionariosRepo.list());
    setAllDocs(documentsRepo.list());
  }, []);

  function handleSearch(params: CombinedParams) {
    setLoading(true);
    setLastParams(params);
    // Simulate async latency so the skeleton is visible
    setTimeout(() => {
      const filtered = applyFilters(allDocs, params, types, users, funcionarios, currentUser.id, isAdmin);
      // Sort: most recent first
      filtered.sort((a, b) => b.criadoEm.localeCompare(a.criadoEm));
      setResults(filtered);
      setLoading(false);
    }, 120);
  }

  function handleRefresh() {
    setAllDocs(documentsRepo.list());
    if (lastParams) handleSearch(lastParams);
  }

  // ─── Exportação (Excel + ficheiros) ───────────────────────────────────────
  const resolveUser = (id?: string): string => {
    if (!id) return '';
    const u = users.find((x) => x.id === id);
    return u ? (u.email || u.nome) : id;
  };

  function buildExportRows(rows: DocRow[]): Record<string, unknown>[] {
    return rows.map((d) => ({
      numero: d.numero,
      tipo_registro: d.tipoRegistro,
      tipo_documento: d.tipoNome,
      assunto: d.assunto,
      data: d.data,
      estado: d.estado,
      confidencial: d.confidencial ? 'Sim' : 'Não',
      regiao: d.regiao ?? '',
      localizacao: d.localizacao ?? '',
      num_anexos: d.anexos?.length ?? 0,
      criado_por: resolveUser(d.criadoPor),
      criado_em: d.criadoEm,
      atualizado_em: d.atualizadoEm,
    }));
  }

  async function generateXlsxBuffer(): Promise<{ buffer: ArrayBuffer; baseName: string }> {
    const stamp = format(new Date(), 'yyyyMMdd_HHmm');
    const buffer = await buildSimpleWorkbook(buildExportRows(results ?? []), 'Documentos');
    return { buffer, baseName: `documentos_${stamp}` };
  }

  function logExport(fmt: 'xlsx' | 'xlsx+zip') {
    auditRepo.create({
      evento: 'exportado',
      tabela: 'documentos',
      userId: currentUser.id,
      ip: '127.0.0.1',
      data: new Date().toISOString(),
      detalhe: JSON.stringify({ origem: 'pesquisa', formato: fmt, total: results?.length ?? 0 }),
    });
  }

  async function downloadExcelOnly() {
    try {
      const { buffer, baseName } = await generateXlsxBuffer();
      downloadArrayBuffer(buffer, `${baseName}.xlsx`);
      logExport('xlsx');
      toast.success(`Ficheiro ${baseName}.xlsx transferido.`);
    } catch (err) {
      console.error(err);
      toast.error('Falha ao gerar o ficheiro Excel.');
    }
  }

  async function downloadExcelWithFiles() {
    setZipLoading(true);
    try {
      const { buffer, baseName } = await generateXlsxBuffer();
      const { blob, missing, included } = await buildDocumentsZip(results ?? [], buffer, {
        xlsxFileName: `${baseName}.xlsx`,
      });
      downloadZipBlob(blob, `${baseName}.zip`);
      logExport('xlsx+zip');
      if (missing.length) {
        toast.warning(
          `${baseName}.zip transferido com ${included} ficheiro(s). ${missing.length} indisponível(is) e não incluído(s).`,
        );
      } else {
        toast.success(`${baseName}.zip transferido com ${included} ficheiro(s).`);
      }
    } catch (err) {
      console.error(err);
      toast.error('Falha ao gerar o ficheiro ZIP.');
    } finally {
      setZipLoading(false);
      setZipDialogOpen(false);
    }
  }

  function handleExport() {
    if (!results?.length) { toast.error('Nenhum documento para exportar.'); return; }
    if (countDownloadableAnexos(results).count > 0) {
      setZipDialogOpen(true);
      return;
    }
    void downloadExcelOnly();
  }

  const columns: ColumnDef<DocRow>[] = useMemo(
    () => [
      {
        id: 'numero',
        header: 'Número',
        accessor: 'numero',
        sortable: true,
        cell: (row) => (
          <span className="font-mono text-xs font-semibold text-sky-700 flex items-center gap-1">
            {row.confidencial && (
              <span title="Confidencial">
                <Lock className="h-3 w-3 text-slate-400 shrink-0" />
              </span>
            )}
            {row.numero}
          </span>
        ),
      },
      {
        id: 'tipoRegistro',
        header: 'Tipo de Registo',
        accessor: 'tipoRegistro',
        sortable: true,
        cell: (row) => (
          <span
            className={`inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium whitespace-nowrap ${
              TIPO_REGISTRO_COLOR[row.tipoRegistro] ?? 'bg-slate-100 text-slate-600 border-slate-200'
            }`}
          >
            {TIPO_REGISTRO_LABEL[row.tipoRegistro] ?? row.tipoRegistro}
          </span>
        ),
      },
      {
        id: 'tipoNome',
        header: 'Tipo de Documento',
        accessor: 'tipoNome',
        sortable: true,
        cell: (row) => (
          <span className="text-xs text-slate-600">{row.tipoNome}</span>
        ),
      },
      {
        id: 'assunto',
        header: 'Assunto',
        accessor: 'assunto',
        sortable: true,
        cell: (row) => (
          <span className="text-xs text-slate-800 line-clamp-1 max-w-[260px]">
            {row.assunto}
          </span>
        ),
      },
      {
        id: 'data',
        header: 'Data',
        accessor: 'data',
        sortable: true,
        cell: (row) => (
          <span className="text-xs text-slate-500 whitespace-nowrap">
            {row.data
              ? format(parseISO(row.data), 'dd MMM yyyy', { locale: ptBR })
              : '—'}
          </span>
        ),
      },
      {
        id: 'estado',
        header: 'Estado',
        accessor: 'estado',
        sortable: true,
        cell: (row) => <StatusBadge status={row.estado} />,
      },
      {
        id: 'acoes',
        header: '',
        cell: (row) => (
          <Button
            variant="ghost"
            size="sm"
            className="h-7 gap-1.5 text-xs text-sky-600 hover:text-sky-700 hover:bg-sky-50"
            onClick={(e) => {
              e.stopPropagation();
              router.push(`/documentos/${row.id}`);
            }}
          >
            <ExternalLink className="h-3.5 w-3.5" />
            Ver
          </Button>
        ),
      },
    ],
    [router],
  );

  const hasActiveFilters =
    lastParams !== null &&
    Object.values(lastParams).some((v) =>
      Array.isArray(v) ? v.length > 0 : v !== '' && v !== undefined,
    );

  return (
    <div className="p-6 space-y-5">
      <PageHeader
        title="Pesquisar Documentos"
        description="Pesquise por número, assunto, tipo, estado, funcionário ou intervalo de datas."
        onRefresh={handleRefresh}
      />

      <SearchFilters
        documentTypes={types}
        users={users}
        onSearch={handleSearch}
      />

      {/* Results */}
      {results === null ? (
        /* Initial state — no search run yet */
        <div className="rounded-xl border border-slate-200 bg-white">
          <EmptyState
            icon={<FileSearch className="h-8 w-8" />}
            title="Introduza critérios de pesquisa"
            description="Use a barra acima para pesquisar documentos por número, assunto, tipo, estado ou funcionário. Para filtros avançados, clique em 'Pesquisa avançada'."
          />
        </div>
      ) : (
        <div className="space-y-2">
          {!loading && (
            <div className="flex items-center justify-between gap-2 px-1">
              <p className="text-xs text-slate-500">
                {results.length === 0
                  ? 'Nenhum documento encontrado.'
                  : `${results.length} documento${results.length !== 1 ? 's' : ''} encontrado${results.length !== 1 ? 's' : ''}.`}
              </p>
              {results.length > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleExport}
                  className="gap-1.5"
                >
                  <FolderArchive className="h-4 w-4" />
                  Exportar (Excel + ficheiros)
                </Button>
              )}
            </div>
          )}
          <DataTable
            columns={columns}
            data={results}
            loading={loading}
            defaultPageSize={15}
            onRowClick={(row) => router.push(`/documentos/${row.id}`)}
            rowClassName={() => 'cursor-pointer'}
            emptyState={
              <EmptyState
                icon={<FileSearch className="h-8 w-8" />}
                title="Sem resultados"
                description={
                  hasActiveFilters
                    ? 'Nenhum documento corresponde aos filtros aplicados. Tente alargar os critérios.'
                    : 'Não existem documentos registados.'
                }
              />
            }
          />
        </div>
      )}

      <IncluirFicheirosDialog
        open={zipDialogOpen}
        onOpenChange={setZipDialogOpen}
        count={countDownloadableAnexos(results ?? []).count}
        bytes={countDownloadableAnexos(results ?? []).bytes}
        loading={zipLoading}
        onlyExcel={() => { setZipDialogOpen(false); void downloadExcelOnly(); }}
        withFiles={() => { void downloadExcelWithFiles(); }}
      />
    </div>
  );
}

export default function PesquisaDocumentosPage() {
  return (
    <PermissionGuard required="documents.read">
      <PesquisaContent />
    </PermissionGuard>
  );
}
