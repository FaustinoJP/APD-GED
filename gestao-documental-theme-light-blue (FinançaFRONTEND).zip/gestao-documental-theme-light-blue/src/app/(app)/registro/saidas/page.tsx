'use client';

import { RegistroPage } from '@/components/registro/registro-page';

export default function SaidasPage() {
  return <RegistroPage tipoRegistro="saida" />;
}
