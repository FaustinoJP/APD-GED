'use client';

import { RegistroPage } from '@/components/registro/registro-page';

export default function EntradasPage() {
  return <RegistroPage tipoRegistro="entrada" />;
}
