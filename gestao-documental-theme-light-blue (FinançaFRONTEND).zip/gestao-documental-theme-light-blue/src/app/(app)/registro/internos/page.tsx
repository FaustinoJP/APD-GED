'use client';

import { RegistroPage } from '@/components/registro/registro-page';

export default function InternosPage() {
  return <RegistroPage tipoRegistro="interno" />;
}
