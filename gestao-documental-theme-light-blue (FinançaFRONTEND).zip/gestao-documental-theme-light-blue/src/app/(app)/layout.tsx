import { AppShell } from "@/components/layout/app-shell";
import { SeedProvider } from "@/components/providers/seed-provider";
import { AuthGuard } from "@/components/auth/auth-guard";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <SeedProvider>
      <AuthGuard>
        <AppShell>{children}</AppShell>
      </AuthGuard>
    </SeedProvider>
  );
}
