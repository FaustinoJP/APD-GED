﻿"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { Loader2, Eye, EyeOff, FileText, Shield, Users } from "lucide-react";
import { useAuthStore } from "@/store/auth-store";

const schema = z.object({
  email: z.string().min(1, "Email obrigatório").email("Email inválido"),
  senha: z.string().min(1, "Palavra-passe obrigatória"),
  lembrarMe: z.boolean(),
});

type FormValues = z.infer<typeof schema>;

export default function LoginPage() {
  const router = useRouter();
  const login = useAuthStore((s) => s.login);
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const hasHydrated = useAuthStore((s) => s._hasHydrated);
  const [showPassword, setShowPassword] = useState(false);
  const [serverError, setServerError] = useState("");

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { lembrarMe: false },
  });

  // Redirect if already authenticated
  useEffect(() => {
    if (hasHydrated && isAuthenticated) {
      router.replace("/");
    }
  }, [hasHydrated, isAuthenticated, router]);

  async function onSubmit(values: FormValues) {
    setServerError("");
    const result = await login(values.email, values.senha);
    if (!result.ok) {
      setServerError(result.error ?? "Erro ao autenticar.");
      return;
    }
    toast.success("Bem-vindo de volta!", { description: "Sessão iniciada com sucesso." });
    router.push("/");
  }

  return (
    <div className="flex h-full">
      {/* ── Left panel: branding ── */}
      <div className="hidden lg:flex lg:w-[45%] flex-col justify-between bg-gradient-to-br from-sky-950 via-sky-800 to-sky-900 p-12 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-32 -left-32 h-96 w-96 rounded-full bg-sky-600/20 blur-3xl" />
          <div className="absolute -bottom-32 -right-32 h-96 w-96 rounded-full bg-sky-400/10 blur-3xl" />
        </div>

        {/* Logo */}
        <div className="relative flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-white font-bold text-lg backdrop-blur-sm">
            F
          </div>
          <div className="leading-tight">
            <p className="text-sm font-bold text-white">Faustware Systems</p>
            <p className="text-xs text-sky-300">& Solutions</p>
          </div>
        </div>

        {/* Center tagline */}
        <div className="relative space-y-6">
          <div>
            <h1 className="text-4xl font-bold tracking-tight text-white leading-snug">
              Gestão Documental,
              <br />
              <span className="text-sky-300">Processos e Workflows</span>
            </h1>
            <p className="mt-4 text-base text-sky-200/80 leading-relaxed max-w-xs">
              Gerencie documentos, automatize processos e controle fluxos de
              trabalho corporativos num único lugar.
            </p>
          </div>

          <ul className="space-y-3">
            {[
              { icon: FileText, text: "Registo e arquivo de documentos corporativos" },
              { icon: Shield, text: "Automação de processos e fluxos de trabalho" },
              { icon: Users, text: "Colaboração com validação e assinatura digital" },
            ].map(({ icon: Icon, text }) => (
              <li key={text} className="flex items-center gap-3 text-sm text-sky-100">
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white/10">
                  <Icon className="h-3.5 w-3.5" />
                </div>
                {text}
              </li>
            ))}
          </ul>
        </div>

        {/* Footer */}
        <p className="relative text-xs text-sky-400/60">
          © {new Date().getFullYear()} Faustware Systems & Solutions
        </p>
      </div>

      {/* ── Right panel: form ── */}
      <div className="flex flex-1 flex-col items-center justify-center bg-slate-50 px-6 py-12">
        {/* Mobile logo */}
        <div className="mb-8 flex items-center gap-2 lg:hidden">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-sky-600 text-white font-bold">
            K
          </div>
          <span className="text-base font-bold text-slate-900">Faustware Systems</span>
        </div>

        <div className="w-full max-w-sm">
          <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
            <div className="mb-7 text-center">
              <h2 className="text-xl font-bold tracking-tight text-slate-900">
                Bem-vindo de volta
              </h2>
              <p className="mt-1 text-sm text-slate-500">
                Aceda ao sistema de gestão documental
              </p>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
              {/* Email */}
              <div className="space-y-1.5">
                <label className="block text-sm font-medium text-slate-700">
                  Email
                </label>
                <input
                  type="email"
                  autoComplete="email"
                  placeholder="utilizador@empresa.ao"
                  {...register("email")}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-shadow aria-invalid:border-red-400"
                  aria-invalid={!!errors.email}
                />
                {errors.email && (
                  <p className="text-xs text-red-500">{errors.email.message}</p>
                )}
              </div>

              {/* Password */}
              <div className="space-y-1.5">
                <label className="block text-sm font-medium text-slate-700">
                  Palavra-passe
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    autoComplete="current-password"
                    placeholder="••••••••"
                    {...register("senha")}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 pr-10 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-shadow aria-invalid:border-red-400"
                    aria-invalid={!!errors.senha}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
                {errors.senha && (
                  <p className="text-xs text-red-500">{errors.senha.message}</p>
                )}
              </div>

              {/* Remember me */}
              <div className="flex items-center gap-2">
                <input
                  id="lembrarMe"
                  type="checkbox"
                  {...register("lembrarMe")}
                  className="h-4 w-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                />
                <label htmlFor="lembrarMe" className="text-sm text-slate-600">
                  Lembrar-me neste dispositivo
                </label>
              </div>

              {/* Server error */}
              {serverError && (
                <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2.5 text-sm text-red-600">
                  {serverError}
                </div>
              )}

              {/* Submit */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full rounded-lg bg-sky-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-sky-700 transition-colors focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isSubmitting && <Loader2 className="h-4 w-4 animate-spin" />}
                Entrar
              </button>
            </form>

            <p className="mt-5 text-center text-xs text-slate-500">
              Esqueceu a senha?{" "}
              <a href="#" className="text-sky-600 hover:text-sky-700 font-medium">
                Recuperar acesso
              </a>
            </p>
          </div>

          {/* Dev hint */}
          {process.env.NODE_ENV === "development" && (
            <div className="mt-4 rounded-lg border border-dashed border-slate-300 bg-slate-100 px-4 py-3 text-center text-xs text-slate-500">
              <strong>DEV</strong> — use qualquer senha não-vazia
              <br />
              admin@faustware.ao · gestor@faustware.ao · colaborador@faustware.ao
            </div>
          )}

          <p className="mt-6 text-center text-xs text-slate-400">
            © {new Date().getFullYear()} Faustware Systems & Solutions
          </p>
        </div>
      </div>
    </div>
  );
}
