import { SeedProvider } from '@/components/providers/seed-provider';
import type { ReactNode } from 'react';

export default function PortalLayout({ children }: { children: ReactNode }) {
  return (
    <SeedProvider>
      {children}
    </SeedProvider>
  );
}
