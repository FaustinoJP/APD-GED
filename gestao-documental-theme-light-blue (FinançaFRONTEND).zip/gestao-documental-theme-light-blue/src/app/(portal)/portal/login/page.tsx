﻿'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { Loader2, Building2, Eye, EyeOff } from 'lucide-react';
import { useAuthStore } from '@/store/auth-store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const schema = z.object({
  email: z.string().min(1, 'E-mail obrigatório').email('E-mail inválido'),
  senha: z.string().min(1, 'Palavra-passe obrigatória'),
});
type FormValues = z.infer<typeof schema>;

export default function PortalLoginPage() {
  const router = useRouter();
  const login = useAuthStore((s) => s.login);
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const hasHydrated = useAuthStore((s) => s._hasHydrated);
  const [showPassword, setShowPassword] = useState(false);
  const [serverError, setServerError] = useState('');

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormValues>({
    resolver: zodResolver(schema),
  });

  useEffect(() => {
    if (hasHydrated && isAuthenticated) router.replace('/portal');
  }, [hasHydrated, isAuthenticated, router]);

  async function onSubmit(values: FormValues) {
    setServerError('');
    const result = await login(values.email, values.senha);
    if (!result.ok) {
      setServerError(result.error ?? 'Erro ao autenticar.');
      return;
    }
    toast.success('Bem-vindo ao Portal!');
    router.push('/portal');
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-sky-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Logo */}
        <div className="text-center space-y-2">
          <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-sky-600 text-white mx-auto">
            <Building2 className="h-7 w-7" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900">Portal das Entidades</h1>
          <p className="text-sm text-slate-500">Acesso exclusivo para entidades externas</p>
        </div>

        {/* Form */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">E-mail</Label>
              <Input {...register('email')} type="email" placeholder="entidade@portal.ao" autoComplete="email" />
              {errors.email && <p className="text-xs text-red-500">{errors.email.message}</p>}
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">Palavra-passe</Label>
              <div className="relative">
                <Input {...register('senha')} type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••" autoComplete="current-password" />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {errors.senha && <p className="text-xs text-red-500">{errors.senha.message}</p>}
            </div>

            {serverError && (
              <div className="rounded-lg bg-red-50 border border-red-200 px-3 py-2 text-sm text-red-600">
                {serverError}
              </div>
            )}

            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Entrar no Portal
            </Button>
          </form>

          {/* Demo note */}
          <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 space-y-1">
            <p className="text-xs font-semibold text-slate-600">Credenciais de demonstração</p>
            <p className="text-xs text-slate-500 font-mono">entidade@portal.ao</p>
            <p className="text-xs text-slate-400">Palavra-passe: qualquer valor não vazio</p>
            <p className="text-xs text-slate-400 mt-1">
              (Necessário limpar localStorage p/ activar conta seed)
            </p>
          </div>
        </div>

        <p className="text-center text-xs text-slate-400">
          Acesso interno?{' '}
          <a href="/login" className="text-sky-600 hover:underline">Login administrativo</a>
        </p>
      </div>
    </div>
  );
}
