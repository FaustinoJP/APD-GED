﻿'use client';

import { useEffect, useMemo, useState } from 'react';
import { format, isPast, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useRouter } from 'next/navigation';
import {
  Building2, LogOut, Clock, FileText, Send, CheckCircle,
  ChevronDown, ChevronUp, AlertTriangle, Plus, Loader2,
} from 'lucide-react';
import { toast } from 'sonner';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DataTable, type ColumnDef } from '@/components/common/data-table';
import { CirculationResponsePanel } from '@/components/circulacao/circulation-response-panel';
import { useAuthStore } from '@/store/auth-store';
import {
  documentsRepo, circulationsRepo, documentTypesRepo,
  entitiesRepo, usersRepo, auditRepo, gerarNumeroDocumento,
} from '@/lib/db';
import type { Circulation, DocumentRecord, DocumentType, Entity, User } from '@/types';

// ─── Helpers ──────────────────────────────────────────────────────────────────

const ACAO_LABEL: Record<string, string> = {
  aprovar: 'Aprovação', assinar: 'Assinatura', parecer: 'Parecer',
  despachar: 'Despacho', deferir: 'Deferimento', verificar: 'Verificação',
  encaminhar_interno: 'Encaminhamento interno', encaminhar_externo: 'Encaminhamento externo',
};

const ACAO_COLOR: Record<string, string> = {
  aprovar: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  assinar: 'bg-purple-50 text-purple-700 border-purple-200',
  parecer: 'bg-blue-50 text-blue-700 border-blue-200',
  deferir: 'bg-teal-50 text-teal-700 border-teal-200',
  despachar: 'bg-sky-50 text-sky-700 border-sky-200',
  verificar: 'bg-amber-50 text-amber-700 border-amber-200',
  encaminhar_interno: 'bg-slate-50 text-slate-600 border-slate-200',
  encaminhar_externo: 'bg-slate-50 text-slate-600 border-slate-200',
};

const ESTADO_COLOR: Record<string, string> = {
  novo: 'bg-slate-50 text-slate-600 border-slate-200',
  em_circulacao: 'bg-amber-50 text-amber-700 border-amber-200',
  aprovado: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  rejeitado: 'bg-red-50 text-red-700 border-red-200',
  deferido: 'bg-teal-50 text-teal-700 border-teal-200',
  arquivado: 'bg-slate-100 text-slate-500 border-slate-200',
  concluido: 'bg-sky-50 text-sky-700 border-sky-200',
};

// ─── Submission form schema ────────────────────────────────────────────────────

const submitSchema = z.object({
  tipoDocumentoId: z.string().min(1, 'Tipo obrigatório'),
  assunto: z.string().min(3, 'Assunto obrigatório'),
  mensagem: z.string().optional(),
});
type SubmitValues = z.infer<typeof submitSchema>;

// ─── Main portal page ─────────────────────────────────────────────────────────

type PendingRow = {
  circ: Circulation;
  docNumero: string;
  docAssunto: string;
  isOverdue: boolean;
};

type DocRow = DocumentRecord & { tipoNome: string };

export default function PortalPage() {
  const router = useRouter();
  const currentUser = useAuthStore((s) => s.currentUser);
  const hasHydrated = useAuthStore((s) => s._hasHydrated);
  const logout = useAuthStore((s) => s.logout);

  // Auth redirect
  useEffect(() => {
    if (!hasHydrated) return;
    if (!currentUser) router.replace('/portal/login');
  }, [hasHydrated, currentUser, router]);

  // Data
  const [allDocs, setAllDocs] = useState<DocumentRecord[]>([]);
  const [allCircs, setAllCircs] = useState<Circulation[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [entities, setEntities] = useState<Entity[]>([]);
  const [docTypes, setDocTypes] = useState<DocumentType[]>([]);
  const [rev, setRev] = useState(0);

  // Selected pending circ for response panel
  const [selectedCircId, setSelectedCircId] = useState<string | null>(null);

  useEffect(() => {
    if (!currentUser) return;
    setAllDocs(documentsRepo.list());
    setAllCircs(circulationsRepo.list());
    setUsers(usersRepo.list());
    setEntities(entitiesRepo.list());
    setDocTypes(documentTypesRepo.list());
  }, [currentUser, rev]);

  function refresh() { setRev((n) => n + 1); setSelectedCircId(null); }

  function handleLogout() {
    logout();
    router.push('/portal/login');
  }

  // My pending circulations
  const pendingRows = useMemo<PendingRow[]>(() => {
    if (!currentUser) return [];
    return allCircs
      .filter((c) =>
        c.status === 'pendente' &&
        c.paraDestinatarios.some((d) => d.tipo === 'user' && d.id === currentUser.id),
      )
      .map((circ) => {
        const doc = allDocs.find((d) => d.id === circ.documentId);
        const isOverdue = !!circ.dataLimite && isPast(parseISO(circ.dataLimite));
        return {
          circ,
          docNumero: doc?.numero ?? '—',
          docAssunto: doc?.assunto ?? '—',
          isOverdue,
        };
      });
  }, [allCircs, allDocs, currentUser]);

  // My visible documents
  const myDocs = useMemo<DocRow[]>(() => {
    if (!currentUser) return [];
    const visible = allDocs.filter((d) =>
      d.criadoPor === currentUser.id ||
      d.destinatarios.some((dest) => dest.tipo === 'user' && dest.id === currentUser.id) ||
      d.remetenteId === currentUser.id,
    );
    return visible.map((d) => ({
      ...d,
      tipoNome: docTypes.find((t) => t.id === d.tipoDocumentoId)?.nome ?? '—',
    }));
  }, [allDocs, docTypes, currentUser]);

  // Submission form
  const { register, handleSubmit, reset, setValue, watch, formState: { errors, isSubmitting } } = useForm<SubmitValues>({
    resolver: zodResolver(submitSchema),
    defaultValues: { tipoDocumentoId: '', assunto: '', mensagem: '' },
  });
  const tipoId = watch('tipoDocumentoId');

  async function onSubmitDoc(values: SubmitValues) {
    if (!currentUser) return;
    const now = new Date().toISOString();
    const numero = gerarNumeroDocumento('entrada');
    documentsRepo.create({
      numero,
      tipoRegistro: 'entrada',
      tipoDocumentoId: values.tipoDocumentoId,
      assunto: values.assunto,
      remetenteId: currentUser.id,
      remetenteTexto: currentUser.nome,
      destinatarios: [],
      data: now,
      confidencial: false,
      estado: 'novo',
      camposValores: { mensagem: values.mensagem ?? '' },
      anexos: [],
      criadoPor: currentUser.id,
      criadoEm: now,
      atualizadoEm: now,
    });
    auditRepo.create({
      evento: 'cadastrado',
      tabela: 'documents',
      userId: currentUser.id,
      ip: '127.0.0.1',
      data: now,
      detalhe: `Entidade submeteu documento: "${values.assunto}" (${numero})`,
    });
    toast.success(`Documento ${numero} submetido com sucesso.`);
    reset();
    refresh();
  }

  // Pending columns
  const pendingCols = useMemo<ColumnDef<PendingRow>[]>(() => [
    {
      id: 'docNumero',
      header: 'Nº Documento',
      cell: (row) => <span className="text-xs font-mono font-semibold text-slate-700">{row.docNumero}</span>,
    },
    {
      id: 'docAssunto',
      header: 'Assunto',
      cell: (row) => <span className="text-xs text-slate-700 line-clamp-1">{row.docAssunto}</span>,
    },
    {
      id: 'acao',
      header: 'Tipo de Ação',
      cell: (row) => (
        <Badge variant="outline" className={`text-xs ${ACAO_COLOR[row.circ.acao] ?? ''}`}>
          {ACAO_LABEL[row.circ.acao] ?? row.circ.acao}
        </Badge>
      ),
    },
    {
      id: 'prazo',
      header: 'Prazo',
      cell: (row) => row.circ.dataLimite ? (
        <span className={`text-xs ${row.isOverdue ? 'text-red-600 font-semibold' : 'text-slate-500'}`}>
          {row.isOverdue && <AlertTriangle className="h-3 w-3 inline mr-0.5" />}
          {format(parseISO(row.circ.dataLimite), 'dd/MM/yyyy', { locale: ptBR })}
        </span>
      ) : <span className="text-xs text-slate-300">—</span>,
    },
    {
      id: 'acao_btn',
      header: 'Ação',
      cell: (row) => (
        <Button variant="ghost" size="sm" className="h-7 text-xs px-2 gap-1"
          onClick={() => setSelectedCircId(selectedCircId === row.circ.id ? null : row.circ.id)}>
          {selectedCircId === row.circ.id
            ? <><ChevronUp className="h-3 w-3" /> Fechar</>
            : <><ChevronDown className="h-3 w-3" /> Responder</>}
        </Button>
      ),
    },
  ], [selectedCircId]);

  // Doc columns
  const docCols = useMemo<ColumnDef<DocRow>[]>(() => [
    {
      id: 'numero',
      header: 'Número',
      cell: (row) => <span className="text-xs font-mono font-semibold text-slate-700">{row.numero}</span>,
    },
    {
      id: 'assunto',
      header: 'Assunto',
      cell: (row) => <span className="text-xs text-slate-700">{row.assunto}</span>,
    },
    {
      id: 'tipoNome',
      header: 'Tipo',
      cell: (row) => <span className="text-xs text-slate-500">{row.tipoNome}</span>,
    },
    {
      id: 'estado',
      header: 'Estado',
      cell: (row) => (
        <Badge variant="outline" className={`text-xs ${ESTADO_COLOR[row.estado] ?? ''}`}>
          {row.estado.replace(/_/g, ' ')}
        </Badge>
      ),
    },
    {
      id: 'data',
      header: 'Data',
      cell: (row) => (
        <span className="text-xs text-slate-500 whitespace-nowrap">
          {format(parseISO(row.criadoEm), 'dd/MM/yyyy', { locale: ptBR })}
        </span>
      ),
    },
  ], []);

  // Find selected pending circ
  const selectedPending = pendingRows.find((r) => r.circ.id === selectedCircId);

  if (!hasHydrated || !currentUser) {
    return (
      <div className="flex h-screen items-center justify-center bg-slate-50">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-sky-200 border-t-sky-600" />
      </div>
    );
  }

  const firstName = currentUser.nome.split(' ')[0];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Topbar */}
      <header className="h-14 border-b border-slate-200 bg-white sticky top-0 z-10 flex items-center px-6 gap-4">
        <div className="flex items-center gap-2.5">
          <div className="h-8 w-8 rounded-lg bg-sky-600 flex items-center justify-center">
            <Building2 className="h-4 w-4 text-white" />
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-800 leading-none">Portal das Entidades</p>
            <p className="text-[10px] text-slate-400 mt-0.5">Faustware · Gestão Documental</p>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <p className="text-xs font-medium text-slate-700">{currentUser.nome}</p>
            <p className="text-[10px] text-slate-400">{currentUser.email}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={handleLogout} className="gap-1.5 text-slate-500 text-xs">
            <LogOut className="h-3.5 w-3.5" /> Sair
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-5xl p-6 space-y-6">
        {/* Welcome */}
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-xl font-bold text-slate-900">Bem-vindo, {firstName}!</h1>
            <p className="text-sm text-slate-500 mt-0.5 capitalize">
              {format(new Date(), "EEEE, d 'de' MMMM 'de' yyyy", { locale: ptBR })}
            </p>
          </div>
          <div className="flex gap-3">
            <StatChip icon={<Clock className="h-4 w-4 text-amber-600" />}
              value={pendingRows.length} label="Pendentes" />
            <StatChip icon={<FileText className="h-4 w-4 text-sky-600" />}
              value={myDocs.length} label="Documentos" />
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="pendentes">
          <TabsList className="h-9">
            <TabsTrigger value="pendentes" className="text-xs gap-1.5">
              <Clock className="h-3.5 w-3.5" /> Pendentes
              {pendingRows.length > 0 && (
                <span className="ml-1 rounded-full bg-amber-500 text-white text-[10px] font-bold px-1.5 py-0.5 leading-none">
                  {pendingRows.length}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger value="documentos" className="text-xs gap-1.5">
              <FileText className="h-3.5 w-3.5" /> Todos os Documentos
            </TabsTrigger>
            <TabsTrigger value="submeter" className="text-xs gap-1.5">
              <Plus className="h-3.5 w-3.5" /> Submeter Documento
            </TabsTrigger>
          </TabsList>

          {/* Pendentes tab */}
          <TabsContent value="pendentes" className="mt-4 space-y-4">
            <DataTable
              columns={pendingCols}
              data={pendingRows}
              compact
              rowClassName={(row) => row.isOverdue ? 'bg-red-50/50' : ''}
              emptyState={
                <div className="py-10 text-center text-sm text-slate-400 space-y-1">
                  <CheckCircle className="h-8 w-8 text-emerald-300 mx-auto" />
                  <p>Sem pendências. Está em dia!</p>
                </div>
              }
            />

            {/* Response panel for selected circ */}
            {selectedPending && (
              <div className="rounded-xl border border-sky-200 bg-white overflow-hidden">
                <div className="px-4 py-3 bg-sky-50 border-b border-sky-100 flex items-center justify-between">
                  <p className="text-xs font-semibold text-sky-800">
                    A responder: {selectedPending.docNumero} — {ACAO_LABEL[selectedPending.circ.acao]}
                  </p>
                  <Button variant="ghost" size="sm" className="h-7 text-xs text-sky-600"
                    onClick={() => setSelectedCircId(null)}>
                    Fechar
                  </Button>
                </div>
                <CirculationResponsePanel
                  circ={selectedPending.circ}
                  users={users}
                  entities={entities}
                  onResponded={refresh}
                />
              </div>
            )}
          </TabsContent>

          {/* Documentos tab */}
          <TabsContent value="documentos" className="mt-4">
            <DataTable
              columns={docCols}
              data={myDocs}
              compact
              defaultPageSize={10}
              emptyState={
                <div className="py-10 text-center text-sm text-slate-400">
                  Nenhum documento associado a si.
                </div>
              }
            />
          </TabsContent>

          {/* Submeter tab */}
          <TabsContent value="submeter" className="mt-4">
            <div className="max-w-lg bg-white rounded-xl border border-slate-200 p-6 space-y-5">
              <div>
                <h3 className="text-sm font-semibold text-slate-800">Submeter Novo Documento</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  O documento será registado como Entrada e classificado pela equipa interna.
                </p>
              </div>

              <form onSubmit={handleSubmit(onSubmitDoc)} className="space-y-4">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">Tipo de Documento <span className="text-red-500">*</span></Label>
                  <Select value={tipoId} onValueChange={(v) => setValue('tipoDocumentoId', v)}>
                    <SelectTrigger className="h-9"><SelectValue placeholder="Selecionar tipo" /></SelectTrigger>
                    <SelectContent>
                      {docTypes.filter((t) => t.ativo).map((t) => (
                        <SelectItem key={t.id} value={t.id}>{t.nome}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.tipoDocumentoId && (
                    <p className="text-xs text-red-500">{errors.tipoDocumentoId.message}</p>
                  )}
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">Assunto <span className="text-red-500">*</span></Label>
                  <Input {...register('assunto')} className="text-sm" placeholder="Descreva o assunto do documento" />
                  {errors.assunto && <p className="text-xs text-red-500">{errors.assunto.message}</p>}
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">Mensagem / Descrição adicional</Label>
                  <Textarea {...register('mensagem')} className="text-sm resize-none" rows={4}
                    placeholder="Informações adicionais relevantes..." />
                </div>

                <div className="rounded-lg bg-amber-50 border border-amber-200 p-3 flex gap-2">
                  <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
                  <p className="text-xs text-amber-700">
                    Após submissão, o documento ficará pendente de classificação pela equipa.
                    Será notificado sobre o estado.
                  </p>
                </div>

                <Button type="submit" className="w-full gap-1.5" disabled={isSubmitting}>
                  {isSubmitting
                    ? <><Loader2 className="h-4 w-4 animate-spin" /> A submeter...</>
                    : <><Send className="h-4 w-4" /> Submeter Documento</>
                  }
                </Button>
              </form>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

function StatChip({ icon, value, label }: { icon: React.ReactNode; value: number; label: string }) {
  return (
    <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5">
      {icon}
      <div>
        <p className="text-lg font-bold text-slate-900 leading-none">{value}</p>
        <p className="text-[10px] text-slate-400 mt-0.5">{label}</p>
      </div>
    </div>
  );
}
