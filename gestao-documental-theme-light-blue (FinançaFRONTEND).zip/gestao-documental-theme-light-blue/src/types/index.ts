// ─── Navigation (shell) ──────────────────────────────────────────────────────

export interface NavItem {
  label: string;
  href: string;
  icon?: string;
  children?: NavItem[];
}

export interface NavGroup {
  label: string;
  items: NavItem[];
}

// ─── RBAC ────────────────────────────────────────────────────────────────────

export type Permission =
  | 'documents.create'
  | 'documents.read'
  | 'documents.update'
  | 'documents.delete'
  | 'documents.forward'
  | 'documents.sign'
  | 'documents.approve'
  | 'documents.giveOpinion'
  | 'documents.dispatch'
  | 'documents.defer'
  | 'documents.archive'
  | 'documents.export'
  | 'config.types.manage'
  | 'config.users.manage'
  | 'config.permissions.manage'
  | 'config.entities.manage'
  | 'config.templates.manage'
  | 'config.company.manage'
  | 'config.locations.manage'
  | 'audit.read'
  | 'exports.run'
  | 'files.manage'
  | 'notifications.read'
  | 'dashboard.view';

export const ALL_PERMISSIONS: Permission[] = [
  'documents.create',
  'documents.read',
  'documents.update',
  'documents.delete',
  'documents.forward',
  'documents.sign',
  'documents.approve',
  'documents.giveOpinion',
  'documents.dispatch',
  'documents.defer',
  'documents.archive',
  'documents.export',
  'config.types.manage',
  'config.users.manage',
  'config.permissions.manage',
  'config.entities.manage',
  'config.templates.manage',
  'config.company.manage',
  'config.locations.manage',
  'audit.read',
  'exports.run',
  'files.manage',
  'notifications.read',
  'dashboard.view',
];

export interface Role {
  id: string;
  nome: string;
  descricao: string;
  permissions: Permission[];
}

// ─── User ─────────────────────────────────────────────────────────────────────

export interface User {
  id: string;
  nome: string;
  email: string;
  avatarUrl?: string;
  roleId: string;
  ativo: boolean;
  criadoEm: string;
  senhaHash?: string;
  /** Campo transiente — apenas enviado na criação (POST). Nunca devolvido pelo backend. */
  senha?: string;
}

// ─── Document Types & Custom Fields ──────────────────────────────────────────

export type FieldType =
  | 'text'
  | 'number'
  | 'date'
  | 'select'
  | 'textarea'
  | 'boolean'
  | 'currency';

export interface CustomField {
  id: string;
  label: string;
  key: string;
  tipo: FieldType;
  obrigatorio: boolean;
  opcoes?: string[];
  ordem: number;
}

export type TipoRegistro = 'entrada' | 'saida' | 'interno';

export interface DocumentType {
  id: string;
  nome: string;
  descricao: string;
  registro: TipoRegistro | 'todos';
  campos: CustomField[];
  ativo: boolean;
}

// ─── Entities ─────────────────────────────────────────────────────────────────

export type TipoEntidade =
  | 'cliente'
  | 'fornecedor'
  | 'parceiro'
  | 'orgao'
  | 'outro';

export interface Entity {
  id: string;
  nome: string;
  tipo: TipoEntidade;
  email?: string;
  telefone?: string;
  endereco?: string;
  regiao?: string;
  localizacao?: string;
  criadoEm: string;
}

// ─── Documents ────────────────────────────────────────────────────────────────

export type EstadoDocumento =
  | 'novo'
  | 'em_circulacao'
  | 'aprovado'
  | 'rejeitado'
  | 'deferido'
  | 'arquivado'
  | 'concluido';

export interface Destinatario {
  tipo: 'user' | 'group' | 'entity';
  id: string;
}

export interface Attachment {
  id: string;
  nome: string;
  versao: number;
  estado: 'check_in' | 'check_out';
  tamanho: number;
  formato: string;
  url?: string;
  adicionadoPor: string;
  criadoEm: string;
  observacao?: string;
  /** Referência ao ficheiro original em memória. Nunca serializada para JSON/localStorage. */
  _file?: File;
}

export interface DocumentRecord {
  id: string;
  numero: string;
  tipoRegistro: TipoRegistro;
  tipoDocumentoId: string;
  assunto: string;
  remetenteId?: string;
  remetenteTexto?: string;
  destinatarios: Destinatario[];
  data: string;
  confidencial: boolean;
  /** Palavras-chave livres para facilitar a pesquisa avançada. */
  tags?: string[];
  estado: EstadoDocumento;
  regiao?: string;
  localizacao?: string;
  /** ID do nó mais profundo escolhido na árvore de localização física (ver LocationNode). */
  localizacaoFisicaId?: string;
  camposValores: Record<string, unknown>;
  anexos: Attachment[];
  criadoPor: string;
  criadoEm: string;
  atualizadoEm: string;
  dossierId?: string;
  funcionarioId?: string;
}

// ─── Funcionário ────────────────────────────────────────────────────────────────

export type EstadoFuncionario =
  | 'ativo'
  | 'reforma'
  | 'licenca'
  | 'suspenso'
  | 'exonerado'
  | 'falecido';

export interface Funcionario {
  id: string;
  nome: string;
  apelido: string;
  numeroProcesso: string;
  estado: EstadoFuncionario;
  dataNascimento: string;
  dataInicioFuncoes: string;
  dataFimFuncoes?: string;
  criadoEm: string;
  atualizadoEm: string;
}

// ─── Circulation ──────────────────────────────────────────────────────────────

export type AcaoCirculacao =
  | 'aprovar'
  | 'assinar'
  | 'parecer'
  | 'despachar'
  | 'deferir'
  | 'verificar'
  | 'encaminhar_interno'
  | 'encaminhar_externo';

export type DecisaoCirculacao =
  | 'aprovado'
  | 'rejeitado'
  | 'assinado'
  | 'nao_assinado'
  | 'parecer_dado'
  | 'deferido';

export interface CirculationResponse {
  id: string;
  circulationId: string;
  userId: string;
  decisao: DecisaoCirculacao;
  mensagem: string;
  assinaturaId?: string;
  signatureZoneId?: string;
  /** Todas as zonas assinadas nesta resposta: zoneId → assinaturaId (quando > 1 zona) */
  allSignedZones?: Record<string, string>;
  /** True when responder used the simulated digital certificate option */
  certificadoDigital?: boolean;
  criadoEm: string;
}

export interface Circulation {
  id: string;
  documentId: string;
  acao: AcaoCirculacao;
  deUserId: string;
  paraDestinatarios: Destinatario[];
  mensagem: string;
  dataLimite?: string;
  obrigatoriaTodos: boolean;
  enviarEmail: boolean;
  receberNotificacao: boolean;
  status: 'pendente' | 'respondido' | 'expirado';
  respostas: CirculationResponse[];
  /** Mapeamento zoneId → userId: quem assina cada zona. Definido ao encaminhar. */
  zoneAssignments?: Record<string, string>;
  criadoEm: string;
}

// ─── Signatures ───────────────────────────────────────────────────────────────

export type TipoAssinatura = 'desenho' | 'imagem' | 'digitada';

export interface Signature {
  id: string;
  userId: string;
  tipo: TipoAssinatura;
  dado: string;
  criadoEm: string;
}

// ─── Audit ────────────────────────────────────────────────────────────────────

export type EventoAuditoria =
  | 'visualizado'
  | 'cadastrado'
  | 'atualizado'
  | 'eliminado'
  | 'encaminhado'
  | 'assinado'
  | 'aprovado'
  | 'rejeitado'
  | 'exportado'
  | 'login';

export interface AuditLog {
  id: string;
  evento: EventoAuditoria;
  tabela: string;
  registroId?: string;
  userId: string;
  ip: string;
  data: string;
  detalhe?: string;
}

// ─── Localização Física (árvore configurável por entidade) ────────────────────

/** Define um "nível" da hierarquia de arquivo físico (ex: Sala, Corredor, Prateleira). */
export interface LocationLevel {
  id: string;
  nome: string;
  /** Posição do nível na hierarquia (0 = topo). */
  ordem: number;
}

/** Instância real da árvore (ex: "Sala A", "Corredor 2"). */
export interface LocationNode {
  id: string;
  nome: string;
  /** LocationLevel a que este nó pertence. */
  nivelId: string;
  /** Nó pai — ausente para nós de topo. */
  parentId?: string;
  /** Posição entre os irmãos. */
  ordem: number;
  criadoEm: string;
}

// ─── Folders & Dossiers ───────────────────────────────────────────────────────

export interface Folder {
  id: string;
  nome: string;
  parentId?: string;
  documentTypeId?: string;
  criadoEm: string;
}

export interface Dossier {
  id: string;
  nome: string;
  descricao?: string;
  documentos: string[];
}

// ─── Notifications ────────────────────────────────────────────────────────────

export interface Notification {
  id: string;
  userId: string;
  titulo: string;
  mensagem: string;
  lida: boolean;
  link?: string;
  criadoEm: string;
}

// ─── Document Templates ───────────────────────────────────────────────────────

export interface SignatureZone {
  id: string;
  label: string;
  x: number;
  y: number;
  width: number;
  height: number;
  obrigatoria: boolean;
  assignedRole?: string;
}

export interface WatermarkConfig {
  incluirNomeUtilizador: boolean;
  incluirDataHora: boolean;
  incluirEstadoDocumento: boolean;
  opacidade: number;
  texto?: string;
}

export interface DocumentTemplate {
  id: string;
  nome: string;
  descricao?: string;
  documentTypeId?: string;
  /** HTML content with {{placeholder}} variables */
  htmlContent: string;
  variaveis: string[];
  signatureZones: SignatureZone[];
  watermark: WatermarkConfig;
  versao: number;
  ativo: boolean;
  criadoEm: string;
}

// ─── Company Settings (singleton, stored as a single key) ─────────────────────

export interface CompanySettings {
  nome: string;
  nif?: string;
  email?: string;
  telefone?: string;
  website?: string;
  endereco?: string;
  /** dataURL of the company logo */
  logoUrl?: string;
}
