'use client';

import { useState } from 'react';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { StatusBadge } from '@/components/common/status-badge';
import { useDocumentsStore } from '@/store/documents-store';
import { auditRepo } from '@/lib/db';
import { useAuthStore } from '@/store/auth-store';
import type { DocumentRecord, EstadoDocumento } from '@/types';

const ESTADO_OPTIONS: Array<{ value: EstadoDocumento; label: string }> = [
  { value: 'novo', label: 'Novo' },
  { value: 'em_circulacao', label: 'Em Circulação' },
  { value: 'aprovado', label: 'Aprovado' },
  { value: 'rejeitado', label: 'Rejeitado' },
  { value: 'deferido', label: 'Deferido' },
  { value: 'arquivado', label: 'Arquivado' },
  { value: 'concluido', label: 'Concluído' },
];

interface StateChangeDialogProps {
  doc: DocumentRecord;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onChanged?: () => void;
}

/**
 * Dialog to change a document's estado with an optional justification message.
 * Persists the change via documentsStore and creates an AuditLog entry.
 */
export function StateChangeDialog({
  doc,
  open,
  onOpenChange,
  onChanged,
}: StateChangeDialogProps) {
  const update = useDocumentsStore((s) => s.update);
  const currentUser = useAuthStore((s) => s.currentUser);

  const [newState, setNewState] = useState<EstadoDocumento>(doc.estado);
  const [message, setMessage] = useState('');
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    if (newState === doc.estado) {
      toast.info('O estado não foi alterado.');
      return;
    }
    setSaving(true);
    try {
      update(doc.id, { estado: newState });
      auditRepo.create({
        evento: 'atualizado',
        tabela: 'documents',
        registroId: doc.id,
        userId: currentUser?.id ?? 'system',
        ip: '127.0.0.1',
        data: new Date().toISOString(),
        detalhe: `Estado alterado de "${doc.estado}" para "${newState}"${message ? ` — ${message}` : ''}`,
      });
      toast.success(`Estado alterado para "${ESTADO_OPTIONS.find((o) => o.value === newState)?.label}"`);
      onOpenChange(false);
      onChanged?.();
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Alterar Estado</DialogTitle>
          <DialogDescription>
            Documento <span className="font-semibold">{doc.numero}</span>
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Current state */}
          <div className="flex items-center justify-between rounded-lg bg-slate-50 px-4 py-3">
            <span className="text-sm text-slate-500">Estado actual</span>
            <StatusBadge status={doc.estado} />
          </div>

          {/* New state */}
          <div className="space-y-1.5">
            <Label className="text-xs font-medium text-slate-600">Novo Estado</Label>
            <Select
              value={newState}
              onValueChange={(v) => setNewState(v as EstadoDocumento)}
            >
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {ESTADO_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>
                    {o.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Justification */}
          <div className="space-y-1.5">
            <Label className="text-xs font-medium text-slate-600">
              Justificação <span className="text-slate-400">(opcional)</span>
            </Label>
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Motivo ou observação sobre esta alteração..."
              rows={3}
              className="text-sm resize-none"
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancelar
          </Button>
          <Button size="sm" onClick={handleSave} disabled={saving || newState === doc.estado} className="gap-1.5">
            {saving && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            Confirmar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
