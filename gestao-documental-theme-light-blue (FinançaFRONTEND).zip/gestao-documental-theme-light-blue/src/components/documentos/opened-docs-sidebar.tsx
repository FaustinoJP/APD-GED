﻿'use client';

import Link from 'next/link';
import { X, FolderOpen, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { useOpenedDocsStore } from '@/store/opened-docs-store';
import { useDocumentsStore } from '@/store/documents-store';

interface OpenedDocsSidebarProps {
  currentDocId?: string;
  className?: string;
}

/**
 * Sidebar panel listing documents opened in this browser session.
 * Each chip links to its detail page and can be individually dismissed.
 * Powered by useOpenedDocsStore (session-only, no persistence).
 *
 * @example
 * <OpenedDocsSidebar currentDocId={doc.id} />
 */
export function OpenedDocsSidebar({ currentDocId, className }: OpenedDocsSidebarProps) {
  const { ids, remove, clear } = useOpenedDocsStore();
  const docs = useDocumentsStore((s) => s.documents);

  const openedDocs = ids
    .map((id) => docs.find((d) => d.id === id))
    .filter(Boolean) as NonNullable<ReturnType<typeof docs.find>>[];

  if (openedDocs.length === 0) {
    return (
      <div
        className={cn(
          'rounded-xl border border-slate-200 bg-white p-4 shadow-xs',
          className,
        )}
      >
        <div className="flex items-center gap-2 mb-3">
          <FolderOpen className="h-3.5 w-3.5 text-slate-400" />
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
            Documentos Abertos
          </h3>
        </div>
        <p className="text-xs text-slate-400 text-center py-4">
          Nenhum documento aberto nesta sessão.
        </p>
      </div>
    );
  }

  return (
    <div
      className={cn(
        'rounded-xl border border-slate-200 bg-white shadow-xs overflow-hidden',
        className,
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between gap-2 px-4 py-3 border-b border-slate-100 bg-slate-50">
        <div className="flex items-center gap-2">
          <FolderOpen className="h-3.5 w-3.5 text-slate-400" />
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
            Documentos Abertos
          </h3>
          <span className="rounded-full bg-sky-100 px-1.5 py-0.5 text-[10px] font-semibold text-sky-700">
            {openedDocs.length}
          </span>
        </div>
        <Button
          variant="ghost"
          size="icon-xs"
          onClick={clear}
          title="Fechar todos"
          className="text-slate-400 hover:text-red-500"
        >
          <Trash2 className="h-3 w-3" />
        </Button>
      </div>

      {/* List */}
      <div className="p-2 space-y-1">
        {openedDocs.map((doc) => {
          const isCurrent = doc.id === currentDocId;
          return (
            <div
              key={doc.id}
              className={cn(
                'group flex items-center gap-2 rounded-md px-2 py-1.5 transition-colors',
                isCurrent
                  ? 'bg-sky-50 border border-sky-200'
                  : 'hover:bg-slate-50 border border-transparent',
              )}
            >
              <Link
                href={`/documentos/${doc.id}`}
                className="min-w-0 flex-1"
              >
                <p
                  className={cn(
                    'truncate text-xs font-semibold',
                    isCurrent ? 'text-sky-700' : 'text-slate-700',
                  )}
                >
                  {doc.numero}
                </p>
                <p className="truncate text-xs text-slate-400">{doc.assunto}</p>
              </Link>
              <button
                type="button"
                onClick={() => remove(doc.id)}
                title="Fechar"
                aria-label={`Fechar ${doc.numero}`}
                className="shrink-0 rounded p-0.5 text-slate-300 opacity-0 transition-opacity group-hover:opacity-100 hover:text-red-500"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          );
        })}
      </div>

      {/* Navigation hint */}
      <div className="border-t border-slate-100 px-3 py-2">
        <p className="text-[10px] text-slate-400">
          Navegue entre documentos clicando nos itens acima.
        </p>
      </div>
    </div>
  );
}
