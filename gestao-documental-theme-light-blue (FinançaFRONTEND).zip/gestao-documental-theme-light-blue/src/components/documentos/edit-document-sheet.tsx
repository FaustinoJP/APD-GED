'use client';

import { useEffect, useState } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { Save } from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetFooter,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { SectionCard } from '@/components/common/section-card';
import { ProvinceSelect } from '@/components/common/province-select';
import { LocationPicker } from '@/components/common/location-picker';
import { FieldRenderer } from '@/components/common/field-renderer';
import { TagInput } from '@/components/common/tag-input';
import { FuncionarioCombobox } from '@/components/common/funcionario-combobox';
import { RecipientSelector } from '@/components/registro/recipient-selector';
import { useDocumentsStore } from '@/store/documents-store';
import { useConfigStore } from '@/store/config-store';
import { useFuncionariosStore } from '@/store/funcionarios-store';
import type {
  Destinatario,
  DocumentRecord,
  EstadoDocumento,
  TipoRegistro,
} from '@/types';

const TIPO_REGISTRO_LABELS: Record<TipoRegistro, string> = {
  entrada: 'Entrada',
  saida: 'Saída',
  interno: 'Interno',
};

const ESTADO_LABELS: Record<EstadoDocumento, string> = {
  novo: 'Novo',
  em_circulacao: 'Em circulação',
  aprovado: 'Aprovado',
  rejeitado: 'Rejeitado',
  deferido: 'Deferido',
  arquivado: 'Arquivado',
  concluido: 'Concluído',
};

const NONE = '__none__';

const schema = z.object({
  tipoRegistro: z.enum(['entrada', 'saida', 'interno']),
  tipoDocumentoId: z.string().min(1, 'Selecione o tipo de documento'),
  assunto: z.string().min(3, 'Assunto obrigatório (mínimo 3 caracteres)'),
  data: z.string().min(1, 'Data obrigatória'),
  estado: z.enum([
    'novo', 'em_circulacao', 'aprovado', 'rejeitado', 'deferido', 'arquivado', 'concluido',
  ]),
  confidencial: z.boolean(),
  regiao: z.string().optional(),
  localizacaoFisicaId: z.string().optional(),
  remetenteTexto: z.string().optional(),
  funcionarioId: z.string().optional(),
});
type FormValues = z.infer<typeof schema>;

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  doc: DocumentRecord;
}

/** Reconstrói o remetente (Destinatario) a partir do remetenteId guardado. */
function remetenteFromDoc(
  doc: DocumentRecord,
  users: { id: string }[],
  entities: { id: string }[],
): Destinatario[] {
  if (!doc.remetenteId) return [];
  if (users.some((u) => u.id === doc.remetenteId)) {
    return [{ tipo: 'user', id: doc.remetenteId }];
  }
  if (entities.some((e) => e.id === doc.remetenteId)) {
    return [{ tipo: 'entity', id: doc.remetenteId }];
  }
  return [];
}

export function EditDocumentSheet({ open, onOpenChange, doc }: Props) {
  const updateDoc = useDocumentsStore((s) => s.update);
  const { documentTypes, users, entities, loaded: configLoaded, loadAll } = useConfigStore();
  const funcionarios = useFuncionariosStore((s) => s.funcionarios);
  const funcLoaded = useFuncionariosStore((s) => s.loaded);
  const loadFuncionarios = useFuncionariosStore((s) => s.load);

  useEffect(() => {
    if (!configLoaded) loadAll();
    if (!funcLoaded) loadFuncionarios();
  }, [configLoaded, loadAll, funcLoaded, loadFuncionarios]);

  // Estado fora do RHF (arrays / campos dinâmicos)
  const [destinatarios, setDestinatarios] = useState<Destinatario[]>(doc.destinatarios);
  const [remetente, setRemetente] = useState<Destinatario[]>([]);
  const [camposValores, setCamposValores] = useState<Record<string, unknown>>(doc.camposValores ?? {});
  const [tags, setTags] = useState<string[]>(doc.tags ?? []);

  const { register, handleSubmit, reset, setValue, watch, control, formState: { errors, isSubmitting } } =
    useForm<FormValues>({
      resolver: zodResolver(schema),
      defaultValues: {
        tipoRegistro: doc.tipoRegistro,
        tipoDocumentoId: doc.tipoDocumentoId,
        assunto: doc.assunto,
        data: doc.data,
        estado: doc.estado,
        confidencial: doc.confidencial,
        regiao: doc.regiao ?? '',
        localizacaoFisicaId: doc.localizacaoFisicaId ?? '',
        remetenteTexto: doc.remetenteTexto ?? '',
        funcionarioId: doc.funcionarioId ?? NONE,
      },
    });

  const confidencial = watch('confidencial');
  const tipoDocumentoId = watch('tipoDocumentoId');
  const funcionarioId = watch('funcionarioId');
  // Documentos internos não exigem participantes (remetente/destinatários)
  const isInterno = watch('tipoRegistro') === 'interno';

  const activeTypes = documentTypes.filter((dt) => dt.ativo);
  const selectedType = documentTypes.find((dt) => dt.id === tipoDocumentoId);

  // Re-popular tudo sempre que o doc muda ou o sheet abre
  useEffect(() => {
    if (!open) return;
    reset({
      tipoRegistro: doc.tipoRegistro,
      tipoDocumentoId: doc.tipoDocumentoId,
      assunto: doc.assunto,
      data: doc.data,
      estado: doc.estado,
      confidencial: doc.confidencial,
      regiao: doc.regiao ?? '',
      localizacaoFisicaId: doc.localizacaoFisicaId ?? '',
      remetenteTexto: doc.remetenteTexto ?? '',
      funcionarioId: doc.funcionarioId ?? NONE,
    });
    setDestinatarios(doc.destinatarios);
    setCamposValores(doc.camposValores ?? {});
    setTags(doc.tags ?? []);
    setRemetente(remetenteFromDoc(doc, users, entities));
  }, [open, doc, reset, users, entities]);

  // Ao mudar o tipo de documento, ajustar os campos dinâmicos preservando valores existentes
  useEffect(() => {
    setCamposValores((prev) => {
      if (!selectedType) return prev;
      const next: Record<string, unknown> = {};
      for (const campo of selectedType.campos) {
        next[campo.key] = prev[campo.key] ?? '';
      }
      return next;
    });
  }, [tipoDocumentoId, selectedType]);

  // Limpar remetenteTexto quando um remetente do sistema é selecionado
  useEffect(() => {
    if (remetente.length > 0) setValue('remetenteTexto', '');
  }, [remetente, setValue]);

  function onSubmit(values: FormValues) {
    if (!isInterno && destinatarios.length === 0) {
      toast.error('Adicione pelo menos um destinatário.');
      return;
    }

    // Resolver remetente
    let remetenteId: string | undefined;
    let remetenteTexto: string | undefined;
    if (remetente.length > 0) {
      const r = remetente[0];
      remetenteId = r.id;
      remetenteTexto =
        r.tipo === 'user'
          ? users.find((u) => u.id === r.id)?.nome
          : entities.find((e) => e.id === r.id)?.nome;
    } else if (values.remetenteTexto) {
      remetenteTexto = values.remetenteTexto;
    }

    const changes: Partial<DocumentRecord> = {
      tipoRegistro: values.tipoRegistro,
      tipoDocumentoId: values.tipoDocumentoId,
      assunto: values.assunto,
      data: values.data,
      estado: values.estado,
      confidencial: values.confidencial,
      regiao: values.regiao || undefined,
      localizacaoFisicaId: values.localizacaoFisicaId || undefined,
      remetenteId,
      remetenteTexto,
      destinatarios,
      tags,
      camposValores,
      funcionarioId: values.funcionarioId && values.funcionarioId !== NONE
        ? values.funcionarioId
        : undefined,
    };
    const updated = updateDoc(doc.id, changes);
    if (updated) {
      toast.success('Documento actualizado.');
      onOpenChange(false);
    } else {
      toast.error('Erro ao actualizar documento.');
    }
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-3xl overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Save className="h-4 w-4 text-sky-600" />
            Editar Documento — {doc.numero}
          </SheetTitle>
        </SheetHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="mt-6 space-y-4 px-3" noValidate>
          <SectionCard title="Dados do Documento">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Tipo de Registo</Label>
                  <Controller
                    control={control}
                    name="tipoRegistro"
                    render={({ field }) => (
                      <Select value={field.value} onValueChange={field.onChange}>
                        <SelectTrigger className="h-9 w-full"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {(Object.keys(TIPO_REGISTRO_LABELS) as TipoRegistro[]).map((t) => (
                            <SelectItem key={t} value={t}>{TIPO_REGISTRO_LABELS[t]}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">
                    Tipo de Documento <span className="text-red-500">*</span>
                  </Label>
                  <Controller
                    control={control}
                    name="tipoDocumentoId"
                    render={({ field }) => (
                      <Select value={field.value} onValueChange={field.onChange}>
                        <SelectTrigger className="h-9 w-full"><SelectValue placeholder="Selecionar tipo..." /></SelectTrigger>
                        <SelectContent>
                          {activeTypes.map((dt) => (
                            <SelectItem key={dt.id} value={dt.id}>{dt.nome}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  />
                  {errors.tipoDocumentoId && (
                    <p className="text-xs text-red-500">{errors.tipoDocumentoId.message}</p>
                  )}
                </div>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-slate-600">
                  Assunto <span className="text-red-500">*</span>
                </Label>
                <Textarea
                  {...register('assunto')}
                  rows={2}
                  className="text-sm resize-none"
                  placeholder="Assunto do documento"
                />
                {errors.assunto && (
                  <p className="text-xs text-red-500">{errors.assunto.message}</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">
                    Data do Documento <span className="text-red-500">*</span>
                  </Label>
                  <Input {...register('data')} type="date" className="text-sm" />
                  {errors.data && (
                    <p className="text-xs text-red-500">{errors.data.message}</p>
                  )}
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium text-slate-600">Estado</Label>
                  <Controller
                    control={control}
                    name="estado"
                    render={({ field }) => (
                      <Select value={field.value} onValueChange={field.onChange}>
                        <SelectTrigger className="h-9 w-full"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {(Object.keys(ESTADO_LABELS) as EstadoDocumento[]).map((e) => (
                            <SelectItem key={e} value={e}>{ESTADO_LABELS[e]}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  />
                </div>
              </div>
            </div>
          </SectionCard>

          <SectionCard title="Funcionário" description="Vincule este documento ao processo de um funcionário.">
            <Controller
              control={control}
              name="funcionarioId"
              render={({ field }) => (
                <FuncionarioCombobox
                  funcionarios={funcionarios}
                  value={field.value || NONE}
                  onChange={field.onChange}
                />
              )}
            />
            {funcionarioId && funcionarioId !== NONE && (
              <p className="mt-2 text-xs text-slate-400">
                Este documento aparecerá na ficha do funcionário selecionado.
              </p>
            )}
          </SectionCard>

          <SectionCard title="Palavras-chave" description="Facilitam a localização do documento na pesquisa avançada.">
            <TagInput
              value={tags}
              onChange={setTags}
              placeholder="Adicionar palavra-chave e premir Enter..."
            />
          </SectionCard>

          {!isInterno && (
            <SectionCard title="Participantes">
              <div className="space-y-5">
                <div className="space-y-2">
                  <Label className="text-xs font-medium text-slate-600">Remetente</Label>
                  <RecipientSelector
                    value={remetente}
                    onChange={setRemetente}
                    users={users}
                    entities={entities}
                    single
                  />
                  <div className="flex items-center gap-2 py-1">
                    <div className="h-px flex-1 bg-slate-200" />
                    <span className="text-xs text-slate-400">ou texto livre</span>
                    <div className="h-px flex-1 bg-slate-200" />
                  </div>
                  <Input
                    {...register('remetenteTexto')}
                    placeholder="Nome ou entidade remetente..."
                    className="h-8 text-sm"
                    disabled={remetente.length > 0}
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-xs font-medium text-slate-600">Destinatários <span className="text-red-500">*</span></Label>
                  <RecipientSelector
                    value={destinatarios}
                    onChange={setDestinatarios}
                    users={users}
                    entities={entities}
                  />
                </div>
              </div>
            </SectionCard>
          )}

          {selectedType && selectedType.campos.length > 0 && (
            <SectionCard
              title={`Campos: ${selectedType.nome}`}
              description="Campos específicos deste tipo de documento"
            >
              <div className="grid grid-cols-2 gap-4">
                {[...selectedType.campos]
                  .sort((a, b) => a.ordem - b.ordem)
                  .map((campo) => (
                    <div key={campo.key} className={campo.tipo === 'textarea' ? 'col-span-2' : ''}>
                      <FieldRenderer
                        field={campo}
                        value={camposValores[campo.key]}
                        onChange={(v) => setCamposValores((prev) => ({ ...prev, [campo.key]: v }))}
                      />
                    </div>
                  ))}
              </div>
            </SectionCard>
          )}

          <SectionCard title="Região">
            <div className="max-w-sm space-y-1.5">
              <Label className="text-xs font-medium text-slate-600">Região</Label>
              <Controller
                control={control}
                name="regiao"
                render={({ field }) => (
                  <ProvinceSelect
                    value={field.value ?? ''}
                    onChange={field.onChange}
                    placeholder="Selecionar província..."
                  />
                )}
              />
            </div>
          </SectionCard>

          <SectionCard title="Localização Física" description="Onde o documento está fisicamente arquivado">
            <Controller
              control={control}
              name="localizacaoFisicaId"
              render={({ field }) => (
                <LocationPicker
                  value={field.value || undefined}
                  onChange={(v) => field.onChange(v ?? '')}
                />
              )}
            />
          </SectionCard>

          <SectionCard title="Classificação">
            <div className="flex items-center gap-3 rounded-lg border border-slate-100 bg-slate-50 px-4 py-3">
              <Switch
                checked={confidencial}
                onCheckedChange={(v) => setValue('confidencial', v)}
              />
              <div>
                <p className="text-xs font-medium">Documento confidencial</p>
                <p className="text-xs text-slate-400">
                  Documentos confidenciais têm acesso restrito.
                </p>
              </div>
            </div>
          </SectionCard>

          <SheetFooter className="mt-4 pt-4 border-t border-slate-100 gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              Cancelar
            </Button>
            <Button type="submit" size="sm" disabled={isSubmitting} className="gap-1.5">
              <Save className="h-3.5 w-3.5" />
              Guardar Alterações
            </Button>
          </SheetFooter>
        </form>
      </SheetContent>
    </Sheet>
  );
}
