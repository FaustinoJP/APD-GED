﻿'use client';

import { useCallback, useState } from 'react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Eye, Download, FileText, FileSpreadsheet, File } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { resolveFileUrl } from '@/lib/file-url';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { FileDropZone } from '@/components/registro/file-drop-zone';
import { FilePreview } from '@/components/common/file-preview';
import { useDocumentsStore } from '@/store/documents-store';
import { auditRepo } from '@/lib/db';
import { useAuthStore } from '@/store/auth-store';
import { apiAddAnexo, apiRemoveAnexo } from '@/lib/api/documents';
import type { Attachment, DocumentRecord } from '@/types';

const IS_API_MODE = process.env.NEXT_PUBLIC_DATA_SOURCE === 'api';

interface AttachmentManagerProps {
  doc: DocumentRecord;
  readonly?: boolean;
  onUpdate?: () => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function FileIconCell({ format: fmt }: { format: string }) {
  if (fmt === 'pdf') return <FileText className="h-4 w-4 text-red-500" />;
  if (['doc', 'docx'].includes(fmt)) return <FileText className="h-4 w-4 text-blue-500" />;
  if (['xls', 'xlsx'].includes(fmt)) return <FileSpreadsheet className="h-4 w-4 text-green-600" />;
  return <File className="h-4 w-4 text-slate-400" />;
}

function EstadoBadge({ estado }: { estado: Attachment['estado'] }) {
  return (
    <Badge
      variant="outline"
      className={cn(
        'text-xs',
        estado === 'check_in'
          ? 'border-emerald-300 bg-emerald-50 text-emerald-700'
          : 'border-amber-300 bg-amber-50 text-amber-700',
      )}
    >
      {estado === 'check_in' ? 'Check-in' : 'Check-out'}
    </Badge>
  );
}

/**
 * Attachment table with upload area and file preview dialog.
 * Shows all attachments for a DocumentRecord and allows adding new ones.
 *
 * @example
 * <AttachmentManager doc={doc} onUpdate={() => reload()} />
 */
export function AttachmentManager({ doc, readonly = false, onUpdate }: AttachmentManagerProps) {
  const update = useDocumentsStore((s) => s.update);
  const currentUser = useAuthStore((s) => s.currentUser);
  const [previewAtt, setPreviewAtt] = useState<Attachment | null>(null);

  const handleAddAttachment = useCallback(
    (att: Attachment) => {
      if (IS_API_MODE && att._file) {
        // Modo API: upload directo via POST /documents/:id/anexos
        void (async () => {
          try {
            const updatedDoc = await apiAddAnexo(doc.id, att._file!, {
              nome: att.nome !== att._file!.name ? att.nome : undefined,
              observacao: att.observacao,
            });
            // Actualizar store com os dados devolvidos pelo servidor (URL real, não base64)
            update(doc.id, { anexos: updatedDoc.anexos });
            auditRepo.create({
              evento: 'atualizado',
              tabela: 'documents',
              registroId: doc.id,
              userId: currentUser?.id ?? 'system',
              ip: '127.0.0.1',
              data: new Date().toISOString(),
              detalhe: `Anexo adicionado: ${att.nome}`,
            });
            toast.success(`Ficheiro "${att.nome}" adicionado.`);
            onUpdate?.();
          } catch {
            toast.error(`Erro ao adicionar "${att.nome}".`);
          }
        })();
      } else {
        // Modo localStorage: actualizar store directamente
        const updatedDoc = update(doc.id, { anexos: [...doc.anexos, att] });
        if (updatedDoc) {
          auditRepo.create({
            evento: 'atualizado',
            tabela: 'documents',
            registroId: doc.id,
            userId: currentUser?.id ?? 'system',
            ip: '127.0.0.1',
            data: new Date().toISOString(),
            detalhe: `Anexo adicionado: ${att.nome}`,
          });
          toast.success(`Ficheiro "${att.nome}" adicionado.`);
          onUpdate?.();
        }
      }
    },
    [doc.id, doc.anexos, update, currentUser, onUpdate],
  );

  const handleRemoveAttachment = useCallback(
    (attId: string) => {
      const att = doc.anexos.find((a) => a.id === attId);
      if (IS_API_MODE) {
        // Modo API: DELETE /documents/:id/anexos/:anexoId
        void (async () => {
          try {
            await apiRemoveAnexo(doc.id, attId);
            update(doc.id, { anexos: doc.anexos.filter((a) => a.id !== attId) });
            if (att) {
              auditRepo.create({
                evento: 'eliminado',
                tabela: 'documents',
                registroId: doc.id,
                userId: currentUser?.id ?? 'system',
                ip: '127.0.0.1',
                data: new Date().toISOString(),
                detalhe: `Anexo removido: ${att.nome}`,
              });
            }
            onUpdate?.();
          } catch {
            toast.error('Erro ao remover o ficheiro.');
          }
        })();
      } else {
        // Modo localStorage: actualizar store directamente
        update(doc.id, { anexos: doc.anexos.filter((a) => a.id !== attId) });
        if (att) {
          auditRepo.create({
            evento: 'eliminado',
            tabela: 'documents',
            registroId: doc.id,
            userId: currentUser?.id ?? 'system',
            ip: '127.0.0.1',
            data: new Date().toISOString(),
            detalhe: `Anexo removido: ${att.nome}`,
          });
        }
        onUpdate?.();
      }
    },
    [doc.id, doc.anexos, update, currentUser, onUpdate],
  );

  return (
    <div className="space-y-4">
      {/* Table */}
      {doc.anexos.length > 0 ? (
        <div className="overflow-x-auto rounded-lg border border-slate-200">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                {[
                  'Nome',
                  'Versão',
                  'Estado',
                  'Observação',
                  'Tamanho',
                  'Formato',
                  'Adicionado por',
                  'Adicionado em',
                  '',
                ].map((h) => (
                  <th
                    key={h}
                    className="px-3 py-2 text-left text-xs font-semibold uppercase tracking-wide text-slate-500 whitespace-nowrap"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-100">
              {doc.anexos.map((att) => (
                <tr key={att.id} className="hover:bg-slate-50 transition-colors">
                  {/* Nome */}
                  <td className="px-3 py-2.5">
                    <button
                      type="button"
                      onClick={() => setPreviewAtt(att)}
                      className="flex items-center gap-2 text-left hover:text-sky-600 transition-colors"
                    >
                      <FileIconCell format={att.formato} />
                      <span className="max-w-[200px] truncate text-sm font-medium">
                        {att.nome}
                      </span>
                    </button>
                  </td>
                  {/* Versão */}
                  <td className="px-3 py-2.5 text-xs text-slate-500">v{att.versao}</td>
                  {/* Estado */}
                  <td className="px-3 py-2.5">
                    <EstadoBadge estado={att.estado} />
                  </td>
                  {/* Observação */}
                  <td className="px-3 py-2.5">
                    <span className="max-w-[160px] truncate text-xs text-slate-500 block">
                      {att.observacao ?? '—'}
                    </span>
                  </td>
                  {/* Tamanho */}
                  <td className="px-3 py-2.5 text-xs text-slate-500 whitespace-nowrap">
                    {formatBytes(att.tamanho)}
                  </td>
                  {/* Formato */}
                  <td className="px-3 py-2.5">
                    <Badge variant="outline" className="text-xs uppercase">
                      {att.formato}
                    </Badge>
                  </td>
                  {/* Adicionado por */}
                  <td className="px-3 py-2.5 text-xs text-slate-500 whitespace-nowrap">
                    {att.adicionadoPor}
                  </td>
                  {/* Adicionado em */}
                  <td className="px-3 py-2.5 text-xs text-slate-500 whitespace-nowrap">
                    {format(parseISO(att.criadoEm), 'dd/MM/yyyy', { locale: ptBR })}
                  </td>
                  {/* Ações */}
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-1">
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon-xs"
                        onClick={() => setPreviewAtt(att)}
                        title="Visualizar"
                        className="text-slate-400 hover:text-sky-600"
                      >
                        <Eye className="h-3.5 w-3.5" />
                      </Button>
                      {att.url && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon-xs"
                          asChild
                          title="Descarregar"
                          className="text-slate-400 hover:text-emerald-600"
                        >
                          <a href={resolveFileUrl(att.url)} download={att.nome}>
                            <Download className="h-3.5 w-3.5" />
                          </a>
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="py-4 text-center text-sm text-slate-400">
          Nenhum ficheiro anexado.
        </p>
      )}

      {/* Upload zone */}
      {!readonly && (
        <div className="rounded-lg border-2 border-dashed border-slate-200 p-1">
          <p className="pb-2 text-center text-xs font-medium text-slate-500">
            Arraste novos anexos para esta área
          </p>
          <FileDropZone
            attachments={[]}
            onAdd={handleAddAttachment}
            onRemove={handleRemoveAttachment}
            currentUserId={currentUser?.id ?? 'system'}
          />
        </div>
      )}

      {/* Preview dialog */}
      <Dialog open={!!previewAtt} onOpenChange={(o) => !o && setPreviewAtt(null)}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-sm">
              <FileText className="h-4 w-4" />
              {previewAtt?.nome}
            </DialogTitle>
          </DialogHeader>
          {previewAtt && (
            <div className="h-[60vh]">
              <FilePreview attachment={previewAtt} maxHeight="55vh" />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
