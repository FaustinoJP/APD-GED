'use client';

import { useEffect, useState } from 'react';
import { Loader2, Mail, Send } from 'lucide-react';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { RecipientSelector } from '@/components/registro/recipient-selector';
import { EmailPreviewDialog } from '@/components/circulacao/email-preview-dialog';
import { useCirculationStore } from '@/store/circulation-store';
import { useConfigStore } from '@/store/config-store';
import { useAuthStore } from '@/store/auth-store';
import type { AcaoCirculacao, Circulation, Destinatario, DocumentRecord, DocumentTemplate } from '@/types';

type ForwardVariant = 'pendencia' | 'interno' | 'externo';

interface AcaoOption {
  value: AcaoCirculacao;
  label: string;
  group: string;
  variant: ForwardVariant[];
}

const ACAO_OPTIONS: AcaoOption[] = [
  { value: 'aprovar',   label: 'Aprovação',              group: 'Ação Pendência', variant: ['pendencia'] },
  { value: 'assinar',   label: 'Assinatura CC',           group: 'Ação Pendência', variant: ['pendencia'] },
  { value: 'verificar', label: 'Verificação',             group: 'Ação Pendência', variant: ['pendencia'] },
  { value: 'parecer',   label: 'Parecer',                 group: 'Ação Pendência', variant: ['pendencia'] },
  { value: 'despachar', label: 'Despacho',                group: 'Ação Pendência', variant: ['pendencia'] },
  { value: 'deferir',   label: 'Deferimento',             group: 'Ação Pendência', variant: ['pendencia'] },
  { value: 'encaminhar_interno', label: 'Dentro da instituição', group: 'Encaminhamento', variant: ['interno'] },
  { value: 'encaminhar_externo', label: 'Para exterior',         group: 'Encaminhamento', variant: ['externo'] },
];

interface ForwardDialogProps {
  doc: DocumentRecord;
  template?: DocumentTemplate;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaultAction?: AcaoCirculacao;
  onForwarded?: (circ: Circulation) => void;
}

/**
 * Dialog to forward a document — supports all ação types, enviar e-mail toggle,
 * and shows EmailPreviewDialog when e-mail is enabled.
 */
export function ForwardDialog({
  doc,
  template,
  open,
  onOpenChange,
  defaultAction,
  onForwarded,
}: ForwardDialogProps) {
  const forward = useCirculationStore((s) => s.forward);
  const { users, entities } = useConfigStore();
  const currentUser = useAuthStore((s) => s.currentUser);

  const [acao, setAcao] = useState<AcaoCirculacao>(defaultAction ?? 'aprovar');
  const [destinatarios, setDestinatarios] = useState<Destinatario[]>([]);
  const [mensagem, setMensagem] = useState('');
  const [dataLimite, setDataLimite] = useState('');
  const [obrigatoriaTodos, setObrigatoriaTodos] = useState(false);
  const [receberNotif, setReceberNotif] = useState(true);
  const [enviarEmail, setEnviarEmail] = useState(false);
  const [saving, setSaving] = useState(false);
  const [zoneAssignments, setZoneAssignments] = useState<Record<string, string>>({});
  const [emailPreview, setEmailPreview] = useState<{ open: boolean; circ: Circulation | null }>({
    open: false,
    circ: null,
  });

  useEffect(() => {
    if (defaultAction) setAcao(defaultAction);
  }, [defaultAction]);

  useEffect(() => {
    if (open) {
      setDestinatarios([]);
      setMensagem('');
      setDataLimite('');
      setObrigatoriaTodos(false);
      setZoneAssignments({});
    }
  }, [open]);

  const variant: ForwardVariant =
    acao === 'encaminhar_interno' ? 'interno'
    : acao === 'encaminhar_externo' ? 'externo'
    : 'pendencia';

  // For exterior encaminhamento, allow only entities; for interno only users
  const filteredUsers = variant === 'externo' ? [] : users;
  const filteredEntities = variant === 'interno' ? [] : entities;

  async function handleSubmit() {
    if (destinatarios.length === 0) {
      toast.error('Selecione pelo menos um destinatário.');
      return;
    }
    setSaving(true);
    try {
      const circ = forward({
        documentId: doc.id,
        documentNumero: doc.numero,
        acao,
        paraDestinatarios: destinatarios,
        mensagem,
        dataLimite: dataLimite || undefined,
        obrigatoriaTodos,
        enviarEmail,
        receberNotificacao: receberNotif,
        zoneAssignments: Object.keys(zoneAssignments).length > 0 ? zoneAssignments : undefined,
      });

      const acaoLabel = ACAO_OPTIONS.find((o) => o.value === acao)?.label ?? acao;
      toast.success(
        `Documento encaminhado para ${destinatarios.length} destinatário(s) — ${acaoLabel}`,
      );

      onOpenChange(false);
      onForwarded?.(circ);

      if (enviarEmail) {
        setEmailPreview({ open: true, circ });
      }
    } finally {
      setSaving(false);
    }
  }

  const recipientNames = destinatarios
    .map((d) => {
      if (d.tipo === 'user') return users.find((u) => u.id === d.id)?.nome ?? d.id;
      if (d.tipo === 'entity') return entities.find((e) => e.id === d.id)?.nome ?? d.id;
      return d.id;
    });

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Send className="h-4 w-4 text-sky-600" />
              Encaminhar Documento
            </DialogTitle>
            <DialogDescription>
              {doc.numero} — {doc.assunto}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-1">
            {/* Ação */}
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-slate-600">
                Ação <span className="text-red-500">*</span>
              </Label>
              <Select value={acao} onValueChange={(v) => setAcao(v as AcaoCirculacao)}>
                <SelectTrigger className="h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectLabel>Ação Pendência</SelectLabel>
                    {ACAO_OPTIONS.filter((o) => o.group === 'Ação Pendência').map((o) => (
                      <SelectItem key={o.value} value={o.value}>
                        {o.label}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                  <SelectGroup>
                    <SelectLabel>Encaminhamento</SelectLabel>
                    {ACAO_OPTIONS.filter((o) => o.group === 'Encaminhamento').map((o) => (
                      <SelectItem key={o.value} value={o.value}>
                        {o.label}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
              {variant === 'externo' && (
                <p className="text-[11px] text-amber-600">
                  Encaminhamento externo: apenas entidades externas disponíveis como destinatário.
                </p>
              )}
              {variant === 'interno' && (
                <p className="text-[11px] text-sky-500">
                  Encaminhamento interno: apenas utilizadores da instituição.
                </p>
              )}
            </div>

            {/* Destinatários */}
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-slate-600">
                Destinatários <span className="text-red-500">*</span>
              </Label>
              <RecipientSelector
                value={destinatarios}
                onChange={setDestinatarios}
                users={filteredUsers}
                entities={filteredEntities}
              />
            </div>

            {/* Atribuição de zonas — apenas para acao=assinar quando o template tem zonas */}
            {acao === 'assinar' && (template?.signatureZones?.length ?? 0) > 0 && destinatarios.length > 0 && (
              <div className="space-y-2 rounded-lg border border-sky-100 bg-sky-50 px-4 py-3">
                <p className="text-xs font-semibold text-sky-700">Atribuição de Zonas de Assinatura</p>
                <p className="text-[11px] text-sky-500">
                  Defina quem assina em cada zona. Deixe em branco para qualquer destinatário.
                </p>
                {template!.signatureZones!.map((zone) => (
                  <div key={zone.id} className="flex items-center gap-2">
                    <Label className="text-xs text-slate-600 w-36 shrink-0">{zone.label}</Label>
                    <Select
                      value={zoneAssignments[zone.id] ?? '__any__'}
                      onValueChange={(uid) =>
                        setZoneAssignments((prev) => {
                          if (uid === '__any__') {
                            // eslint-disable-next-line @typescript-eslint/no-unused-vars
                            const { [zone.id]: _removed, ...rest } = prev;
                            return rest;
                          }
                          return { ...prev, [zone.id]: uid };
                        })
                      }
                    >
                      <SelectTrigger className="h-8 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__any__">— Qualquer destinatário —</SelectItem>
                        {destinatarios
                          .filter((d) => d.tipo === 'user')
                          .map((d) => (
                            <SelectItem key={d.id} value={d.id}>
                              {users.find((u) => u.id === d.id)?.nome ?? d.id}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>
                ))}
              </div>
            )}

            {/* Mensagem */}
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-slate-600">Mensagem / Instrução</Label>
              <Textarea
                value={mensagem}
                onChange={(e) => setMensagem(e.target.value)}
                placeholder="Instruções ou observações para os destinatários..."
                rows={3}
                className="text-sm resize-none"
              />
            </div>

            {/* Data limite */}
            <div className="space-y-1.5">
              <Label className="text-xs font-medium text-slate-600">
                Data Limite <span className="text-slate-400">(opcional)</span>
              </Label>
              <input
                type="date"
                value={dataLimite}
                onChange={(e) => setDataLimite(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                className="h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1"
              />
            </div>

            {/* Toggles */}
            <div className="space-y-2 rounded-lg border border-slate-100 bg-slate-50 px-4 py-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-700">Obrigatório de todos</p>
                  <p className="text-xs text-slate-500">Todos os destinatários devem responder</p>
                </div>
                <Switch checked={obrigatoriaTodos} onCheckedChange={setObrigatoriaTodos} />
              </div>

              <div className="flex items-center justify-between border-t border-slate-200 pt-2">
                <div>
                  <p className="text-sm font-medium text-slate-700">Receber notificação</p>
                  <p className="text-xs text-slate-500">Notificar ao receber resposta</p>
                </div>
                <Switch checked={receberNotif} onCheckedChange={setReceberNotif} />
              </div>

              <div className="flex items-center justify-between border-t border-slate-200 pt-2">
                <div className="flex items-center gap-2">
                  <Mail className="h-3.5 w-3.5 text-slate-400" />
                  <div>
                    <p className="text-sm font-medium text-slate-700">Enviar e-mail</p>
                    <p className="text-xs text-slate-500">Notificar destinatários por e-mail</p>
                  </div>
                </div>
                <Switch checked={enviarEmail} onCheckedChange={setEnviarEmail} />
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" size="sm" onClick={() => onOpenChange(false)} disabled={saving}>
              Cancelar
            </Button>
            <Button
              size="sm"
              onClick={handleSubmit}
              disabled={saving || destinatarios.length === 0}
              className="gap-1.5"
            >
              {saving ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Send className="h-3.5 w-3.5" />
              )}
              Encaminhar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Email preview shown post-forward if enviarEmail was on */}
      {emailPreview.circ && (
        <EmailPreviewDialog
          open={emailPreview.open}
          onOpenChange={(o) => setEmailPreview((s) => ({ ...s, open: o }))}
          circulation={emailPreview.circ}
          doc={doc}
          sender={users.find((u) => u.id === currentUser?.id)}
          recipients={recipientNames}
        />
      )}
    </>
  );
}
