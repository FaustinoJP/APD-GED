'use client';

import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import type { WatermarkConfig } from '@/types';

interface WatermarkProps {
  utilizadorNome?: string;
  estadoDocumento?: string;
  config: WatermarkConfig;
}

const ESTADO_PT: Record<string, string> = {
  novo: 'NOVO',
  em_circulacao: 'EM CIRCULAÇÃO',
  aprovado: 'APROVADO',
  rejeitado: 'REJEITADO',
  deferido: 'DEFERIDO',
  arquivado: 'ARQUIVADO',
  concluido: 'CONCLUÍDO',
};

function escapeXml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function buildDataUrl(lines: string[]): string {
  const w = 420;
  const h = 280;
  const lineH = 34;
  const totalTextH = lines.length * lineH;
  const startY = (h - totalTextH) / 2 + lineH * 0.75;

  const texts = lines
    .map(
      (line, i) =>
        `<text x="${w / 2}" y="${startY + i * lineH}"
          font-family="Arial,Helvetica,sans-serif"
          font-size="15"
          fill="#000000"
          text-anchor="middle"
          font-weight="700"
          letter-spacing="0.5">${escapeXml(line)}</text>`,
    )
    .join('\n');

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">
    <g transform="rotate(-35,${w / 2},${h / 2})">${texts}</g>
  </svg>`;

  return `data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(svg)))}`;
}

export function Watermark({ utilizadorNome = '', estadoDocumento = '', config }: WatermarkProps) {
  const lines: string[] = [];
  if (config.incluirNomeUtilizador && utilizadorNome) lines.push(utilizadorNome);
  if (config.incluirDataHora) {
    lines.push(format(new Date(), "dd/MM/yyyy HH:mm", { locale: ptBR }));
  }
  if (config.incluirEstadoDocumento && estadoDocumento) {
    lines.push(ESTADO_PT[estadoDocumento] ?? estadoDocumento.toUpperCase());
  }
  if (config.texto) lines.push(config.texto);

  if (lines.length === 0) return null;

  const dataUrl = buildDataUrl(lines);
  const opacity = config.opacidade ?? 0.08;

  return (
    <div
      aria-hidden="true"
      style={{
        position: 'absolute',
        inset: 0,
        backgroundImage: `url("${dataUrl}")`,
        backgroundRepeat: 'repeat',
        backgroundSize: '420px 280px',
        opacity,
        pointerEvents: 'none',
        zIndex: 10,
      }}
    />
  );
}

/** Generates the watermark CSS+HTML snippet for injection into a printable HTML string. */
export function buildWatermarkPrintSnippet(
  config: WatermarkConfig,
  utilizadorNome: string,
  estadoDocumento: string,
): { css: string; html: string } {
  const lines: string[] = [];
  if (config.incluirNomeUtilizador && utilizadorNome) lines.push(utilizadorNome);
  if (config.incluirDataHora) {
    lines.push(format(new Date(), "dd/MM/yyyy HH:mm", { locale: ptBR }));
  }
  if (config.incluirEstadoDocumento && estadoDocumento) {
    lines.push(ESTADO_PT[estadoDocumento] ?? estadoDocumento.toUpperCase());
  }
  if (config.texto) lines.push(config.texto);

  if (lines.length === 0) return { css: '', html: '' };

  const dataUrl = buildDataUrl(lines);
  const opacity = config.opacidade ?? 0.08;

  const css = `.gd-wm{position:fixed;inset:0;background-image:url("${dataUrl}");background-repeat:repeat;background-size:420px 280px;opacity:${opacity};pointer-events:none;z-index:9999;}`;
  const html = '<div class="gd-wm" aria-hidden="true"></div>';
  return { css, html };
}
