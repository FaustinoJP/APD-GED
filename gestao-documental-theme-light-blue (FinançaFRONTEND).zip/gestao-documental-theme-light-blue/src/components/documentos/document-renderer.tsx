'use client';

import { useCallback, useRef, useState } from 'react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { PenLine, Printer, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Watermark, buildWatermarkPrintSnippet } from './watermark';
import { SignatureDialog } from '@/components/circulacao/signature-dialog';
import { resolveFileUrl } from '@/lib/file-url';
import type {
  DocumentRecord,
  DocumentTemplate,
  CompanySettings,
  User,
  Entity,
  SignatureZone,
} from '@/types';

// ── Types ──────────────────────────────────────────────────────────────────────

export interface SignedZoneData {
  dado: string;
  userId: string;
  criadoEm: string;
}

interface DocumentRendererProps {
  doc: DocumentRecord;
  template: DocumentTemplate;
  mode: 'preview' | 'sign' | 'print';
  company: CompanySettings;
  currentUser: User | null;
  currentUserRoleName?: string;
  users: User[];
  entities: Entity[];
  signedZones?: Record<string, SignedZoneData>;
  onZoneSigned?: (zoneId: string, data: SignedZoneData) => void;
  /** IDs das zonas que o utilizador actual pode assinar. undefined = todas (legado). */
  assignedZoneIds?: string[];
}

// ── Placeholder substitution ────────────────────────────────────────────────────

const ESTADO_PT: Record<string, string> = {
  novo: 'NOVO',
  em_circulacao: 'EM CIRCULAÇÃO',
  aprovado: 'APROVADO',
  rejeitado: 'REJEITADO',
  deferido: 'DEFERIDO',
  arquivado: 'ARQUIVADO',
  concluido: 'CONCLUÍDO',
};

const CAMPO_ALIAS: Record<string, string> = {
  tipoContrato: 'tipo_contrato',
  valorMensal: 'valor',
  mesReferencia: 'mes_referencia',
  totalBruto: 'total_bruto',
  tipoImposto: 'tipo_imposto',
  periodo: 'periodo',
  valorPagar: 'valor_pagar',
  valorContrato: 'valor',
  prazoVigencia: 'prazo_vigencia',
  objetoContrato: 'objeto_contrato',
};

function fmtCurrency(val: unknown): string {
  if (val == null || val === '') return '—';
  const n = Number(val);
  if (isNaN(n)) return String(val);
  return n.toLocaleString('pt-AO', { minimumFractionDigits: 2 });
}

function substitutePlaceholders(
  html: string,
  doc: DocumentRecord,
  company: CompanySettings,
  user: User | null,
  roleName: string | undefined,
  firstDestinatarioNome: string,
): string {
  const safeDate = (iso: string) => {
    try { return format(parseISO(iso), 'dd/MM/yyyy', { locale: ptBR }); }
    catch { return iso; }
  };

  const map: Record<string, string> = {
    '{{empresa_nome}}': company.nome || '—',
    '{{empresa_nif}}': company.nif || '—',
    '{{empresa_endereco}}': company.endereco || '—',
    '{{empresa_logo}}': resolveFileUrl(company.logoUrl) || '',
    '{{nr_documento}}': doc.numero,
    '{{data_documento}}': safeDate(doc.data),
    '{{assunto}}': doc.assunto,
    '{{remetente_nome}}': doc.remetenteTexto || '—',
    '{{destinatario_nome}}': firstDestinatarioNome,
    '{{utilizador_nome}}': user?.nome || '—',
    '{{utilizador_cargo}}': roleName || '—',
    '{{data_hora_impressao}}': format(new Date(), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR }),
    '{{estado_documento}}': ESTADO_PT[doc.estado] ?? doc.estado.toUpperCase(),
    // default empties (overridden below by camposValores)
    '{{mes_referencia}}': '—',
    '{{total_bruto}}': '—',
    '{{salario_base}}': '—',
    '{{subsidios}}': '—',
    '{{descontos}}': '—',
    '{{liquido_pagar}}': '—',
    '{{tipo_imposto}}': '—',
    '{{periodo}}': '—',
    '{{valor_pagar}}': '—',
    '{{base_tributavel}}': '—',
    '{{taxa}}': '—',
    '{{valor}}': '—',
    '{{tipo_contrato}}': '—',
    '{{prazo_vigencia}}': '—',
    '{{objeto_contrato}}': '—',
  };

  // Map custom field values using aliases
  for (const [key, raw] of Object.entries(doc.camposValores)) {
    const alias = CAMPO_ALIAS[key] ?? key;
    const ph = `{{${alias}}}`;
    // currency fields get formatted
    const isCurrency = ['valor', 'total_bruto', 'valor_pagar', 'valor_mensal', 'liquido_pagar'].includes(alias);
    map[ph] = isCurrency ? fmtCurrency(raw) : (raw == null ? '—' : String(raw));
  }

  // Special date parsing for mesReferencia
  const mesRef = doc.camposValores['mesReferencia'];
  if (mesRef) {
    try {
      const d = parseISO(String(mesRef));
      map['{{mes_referencia}}'] = format(d, "MMMM 'de' yyyy", { locale: ptBR });
    } catch { /* keep default */ }
  }

  // Special date parsing for prazoVigencia
  const prazo = doc.camposValores['prazoVigencia'];
  if (prazo) {
    try {
      map['{{prazo_vigencia}}'] = format(parseISO(String(prazo)), 'dd/MM/yyyy', { locale: ptBR });
    } catch { /* keep default */ }
  }

  let result = html;
  for (const [ph, val] of Object.entries(map)) {
    result = result.replaceAll(ph, val);
  }
  return result;
}

// ── SignatureZoneOverlay ────────────────────────────────────────────────────────

interface ZoneOverlayProps {
  zone: SignatureZone;
  mode: 'preview' | 'sign' | 'print';
  signed?: SignedZoneData;
  active: boolean;
  locked?: boolean;
  onClick?: () => void;
}

function SignatureZoneOverlay({ zone, mode, signed, active, locked, onClick }: ZoneOverlayProps) {
  const base: React.CSSProperties = {
    position: 'absolute',
    left: `${zone.x}%`,
    top: `${zone.y}%`,
    width: `${zone.width}%`,
    height: `${zone.height}%`,
    zIndex: 20,
    boxSizing: 'border-box',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  };

  if (signed) {
    return (
      <div style={base}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={resolveFileUrl(signed.dado)}
          alt={zone.label}
          style={{ maxHeight: '55%', maxWidth: '85%', objectFit: 'contain' }}
        />
        <div style={{ marginTop: 3, textAlign: 'center' }}>
          <div style={{ fontSize: 8, fontWeight: 700, color: '#334155' }}>{zone.label}</div>
          <div style={{ fontSize: 7, color: '#64748b' }}>
            {format(parseISO(signed.criadoEm), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
          </div>
        </div>
      </div>
    );
  }

  if (mode === 'print') {
    return (
      <div
        style={{
          ...base,
          border: '1px dashed #94a3b8',
          justifyContent: 'flex-end',
          paddingBottom: 4,
        }}
      >
        <span style={{ fontSize: 8, color: '#94a3b8' }}>{zone.label}</span>
      </div>
    );
  }

  if (locked) {
    return (
      <div
        style={{
          ...base,
          border: '2px dashed #cbd5e1',
          backgroundColor: 'rgba(226,232,240,0.6)',
          gap: 4,
        }}
      >
        <PenLine style={{ width: 14, height: 14, color: '#94a3b8' }} />
        <span style={{ fontSize: 8, color: '#94a3b8', fontWeight: 700 }}>{zone.label}</span>
        <span style={{ fontSize: 7, color: '#cbd5e1' }}>Aguardando outro signatário</span>
      </div>
    );
  }

  const isSign = mode === 'sign';
  return (
    <button
      type="button"
      onClick={onClick}
      title={isSign ? `Clique para assinar: ${zone.label}` : zone.label}
      style={{
        ...base,
        border: `2px dashed ${active ? '#4f46e5' : '#94a3b8'}`,
        backgroundColor: active ? 'rgba(79,70,229,0.08)' : 'rgba(241,245,249,0.75)',
        cursor: isSign ? 'pointer' : 'default',
        gap: 4,
        transition: 'border-color .15s, background-color .15s',
      }}
    >
      {signed ? (
        <CheckCircle2 style={{ width: 14, height: 14, color: '#10b981' }} />
      ) : (
        <PenLine style={{ width: 14, height: 14, color: active ? '#4f46e5' : '#94a3b8' }} />
      )}
      <span style={{ fontSize: 8, color: active ? '#4f46e5' : '#94a3b8', fontWeight: 700 }}>
        {zone.label}
      </span>
      {isSign && !signed && (
        <span style={{ fontSize: 7, color: '#cbd5e1' }}>
          {zone.obrigatoria ? 'Obrigatória' : 'Opcional'}
        </span>
      )}
      {mode === 'preview' && (
        <span style={{ fontSize: 7, color: '#94a3b8', background: '#f1f5f9', padding: '1px 5px', borderRadius: 2, marginTop: 2 }}>
          Pendente
        </span>
      )}
    </button>
  );
}

// ── DocumentRenderer ───────────────────────────────────────────────────────────

export function DocumentRenderer({
  doc,
  template,
  mode,
  company,
  currentUser,
  currentUserRoleName,
  users,
  entities,
  signedZones = {},
  onZoneSigned,
  assignedZoneIds,
}: DocumentRendererProps) {
  const [activeZoneId, setActiveZoneId] = useState<string | null>(null);
  const [iframeHeight, setIframeHeight] = useState(1160);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const firstDestinatario = (() => {
    const d = doc.destinatarios[0];
    if (!d) return '—';
    if (d.tipo === 'user') return users.find((u) => u.id === d.id)?.nome ?? '—';
    if (d.tipo === 'entity') return entities.find((e) => e.id === d.id)?.nome ?? '—';
    return d.id;
  })();

  const processedHtml = substitutePlaceholders(
    template.htmlContent,
    doc,
    company,
    currentUser,
    currentUserRoleName,
    firstDestinatario,
  );

  const handleIframeLoad = useCallback(() => {
    try {
      const iframe = iframeRef.current;
      if (!iframe?.contentDocument?.body) return;
      const h = iframe.contentDocument.body.scrollHeight;
      if (h > 200) setIframeHeight(h + 20);
    } catch { /* cross-origin guard */ }
  }, []);

  function handlePrint() {
    let printHtml = processedHtml;
    if (template.watermark) {
      const { css, html } = buildWatermarkPrintSnippet(
        template.watermark,
        currentUser?.nome ?? '',
        doc.estado,
      );
      if (css) {
        printHtml = printHtml
          .replace('</head>', `<style>${css}</style></head>`)
          .replace('</body>', `${html}</body>`);
      }
    }
    const win = window.open('', '_blank');
    if (!win) return;
    win.document.write(printHtml);
    win.document.close();
    win.focus();
    setTimeout(() => { win.print(); win.close(); }, 600);
  }

  const zones = template.signatureZones ?? [];

  return (
    <div className="flex flex-col gap-3">
      {/* Toolbar */}
      <div className="flex items-center gap-2">
        <Button type="button" variant="outline" size="sm" onClick={handlePrint} className="gap-1.5">
          <Printer className="h-3.5 w-3.5" />
          Imprimir
        </Button>
        {mode === 'sign' && zones.some((z) => !signedZones[z.id]) && (
          <span className="text-xs text-slate-500">
            Clique numa zona de assinatura para assinar
          </span>
        )}
        {mode === 'sign' && zones.length > 0 && zones.every((z) => !z.obrigatoria || signedZones[z.id]) && (
          <span className="text-xs font-medium text-emerald-600 flex items-center gap-1">
            <CheckCircle2 className="h-3.5 w-3.5" />
            Todas as zonas obrigatórias assinadas
          </span>
        )}
      </div>

      {/* A4 document wrapper — position:relative so zones are anchored here */}
      <div
        className="relative bg-white shadow-md mx-auto overflow-hidden"
        style={{ width: 794, minHeight: iframeHeight }}
      >
        {/* HTML content in isolated iframe */}
        <iframe
          ref={iframeRef}
          srcDoc={processedHtml}
          title={`Documento ${doc.numero}`}
          style={{ width: '100%', height: iframeHeight, border: 'none', display: 'block' }}
          sandbox="allow-same-origin"
          onLoad={handleIframeLoad}
        />

        {/* Watermark overlay */}
        {template.watermark && (
          <Watermark
            utilizadorNome={currentUser?.nome}
            estadoDocumento={doc.estado}
            config={template.watermark}
          />
        )}

        {/* Signature zones */}
        {zones.map((zone) => {
          const isAssignedToMe = !assignedZoneIds || assignedZoneIds.includes(zone.id);
          const isAlreadySigned = !!signedZones[zone.id];
          const canClick = mode === 'sign' && !isAlreadySigned && isAssignedToMe;
          const isLocked = mode === 'sign' && !isAssignedToMe && !isAlreadySigned;
          return (
            <SignatureZoneOverlay
              key={zone.id}
              zone={zone}
              mode={mode}
              signed={signedZones[zone.id]}
              active={activeZoneId === zone.id}
              locked={isLocked}
              onClick={canClick ? () => setActiveZoneId(zone.id) : undefined}
            />
          );
        })}
      </div>

      {/* Signature dialog — opened when a zone is clicked in sign mode */}
      {mode === 'sign' && (
        <SignatureDialog
          open={!!activeZoneId}
          onOpenChange={(open) => { if (!open) setActiveZoneId(null); }}
          onConfirm={(result) => {
            if (!activeZoneId || !currentUser) return;
            onZoneSigned?.(activeZoneId, {
              dado: result.dado,
              userId: currentUser.id,
              criadoEm: new Date().toISOString(),
            });
            setActiveZoneId(null);
          }}
        />
      )}
    </div>
  );
}
