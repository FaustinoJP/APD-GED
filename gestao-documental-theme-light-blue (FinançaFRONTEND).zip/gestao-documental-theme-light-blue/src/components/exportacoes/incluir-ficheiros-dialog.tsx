'use client';

import { FileSpreadsheet, FolderArchive } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface IncluirFicheirosDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Nº de ficheiros anexos descarregáveis. */
  count: number;
  /** Tamanho total estimado dos anexos, em bytes. */
  bytes: number;
  /** Está a gerar o ZIP (bloqueia os botões). */
  loading?: boolean;
  /** Utilizador optou por descarregar só o Excel. */
  onlyExcel: () => void;
  /** Utilizador optou por descarregar o ZIP (Excel + ficheiros). */
  withFiles: () => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

/**
 * Pergunta ao utilizador se, além do Excel, quer descarregar também os
 * ficheiros anexos (empacotados num ZIP organizado por tipo/categoria).
 */
export function IncluirFicheirosDialog({
  open,
  onOpenChange,
  count,
  bytes,
  loading = false,
  onlyExcel,
  withFiles,
}: IncluirFicheirosDialogProps) {
  return (
    <Dialog open={open} onOpenChange={(v) => { if (!loading) onOpenChange(v); }}>
      <DialogContent showCloseButton={!loading}>
        <DialogHeader>
          <DialogTitle>Incluir os ficheiros anexos?</DialogTitle>
          <DialogDescription>
            Esta exportação tem <strong>{count}</strong> ficheiro(s) anexo(s)
            (~{formatBytes(bytes)}). Pode descarregar apenas a planilha Excel ou um
            ficheiro ZIP com a planilha e os ficheiros organizados por tipo de documento.
          </DialogDescription>
        </DialogHeader>

        <DialogFooter>
          <Button variant="outline" onClick={onlyExcel} disabled={loading} className="gap-1.5">
            <FileSpreadsheet className="h-4 w-4" />
            Só Excel
          </Button>
          <Button onClick={withFiles} disabled={loading} className="gap-1.5">
            <FolderArchive className="h-4 w-4" />
            {loading ? 'A gerar ZIP…' : 'Excel + ficheiros (ZIP)'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
