"use client";

import { useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Clock,
  Search,
  FileInput,
  FileOutput,
  FileSymlink,
  FolderOpen,
  Settings,
  Tag,
  LayoutTemplate,
  Building2,
  Users,
  Contact,
  ShieldCheck,
  Globe,
  Lock,
  Download,
  ChevronLeft,
  ChevronRight,
  Archive,
  MapPin,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { resolveFileUrl } from "@/lib/file-url";
import { useUiStore } from "@/store/ui-store";
import { useAuthStore } from "@/store/auth-store";
import { usePermissions } from "@/hooks/use-permissions";
import { useCirculationStore } from "@/store/circulation-store";
import type { Permission } from "@/types";

interface NavItem {
  label: string;
  href: string;
  icon: React.ReactNode;
  permission?: Permission;
}

interface NavGroup {
  label: string;
  items: NavItem[];
}

const navGroups: NavGroup[] = [
  {
    label: "DASHBOARDS",
    items: [
      {
        label: "Geral",
        href: "/",
        icon: <LayoutDashboard className="h-4 w-4" />,
        permission: "dashboard.view",
      },
      {
        label: "Funcionários",
        href: "/configuracoes/funcionarios",
        icon: <Contact className="h-4 w-4" />,
        permission: "config.users.manage",
      },
      {
        label: "Pendentes",
        href: "/pendentes",
        icon: <Clock className="h-4 w-4" />,
        permission: "documents.read",
      },
    ],
  },
  {
    label: "DOCUMENTOS",
    items: [
      {
        label: "Pesquisar Documentos",
        href: "/pesquisas/documentos",
        icon: <Search className="h-4 w-4" />,
        permission: "documents.read",
      },
      {
        label: "Entradas",
        href: "/registro/entradas",
        icon: <FileInput className="h-4 w-4" />,
        permission: "documents.create",
      },
      {
        label: "Saídas",
        href: "/registro/saidas",
        icon: <FileOutput className="h-4 w-4" />,
        permission: "documents.create",
      },
      {
        label: "Internos",
        href: "/registro/internos",
        icon: <FileSymlink className="h-4 w-4" />,
        permission: "documents.create",
      },
      {
        label: "Gerenciador de Arquivos",
        href: "/arquivos",
        icon: <FolderOpen className="h-4 w-4" />,
        permission: "files.manage",
      },
      {
        label: "Localização Física",
        href: "/localizacao-fisica",
        icon: <Archive className="h-4 w-4" />,
        permission: "files.manage",
      },
      {
        label: "Exportações",
        href: "/exportacoes",
        icon: <Download className="h-4 w-4" />,
        permission: "exports.run",
      },
    ],
  },
  {
    label: "DADOS",
    items: [
      {
        label: "Tipos",
        href: "/configuracoes/tipos",
        icon: <Tag className="h-4 w-4" />,
        permission: "config.types.manage",
      },
      {
        label: "Templates",
        href: "/configuracoes/templates",
        icon: <LayoutTemplate className="h-4 w-4" />,
        permission: "config.templates.manage",
      },
      {
        label: "Entidades",
        href: "/configuracoes/entidades",
        icon: <Building2 className="h-4 w-4" />,
        permission: "config.entities.manage",
      },
      {
        label: "Utilizadores",
        href: "/configuracoes/utilizadores",
        icon: <Users className="h-4 w-4" />,
        permission: "config.users.manage",
      },
      {
        label: "Auditoria",
        href: "/configuracoes/auditoria",
        icon: <ShieldCheck className="h-4 w-4" />,
        permission: "audit.read",
      },
      {
        label: "Empresa",
        href: "/configuracoes/empresa",
        icon: <Globe className="h-4 w-4" />,
        permission: "config.company.manage",
      },
      {
        label: "Localização Física",
        href: "/configuracoes/localizacao",
        icon: <MapPin className="h-4 w-4" />,
        permission: "config.locations.manage",
      },
      {
        label: "Permissões",
        href: "/configuracoes/permissoes",
        icon: <Lock className="h-4 w-4" />,
        permission: "config.permissions.manage",
      },
    ],
  },
];

function getInitials(nome: string): string {
  return nome
    .split(" ")
    .slice(0, 2)
    .map((n) => n[0]?.toUpperCase() ?? "")
    .join("");
}

export function Sidebar() {
  const pathname = usePathname();
  const { sidebarCollapsed, toggleSidebar } = useUiStore();
  const currentUser = useAuthStore((s) => s.currentUser);
  const currentRole = useAuthStore((s) => s.currentRole);
  const { can } = usePermissions();
  const { pendingCirculations, loadPending } = useCirculationStore();

  useEffect(() => {
    if (currentUser?.id) loadPending(currentUser.id);
  }, [currentUser?.id, loadPending]);

  const pendingCount = pendingCirculations.length;
  const isCollapsed = sidebarCollapsed;

  return (
    <aside
      className={cn(
        "relative flex h-screen flex-col bg-slate-950 text-slate-100 transition-all duration-300",
        isCollapsed ? "w-16" : "w-64",
      )}
    >
      {/* Logo / Brand */}
      <div className="flex h-14 items-center border-b border-slate-800 px-4">
        <div
          className={cn(
            "flex items-center gap-2 overflow-hidden",
            isCollapsed && "justify-center",
          )}
        >
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-sky-500 text-white font-bold text-sm">
            F
          </div>
          {!isCollapsed && (
            <div className="flex flex-col leading-tight">
              <span className="text-xs font-bold tracking-tight text-white">Faustware Systems</span>
              <span className="text-[10px] text-slate-400 tracking-wide">&amp; Solutions</span>
            </div>
          )}
        </div>
      </div>

      {/* User info */}
      {!isCollapsed && currentUser && (
        <div className="flex items-center gap-3 border-b border-slate-800 px-4 py-3">
          {currentUser.avatarUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={resolveFileUrl(currentUser.avatarUrl)}
              alt={currentUser.nome}
              className="h-8 w-8 rounded-full object-cover shrink-0"
            />
          ) : (
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-sky-400 text-xs font-semibold text-white">
              {getInitials(currentUser.nome)}
            </div>
          )}
          <div className="overflow-hidden">
            <p className="truncate text-sm font-medium text-slate-100">{currentUser.nome}</p>
            <p className="truncate text-xs text-slate-400">{currentRole?.nome ?? "—"}</p>
          </div>
        </div>
      )}

      {/* Collapsed user avatar */}
      {isCollapsed && currentUser && (
        <div className="flex items-center justify-center border-b border-slate-800 py-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-sky-400 text-xs font-semibold text-white">
            {getInitials(currentUser.nome)}
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-3 scrollbar-thin">
        {navGroups.map((group) => {
          const visibleItems = group.items.filter(
            (item) => !item.permission || can(item.permission),
          );
          if (visibleItems.length === 0) return null;
          return (
            <div key={group.label} className="mb-4">
              {!isCollapsed && (
                <p className="mb-1 px-4 text-[10px] font-semibold uppercase tracking-widest text-slate-500">
                  {group.label}
                </p>
              )}
              <ul className="space-y-0.5 px-2">
                {visibleItems.map((item) => {
                  const isActive =
                    item.href === "/"
                      ? pathname === "/"
                      : pathname.startsWith(item.href);
                  return (
                    <li key={item.href}>
                      <Link
                        href={item.href}
                        title={isCollapsed ? item.label : undefined}
                        className={cn(
                          "flex items-center gap-3 rounded-md px-2 py-2 text-sm font-medium transition-colors",
                          isActive
                            ? "bg-sky-500 text-white"
                            : "text-slate-400 hover:bg-slate-800 hover:text-slate-100",
                          isCollapsed && "justify-center",
                        )}
                      >
                        <span className="relative shrink-0">
                          {item.icon}
                          {item.href === "/pendentes" && pendingCount > 0 && isCollapsed && (
                            <span className="absolute -right-1 -top-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-amber-500 text-[8px] font-bold text-white">
                              {pendingCount > 9 ? "9+" : pendingCount}
                            </span>
                          )}
                        </span>
                        {!isCollapsed && (
                          <>
                            <span className="truncate flex-1">{item.label}</span>
                            {item.href === "/pendentes" && pendingCount > 0 && (
                              <span className="shrink-0 rounded-full bg-amber-500 px-1.5 py-0.5 text-[10px] font-bold text-white">
                                {pendingCount}
                              </span>
                            )}
                          </>
                        )}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
      </nav>

      {/* Collapse toggle */}
      <div className="border-t border-slate-800 p-2">
        <button
          onClick={toggleSidebar}
          className="flex w-full items-center justify-center gap-2 rounded-md py-2 text-slate-400 hover:bg-slate-800 hover:text-slate-100 transition-colors"
          aria-label={isCollapsed ? "Expandir sidebar" : "Recolher sidebar"}
        >
          {isCollapsed ? (
            <ChevronRight className="h-4 w-4" />
          ) : (
            <>
              <ChevronLeft className="h-4 w-4" />
              <span className="text-xs">Recolher</span>
            </>
          )}
        </button>
      </div>
    </aside>
  );
}
