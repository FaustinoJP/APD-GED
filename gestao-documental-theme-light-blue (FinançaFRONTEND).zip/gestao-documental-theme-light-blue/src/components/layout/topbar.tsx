"use client";

import { useEffect, useRef, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import {
  Search,
  Bell,
  Maximize2,
  ChevronRight,
  LogOut,
  User,
  Settings,
  FlaskConical,
  ChevronDown,
  X,
  CheckCheck,
  FileText,
  MapPin,
  HelpCircle,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { formatDistanceToNow, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";
import { resolveFileUrl } from "@/lib/file-url";
import { cn } from "@/lib/utils";
import { useAuthStore } from "@/store/auth-store";
import { useNotificationStore } from "@/store/notification-store";
import { documentsRepo, usersRepo, funcionariosRepo } from "@/lib/db";
import type { DocumentRecord } from "@/types";

// ─── Route labels ─────────────────────────────────────────────────────────────

const routeLabels: Record<string, string> = {
  "/": "Dashboard Geral",
  "/pendentes": "Pendentes",
  "/pesquisas/documentos": "Pesquisar Documentos",
  "/registro/entradas": "Entradas",
  "/registro/saidas": "Saídas",
  "/registro/internos": "Internos",
  "/arquivos": "Gerenciador de Arquivos",
  "/exportacoes": "Exportações",
  "/configuracoes/tipos": "Tipos",
  "/configuracoes/templates": "Templates",
  "/configuracoes/entidades": "Entidades",
  "/configuracoes/utilizadores": "Utilizadores",
  "/configuracoes/auditoria": "Auditoria",
  "/configuracoes/empresa": "Empresa",
  "/configuracoes/permissoes": "Permissões",
};

// ─── Breadcrumb ───────────────────────────────────────────────────────────────

function Breadcrumb({ pathname }: { pathname: string }) {
  const segments = pathname.split("/").filter(Boolean);
  const label =
    routeLabels[pathname] ?? segments[segments.length - 1] ?? "Dashboard";

  return (
    <nav className="flex items-center gap-1 text-sm text-slate-500">
      <span className="font-medium text-slate-700">Faustware</span>
      {segments.map((seg, i) => (
        <span key={i} className="flex items-center gap-1">
          <ChevronRight className="h-3.5 w-3.5 text-slate-400" />
          <span
            className={cn(
              i === segments.length - 1
                ? "font-semibold text-slate-900"
                : "text-slate-500 capitalize",
            )}
          >
            {i === segments.length - 1
              ? label
              : seg.charAt(0).toUpperCase() + seg.slice(1)}
          </span>
        </span>
      ))}
      {segments.length === 0 && (
        <span className="flex items-center gap-1">
          <ChevronRight className="h-3.5 w-3.5 text-slate-400" />
          <span className="font-semibold text-slate-900">Dashboard Geral</span>
        </span>
      )}
    </nav>
  );
}

// ─── Global search ────────────────────────────────────────────────────────────

function GlobalSearch() {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<DocumentRecord[]>([]);
  const [locResults, setLocResults] = useState<string[]>([]);
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const q = query.trim().toLowerCase();
    if (q.length < 2) {
      setResults([]);
      setLocResults([]);
      setOpen(false);
      return;
    }
    const all = documentsRepo.list();
    const funcMap = Object.fromEntries(
      funcionariosRepo.list().map((f) => [f.id, f]),
    );
    const matches = all
      .filter((d) => {
        const func = d.funcionarioId ? funcMap[d.funcionarioId] : undefined;
        return (
          d.numero.toLowerCase().includes(q) ||
          d.assunto.toLowerCase().includes(q) ||
          (!!func && `${func.nome} ${func.apelido}`.toLowerCase().includes(q)) ||
          (!!func && func.numeroProcesso.toLowerCase().includes(q))
        );
      })
      .slice(0, 6);

    const seen = new Set<string>();
    const locs: string[] = [];
    for (const d of all) {
      const raw = d.localizacao?.trim();
      if (!raw) continue;
      const loc = raw.charAt(0).toUpperCase() + raw.slice(1);
      if (!seen.has(loc) && loc.toLowerCase().includes(q)) {
        seen.add(loc);
        locs.push(loc);
        if (locs.length >= 2) break;
      }
    }

    setResults(matches);
    setLocResults(locs);
    setOpen(matches.length > 0 || locs.length > 0);
  }, [query]);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target as Node)
      ) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  function navigate(id: string) {
    router.push(`/documentos/${id}`);
    setQuery("");
    setOpen(false);
    inputRef.current?.blur();
  }

  function navigateToArchive(loc: string) {
    router.push(`/arquivos?node=${encodeURIComponent(loc)}`);
    setQuery("");
    setOpen(false);
    inputRef.current?.blur();
  }

  const TIPO_COLOR: Record<string, string> = {
    entrada: "text-emerald-600",
    saida: "text-rose-600",
    interno: "text-sky-600",
  };

  return (
    <div ref={containerRef} className="relative hidden md:block">
      <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400 pointer-events-none" />
      <input
        ref={inputRef}
        type="search"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        onFocus={() => results.length > 0 && setOpen(true)}
        onKeyDown={(e) => e.key === "Escape" && setOpen(false)}
        placeholder="Pesquisar documentos ou funcionário..."
        className="h-8 w-52 rounded-md border border-slate-200 bg-slate-50 pl-8 pr-3 text-sm text-slate-700 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:border-transparent focus:w-72 transition-[width] duration-200"
        aria-label="Pesquisa global de documentos"
        aria-autocomplete="list"
        aria-expanded={open}
      />
      {open && (
        <div className="absolute left-0 top-full z-50 mt-1 w-80 rounded-xl border border-slate-200 bg-white shadow-xl overflow-hidden">
          {locResults.length > 0 && (
            <>
              <p className="px-4 py-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400 border-b border-slate-100">
                Arquivos por localidade
              </p>
              {locResults.map((loc) => (
                <button
                  key={loc}
                  type="button"
                  onClick={() => navigateToArchive(loc)}
                  className="w-full text-left px-4 py-2.5 hover:bg-sky-50 transition-colors border-b border-slate-50 flex items-center gap-3"
                >
                  <MapPin className="h-4 w-4 text-sky-400 shrink-0" />
                  <span className="flex-1 text-xs font-medium text-slate-700">
                    Ver arquivos de {loc}
                  </span>
                  <span className="text-[10px] text-sky-500">→</span>
                </button>
              ))}
            </>
          )}
          {results.length > 0 && (
            <>
              <p className="px-4 py-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400 border-b border-slate-100">
                Documentos encontrados
              </p>
              {results.map((doc) => (
                <button
                  key={doc.id}
                  type="button"
                  onClick={() => navigate(doc.id)}
                  className="w-full text-left px-4 py-2.5 hover:bg-slate-50 transition-colors border-b border-slate-50 last:border-0 flex items-start gap-3"
                >
                  <FileText className="h-4 w-4 text-slate-300 shrink-0 mt-0.5" />
                  <div className="min-w-0">
                    <p
                      className={cn(
                        "text-xs font-semibold",
                        TIPO_COLOR[doc.tipoRegistro] ?? "text-slate-600",
                      )}
                    >
                      {doc.numero}
                    </p>
                    <p className="text-xs text-slate-600 truncate leading-snug">
                      {doc.assunto}
                    </p>
                    <p className="text-[10px] text-slate-400 mt-0.5 capitalize">
                      {doc.tipoRegistro} · {doc.estado.replace(/_/g, " ")}
                    </p>
                  </div>
                </button>
              ))}
            </>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Notifications panel ──────────────────────────────────────────────────────

function NotificationsPanel({
  userId,
  onClose,
}: {
  userId: string;
  onClose: () => void;
}) {
  const router = useRouter();
  const { notifications, loaded, load, markAsRead, markAllAsRead } =
    useNotificationStore();

  useEffect(() => {
    load(userId);
  }, [userId, load]);

  const unread = notifications.filter((n) => !n.lida).length;

  function handleClick(id: string, link?: string) {
    markAsRead(id);
    if (link) router.push(link);
    onClose();
  }

  return (
    <div className="absolute right-0 top-full z-50 mt-1 w-80 rounded-xl border border-slate-200 bg-white shadow-xl overflow-hidden flex flex-col max-h-[480px]">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100 shrink-0">
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-slate-800">
            Notificações
          </span>
          {unread > 0 && (
            <span className="rounded-full bg-sky-100 text-sky-700 px-1.5 py-0.5 text-[10px] font-bold">
              {unread}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          {unread > 0 && (
            <button
              type="button"
              onClick={markAllAsRead}
              title="Marcar todas como lidas"
              className="flex h-7 w-7 items-center justify-center rounded-md text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors"
            >
              <CheckCheck className="h-3.5 w-3.5" />
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="flex h-7 w-7 items-center justify-center rounded-md text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* List */}
      <div className="overflow-y-auto flex-1 divide-y divide-slate-50">
        {!loaded ? (
          <div className="px-4 py-8 text-center text-sm text-slate-400">
            A carregar…
          </div>
        ) : notifications.length === 0 ? (
          <div className="px-4 py-10 text-center space-y-1">
            <Bell className="h-8 w-8 text-slate-200 mx-auto" />
            <p className="text-sm text-slate-400">Sem notificações</p>
          </div>
        ) : (
          notifications.slice(0, 20).map((n) => (
            <button
              key={n.id}
              type="button"
              onClick={() => handleClick(n.id, n.link)}
              className={cn(
                "w-full text-left px-4 py-3 hover:bg-slate-50 transition-colors",
                !n.lida && "bg-sky-50/40",
              )}
            >
              <div className="flex items-start gap-2.5">
                <span
                  className={cn(
                    "mt-1.5 h-1.5 w-1.5 rounded-full shrink-0",
                    n.lida ? "bg-transparent" : "bg-sky-500",
                  )}
                />
                <div className="min-w-0">
                  <p
                    className={cn(
                      "text-xs leading-tight",
                      n.lida
                        ? "font-medium text-slate-600"
                        : "font-semibold text-slate-800",
                    )}
                  >
                    {n.titulo}
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5 leading-snug line-clamp-2">
                    {n.mensagem}
                  </p>
                  <p className="text-[10px] text-slate-400 mt-1">
                    {formatDistanceToNow(parseISO(n.criadoEm), {
                      locale: ptBR,
                      addSuffix: true,
                    })}
                  </p>
                </div>
              </div>
            </button>
          ))
        )}
      </div>
    </div>
  );
}

// ─── Dev user switcher ────────────────────────────────────────────────────────

function getInitials(nome: string): string {
  return nome
    .split(" ")
    .slice(0, 2)
    .map((n) => n[0]?.toUpperCase() ?? "")
    .join("");
}

function DevUserSwitcher() {
  const switchUser = useAuthStore((s) => s.switchUser);
  const currentUser = useAuthStore((s) => s.currentUser);
  const allUsers = usersRepo.list();

  if (process.env.NODE_ENV !== "development") return null;

  return (
    <div className="border-t border-slate-100 pt-1">
      <p className="px-3 py-1 text-[10px] font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1">
        <FlaskConical className="h-3 w-3" />
        Dev — Trocar Utilizador
      </p>
      {allUsers.map((u) => (
        <button
          key={u.id}
          type="button"
          onClick={() => {
            switchUser(u.id);
            toast.info(`Utilizador trocado para ${u.nome}`, { duration: 2000 });
          }}
          className={cn(
            "flex w-full items-center gap-2 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 transition-colors",
            u.id === currentUser?.id && "bg-sky-50 text-sky-700 font-medium",
          )}
        >
          <div className="flex h-5 w-5 items-center justify-center rounded-full bg-sky-100 text-[10px] font-bold text-sky-700 shrink-0">
            {getInitials(u.nome)}
          </div>
          <div className="text-left leading-tight">
            <p className="text-xs font-medium">{u.nome}</p>
            <p className="text-[10px] text-slate-400">{u.email}</p>
          </div>
        </button>
      ))}
    </div>
  );
}

// ─── Topbar ───────────────────────────────────────────────────────────────────

export function Topbar() {
  const pathname = usePathname();
  const router = useRouter();
  const currentUser = useAuthStore((s) => s.currentUser);
  const logout = useAuthStore((s) => s.logout);
  const unreadCount = useNotificationStore((s) => s.unreadCount);

  const [notifOpen, setNotifOpen] = useState(false);
  const [tourOpen, setTourOpen] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);

  // Close notifications on outside click
  useEffect(() => {
    function handler(e: MouseEvent) {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifOpen(false);
      }
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  // Load notifications when user is available
  const load = useNotificationStore((s) => s.load);
  useEffect(() => {
    if (currentUser?.id) load(currentUser.id);
  }, [currentUser?.id, load]);

  function handleLogout() {
    logout();
    toast.success("Sessão terminada", { description: "Até breve!" });
    router.push("/login");
  }

  return (
    <header className="flex h-14 items-center justify-between border-b border-slate-200 bg-white px-6">
      <Breadcrumb pathname={pathname} />

      <div className="flex items-center gap-3">
        {/* Global search */}
        <GlobalSearch />

        {/* Language selector */}
        <button
          type="button"
          className="flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2 py-1 text-xs font-medium text-slate-600 hover:bg-slate-50 transition-colors"
          title="Selecionar idioma"
        >
          <span className="text-base leading-none">🇦🇴</span>
          <span>PT</span>
        </button>

        {/* Tour / Help */}
        <button
          type="button"
          onClick={() => setTourOpen(true)}
          className="flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2 py-1 text-xs font-medium text-slate-600 hover:bg-slate-50 transition-colors"
          title="Ver utilizadores de teste e ajuda"
        >
          <HelpCircle className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">Ajuda</span>
        </button>

        {/* Notifications */}
        <div ref={notifRef} className="relative">
          <button
            type="button"
            onClick={() => setNotifOpen((v) => !v)}
            className={cn(
              "relative flex h-8 w-8 items-center justify-center rounded-md border bg-white transition-colors",
              notifOpen
                ? "border-sky-300 bg-sky-50 text-sky-600"
                : "border-slate-200 text-slate-500 hover:bg-slate-50",
            )}
            title="Notificações"
            aria-label={`Notificações${unreadCount > 0 ? ` (${unreadCount} não lidas)` : ""}`}
          >
            <Bell className="h-4 w-4" />
            {unreadCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-sky-500 text-[10px] font-bold text-white">
                {unreadCount > 9 ? "9+" : unreadCount}
              </span>
            )}
          </button>

          {notifOpen && currentUser && (
            <NotificationsPanel
              userId={currentUser.id}
              onClose={() => setNotifOpen(false)}
            />
          )}
        </div>

        {/* Fullscreen */}
        <button
          type="button"
          className="flex h-8 w-8 items-center justify-center rounded-md border border-slate-200 bg-white text-slate-500 hover:bg-slate-50 transition-colors"
          title="Ecrã inteiro"
          onClick={() => {
            if (!document.fullscreenElement) {
              document.documentElement.requestFullscreen();
            } else {
              document.exitFullscreen();
            }
          }}
        >
          <Maximize2 className="h-4 w-4" />
        </button>

        {/* User menu */}
        <div className="relative group">
          <button
            type="button"
            className="flex items-center gap-2 rounded-md border border-slate-200 bg-white px-2 py-1 hover:bg-slate-50 transition-colors"
          >
            {currentUser?.avatarUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={resolveFileUrl(currentUser.avatarUrl)}
                alt={currentUser.nome}
                className="h-6 w-6 rounded-full object-cover shrink-0"
              />
            ) : (
              <div className="flex h-6 w-6 items-center justify-center rounded-full bg-sky-500 text-[10px] font-bold text-white shrink-0">
                {currentUser ? getInitials(currentUser.nome) : "?"}
              </div>
            )}
            <span className="hidden text-sm font-medium text-slate-700 sm:block max-w-[100px] truncate">
              {currentUser?.nome.split(" ")[0] ?? "Utilizador"}
            </span>
            <ChevronDown className="hidden sm:block h-3.5 w-3.5 text-slate-400" />
          </button>

          {/* Dropdown */}
          <div className="absolute right-0 top-full z-50 mt-1 hidden w-52 rounded-lg border border-slate-200 bg-white py-1 shadow-lg group-focus-within:block">
            {/* User info */}
            <div className="px-3 py-2 border-b border-slate-100">
              <p className="text-sm font-semibold text-slate-900 truncate">
                {currentUser?.nome ?? "—"}
              </p>
              <p className="text-xs text-slate-500 truncate">
                {currentUser?.email ?? "—"}
              </p>
            </div>

            <a
              href="/configuracoes/utilizadores"
              className="flex items-center gap-2 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 transition-colors"
            >
              <User className="h-4 w-4 text-slate-400" />
              Perfil
            </a>
            <a
              href="/configuracoes/empresa"
              className="flex items-center gap-2 px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 transition-colors"
            >
              <Settings className="h-4 w-4 text-slate-400" />
              Configurações
            </a>

            <DevUserSwitcher />

            <div className="my-1 border-t border-slate-100" />
            <button
              type="button"
              onClick={handleLogout}
              className="flex w-full items-center gap-2 px-3 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors"
            >
              <LogOut className="h-4 w-4" />
              Terminar Sessão
            </button>
          </div>
        </div>
      </div>

      {/* Tour / Help dialog */}
      <Dialog open={tourOpen} onOpenChange={setTourOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <HelpCircle className="h-4 w-4 text-sky-600" />
              Utilizadores de demonstração
            </DialogTitle>
            <DialogDescription>
              Use uma das contas abaixo para explorar a aplicação. A palavra-passe pode ser qualquer valor não vazio.
            </DialogDescription>
          </DialogHeader>

          <div className="overflow-x-auto rounded-lg border border-slate-200">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  {['Nome', 'E-mail', 'Perfil'].map((h) => (
                    <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-slate-500 uppercase tracking-wide whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {[
                  { nome: 'Dr. António Bula', email: 'admin@faustware.ao', papel: 'Administrador' },
                  { nome: 'Dra. Conceição Mendes', email: 'gestor@faustware.ao', papel: 'Gestor Documental' },
                  { nome: 'Engº Carlos Menezes', email: 'colaborador@faustware.ao', papel: 'Colaborador' },
                  { nome: 'Faustware Formação (Portal)', email: 'entidade@portal.ao', papel: 'Entidade Externa' },
                ].map((u) => (
                  <tr key={u.email} className="hover:bg-slate-50">
                    <td className="px-4 py-2.5 text-xs font-medium text-slate-800">{u.nome}</td>
                    <td className="px-4 py-2.5 text-xs text-slate-500 font-mono">{u.email}</td>
                    <td className="px-4 py-2.5 text-xs text-sky-700">{u.papel}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <p className="text-xs text-slate-400 mt-1">
            Para repor os dados de demonstração: <span className="font-medium text-slate-600">Configurações → Empresa → Zona de risco → Repor dados</span>
          </p>
        </DialogContent>
      </Dialog>
    </header>
  );
}
