"use client";

import { useEffect } from "react";
import { seedDatabase } from "@/data/seed";

export function SeedProvider({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    try {
      seedDatabase();
    } catch (err) {
      console.error("[gd] Seed failed — some demo data may be missing:", err);
    }
  }, []);

  return <>{children}</>;
}
