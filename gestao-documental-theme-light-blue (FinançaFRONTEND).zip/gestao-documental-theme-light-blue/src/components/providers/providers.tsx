'use client';

import { ThemeProvider } from 'next-themes';
import { Toaster } from '@/components/ui/sonner';
import { SessionRestoreProvider } from './session-restore-provider';

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
      <SessionRestoreProvider>
        {children}
      </SessionRestoreProvider>
      <Toaster richColors position="top-right" closeButton />
    </ThemeProvider>
  );
}
