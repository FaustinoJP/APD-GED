﻿'use client';

import { useEffect, useState } from 'react';
import { useAuthStore } from '@/store/auth-store';
import { WifiOff, RotateCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

const IS_API_MODE = process.env.NEXT_PUBLIC_DATA_SOURCE === 'api';

/**
 * SessionRestoreProvider — restaura a sessão JWT após page refresh.
 *
 * Problema resolvido:
 *   Após F5, o access token em memória é perdido mas o cookie httpOnly
 *   de refresh token persiste. Este componente bloqueia o render dos
 *   filhos até ao token ser renovado e o cache do ApiStorageAdapter
 *   estar hidratado — evitando que as páginas carreguem com dados vazios.
 *
 * Fluxo:
 *   1. Aguarda _hasHydrated (Zustand terminou de ler o localStorage)
 *   2. Se autenticado → restoreSession() → aguarda → setReady(true)
 *   3. Se não autenticado → setReady(true) imediatamente (as guards
 *      redireccionam para /login)
 *   4. Em modo local (localStorage) → ready=true desde o início
 */
export function SessionRestoreProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const { isAuthenticated, restoreSession, _hasHydrated } = useAuthStore();

  // Em modo local não há nada a restaurar — pronto de imediato
  const [ready, setReady] = useState(!IS_API_MODE);
  const [error, setError] = useState<string | null>(null);
  const [retrying, setRetrying] = useState(false);

  const handleRetry = () => {
    setRetrying(true);
    setError(null);
    restoreSession()
      .then(() => setReady(true))
      .catch((err: any) => {
        const status = err?.response?.status;
        const isNetworkError = !status || status >= 500;
        if (isNetworkError) {
          setError('Servidor indisponível. Por favor, verifique a sua ligação ao backend.');
        } else {
          setReady(true);
        }
      })
      .finally(() => setRetrying(false));
  };

  useEffect(() => {
    if (!IS_API_MODE) return;
    if (!_hasHydrated) return; // aguarda Zustand reidratar do localStorage

    if (isAuthenticated) {
      // Restaurar via cookie httpOnly e hidratar cache — aguardar conclusão
      restoreSession()
        .then(() => setReady(true))
        .catch((err: any) => {
          const status = err?.response?.status;
          const isNetworkError = !status || status >= 500;
          if (isNetworkError) {
            setError('Servidor indisponível. Por favor, verifique a sua ligação ao backend.');
          } else {
            setReady(true);
          }
        });
    } else {
      // Sem sessão — deixar renderizar (auth guards tratam do redirect)
      setReady(true);
    }
    // Executar apenas uma vez quando _hasHydrated muda para true
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [_hasHydrated]);

  if (error) {
    return (
      <div className="flex h-screen w-screen flex-col items-center justify-center bg-slate-950 text-slate-100 p-6">
        <div className="flex flex-col items-center max-w-md text-center space-y-6">
          <div className="rounded-full bg-red-950/50 p-4 border border-red-500/20 text-red-400 animate-pulse">
            <WifiOff className="h-10 w-10" />
          </div>
          <div className="space-y-2">
            <h1 className="text-xl font-semibold tracking-tight text-white">Ligação ao Servidor Falhou</h1>
            <p className="text-sm text-slate-400 leading-relaxed">
              {error}
            </p>
          </div>
          <Button
            onClick={handleRetry}
            disabled={retrying}
            className="flex items-center gap-2 bg-sky-600 hover:bg-sky-500 text-white font-medium shadow-lg hover:shadow-sky-500/20 transition-all duration-200 cursor-pointer"
          >
            <RotateCw className={`h-4 w-4 ${retrying ? 'animate-spin' : ''}`} />
            {retrying ? 'A tentar novamente...' : 'Tentar novamente'}
          </Button>
        </div>
      </div>
    );
  }

  if (!ready) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-background">
        <p className="text-sm text-muted-foreground animate-pulse">
          A iniciar sessão…
        </p>
      </div>
    );
  }

  return <>{children}</>;
}
