﻿'use client';

import Link from 'next/link';
import { ShieldX } from 'lucide-react';
import type { Permission } from '@/types';
import { usePermissions } from '@/hooks/use-permissions';
import { useAuthStore } from '@/store/auth-store';

interface PermissionGuardProps {
  required: Permission;
  children: React.ReactNode;
}

function Forbidden() {
  return (
    <div className="flex flex-col items-center justify-center gap-4 py-24">
      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-red-50 text-red-500">
        <ShieldX className="h-8 w-8" />
      </div>
      <div className="text-center">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Sem Permissão</h1>
        <p className="mt-2 text-sm text-slate-500">
          Não tem permissão para aceder a esta secção.
          <br />
          Contacte o administrador se precisar de acesso.
        </p>
      </div>
      <Link
        href="/"
        className="mt-2 rounded-lg bg-sky-600 px-4 py-2 text-sm font-semibold text-white hover:bg-sky-700 transition-colors"
      >
        Voltar ao Dashboard
      </Link>
    </div>
  );
}

/**
 * Renders children when the current user has the required permission.
 * Shows a 403 screen otherwise.
 *
 * @example
 * <PermissionGuard required="config.types.manage">
 *   <PageContent />
 * </PermissionGuard>
 */
export function PermissionGuard({ required, children }: PermissionGuardProps) {
  const { can } = usePermissions();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  if (!isAuthenticated) return null;
  if (!can(required)) return <Forbidden />;
  return <>{children}</>;
}

/**
 * HOC variant for client components. Wraps a component with a PermissionGuard.
 *
 * @example
 * export default withPermissionGuard(MyClientPage, 'config.types.manage');
 */
export function withPermissionGuard<P extends object>(
  Component: React.ComponentType<P>,
  required: Permission,
): React.FC<P> {
  const Guarded = (props: P) => (
    <PermissionGuard required={required}>
      <Component {...props} />
    </PermissionGuard>
  );
  Guarded.displayName = `withPermissionGuard(${Component.displayName ?? Component.name ?? 'Component'})`;
  return Guarded;
}
