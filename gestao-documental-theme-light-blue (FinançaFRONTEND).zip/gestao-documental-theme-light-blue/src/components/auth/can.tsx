'use client';

import type { Permission } from '@/types';
import { usePermissions } from '@/hooks/use-permissions';

interface CanProps {
  permission: Permission;
  fallback?: React.ReactNode;
  children: React.ReactNode;
}

/**
 * Renders children only when the current user has the given permission.
 * Use the optional fallback prop to show alternative content.
 *
 * @example
 * <Can permission="config.users.manage">
 *   <DeleteButton />
 * </Can>
 */
export function Can({ permission, fallback = null, children }: CanProps) {
  const { can } = usePermissions();
  return can(permission) ? <>{children}</> : <>{fallback}</>;
}
