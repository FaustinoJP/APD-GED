﻿'use client';

import { useMemo, useState } from 'react';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  CheckCircle2,
  XCircle,
  Clock,
  Users,
  Building2,
  PenLine,
  Loader2,
  Send,
  ShieldCheck,
  LayoutTemplate,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { SignatureDialog } from './signature-dialog';
import { DocumentRenderer } from '@/components/documentos/document-renderer';
import type { SignedZoneData } from '@/components/documentos/document-renderer';
import { useCirculationStore } from '@/store/circulation-store';
import { useAuthStore } from '@/store/auth-store';
import { signaturesRepo } from '@/lib/db';
import type {
  AcaoCirculacao,
  Circulation,
  CompanySettings,
  DecisaoCirculacao,
  DocumentRecord,
  DocumentTemplate,
  User,
  Entity,
} from '@/types';

// ── Ação → decisão options ─────────────────────────────────────────────────────

interface DecisaoOption {
  value: DecisaoCirculacao;
  label: string;
  color: 'green' | 'red' | 'blue' | 'slate';
}

const DECISAO_BY_ACAO: Record<AcaoCirculacao, DecisaoOption[]> = {
  aprovar:    [
    { value: 'aprovado',     label: 'Aprovar',      color: 'green' },
    { value: 'rejeitado',    label: 'Rejeitar',     color: 'red'   },
  ],
  assinar:    [
    { value: 'assinado',     label: 'Assinar',      color: 'green' },
    { value: 'nao_assinado', label: 'Não assinar',  color: 'red'   },
  ],
  parecer:    [
    { value: 'parecer_dado', label: 'Dar Parecer',  color: 'blue'  },
    { value: 'rejeitado',    label: 'Discordar',    color: 'red'   },
  ],
  despachar:  [
    { value: 'parecer_dado', label: 'Despachar',    color: 'blue'  },
    { value: 'rejeitado',    label: 'Devolver',     color: 'red'   },
  ],
  deferir:    [
    { value: 'deferido',     label: 'Deferir',      color: 'green' },
    { value: 'rejeitado',    label: 'Indeferir',    color: 'red'   },
  ],
  verificar:  [
    { value: 'parecer_dado', label: 'Verificado',   color: 'green' },
    { value: 'rejeitado',    label: 'Devolver',     color: 'red'   },
  ],
  encaminhar_interno: [
    { value: 'aprovado',     label: 'Recebido',     color: 'blue'  },
    { value: 'rejeitado',    label: 'Devolver',     color: 'red'   },
  ],
  encaminhar_externo: [
    { value: 'aprovado',     label: 'Recebido',     color: 'blue'  },
    { value: 'rejeitado',    label: 'Devolver',     color: 'red'   },
  ],
};

const ACAO_LABEL: Record<AcaoCirculacao, string> = {
  aprovar:            'Aprovação',
  assinar:            'Assinatura',
  parecer:            'Parecer',
  despachar:          'Despacho',
  deferir:            'Deferimento',
  verificar:          'Verificação',
  encaminhar_interno: 'Encaminhamento interno',
  encaminhar_externo: 'Encaminhamento externo',
};

const COLOR_CLASSES = {
  green: 'border-emerald-400 bg-emerald-50 text-emerald-700 hover:bg-emerald-100',
  red:   'border-red-400    bg-red-50    text-red-700    hover:bg-red-100',
  blue:  'border-sky-400 bg-sky-50 text-sky-700 hover:bg-sky-100',
  slate: 'border-slate-300  bg-slate-50  text-slate-600  hover:bg-slate-100',
};

const SELECTED_COLOR = {
  green: 'border-emerald-500 bg-emerald-500 text-white',
  red:   'border-red-500    bg-red-500    text-white',
  blue:  'border-sky-500 bg-sky-500 text-white',
  slate: 'border-slate-500  bg-slate-500  text-white',
};

// ── Props ───────────────────────────────────────────────────────────────────────

interface CirculationResponsePanelProps {
  circ: Circulation;
  users: User[];
  entities: Entity[];
  /** Document record — used for document-based signing */
  docRecord?: DocumentRecord;
  /** Template with signature zones — if provided and acao=assinar, enables visual signing */
  template?: DocumentTemplate;
  company?: CompanySettings;
  currentUserRoleName?: string;
  onResponded?: () => void;
  className?: string;
}

/**
 * Split panel — left shows circulation info, right the response form.
 * When acao=assinar and a template with signatureZones is provided, offers
 * visual document-based signing instead of the generic SignatureDialog.
 */
export function CirculationResponsePanel({
  circ,
  users,
  entities,
  docRecord,
  template,
  company,
  currentUserRoleName,
  onResponded,
  className,
}: CirculationResponsePanelProps) {
  const respond = useCirculationStore((s) => s.respond);
  const currentUser = useAuthStore((s) => s.currentUser);

  const [decisao, setDecisao] = useState<DecisaoCirculacao | null>(null);
  const [mensagem, setMensagem] = useState('');
  const [saving, setSaving] = useState(false);

  // Generic signature dialog (fallback / no template)
  const [sigOpen, setSigOpen] = useState(false);
  const [signatureDado, setSignatureDado] = useState<{
    dado: string;
    certificadoDigital: boolean;
    signatureZoneId?: string;
  } | null>(null);

  // Document-based signing dialog
  const [docSignOpen, setDocSignOpen] = useState(false);
  const [zoneSignatures, setZoneSignatures] = useState<Record<string, SignedZoneData>>({});

  const options = DECISAO_BY_ACAO[circ.acao] ?? [];
  const needsSignature = circ.acao === 'assinar' && decisao === 'assinado';
  const hasTemplateZones = !!(template?.signatureZones?.length && docRecord && company);

  const fromUser = users.find((u) => u.id === circ.deUserId);
  const alreadyResponded = circ.respostas.some((r) => r.userId === currentUser?.id);

  // Reconstruir zonas já assinadas por outros utilizadores
  const existingSignedZones = useMemo<Record<string, SignedZoneData>>(() => {
    const result: Record<string, SignedZoneData> = {};
    for (const resp of circ.respostas) {
      if (resp.userId === currentUser?.id) continue;
      if (resp.allSignedZones) {
        for (const [zoneId, sigId] of Object.entries(resp.allSignedZones)) {
          const sig = signaturesRepo.getById(sigId);
          if (sig) result[zoneId] = { dado: sig.dado, userId: resp.userId, criadoEm: resp.criadoEm };
        }
      } else if (resp.signatureZoneId && resp.assinaturaId) {
        const sig = signaturesRepo.getById(resp.assinaturaId);
        if (sig) result[resp.signatureZoneId] = { dado: sig.dado, userId: resp.userId, criadoEm: resp.criadoEm };
      }
    }
    return result;
  }, [circ.respostas, currentUser?.id]);

  // Zonas atribuídas ao utilizador actual (undefined = sem atribuição → todas disponíveis)
  const myAssignedZoneIds = useMemo<string[] | undefined>(() => {
    if (!circ.zoneAssignments || !currentUser) return undefined;
    const entries = Object.entries(circ.zoneAssignments);
    if (entries.length === 0) return undefined;
    const mine = entries.filter(([, uid]) => uid === currentUser.id).map(([zoneId]) => zoneId);
    return mine.length > 0 ? mine : undefined;
  }, [circ.zoneAssignments, currentUser]);

  // Mesclar: zonas de outros já assinadas + zonas assinadas nesta sessão
  const mergedSignedZones = useMemo<Record<string, SignedZoneData>>(
    () => ({ ...existingSignedZones, ...zoneSignatures }),
    [existingSignedZones, zoneSignatures],
  );

  function resolveLabel(tipo: string, id: string): string {
    if (tipo === 'user') return users.find((u) => u.id === id)?.nome ?? id;
    if (tipo === 'entity') return entities.find((e) => e.id === id)?.nome ?? id;
    return id;
  }

  async function handleSubmit() {
    if (!decisao) { toast.error('Selecione uma decisão.'); return; }
    if (needsSignature && !signatureDado && Object.keys(zoneSignatures).length === 0) {
      if (hasTemplateZones) setDocSignOpen(true);
      else setSigOpen(true);
      return;
    }

    setSaving(true);
    try {
      let assinaturaId: string | undefined;
      let signatureZoneId: string | undefined;

      let allSignedZones: Record<string, string> | undefined;

      if (decisao === 'assinado') {
        if (Object.keys(zoneSignatures).length > 0) {
          // Guardar TODAS as zonas assinadas nesta sessão
          const allSignedMap: Record<string, string> = {};
          for (const [zoneId, zoneData] of Object.entries(zoneSignatures)) {
            const sig = signaturesRepo.create({
              userId: currentUser?.id ?? 'system',
              tipo: 'desenho',
              dado: zoneData.dado,
              criadoEm: zoneData.criadoEm,
            });
            allSignedMap[zoneId] = sig.id;
            if (!assinaturaId) { assinaturaId = sig.id; signatureZoneId = zoneId; }
          }
          if (Object.keys(allSignedMap).length > 1) allSignedZones = allSignedMap;
        } else if (signatureDado) {
          const sig = signaturesRepo.create({
            userId: currentUser?.id ?? 'system',
            tipo: 'desenho',
            dado: signatureDado.dado,
            criadoEm: new Date().toISOString(),
          });
          assinaturaId = sig.id;
          signatureZoneId = signatureDado.signatureZoneId;
        }
      }

      respond(circ.id, {
        circulationId: circ.id,
        userId: currentUser?.id ?? 'system',
        decisao,
        mensagem,
        assinaturaId,
        signatureZoneId,
        allSignedZones,
        certificadoDigital: signatureDado?.certificadoDigital ?? false,
      });

      const dec = options.find((o) => o.value === decisao);
      toast.success(`Resposta enviada: ${dec?.label ?? decisao}`);
      onResponded?.();
    } finally {
      setSaving(false);
    }
  }

  const signedZoneCount = Object.keys(zoneSignatures).length;
  // Zonas obrigatórias do utilizador actual (ou todas se sem atribuição)
  const myRequiredZones = (template?.signatureZones ?? []).filter(
    (z) => z.obrigatoria && (!myAssignedZoneIds || myAssignedZoneIds.includes(z.id)),
  );
  const allRequiredSigned = myRequiredZones.every((z) => zoneSignatures[z.id]);

  return (
    <>
      <div
        className={cn(
          'grid gap-4 sm:grid-cols-2 rounded-xl border border-slate-200 bg-white overflow-hidden',
          className,
        )}
      >
        {/* ── Left: circulation info ─────────────────────────────────────── */}
        <div className="border-r border-slate-100 bg-slate-50 p-5 space-y-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Encaminhamento para
            </p>
            <p className="mt-1 text-base font-bold text-slate-800">
              {ACAO_LABEL[circ.acao]}
            </p>
          </div>

          <dl className="space-y-3 text-sm">
            <div>
              <dt className="text-xs text-slate-500">De</dt>
              <dd className="font-medium text-slate-700">{fromUser?.nome ?? circ.deUserId}</dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">Para</dt>
              <dd className="flex flex-wrap gap-1 mt-0.5">
                {circ.paraDestinatarios.map((d, i) => (
                  <Badge key={i} variant="secondary" className="gap-1 text-xs">
                    {d.tipo === 'user' ? (
                      <Users className="h-2.5 w-2.5" />
                    ) : (
                      <Building2 className="h-2.5 w-2.5" />
                    )}
                    {resolveLabel(d.tipo, d.id)}
                  </Badge>
                ))}
              </dd>
            </div>
            {circ.mensagem && (
              <div>
                <dt className="text-xs text-slate-500">Mensagem</dt>
                <dd className="mt-0.5 italic text-slate-600 text-sm">
                  &ldquo;{circ.mensagem}&rdquo;
                </dd>
              </div>
            )}
            {circ.dataLimite && (
              <div>
                <dt className="flex items-center gap-1 text-xs text-slate-500">
                  <Clock className="h-3 w-3" /> Prazo
                </dt>
                <dd className="font-medium text-amber-700">
                  {format(parseISO(circ.dataLimite), 'dd/MM/yyyy', { locale: ptBR })}
                </dd>
              </div>
            )}
            {circ.obrigatoriaTodos && (
              <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-700">
                Resposta obrigatória de todos os destinatários
              </div>
            )}
          </dl>

          {/* Existing responses */}
          {circ.respostas.length > 0 && (
            <div className="border-t border-slate-200 pt-3 space-y-2">
              <p className="text-xs font-medium text-slate-500">Respostas recebidas:</p>
              {circ.respostas.map((r) => {
                const ru = users.find((u) => u.id === r.userId);
                return (
                  <div key={r.id} className="flex items-start gap-2 text-xs">
                    <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" />
                    <div>
                      <span className="font-medium text-slate-700">{ru?.nome ?? r.userId}</span>{' '}
                      <span className="text-slate-500 capitalize">
                        {r.decisao.replace(/_/g, ' ')}
                      </span>
                      {r.certificadoDigital && (
                        <span title="Certificado digital">
                          <ShieldCheck className="inline ml-1 h-3 w-3 text-emerald-600" />
                        </span>
                      )}
                      {r.mensagem && (
                        <p className="text-slate-400 italic">&ldquo;{r.mensagem}&rdquo;</p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* ── Right: response form ──────────────────────────────────────── */}
        <div className="p-5 space-y-4">
          {alreadyResponded ? (
            <div className="flex flex-col items-center justify-center h-full gap-3 py-8 text-center">
              <CheckCircle2 className="h-10 w-10 text-emerald-500" />
              <p className="text-sm font-medium text-slate-700">Já respondeu a esta circulação</p>
              <p className="text-xs text-slate-400">A sua resposta foi registada com sucesso.</p>
            </div>
          ) : (
            <>
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Resposta
                </p>
                <p className="mt-1 text-xs text-slate-500">
                  Selecione a sua decisão e adicione uma nota se necessário.
                </p>
              </div>

              {/* Decisão buttons */}
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-slate-600">
                  Decisão <span className="text-red-500">*</span>
                </Label>
                <div className="flex flex-wrap gap-2">
                  {options.map((opt) => {
                    const isSelected = decisao === opt.value;
                    return (
                      <button
                        key={opt.value}
                        type="button"
                        onClick={() => setDecisao(opt.value)}
                        className={cn(
                          'flex items-center gap-1.5 rounded-md border px-3 py-1.5 text-sm font-medium transition-colors',
                          isSelected ? SELECTED_COLOR[opt.color] : COLOR_CLASSES[opt.color],
                        )}
                      >
                        {opt.color === 'green' ? (
                          <CheckCircle2 className="h-3.5 w-3.5" />
                        ) : opt.color === 'red' ? (
                          <XCircle className="h-3.5 w-3.5" />
                        ) : (
                          <Send className="h-3.5 w-3.5" />
                        )}
                        {opt.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Signature section */}
              {needsSignature && (
                <div className="rounded-md border border-sky-100 bg-sky-50 px-3 py-2 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <PenLine className="h-4 w-4 text-sky-500" />
                      <div>
                        <p className="text-sm font-medium text-sky-700">Assinatura obrigatória</p>
                        {hasTemplateZones ? (
                          <p className="text-xs text-sky-500">
                            {signedZoneCount > 0
                              ? `${signedZoneCount} zona(s) assinada(s)${allRequiredSigned ? ' — todas obrigatórias concluídas' : ''}`
                              : 'Abra o documento para assinar nas zonas definidas'}
                          </p>
                        ) : (
                          <p className="text-xs text-sky-500">
                            {signatureDado ? 'Assinatura capturada.' : 'Clique para adicionar.'}
                          </p>
                        )}
                      </div>
                    </div>
                    {hasTemplateZones ? (
                      <Button
                        type="button"
                        variant={signedZoneCount > 0 ? 'outline' : 'default'}
                        size="sm"
                        onClick={() => setDocSignOpen(true)}
                        className="shrink-0 text-xs gap-1.5"
                      >
                        <LayoutTemplate className="h-3.5 w-3.5" />
                        {signedZoneCount > 0 ? 'Ver / Alterar' : 'Abrir Documento'}
                      </Button>
                    ) : (
                      <Button
                        type="button"
                        variant={signatureDado ? 'outline' : 'default'}
                        size="sm"
                        onClick={() => setSigOpen(true)}
                        className="shrink-0 text-xs"
                      >
                        {signatureDado ? 'Alterar' : 'Assinar'}
                      </Button>
                    )}
                  </div>

                  {/* Preview of first signed zone */}
                  {signedZoneCount > 0 && (
                    <div className="flex items-center gap-2 bg-white rounded border border-sky-100 px-2 py-1.5">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={Object.values(zoneSignatures)[0].dado}
                        alt="Assinatura"
                        className="h-8 object-contain"
                      />
                      <span className="text-xs text-emerald-600 font-medium flex items-center gap-1">
                        <CheckCircle2 className="h-3 w-3" />
                        Assinado
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Note */}
              <div className="space-y-1.5">
                <Label className="text-xs font-medium text-slate-600">
                  Nota / Justificação{' '}
                  <span className="text-slate-400">(opcional)</span>
                </Label>
                <Textarea
                  value={mensagem}
                  onChange={(e) => setMensagem(e.target.value)}
                  placeholder="Adicione uma nota para o remetente…"
                  rows={3}
                  className="text-sm resize-none"
                />
              </div>

              <Button
                onClick={handleSubmit}
                disabled={
                  saving || !decisao ||
                  (needsSignature && !signatureDado && signedZoneCount === 0)
                }
                className="w-full gap-1.5"
                size="sm"
              >
                {saving ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Send className="h-3.5 w-3.5" />
                )}
                Enviar Resposta
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Generic signature dialog (when no template zones) */}
      <SignatureDialog
        open={sigOpen}
        onOpenChange={setSigOpen}
        onConfirm={(result) => {
          setSignatureDado({ dado: result.dado, certificadoDigital: result.certificadoDigital });
        }}
      />

      {/* Document-based signing dialog */}
      {docRecord && template && company && (
        <Dialog open={docSignOpen} onOpenChange={setDocSignOpen}>
<DialogContent
  className="
    w-[95vw]
    !max-w-[75vw]
    h-[90vh]
    flex
    flex-col
    gap-0
    p-0
    overflow-hidden
  "
>
            <DialogHeader className="px-6 pt-5 pb-3 border-b border-slate-100 shrink-0">
              <DialogTitle className="flex items-center gap-2">
                <PenLine className="h-4 w-4 text-sky-600" />
                Assinar Documento — {docRecord.numero}
              </DialogTitle>
            </DialogHeader>
            <div className="flex-1 overflow-y-auto bg-slate-100 p-4">
            <DocumentRenderer
              doc={docRecord}
              template={template}
              mode="sign"
              company={company}
              currentUser={currentUser}
              currentUserRoleName={currentUserRoleName}
              users={users}
              entities={entities}
              signedZones={mergedSignedZones}
              assignedZoneIds={myAssignedZoneIds}
              onZoneSigned={(zoneId, data) => {
                setZoneSignatures((prev) => ({ ...prev, [zoneId]: data }));
              }}
            />
            </div>
            <div className="flex justify-end px-6 py-3 border-t border-slate-100 shrink-0 bg-white">
              <Button
                size="sm"
                onClick={() => setDocSignOpen(false)}
                disabled={myRequiredZones.length > 0 && !allRequiredSigned}
                className="gap-1.5"
              >
                <CheckCircle2 className="h-3.5 w-3.5" />
                {allRequiredSigned || myRequiredZones.length === 0
                  ? 'Confirmar Assinaturas'
                  : `Aguardando ${myRequiredZones.length - signedZoneCount} zona(s)`}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
