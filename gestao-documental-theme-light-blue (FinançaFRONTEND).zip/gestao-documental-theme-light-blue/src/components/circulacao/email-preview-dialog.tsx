﻿'use client';

import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Mail, Paperclip, Send, X } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { AcaoCirculacao, Circulation, DocumentRecord, User } from '@/types';

const ACAO_LABEL: Record<AcaoCirculacao, string> = {
  aprovar: 'Aprovação',
  assinar: 'Assinatura',
  parecer: 'Parecer',
  despachar: 'Despacho',
  deferir: 'Deferimento',
  verificar: 'Verificação',
  encaminhar_interno: 'Encaminhamento interno',
  encaminhar_externo: 'Encaminhamento externo',
};

interface EmailPreviewDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  circulation: Circulation;
  doc: DocumentRecord;
  sender: User | undefined;
  recipients: string[];
}

/**
 * Mock email preview shown after forwarding a document with "Enviar e-mail" enabled.
 * Reproduces the "Email Recebido pelo Destinatário" reference view.
 */
export function EmailPreviewDialog({
  open,
  onOpenChange,
  circulation,
  doc,
  sender,
  recipients,
}: EmailPreviewDialogProps) {
  const acaoLabel = ACAO_LABEL[circulation.acao] ?? circulation.acao;
  const subject = `[${acaoLabel.toUpperCase()}] ${doc.numero} — ${doc.assunto}`;
  const sentAt = format(parseISO(circulation.criadoEm), "dd 'de' MMMM 'de' yyyy 'às' HH:mm", {
    locale: ptBR,
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto p-0">
        <DialogHeader className="px-6 pt-5 pb-4 border-b border-slate-100">
          <DialogTitle className="flex items-center gap-2 text-base">
            <Mail className="h-4 w-4 text-sky-600" />
            Pré-visualização do E-mail Enviado
          </DialogTitle>
        </DialogHeader>

        {/* Email chrome */}
        <div className="p-6 space-y-0">
          {/* Email header */}
          <div className="rounded-t-xl border border-slate-200 bg-slate-50 px-5 py-4 space-y-3">
            {/* From */}
            <div className="flex gap-3 text-sm">
              <span className="w-16 shrink-0 text-xs font-semibold text-slate-500 mt-0.5">De:</span>
              <div>
                <span className="font-medium text-slate-800">{sender?.nome ?? 'Sistema'}</span>
                <span className="ml-2 text-xs text-slate-400">
                  &lt;{sender?.email ?? 'noreply@gestao.doc'}&gt;
                </span>
              </div>
            </div>
            {/* To */}
            <div className="flex gap-3 text-sm">
              <span className="w-16 shrink-0 text-xs font-semibold text-slate-500 mt-0.5">Para:</span>
              <div className="flex flex-wrap gap-1">
                {recipients.map((r, i) => (
                  <Badge key={i} variant="secondary" className="text-xs font-normal">
                    {r}
                  </Badge>
                ))}
              </div>
            </div>
            {/* Subject */}
            <div className="flex gap-3 text-sm">
              <span className="w-16 shrink-0 text-xs font-semibold text-slate-500 mt-0.5">
                Assunto:
              </span>
              <span className="font-semibold text-slate-800">{subject}</span>
            </div>
            {/* Date */}
            <div className="flex gap-3 text-sm">
              <span className="w-16 shrink-0 text-xs font-semibold text-slate-500">Data:</span>
              <span className="text-slate-600">{sentAt}</span>
            </div>
          </div>

          {/* Email body */}
          <div className="rounded-b-xl border border-t-0 border-slate-200 bg-white px-5 py-5 space-y-4">
            {/* Greeting */}
            <p className="text-sm text-slate-700">Prezado(a),</p>

            <p className="text-sm text-slate-700">
              Informamos que o documento abaixo foi encaminhado para a sua apreciação e requer a
              seguinte ação:{' '}
              <span className="font-semibold text-sky-700">{acaoLabel.toUpperCase()}</span>.
            </p>

            {/* Doc card */}
            <div className="rounded-lg border border-sky-100 bg-sky-50 px-4 py-3 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold uppercase tracking-wide text-sky-600">
                  Documento
                </span>
                <Badge className="bg-sky-600 text-white text-xs">{acaoLabel}</Badge>
              </div>
              <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                <div>
                  <span className="text-xs text-slate-500">Número: </span>
                  <span className="font-semibold text-slate-800">{doc.numero}</span>
                </div>
                <div>
                  <span className="text-xs text-slate-500">Data: </span>
                  <span className="text-slate-700">
                    {format(parseISO(doc.data), 'dd/MM/yyyy', { locale: ptBR })}
                  </span>
                </div>
                <div className="col-span-2">
                  <span className="text-xs text-slate-500">Assunto: </span>
                  <span className="text-slate-700">{doc.assunto}</span>
                </div>
                {circulation.dataLimite && (
                  <div className="col-span-2">
                    <span className="text-xs text-slate-500">Prazo para resposta: </span>
                    <span className="font-medium text-amber-700">
                      {format(parseISO(circulation.dataLimite), 'dd/MM/yyyy', { locale: ptBR })}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Message */}
            {circulation.mensagem && (
              <blockquote className="border-l-4 border-sky-300 pl-4 italic text-sm text-slate-600">
                &ldquo;{circulation.mensagem}&rdquo;
              </blockquote>
            )}

            {/* Attachments mention */}
            {doc.anexos.length > 0 && (
              <div className="flex items-start gap-2 rounded-md border border-slate-100 bg-slate-50 px-3 py-2">
                <Paperclip className="mt-0.5 h-4 w-4 shrink-0 text-slate-400" />
                <div className="text-xs text-slate-600">
                  <p className="font-medium text-slate-700">Anexos ({doc.anexos.length})</p>
                  {doc.anexos.map((a) => (
                    <p key={a.id} className="text-slate-500">
                      {a.nome}
                    </p>
                  ))}
                </div>
              </div>
            )}

            {/* CTA */}
            <div className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 text-center space-y-2">
              <p className="text-xs text-slate-500">
                Para responder, aceda ao sistema de gestão documental:
              </p>
              <div className="inline-flex items-center gap-2 rounded-md bg-sky-600 px-4 py-2 text-sm font-semibold text-white">
                <Send className="h-3.5 w-3.5" />
                Responder no Sistema
              </div>
              <p className="text-[10px] text-slate-400">
                (Este é um e-mail simulado — em produção, incluiria um link direto para a
                ficha do documento.)
              </p>
            </div>

            {/* Footer */}
            <div className="border-t border-slate-100 pt-3 text-xs text-slate-400 space-y-1">
              <p>
                Este e-mail foi gerado automaticamente pelo sistema de Gestão Documental.
              </p>
              <p>
                Remetente: <span className="font-medium">{sender?.nome ?? 'Sistema'}</span>
              </p>
            </div>
          </div>
        </div>

        <div className="flex justify-end px-6 pb-5">
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)} className="gap-1.5">
            <X className="h-3.5 w-3.5" />
            Fechar pré-visualização
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
