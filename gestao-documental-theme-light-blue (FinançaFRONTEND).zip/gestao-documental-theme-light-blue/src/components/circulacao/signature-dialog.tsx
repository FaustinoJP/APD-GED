﻿'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { PenLine, ImageIcon, Type, RotateCcw, Check, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { apiUploadFile } from '@/lib/api/uploads';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import type { TipoAssinatura } from '@/types';

const IS_API_MODE = process.env.NEXT_PUBLIC_DATA_SOURCE === 'api';

interface SignatureResult {
  tipo: TipoAssinatura;
  dado: string;
  certificadoDigital: boolean;
}

interface SignatureDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: (result: SignatureResult) => void;
}

// ── Canvas draw tab ────────────────────────────────────────────────────────────

function DrawTab({ onCapture }: { onCapture: (dataUrl: string | null) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawing = useRef(false);
  const [hasDrawn, setHasDrawn] = useState(false);

  function getPos(e: React.MouseEvent | React.TouchEvent, canvas: HTMLCanvasElement) {
    const rect = canvas.getBoundingClientRect();
    if ('touches' in e) {
      const t = e.touches[0];
      return { x: t.clientX - rect.left, y: t.clientY - rect.top };
    }
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  }

  function startDraw(e: React.MouseEvent | React.TouchEvent) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    drawing.current = true;
    const ctx = canvas.getContext('2d')!;
    const pos = getPos(e, canvas);
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
    e.preventDefault();
  }

  function draw(e: React.MouseEvent | React.TouchEvent) {
    if (!drawing.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#1e293b';
    const pos = getPos(e, canvas);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
    setHasDrawn(true);
    onCapture(canvas.toDataURL());
    e.preventDefault();
  }

  function stopDraw() {
    drawing.current = false;
  }

  function clearCanvas() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasDrawn(false);
    onCapture(null);
  }

  return (
    <div className="space-y-3">
      <div className="relative rounded-lg border-2 border-dashed border-slate-200 bg-slate-50 overflow-hidden">
        <canvas
          ref={canvasRef}
          width={560}
          height={200}
          className="w-full touch-none cursor-crosshair"
          style={{ height: '160px' }}
          onMouseDown={startDraw}
          onMouseMove={draw}
          onMouseUp={stopDraw}
          onMouseLeave={stopDraw}
          onTouchStart={startDraw}
          onTouchMove={draw}
          onTouchEnd={stopDraw}
        />
        {!hasDrawn && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <p className="text-sm text-slate-400 select-none">Desenhe a sua assinatura aqui</p>
          </div>
        )}
      </div>
      <div className="flex justify-end">
        <Button type="button" variant="ghost" size="sm" onClick={clearCanvas} className="gap-1.5 text-slate-500">
          <RotateCcw className="h-3.5 w-3.5" />
          Limpar
        </Button>
      </div>
    </div>
  );
}

// ── Image upload tab ───────────────────────────────────────────────────────────

function ImageTab({
  onCapture,
  onFileSelect,
}: {
  onCapture: (dataUrl: string | null) => void;
  onFileSelect?: (file: File | null) => void;
}) {
  const [preview, setPreview] = useState<string | null>(null);

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0] || null;
    onFileSelect?.(file);
    if (!file) {
      setPreview(null);
      onCapture(null);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const url = reader.result as string;
      setPreview(url);
      onCapture(url);
    };
    reader.readAsDataURL(file);
  }

  return (
    <div className="space-y-3">
      <Label className="text-xs text-slate-500">Carregar imagem da assinatura (PNG, JPG)</Label>
      <Input type="file" accept="image/*" onChange={handleFile} className="text-sm" />
      {preview && (
        <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 flex justify-center">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={preview} alt="Assinatura" className="max-h-32 object-contain" />
        </div>
      )}
    </div>
  );
}

// ── Typed signature tab ────────────────────────────────────────────────────────

const FONT_OPTIONS = [
  { label: 'Cursiva clássica', className: 'font-[cursive] text-2xl text-slate-800' },
  { label: 'Script elegante', className: 'italic font-serif text-2xl text-slate-800' },
  { label: 'Bloco', className: 'font-mono text-xl text-slate-800' },
];

function TypeTab({
  onCapture,
}: {
  onCapture: (dataUrl: string | null, text: string) => void;
}) {
  const [text, setText] = useState('');
  const [fontIdx, setFontIdx] = useState(0);

  const previewRef = useRef<HTMLDivElement>(null);

  const capture = useCallback(
    (t: string) => {
      if (!t.trim()) { onCapture(null, t); return; }
      // Encode as SVG data URL for a lightweight representation
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="80">
        <text x="10" y="60" font-family="${fontIdx === 2 ? 'monospace' : fontIdx === 1 ? 'serif' : 'cursive'}"
          font-size="40" fill="#1e293b" font-style="${fontIdx === 1 ? 'italic' : 'normal'}">${t}</text>
      </svg>`;
      const url = `data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(svg)))}`;
      onCapture(url, t);
    },
    [fontIdx, onCapture],
  );

  useEffect(() => { capture(text); }, [text, fontIdx, capture]);

  return (
    <div className="space-y-3">
      <div className="space-y-1.5">
        <Label className="text-xs text-slate-500">Nome / Texto da assinatura</Label>
        <Input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Escreva o seu nome..."
          className="text-sm"
        />
      </div>

      <div className="space-y-1.5">
        <Label className="text-xs text-slate-500">Estilo</Label>
        <div className="flex gap-2 flex-wrap">
          {FONT_OPTIONS.map((f, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setFontIdx(i)}
              className={`rounded-md border px-3 py-1.5 text-xs transition-colors ${
                fontIdx === i
                  ? 'border-sky-400 bg-sky-50 text-sky-700'
                  : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {text && (
        <div
          ref={previewRef}
          className="rounded-lg border border-slate-200 bg-slate-50 px-5 py-4 min-h-[64px] flex items-center"
        >
          <span className={FONT_OPTIONS[fontIdx].className}>{text}</span>
        </div>
      )}
    </div>
  );
}

function dataURLtoFile(dataurl: string, filename: string): File {
  const arr = dataurl.split(',');
  const mime = arr[0].match(/:(.*?);/)?.[1] || 'image/png';
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new File([u8arr], filename, { type: mime });
}

// ── Main dialog ────────────────────────────────────────────────────────────────

/**
 * Signature capture dialog — 3 tabs: Draw (canvas), Image (upload), Type (styled text).
 * Includes a placeholder for certificado digital integration.
 *
 * To integrate a real digital certificate provider:
 * 1. Replace the checkbox with an OAuth/PKCS#11 flow (e.g. Autenticação.gov, DocuSign).
 * 2. Receive a signed token/hash and store it in CirculationResponse.assinaturaId.
 * 3. Verify server-side on respond() using the provider's verification API.
 */
export function SignatureDialog({ open, onOpenChange, onConfirm }: SignatureDialogProps) {
  const [tab, setTab] = useState<TipoAssinatura>('desenho');
  const [dado, setDado] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [certificado, setCertificado] = useState(false);

  useEffect(() => {
    if (!open) {
      setDado(null);
      setSelectedFile(null);
      setUploading(false);
      setCertificado(false);
    }
  }, [open]);

  async function handleConfirm() {
    if (!dado && !certificado) return;

    let finalDado = dado ?? '(certificado digital)';

    if (IS_API_MODE && !certificado) {
      if (tab === 'imagem' && selectedFile) {
        setUploading(true);
        try {
          const res = await apiUploadFile(selectedFile);
          finalDado = res.url;
        } catch (err) {
          console.error('[signature] upload image failed', err);
          toast.error('Erro ao carregar ficheiro da assinatura.');
          setUploading(false);
          return;
        }
      } else if (tab === 'desenho' && dado) {
        setUploading(true);
        try {
          const file = dataURLtoFile(dado, 'assinatura.png');
          const res = await apiUploadFile(file);
          finalDado = res.url;
        } catch (err) {
          console.error('[signature] upload canvas failed', err);
          toast.error('Erro ao guardar desenho da assinatura.');
          setUploading(false);
          return;
        }
      }
    }

    onConfirm({
      tipo: tab,
      dado: finalDado,
      certificadoDigital: certificado,
    });
    setUploading(false);
    onOpenChange(false);
  }

  const canConfirm = (!!dado || certificado) && !uploading;

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!uploading) onOpenChange(o); }}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <PenLine className="h-4 w-4 text-sky-600" />
            Adicionar Assinatura
          </DialogTitle>
          <DialogDescription>
            Escolha como pretende assinar este documento.
          </DialogDescription>
        </DialogHeader>

        <Tabs value={tab} onValueChange={(v) => { if (!uploading) { setTab(v as TipoAssinatura); setDado(null); setSelectedFile(null); } }}>
          <TabsList className="grid grid-cols-3 w-full">
            <TabsTrigger value="desenho" className="gap-1.5 text-xs" disabled={uploading}>
              <PenLine className="h-3.5 w-3.5" /> Desenhar
            </TabsTrigger>
            <TabsTrigger value="imagem" className="gap-1.5 text-xs" disabled={uploading}>
              <ImageIcon className="h-3.5 w-3.5" /> Imagem
            </TabsTrigger>
            <TabsTrigger value="digitada" className="gap-1.5 text-xs" disabled={uploading}>
              <Type className="h-3.5 w-3.5" /> Digitar
            </TabsTrigger>
          </TabsList>

          <TabsContent value="desenho" className="mt-4">
            <DrawTab onCapture={setDado} />
          </TabsContent>

          <TabsContent value="imagem" className="mt-4">
            <ImageTab onCapture={setDado} onFileSelect={setSelectedFile} />
          </TabsContent>

          <TabsContent value="digitada" className="mt-4">
            <TypeTab onCapture={(url) => setDado(url)} />
          </TabsContent>
        </Tabs>

        {/* Digital certificate placeholder */}
        <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50 px-4 py-3 mt-2">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-2">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-slate-400" />
              <div>
                <p className="text-sm font-medium text-slate-700">
                  Assinar com certificado digital da instituição
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  Simulado — marca o metadado{' '}
                  <code className="rounded bg-slate-100 px-1 text-[11px]">certificadoDigital: true</code>
                  {' '}na resposta. Em produção, integrar com provedor (ex.: Autenticação.gov, DocuSign).
                </p>
              </div>
            </div>
            <Switch checked={certificado} onCheckedChange={(c) => { if (!uploading) setCertificado(c); }} disabled={uploading} />
          </div>
          {certificado && (
            <p className="mt-2 text-xs text-emerald-600 font-medium">
              ✓ Certificado digital da instituição será registado na resposta.
            </p>
          )}
        </div>

        <DialogFooter className="gap-2 mt-4">
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)} disabled={uploading}>
            Cancelar
          </Button>
          <Button size="sm" onClick={handleConfirm} disabled={!canConfirm} className="gap-1.5">
            <Check className="h-3.5 w-3.5" />
            {uploading ? 'A guardar...' : 'Confirmar Assinatura'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
