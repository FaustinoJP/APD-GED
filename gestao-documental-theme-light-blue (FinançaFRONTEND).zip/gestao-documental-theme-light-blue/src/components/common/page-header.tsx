'use client';

import { RefreshCw, Download, MoreHorizontal } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface MoreOption {
  label: string;
  icon?: React.ReactNode;
  onClick: () => void;
  danger?: boolean;
}

interface PageHeaderProps {
  title: string;
  description?: string;
  /** Quick-access icon buttons: refresh, export. */
  onRefresh?: () => void;
  onExport?: () => void;
  /** Items for the "..." more-options dropdown. */
  moreOptions?: MoreOption[];
  /** Primary CTA button rendered on the right. */
  primaryAction?: {
    label: string;
    icon?: React.ReactNode;
    onClick: () => void;
    disabled?: boolean;
  };
  className?: string;
}

/**
 * Page header with title, optional description, and an actions area.
 *
 * @example
 * <PageHeader
 *   title="Documentos de Entrada"
 *   description="Gerencie os documentos recebidos"
 *   onRefresh={loadDocs}
 *   onExport={handleExport}
 *   primaryAction={{ label: 'Novo Documento', icon: <Plus />, onClick: () => setOpen(true) }}
 * />
 */
export function PageHeader({
  title,
  description,
  onRefresh,
  onExport,
  moreOptions,
  primaryAction,
  className,
}: PageHeaderProps) {
  return (
    <div
      className={cn(
        'flex items-start justify-between gap-4 pb-4 mb-4 border-b border-slate-200',
        className,
      )}
    >
      {/* Title */}
      <div className="min-w-0">
        <h1 className="text-xl font-bold tracking-tight text-slate-900">{title}</h1>
        {description && (
          <p className="mt-0.5 text-sm text-slate-500">{description}</p>
        )}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2 shrink-0">
        {onRefresh && (
          <Button
            variant="outline"
            size="icon-sm"
            onClick={onRefresh}
            title="Actualizar"
            aria-label="Actualizar dados"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
        )}

        {onExport && (
          <Button
            variant="outline"
            size="sm"
            onClick={onExport}
            className="gap-1.5"
          >
            <Download className="h-4 w-4" />
            <span className="hidden sm:inline">Exportar</span>
          </Button>
        )}

        {moreOptions && moreOptions.length > 0 && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon-sm" aria-label="Mais opções">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              {moreOptions.map((opt, i) => (
                <span key={i}>
                  {opt.danger && i > 0 && <DropdownMenuSeparator />}
                  <DropdownMenuItem
                    onClick={opt.onClick}
                    variant={opt.danger ? 'destructive' : 'default'}
                    className="gap-2"
                  >
                    {opt.icon}
                    {opt.label}
                  </DropdownMenuItem>
                </span>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        )}

        {primaryAction && (
          <Button
            onClick={primaryAction.onClick}
            disabled={primaryAction.disabled}
            size="sm"
            className="gap-1.5"
          >
            {primaryAction.icon}
            {primaryAction.label}
          </Button>
        )}
      </div>
    </div>
  );
}
