'use client';

import { useMemo } from 'react';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { useConfigStore } from '@/store/config-store';
import { childrenOf, getLocationPath, sortedLevels } from '@/lib/locations/locationTree';
import { cn } from '@/lib/utils';

const NONE = '__none__';

interface LocationPickerProps {
  /** ID do LocationNode mais profundo escolhido (ou undefined se nenhum). */
  value?: string;
  onChange: (value: string | undefined) => void;
  className?: string;
  disabled?: boolean;
}

/**
 * Selects em cascata, um por nível configurado em Configurações > Localização
 * Física (ex: Sala → Corredor → Prateleira...). Cada nível só fica disponível
 * depois de escolhido o nível anterior; é possível parar num nível intermédio.
 */
export function LocationPicker({ value, onChange, className, disabled }: LocationPickerProps) {
  const locationLevels = useConfigStore((s) => s.locationLevels);
  const locationNodes = useConfigStore((s) => s.locationNodes);

  const levels = useMemo(() => sortedLevels(locationLevels), [locationLevels]);
  const selectedPath = useMemo(() => getLocationPath(value, locationNodes), [value, locationNodes]);

  if (levels.length === 0) {
    return (
      <p className="text-xs text-slate-400">
        Nenhum nível de localização física configurado. Configure em Configurações → Localização Física.
      </p>
    );
  }

  function handleSelect(levelIndex: number, nodeId: string) {
    if (nodeId === NONE) {
      onChange(selectedPath[levelIndex - 1]?.id);
      return;
    }
    onChange(nodeId);
  }

  return (
    <div className={cn('grid gap-3 sm:grid-cols-2 lg:grid-cols-3', className)}>
      {levels.map((level, i) => {
        const parentId = i === 0 ? undefined : selectedPath[i - 1]?.id;
        const isLocked = i > 0 && !parentId;
        const options = isLocked ? [] : childrenOf(parentId, locationNodes);
        const current = selectedPath[i]?.id ?? '';

        return (
          <div key={level.id} className="space-y-1.5">
            <Label className="text-xs font-medium text-slate-600">{level.nome}</Label>
            <Select
              value={current}
              onValueChange={(v) => handleSelect(i, v)}
              disabled={disabled || isLocked || options.length === 0}
            >
              <SelectTrigger className="h-9 w-full">
                <SelectValue
                  placeholder={
                    isLocked
                      ? '—'
                      : options.length === 0
                        ? 'Sem opções'
                        : `Selecionar ${level.nome.toLowerCase()}...`
                  }
                />
              </SelectTrigger>
              <SelectContent>
                {current && <SelectItem value={NONE}>Nenhum</SelectItem>}
                {options.map((n) => (
                  <SelectItem key={n.id} value={n.id}>{n.nome}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        );
      })}
    </div>
  );
}
