﻿'use client';

import { useState } from 'react';
import {
  FileText,
  FileSpreadsheet,
  FileImage,
  FileArchive,
  File,
  Download,
  ExternalLink,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { resolveFileUrl } from '@/lib/file-url';
import type { Attachment } from '@/types';

interface FilePreviewProps {
  attachment: Attachment;
  /** CSS max-height for the preview area (default: '320px'). */
  maxHeight?: string;
  className?: string;
}

const IMAGE_FORMATS = new Set(['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp']);
const PDF_FORMATS = new Set(['pdf']);
const SPREADSHEET_FORMATS = new Set(['xls', 'xlsx', 'ods', 'csv']);
const ARCHIVE_FORMATS = new Set(['zip', 'rar', '7z', 'tar', 'gz']);

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function getFileIcon(formato: string): React.ReactNode {
  const ext = formato.toLowerCase();
  if (IMAGE_FORMATS.has(ext)) return <FileImage className="h-10 w-10" />;
  if (PDF_FORMATS.has(ext)) return <FileText className="h-10 w-10" />;
  if (SPREADSHEET_FORMATS.has(ext)) return <FileSpreadsheet className="h-10 w-10" />;
  if (ARCHIVE_FORMATS.has(ext)) return <FileArchive className="h-10 w-10" />;
  return <File className="h-10 w-10" />;
}

function isMockUrl(url: string | undefined): boolean {
  return !url || url.startsWith('/mock/') || url.startsWith('mock/');
}

/**
 * Renders an attachment preview: inline image, embedded PDF, or file icon fallback.
 * Mock URLs (starting with '/mock/') always show the fallback icon.
 *
 * @example
 * <FilePreview attachment={doc.anexos[0]} maxHeight="400px" />
 */
export function FilePreview({ attachment, maxHeight = '320px', className }: FilePreviewProps) {
  const ext = attachment.formato.toLowerCase();
  const [imgError, setImgError] = useState(false);

  const isImage = IMAGE_FORMATS.has(ext);
  const isPdf = PDF_FORMATS.has(ext);
  const mock = isMockUrl(attachment.url);
  const resolvedUrl = resolveFileUrl(attachment.url);

  // Inline image (only if it's a real data URL or a hosted URL)
  if (isImage && resolvedUrl && !mock && !imgError) {
    return (
      <div className={cn('rounded-lg overflow-hidden border border-slate-200 bg-slate-50', className)}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={resolvedUrl}
          alt={attachment.nome}
          className="w-full object-contain"
          style={{ maxHeight }}
          onError={() => setImgError(true)}
        />
        <FileFooter attachment={attachment} resolvedUrl={resolvedUrl} />
      </div>
    );
  }

  // Embedded PDF (only real URLs)
  if (isPdf && resolvedUrl && !mock) {
    return (
      <div className={cn('rounded-lg overflow-hidden border border-slate-200 bg-slate-50', className)}>
        <embed
          src={resolvedUrl}
          type="application/pdf"
          className="w-full"
          style={{ height: maxHeight }}
        />
        <FileFooter attachment={attachment} resolvedUrl={resolvedUrl} />
      </div>
    );
  }

  // Fallback: icon + meta
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-slate-300 bg-slate-50 p-6 text-slate-400',
        className,
      )}
      style={{ minHeight: '120px' }}
    >
      {getFileIcon(ext)}
      <div className="text-center space-y-0.5">
        <p className="text-sm font-medium text-slate-700 break-all">{attachment.nome}</p>
        <p className="text-xs text-slate-400">
          {attachment.formato.toUpperCase()} · {formatBytes(attachment.tamanho)} · v{attachment.versao}
        </p>
        <p className="text-xs text-slate-400">
          Estado: {attachment.estado === 'check_in' ? 'Disponível' : 'Check-out'}
        </p>
      </div>
      {resolvedUrl && !mock && (
        <a
          href={resolvedUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 rounded-md bg-sky-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-sky-700 transition-colors"
        >
          <ExternalLink className="h-3 w-3" />
          Abrir
        </a>
      )}
    </div>
  );
}

function FileFooter({ attachment, resolvedUrl }: { attachment: Attachment; resolvedUrl?: string }) {
  return (
    <div className="flex items-center justify-between gap-2 border-t border-slate-200 bg-white px-3 py-2">
      <div className="min-w-0">
        <p className="truncate text-xs font-medium text-slate-700">{attachment.nome}</p>
        <p className="text-[10px] text-slate-400">
          {attachment.formato.toUpperCase()} · {formatBytes(attachment.tamanho)}
        </p>
      </div>
      {resolvedUrl && (
        <a
          href={resolvedUrl}
          download={attachment.nome}
          className="shrink-0 rounded p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition-colors"
          title="Descarregar"
        >
          <Download className="h-4 w-4" />
        </a>
      )}
    </div>
  );
}
