﻿'use client';

import { useState } from 'react';
import { Search, SlidersHorizontal } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { AdvancedSearchDialog, type AdvancedSearchParams } from './advanced-search-dialog';
import type { DocumentType, User } from '@/types';

export interface SearchParams {
  query: string;
  data: string;
  tipoDocumentoId: string;
  participantes: string;
}

interface SearchFiltersProps {
  onSearch: (params: SearchParams & AdvancedSearchParams) => void;
  documentTypes?: DocumentType[];
  users?: User[];
  className?: string;
  initialParams?: Partial<SearchParams & AdvancedSearchParams>;
}

const EMPTY_PARAMS: SearchParams = {
  query: '',
  data: '',
  tipoDocumentoId: '',
  participantes: '',
};

/**
 * Primary search bar with quick filters and an advanced search dialog.
 *
 * @example
 * <SearchFilters
 *   documentTypes={configStore.documentTypes}
 *   onSearch={(params) => documentsStore.filter(params)}
 * />
 */
export function SearchFilters({
  onSearch,
  documentTypes = [],
  users = [],
  className,
  initialParams = {},
}: SearchFiltersProps) {
  const [params, setParams] = useState<SearchParams>(() => ({
    ...EMPTY_PARAMS,
    ...initialParams,
  }));
  const [advancedOpen, setAdvancedOpen] = useState(false);

  function patch<K extends keyof SearchParams>(key: K, value: SearchParams[K]) {
    setParams((prev) => ({ ...prev, [key]: value }));
  }

  function handleSearch() {
    onSearch({ ...params });
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter') handleSearch();
  }

  function handleAdvancedSearch(advanced: AdvancedSearchParams) {
    setAdvancedOpen(false);
    onSearch({ ...params, ...advanced });
  }

  return (
    <>
      <div
        className={cn(
          'flex flex-wrap items-end gap-2 rounded-xl border border-slate-200 bg-white p-3 shadow-xs',
          className,
        )}
      >
        {/* Pesquisar por */}
        <div className="flex-1 min-w-48">
          <label className="mb-1 block text-xs font-medium text-slate-500">
            Pesquisar por
          </label>
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            <input
              type="search"
              value={params.query}
              onChange={(e) => patch('query', e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Nº, assunto, remetente, funcionário, nº processo..."
              className="h-9 w-full rounded-md border border-slate-200 bg-slate-50 pl-8 pr-3 text-sm text-slate-700 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-shadow"
            />
          </div>
        </div>

        {/* Data do documento */}
        <div className="min-w-36">
          <label className="mb-1 block text-xs font-medium text-slate-500">
            Data do documento
          </label>
          <input
            type="date"
            value={params.data}
            onChange={(e) => patch('data', e.target.value)}
            className="h-9 w-full rounded-md border border-slate-200 bg-slate-50 px-3 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition-shadow"
          />
        </div>

        {/* Tipo de Documento */}
        <div className="min-w-44">
          <label className="mb-1 block text-xs font-medium text-slate-500">
            Tipo de Documento
          </label>
          <Select
            value={params.tipoDocumentoId || '__all__'}
            onValueChange={(v) => patch('tipoDocumentoId', v === '__all__' ? '' : v)}
          >
            <SelectTrigger className="h-9 w-full bg-slate-50">
              <SelectValue placeholder="Todos os tipos" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__all__">Todos os tipos</SelectItem>
              {documentTypes.map((dt) => (
                <SelectItem key={dt.id} value={dt.id}>
                  {dt.nome}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Participantes */}
        <div className="min-w-44">
          <label className="mb-1 block text-xs font-medium text-slate-500">
            Participantes
          </label>
          <Select
            value={params.participantes || '__all__'}
            onValueChange={(v) => patch('participantes', v === '__all__' ? '' : v)}
          >
            <SelectTrigger className="h-9 w-full bg-slate-50">
              <SelectValue placeholder="Todos" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__all__">Todos</SelectItem>
              {users.map((u) => (
                <SelectItem key={u.id} value={u.id}>
                  {u.nome}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Actions */}
        <div className="flex items-end gap-2">
          <Button size="sm" onClick={handleSearch} className="gap-1.5 h-9">
            <Search className="h-3.5 w-3.5" />
            Pesquisar
          </Button>
          <Button
            variant="yellow"
            size="sm"
            onClick={() => setAdvancedOpen(true)}
            className="gap-1.5 h-9"
          >
            <SlidersHorizontal className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Pesquisa avançada</span>
          </Button>
        </div>
      </div>

      <AdvancedSearchDialog
        open={advancedOpen}
        onOpenChange={setAdvancedOpen}
        onSearch={handleAdvancedSearch}
        documentTypes={documentTypes}
        initialParams={initialParams}
      />
    </>
  );
}
