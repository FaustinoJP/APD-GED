'use client';

import { useId, useState } from 'react';
import { X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

interface TagInputProps {
  value: string[];
  onChange: (tags: string[]) => void;
  placeholder?: string;
  /** Sugestões de autocomplete (ex.: tags já existentes noutros documentos). */
  suggestions?: string[];
  className?: string;
  disabled?: boolean;
}

/** Normaliza uma tag: trim + lowercase, para consistência de armazenamento e pesquisa. */
function normalize(tag: string): string {
  return tag.trim().toLowerCase();
}

/**
 * Campo de entrada de palavras-chave (tags) com chips removíveis.
 * Enter ou vírgula adiciona; Backspace com input vazio remove a última.
 *
 * @example
 * <TagInput value={tags} onChange={setTags} suggestions={existingTags} />
 */
export function TagInput({
  value,
  onChange,
  placeholder = 'Adicionar palavra-chave e premir Enter...',
  suggestions = [],
  className,
  disabled = false,
}: TagInputProps) {
  const [input, setInput] = useState('');
  const listId = useId();

  function addTag(raw: string) {
    const tag = normalize(raw);
    if (!tag) return;
    if (value.includes(tag)) {
      setInput('');
      return;
    }
    onChange([...value, tag]);
    setInput('');
  }

  function removeTag(tag: string) {
    onChange(value.filter((t) => t !== tag));
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      addTag(input);
    } else if (e.key === 'Backspace' && input === '' && value.length > 0) {
      removeTag(value[value.length - 1]);
    }
  }

  const availableSuggestions = suggestions.filter((s) => !value.includes(s));

  return (
    <div
      className={cn(
        'flex flex-wrap items-center gap-1.5 rounded-md border border-input bg-transparent px-2 py-1.5 focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-1',
        disabled && 'opacity-60',
        className,
      )}
    >
      {value.map((tag) => (
        <Badge key={tag} variant="secondary" className="gap-1 pr-1">
          {tag}
          {!disabled && (
            <button
              type="button"
              onClick={() => removeTag(tag)}
              className="rounded-full p-0.5 hover:bg-slate-300/60"
              aria-label={`Remover ${tag}`}
            >
              <X className="h-3 w-3" />
            </button>
          )}
        </Badge>
      ))}
      <input
        type="text"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={handleKeyDown}
        onBlur={() => addTag(input)}
        placeholder={value.length === 0 ? placeholder : ''}
        disabled={disabled}
        list={availableSuggestions.length > 0 ? listId : undefined}
        className="h-6 min-w-32 flex-1 bg-transparent px-1 text-sm text-slate-700 placeholder:text-slate-400 focus:outline-none"
      />
      {availableSuggestions.length > 0 && (
        <datalist id={listId}>
          {availableSuggestions.map((s) => (
            <option key={s} value={s} />
          ))}
        </datalist>
      )}
    </div>
  );
}
