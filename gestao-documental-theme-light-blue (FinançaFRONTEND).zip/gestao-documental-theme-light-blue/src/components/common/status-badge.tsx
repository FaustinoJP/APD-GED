﻿'use client';

import { cn } from '@/lib/utils';
import type { EstadoDocumento } from '@/types';

type CirculationStatus = 'pendente' | 'respondido' | 'expirado';
type AcaoCirculacao =
  | 'aprovar'
  | 'assinar'
  | 'parecer'
  | 'despachar'
  | 'deferir'
  | 'verificar'
  | 'encaminhar_interno'
  | 'encaminhar_externo';

export type BadgeStatus = EstadoDocumento | CirculationStatus | AcaoCirculacao;

interface StatusBadgeProps {
  status: BadgeStatus;
  className?: string;
}

const STATUS_CONFIG: Record<BadgeStatus, { label: string; className: string }> = {
  // EstadoDocumento
  novo: { label: 'Novo', className: 'bg-blue-50 text-blue-700 border-blue-200' },
  em_circulacao: { label: 'Em Circulação', className: 'bg-amber-50 text-amber-700 border-amber-200' },
  aprovado: { label: 'Aprovado', className: 'bg-green-50 text-green-700 border-green-200' },
  rejeitado: { label: 'Rejeitado', className: 'bg-red-50 text-red-700 border-red-200' },
  deferido: { label: 'Deferido', className: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  arquivado: { label: 'Arquivado', className: 'bg-gray-50 text-gray-600 border-gray-200' },
  concluido: { label: 'Concluído', className: 'bg-slate-100 text-slate-600 border-slate-200' },
  // CirculationStatus
  pendente: { label: 'Pendente', className: 'bg-orange-50 text-orange-700 border-orange-200' },
  respondido: { label: 'Respondido', className: 'bg-green-50 text-green-700 border-green-200' },
  expirado: { label: 'Expirado', className: 'bg-red-50 text-red-600 border-red-200' },
  // AcaoCirculacao
  aprovar: { label: 'Aprovação', className: 'bg-green-50 text-green-700 border-green-200' },
  assinar: { label: 'Assinatura', className: 'bg-sky-50 text-sky-700 border-sky-200' },
  parecer: { label: 'Parecer', className: 'bg-purple-50 text-purple-700 border-purple-200' },
  despachar: { label: 'Despacho', className: 'bg-cyan-50 text-cyan-700 border-cyan-200' },
  deferir: { label: 'Deferimento', className: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  verificar: { label: 'Verificação', className: 'bg-sky-50 text-sky-700 border-sky-200' },
  encaminhar_interno: { label: 'Enc. Interno', className: 'bg-violet-50 text-violet-700 border-violet-200' },
  encaminhar_externo: { label: 'Enc. Externo', className: 'bg-fuchsia-50 text-fuchsia-700 border-fuchsia-200' },
};

/**
 * Maps document estados and circulation actions/statuses to semantic color badges.
 *
 * @example
 * <StatusBadge status="aprovado" />
 * <StatusBadge status="em_circulacao" />
 * <StatusBadge status="pendente" />
 */
export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = STATUS_CONFIG[status] ?? { label: status, className: 'bg-slate-100 text-slate-600 border-slate-200' };
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium whitespace-nowrap',
        config.className,
        className,
      )}
    >
      {config.label}
    </span>
  );
}
