'use client';

import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SectionCardProps {
  title: string;
  description?: string;
  /** Slot for buttons or badges in the card header. */
  actions?: React.ReactNode;
  children: React.ReactNode;
  /** Enables a toggle to collapse/expand the card body. */
  collapsible?: boolean;
  defaultCollapsed?: boolean;
  className?: string;
  bodyClassName?: string;
}

/**
 * Card with a labelled header, optional actions slot, and collapsible body.
 * Use in forms and detail pages to group related fields.
 *
 * @example
 * <SectionCard title="Dados do Documento" collapsible>
 *   <FormFields />
 * </SectionCard>
 */
export function SectionCard({
  title,
  description,
  actions,
  children,
  collapsible = false,
  defaultCollapsed = false,
  className,
  bodyClassName,
}: SectionCardProps) {
  const [collapsed, setCollapsed] = useState(defaultCollapsed);

  return (
    <div
      className={cn(
        'rounded-xl border border-slate-200 bg-white shadow-xs overflow-hidden',
        className,
      )}
    >
      {/* Header */}
      <div
        className={cn(
          'flex items-center justify-between gap-3 px-5 py-4 border-b border-slate-100',
          collapsible && 'cursor-pointer select-none hover:bg-slate-50 transition-colors',
        )}
        onClick={collapsible ? () => setCollapsed((c) => !c) : undefined}
        role={collapsible ? 'button' : undefined}
        aria-expanded={collapsible ? !collapsed : undefined}
      >
        <div className="min-w-0">
          <h3 className="text-sm font-semibold text-slate-900 truncate">{title}</h3>
          {description && (
            <p className="mt-0.5 text-xs text-slate-500 truncate">{description}</p>
          )}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {actions && !collapsed && (
            <div
              onClick={(e) => e.stopPropagation()}
              className="flex items-center gap-2"
            >
              {actions}
            </div>
          )}
          {collapsible && (
            <ChevronDown
              className={cn(
                'h-4 w-4 text-slate-400 transition-transform duration-200',
                collapsed && '-rotate-90',
              )}
            />
          )}
        </div>
      </div>

      {/* Body */}
      {!collapsed && (
        <div className={cn('px-5 py-4', bodyClassName)}>{children}</div>
      )}
    </div>
  );
}
