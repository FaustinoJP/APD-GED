'use client';

import { useEffect, useState } from 'react';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectSeparator,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

// Lista local — fallback quando a API não está disponível ou em modo local
export const ANGOLA_PROVINCES: string[] = [
  'Luanda', 'Benguela', 'Huambo', 'Huíla', 'Malanje',
  'Cuanza Norte', 'Cuanza Sul', 'Lunda Norte', 'Lunda Sul',
  'Bié', 'Moxico', 'Cubango', 'Cunene', 'Namibe',
  'Bengo', 'Uíge', 'Zaire', 'Cabinda',
  // 2025
  'Icolo e Bengo', 'Moxico Leste', 'Cuando',
];

const IS_API_MODE = process.env.NEXT_PUBLIC_DATA_SOURCE === 'api';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? 'http://localhost:3001/api/v1';

const OUTROS = '__outros__';

/**
 * Procura a província na lista ignorando maiúsculas/minúsculas e espaços extras.
 * Devolve o nome canónico (ex: "Icolo e Bengo") se encontrado, null caso contrário.
 */
export function findProvince(list: string[], value: string): string | null {
  if (!value) return null;
  const norm = value.trim().toLowerCase();
  return list.find((p) => p.toLowerCase() === norm) ?? null;
}

interface ProvinceSelectProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
}

export function ProvinceSelect({
  value,
  onChange,
  placeholder = 'Selecionar província...',
  className,
  disabled,
}: ProvinceSelectProps) {
  const [provinces, setProvinces] = useState<string[]>(ANGOLA_PROVINCES);

  // Buscar lista actualizada do backend (uma só vez por montagem)
  useEffect(() => {
    if (!IS_API_MODE) return;
    fetch(`${API_BASE}/provinces`)
      .then((r) => r.json())
      .then((data: { nome: string }[]) => {
        if (Array.isArray(data) && data.length > 0) {
          setProvinces(data.map((p) => p.nome));
        }
      })
      .catch(() => { /* manter fallback local */ });
  }, []);

  // Detecção case-insensitive: "luanda" → "Luanda", "BENGUELA" → "Benguela"
  const canonical = findProvince(provinces, value);
  const isCustom = value !== '' && canonical === null;

  // O Select usa sempre o nome canónico como valor (garante consistência)
  const selectValue = canonical ?? (isCustom ? OUTROS : '');

  function handleSelectChange(val: string) {
    if (val === OUTROS) {
      onChange(isCustom ? value : '');
    } else {
      // Guardar sempre o nome canónico (normalizado)
      onChange(val);
    }
  }

  return (
    <div className="space-y-2">
      <Select value={selectValue} onValueChange={handleSelectChange} disabled={disabled}>
        <SelectTrigger className={cn('h-9 w-full', className)}>
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>
          {provinces.map((nome) => (
            <SelectItem key={nome} value={nome}>
              {nome}
            </SelectItem>
          ))}
          <SelectSeparator />
          <SelectItem value={OUTROS}>Outros...</SelectItem>
        </SelectContent>
      </Select>

      {selectValue === OUTROS && (
        <Input
          value={isCustom ? value : ''}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Especifique a região..."
          className="h-9 text-sm"
          disabled={disabled}
          autoFocus
        />
      )}
    </div>
  );
}
