'use client';

import { useId, useMemo, useState } from 'react';
import { Check, ChevronsUpDown, Search, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import type { Funcionario } from '@/types';

/** Valor sentinela para "nenhum funcionário". Compatível com os formulários. */
export const FUNCIONARIO_NONE = '__none__';

interface FuncionarioComboboxProps {
  funcionarios: Funcionario[];
  /** ID do funcionário selecionado, ou FUNCIONARIO_NONE / '' para nenhum. */
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
}

/**
 * Combobox pesquisável para selecionar um funcionário por nome, apelido ou nº de processo.
 * Emite FUNCIONARIO_NONE quando "Nenhum" é escolhido.
 *
 * @example
 * <FuncionarioCombobox funcionarios={funcionarios} value={value} onChange={onChange} />
 */
export function FuncionarioCombobox({
  funcionarios,
  value,
  onChange,
  placeholder = 'Nenhum funcionário',
  disabled = false,
  className,
}: FuncionarioComboboxProps) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const listboxId = useId();

  const selected =
    value && value !== FUNCIONARIO_NONE
      ? funcionarios.find((f) => f.id === value)
      : undefined;

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return funcionarios;
    return funcionarios.filter((f) =>
      `${f.nome} ${f.apelido}`.toLowerCase().includes(q) ||
      f.numeroProcesso.toLowerCase().includes(q),
    );
  }, [funcionarios, search]);

  function select(v: string) {
    onChange(v);
    setOpen(false);
    setSearch('');
  }

  return (
    <Popover
      open={open}
      onOpenChange={(o) => {
        setOpen(o);
        if (!o) setSearch('');
      }}
    >
      <PopoverTrigger asChild disabled={disabled}>
        <button
          type="button"
          role="combobox"
          aria-expanded={open}
          aria-controls={listboxId}
          className={cn(
            'flex h-9 w-full items-center justify-between gap-2 rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-xs focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1 disabled:cursor-not-allowed disabled:opacity-50',
            !selected && 'text-slate-400',
            className,
          )}
        >
          <span className="truncate">
            {selected
              ? `${selected.nome} ${selected.apelido} — ${selected.numeroProcesso}`
              : placeholder}
          </span>
          <ChevronsUpDown className="h-4 w-4 shrink-0 text-slate-400" />
        </button>
      </PopoverTrigger>
      <PopoverContent
        align="start"
        className="w-(--radix-popover-trigger-width) p-0"
      >
        <div className="flex items-center gap-2 border-b border-slate-100 px-3">
          <Search className="h-3.5 w-3.5 shrink-0 text-slate-400" />
          <input
            autoFocus
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Pesquisar por nome ou nº de processo..."
            className="h-9 w-full bg-transparent text-sm text-slate-700 placeholder:text-slate-400 focus:outline-none"
          />
          {search && (
            <button
              type="button"
              onClick={() => setSearch('')}
              className="rounded-full p-0.5 text-slate-400 hover:bg-slate-100"
              aria-label="Limpar pesquisa"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
        <div id={listboxId} role="listbox" className="max-h-60 overflow-y-auto p-1">
          <button
            type="button"
            onClick={() => select(FUNCIONARIO_NONE)}
            className="flex w-full items-center gap-2 rounded-sm px-2 py-1.5 text-left text-sm text-slate-600 hover:bg-slate-100"
          >
            <Check
              className={cn(
                'h-4 w-4 shrink-0',
                !selected ? 'opacity-100 text-sky-600' : 'opacity-0',
              )}
            />
            Nenhum
          </button>
          {filtered.length === 0 ? (
            <p className="px-2 py-3 text-center text-xs text-slate-400">
              Nenhum funcionário encontrado.
            </p>
          ) : (
            filtered.map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => select(f.id)}
                className="flex w-full items-center gap-2 rounded-sm px-2 py-1.5 text-left text-sm text-slate-700 hover:bg-slate-100"
              >
                <Check
                  className={cn(
                    'h-4 w-4 shrink-0',
                    selected?.id === f.id ? 'opacity-100 text-sky-600' : 'opacity-0',
                  )}
                />
                <span className="truncate">
                  {f.nome} {f.apelido}
                  <span className="ml-1 text-xs text-slate-400">
                    — {f.numeroProcesso}
                  </span>
                </span>
              </button>
            ))
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
