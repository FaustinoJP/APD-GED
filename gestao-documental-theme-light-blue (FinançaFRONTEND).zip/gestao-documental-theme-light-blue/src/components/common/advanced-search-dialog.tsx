﻿'use client';

import { useState } from 'react';
import { ChevronDown, Search } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { TagInput } from '@/components/common/tag-input';
import type { DocumentType, EstadoDocumento, EstadoFuncionario } from '@/types';

export interface AdvancedSearchParams {
  numero?: string;
  tipoDocumentoId?: string;
  assunto?: string;
  estado?: EstadoDocumento | '';
  tags?: string[];
  remetente?: string;
  destinatario?: string;
  dataInicial?: string;
  dataFinal?: string;
  // Filtros de funcionário vinculado
  funcNome?: string;
  funcNumeroProcesso?: string;
  funcEstado?: EstadoFuncionario | '';
  funcNascimentoInicio?: string;
  funcNascimentoFim?: string;
  funcInicioFuncoesInicio?: string;
  funcInicioFuncoesFim?: string;
  funcFimFuncoesInicio?: string;
  funcFimFuncoesFim?: string;
}

interface AdvancedSearchDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSearch: (params: AdvancedSearchParams) => void;
  documentTypes?: DocumentType[];
  initialParams?: Partial<AdvancedSearchParams>;
}

const FUNCIONARIO_STATES: Array<{ value: EstadoFuncionario; label: string }> = [
  { value: 'ativo', label: 'Ativo' },
  { value: 'reforma', label: 'Reforma' },
  { value: 'licenca', label: 'Licença' },
  { value: 'suspenso', label: 'Suspenso' },
  { value: 'exonerado', label: 'Exonerado' },
  { value: 'falecido', label: 'Falecido' },
];

const DOCUMENT_STATES: Array<{ value: EstadoDocumento; label: string }> = [
  { value: 'novo', label: 'Novo' },
  { value: 'em_circulacao', label: 'Em Circulação' },
  { value: 'aprovado', label: 'Aprovado' },
  { value: 'rejeitado', label: 'Rejeitado' },
  { value: 'deferido', label: 'Deferido' },
  { value: 'arquivado', label: 'Arquivado' },
  { value: 'concluido', label: 'Concluído' },
];

const EMPTY_PARAMS: AdvancedSearchParams = {
  numero: '',
  tipoDocumentoId: '',
  assunto: '',
  estado: '',
  tags: [],
  remetente: '',
  destinatario: '',
  dataInicial: '',
  dataFinal: '',
  funcNome: '',
  funcNumeroProcesso: '',
  funcEstado: '',
  funcNascimentoInicio: '',
  funcNascimentoFim: '',
  funcInicioFuncoesInicio: '',
  funcInicioFuncoesFim: '',
  funcFimFuncoesInicio: '',
  funcFimFuncoesFim: '',
};

/** Collapsible section within the dialog. */
function Section({
  title,
  defaultOpen = true,
  children,
}: {
  title: string;
  defaultOpen?: boolean;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border border-slate-200 rounded-lg overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between px-4 py-3 text-sm font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 transition-colors"
        aria-expanded={open}
      >
        {title}
        <ChevronDown
          className={cn(
            'h-4 w-4 text-slate-400 transition-transform duration-200',
            !open && '-rotate-90',
          )}
        />
      </button>
      {open && <div className="grid grid-cols-2 gap-3 p-4">{children}</div>}
    </div>
  );
}

/** Two-column form field. Pass `span` to make a field span both columns. */
function Field({
  label,
  span = false,
  required = false,
  children,
}: {
  label: string;
  span?: boolean;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div className={cn('space-y-1', span && 'col-span-2')}>
      <Label className="text-xs font-medium text-slate-500">
        {label}
        {required && <span className="ml-0.5 text-red-500">*</span>}
      </Label>
      {children}
    </div>
  );
}

/**
 * Full-featured advanced search dialog with collapsible sections.
 * Triggered by SearchFilters' "Pesquisa avançada" button.
 *
 * @example
 * <AdvancedSearchDialog
 *   open={open}
 *   onOpenChange={setOpen}
 *   documentTypes={configStore.documentTypes}
 *   onSearch={(params) => documentsStore.filter(params)}
 * />
 */
export function AdvancedSearchDialog({
  open,
  onOpenChange,
  onSearch,
  documentTypes = [],
  initialParams = {},
}: AdvancedSearchDialogProps) {
  const [params, setParams] = useState<AdvancedSearchParams>(() => ({
    ...EMPTY_PARAMS,
    ...initialParams,
  }));

  function patch<K extends keyof AdvancedSearchParams>(
    key: K,
    value: AdvancedSearchParams[K],
  ) {
    setParams((prev) => ({ ...prev, [key]: value }));
  }

  function handleSearch() {
    onSearch(params);
  }

  function handleReset() {
    setParams(EMPTY_PARAMS);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Search className="h-4 w-4 text-sky-600" />
            Pesquisa Avançada
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3 py-1">
          {/* Documento */}
          <Section title="Documento">
            <Field label="Nº do Documento">
              <Input
                value={params.numero ?? ''}
                onChange={(e) => patch('numero', e.target.value)}
                placeholder="Ex: ENT-2024/00001"
                className="h-8 text-sm"
              />
            </Field>

            <Field label="Tipo de Documento">
              <Select
                value={params.tipoDocumentoId || '__all__'}
                onValueChange={(v) => patch('tipoDocumentoId', v === '__all__' ? '' : v)}
              >
                <SelectTrigger className="h-8 text-sm w-full">
                  <SelectValue placeholder="Todos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__all__">Todos os tipos</SelectItem>
                  {documentTypes.map((dt) => (
                    <SelectItem key={dt.id} value={dt.id}>
                      {dt.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>

            <Field label="Assunto" span>
              <Input
                value={params.assunto ?? ''}
                onChange={(e) => patch('assunto', e.target.value)}
                placeholder="Palavra-chave no assunto..."
                className="h-8 text-sm"
              />
            </Field>

            <Field label="Estado">
              <Select
                value={params.estado || '__all__'}
                onValueChange={(v) => patch('estado', v === '__all__' ? '' : v as EstadoDocumento)}
              >
                <SelectTrigger className="h-8 text-sm w-full">
                  <SelectValue placeholder="Todos os estados" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__all__">Todos os estados</SelectItem>
                  {DOCUMENT_STATES.map((s) => (
                    <SelectItem key={s.value} value={s.value}>
                      {s.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>

            <Field label="Palavras-chave" span>
              <TagInput
                value={params.tags ?? []}
                onChange={(tags) => patch('tags', tags)}
                placeholder="Filtrar por palavra-chave..."
              />
            </Field>
          </Section>

          {/* Participantes */}
          <Section title="Participantes" defaultOpen={false}>
            <Field label="Remetente">
              <Input
                value={params.remetente ?? ''}
                onChange={(e) => patch('remetente', e.target.value)}
                placeholder="Nome ou entidade..."
                className="h-8 text-sm"
              />
            </Field>

            <Field label="Destinatário">
              <Input
                value={params.destinatario ?? ''}
                onChange={(e) => patch('destinatario', e.target.value)}
                placeholder="Nome ou entidade..."
                className="h-8 text-sm"
              />
            </Field>
          </Section>

          {/* Datas */}
          <Section title="Datas" defaultOpen={false}>
            <Field label="Data inicial">
              <input
                type="date"
                value={params.dataInicial ?? ''}
                onChange={(e) => patch('dataInicial', e.target.value)}
                className="h-8 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1"
              />
            </Field>

            <Field label="Data final">
              <input
                type="date"
                value={params.dataFinal ?? ''}
                onChange={(e) => patch('dataFinal', e.target.value)}
                min={params.dataInicial}
                className="h-8 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1"
              />
            </Field>
          </Section>

          {/* Funcionário */}
          <Section title="Funcionário" defaultOpen={false}>
            <Field label="Nome / Apelido">
              <Input
                value={params.funcNome ?? ''}
                onChange={(e) => patch('funcNome', e.target.value)}
                placeholder="Nome do funcionário..."
                className="h-8 text-sm"
              />
            </Field>

            <Field label="Nº do Processo">
              <Input
                value={params.funcNumeroProcesso ?? ''}
                onChange={(e) => patch('funcNumeroProcesso', e.target.value)}
                placeholder="Ex: PROC-2024/00123"
                className="h-8 text-sm"
              />
            </Field>

            <Field label="Estado" span>
              <Select
                value={params.funcEstado || '__all__'}
                onValueChange={(v) =>
                  patch('funcEstado', v === '__all__' ? '' : (v as EstadoFuncionario))
                }
              >
                <SelectTrigger className="h-8 text-sm w-full">
                  <SelectValue placeholder="Todos os estados" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__all__">Todos os estados</SelectItem>
                  {FUNCIONARIO_STATES.map((s) => (
                    <SelectItem key={s.value} value={s.value}>
                      {s.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>

            <Field label="Nascimento (de)">
              <input
                type="date"
                value={params.funcNascimentoInicio ?? ''}
                onChange={(e) => patch('funcNascimentoInicio', e.target.value)}
                className="h-8 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1"
              />
            </Field>

            <Field label="Nascimento (até)">
              <input
                type="date"
                value={params.funcNascimentoFim ?? ''}
                onChange={(e) => patch('funcNascimentoFim', e.target.value)}
                min={params.funcNascimentoInicio}
                className="h-8 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1"
              />
            </Field>

            <Field label="Início de funções (de)">
              <input
                type="date"
                value={params.funcInicioFuncoesInicio ?? ''}
                onChange={(e) => patch('funcInicioFuncoesInicio', e.target.value)}
                className="h-8 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1"
              />
            </Field>

            <Field label="Início de funções (até)">
              <input
                type="date"
                value={params.funcInicioFuncoesFim ?? ''}
                onChange={(e) => patch('funcInicioFuncoesFim', e.target.value)}
                min={params.funcInicioFuncoesInicio}
                className="h-8 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1"
              />
            </Field>

            <Field label="Fim de funções (de)">
              <input
                type="date"
                value={params.funcFimFuncoesInicio ?? ''}
                onChange={(e) => patch('funcFimFuncoesInicio', e.target.value)}
                className="h-8 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1"
              />
            </Field>

            <Field label="Fim de funções (até)">
              <input
                type="date"
                value={params.funcFimFuncoesFim ?? ''}
                onChange={(e) => patch('funcFimFuncoesFim', e.target.value)}
                min={params.funcFimFuncoesInicio}
                className="h-8 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1"
              />
            </Field>
          </Section>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="ghost" size="sm" onClick={handleReset}>
            Limpar filtros
          </Button>
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button size="sm" onClick={handleSearch} className="gap-1.5">
            <Search className="h-3.5 w-3.5" />
            Pesquisar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
