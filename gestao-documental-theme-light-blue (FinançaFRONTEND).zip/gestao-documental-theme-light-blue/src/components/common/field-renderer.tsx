'use client';

import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import type { CustomField } from '@/types';

export interface FieldRendererProps {
  /** The CustomField definition from DocumentType.campos. */
  field: CustomField;
  value: unknown;
  onChange: (value: unknown) => void;
  onBlur?: () => void;
  error?: string;
  disabled?: boolean;
  className?: string;
}

/**
 * Renders a single CustomField as the appropriate input type.
 * Designed to be used inside react-hook-form's Controller:
 *
 * @example
 * <Controller
 *   control={form.control}
 *   name={`camposValores.${field.key}`}
 *   render={({ field: f, fieldState }) => (
 *     <FieldRenderer
 *       field={fieldDef}
 *       value={f.value}
 *       onChange={f.onChange}
 *       onBlur={f.onBlur}
 *       error={fieldState.error?.message}
 *     />
 *   )}
 * />
 */
export function FieldRenderer({
  field,
  value,
  onChange,
  onBlur,
  error,
  disabled = false,
  className,
}: FieldRendererProps) {
  const id = `field-${field.key}`;
  const strValue = value === null || value === undefined ? '' : String(value);
  const numValue = typeof value === 'number' ? value : Number(value) || 0;
  const boolValue = Boolean(value);

  return (
    <div className={cn('space-y-1.5', className)}>
      <Label htmlFor={id} className="text-sm font-medium text-slate-700">
        {field.label}
        {field.obrigatorio && <span className="ml-0.5 text-red-500">*</span>}
      </Label>

      {field.tipo === 'text' && (
        <Input
          id={id}
          value={strValue}
          onChange={(e) => onChange(e.target.value)}
          onBlur={onBlur}
          disabled={disabled}
          aria-invalid={!!error}
          placeholder={`Inserir ${field.label.toLowerCase()}...`}
        />
      )}

      {field.tipo === 'textarea' && (
        <Textarea
          id={id}
          value={strValue}
          onChange={(e) => onChange(e.target.value)}
          onBlur={onBlur}
          disabled={disabled}
          aria-invalid={!!error}
          rows={3}
          placeholder={`Inserir ${field.label.toLowerCase()}...`}
        />
      )}

      {field.tipo === 'number' && (
        <Input
          id={id}
          type="number"
          value={numValue === 0 && strValue === '' ? '' : numValue}
          onChange={(e) => onChange(e.target.valueAsNumber)}
          onBlur={onBlur}
          disabled={disabled}
          aria-invalid={!!error}
        />
      )}

      {field.tipo === 'currency' && (
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-medium text-slate-400 select-none">
            AOA
          </span>
          <Input
            id={id}
            type="number"
            min={0}
            step={0.01}
            value={numValue === 0 && strValue === '' ? '' : numValue}
            onChange={(e) => onChange(e.target.valueAsNumber)}
            onBlur={onBlur}
            disabled={disabled}
            aria-invalid={!!error}
            className="pl-11"
          />
        </div>
      )}

      {field.tipo === 'date' && (
        <Input
          id={id}
          type="date"
          value={strValue}
          onChange={(e) => onChange(e.target.value)}
          onBlur={onBlur}
          disabled={disabled}
          aria-invalid={!!error}
        />
      )}

      {field.tipo === 'select' && (
        <Select
          value={strValue}
          onValueChange={(v) => onChange(v)}
          disabled={disabled}
        >
          <SelectTrigger id={id} aria-invalid={!!error} className="w-full">
            <SelectValue placeholder={`Selecionar ${field.label.toLowerCase()}...`} />
          </SelectTrigger>
          <SelectContent>
            {(field.opcoes ?? []).map((opt) => (
              <SelectItem key={opt} value={opt}>
                {opt}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}

      {field.tipo === 'boolean' && (
        <div className="flex items-center gap-3">
          <Switch
            id={id}
            checked={boolValue}
            onCheckedChange={(checked) => onChange(checked)}
            disabled={disabled}
          />
          <Label htmlFor={id} className="text-sm text-slate-600 cursor-pointer">
            {boolValue ? 'Sim' : 'Não'}
          </Label>
        </div>
      )}

      {error && (
        <p role="alert" className="text-xs text-red-500">
          {error}
        </p>
      )}
    </div>
  );
}
