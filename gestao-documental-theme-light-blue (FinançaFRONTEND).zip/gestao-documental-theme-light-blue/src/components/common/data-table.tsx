﻿'use client';

import { useState, useMemo, useEffect, useCallback } from 'react';
import {
  ChevronUp,
  ChevronDown,
  ChevronsUpDown,
  ChevronsLeft,
  ChevronLeft,
  ChevronRight,
  ChevronsRight,
  Settings2,
  Check,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Checkbox } from '@/components/ui/checkbox';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

// ── Types ────────────────────────────────────────────────────────────────────

export interface ColumnDef<T> {
  /** Unique column identifier used for sorting and visibility. */
  id: string;
  header: string;
  /** Key of T used for default cell rendering and client-side sorting. */
  accessor?: keyof T;
  /** Custom cell renderer. Takes precedence over accessor for display. */
  cell?: (row: T) => React.ReactNode;
  sortable?: boolean;
  width?: string | number;
  align?: 'left' | 'center' | 'right';
  /** Start hidden; togglable via the column-visibility popover. */
  hidden?: boolean;
}

export interface DataTableProps<T> {
  columns: ColumnDef<T>[];
  data: T[];
  loading?: boolean;
  /** Rendered inside the empty-state cell when data is empty and not loading. */
  emptyState?: React.ReactNode;
  /** External content placed in the table toolbar (search, filters, bulk actions). */
  toolbar?: React.ReactNode;
  /** Enable row selection via checkboxes. */
  selectable?: boolean;
  /** Called whenever the selection set changes. */
  onSelectionChange?: (selected: T[]) => void;
  defaultPageSize?: 5 | 10 | 15 | 25;
  /** Reduces cell padding for dense lists. */
  compact?: boolean;
  className?: string;
  /** Called when a data row is clicked (for navigation or preview). */
  onRowClick?: (row: T) => void;
  /** Extra className applied per-row (for active/preview highlight). */
  rowClassName?: (row: T) => string;
}

type SortDir = 'asc' | 'desc';
type SortState = { id: string; dir: SortDir } | null;

const PAGE_SIZE_OPTIONS = [5, 10, 15, 25] as const;

// ── Helpers ───────────────────────────────────────────────────────────────────

function compareValues(a: unknown, b: unknown, dir: SortDir): number {
  const numA = Number(a);
  const numB = Number(b);
  if (!Number.isNaN(numA) && !Number.isNaN(numB)) {
    return dir === 'asc' ? numA - numB : numB - numA;
  }
  const result = String(a ?? '').localeCompare(String(b ?? ''), 'pt');
  return dir === 'asc' ? result : -result;
}

const ALIGN_CLASS: Record<NonNullable<ColumnDef<unknown>['align']>, string> = {
  left: 'text-left',
  center: 'text-center',
  right: 'text-right',
};

// ── Component ────────────────────────────────────────────────────────────────

/**
 * Generic, typed data table with client-side sort, pagination, row selection,
 * and column-visibility toggling.
 *
 * @example
 * const columns: ColumnDef<DocumentRecord>[] = [
 *   { id: 'numero', header: 'Nº', accessor: 'numero', sortable: true },
 *   { id: 'assunto', header: 'Assunto', accessor: 'assunto' },
 *   { id: 'estado', header: 'Estado', cell: (row) => <StatusBadge status={row.estado} /> },
 * ];
 * <DataTable columns={columns} data={docs} selectable onSelectionChange={setSelected} />
 */
export function DataTable<T>({
  columns,
  data,
  loading = false,
  emptyState,
  toolbar,
  selectable = false,
  onSelectionChange,
  defaultPageSize = 10,
  compact = false,
  className,
  onRowClick,
  rowClassName,
}: DataTableProps<T>) {
  const [sort, setSort] = useState<SortState>(null);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState<number>(defaultPageSize);
  // Set of original-data indices (stable across sort/page changes)
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [hiddenCols, setHiddenCols] = useState<Set<string>>(
    () => new Set(columns.filter((c) => c.hidden).map((c) => c.id)),
  );

  // Reset page when data reference changes (e.g. after external filtering)
  useEffect(() => {
    setPage(0);
    setSelected(new Set());
  }, [data]);

  // Notify parent of selection changes
  useEffect(() => {
    onSelectionChange?.(data.filter((_, i) => selected.has(i)));
  }, [selected, data, onSelectionChange]);

  // Pair each row with its original index so selection survives sorting
  const indexed = useMemo(
    () => data.map((row, originalIndex) => ({ row, originalIndex })),
    [data],
  );

  const sorted = useMemo(() => {
    if (!sort) return indexed;
    const col = columns.find((c) => c.id === sort.id);
    if (!col?.accessor) return indexed;
    return [...indexed].sort((a, b) =>
      compareValues(
        a.row[col.accessor as keyof T],
        b.row[col.accessor as keyof T],
        sort.dir,
      ),
    );
  }, [indexed, sort, columns]);

  const pageCount = Math.max(1, Math.ceil(sorted.length / pageSize));
  const paged = sorted.slice(page * pageSize, (page + 1) * pageSize);
  const visibleColumns = columns.filter((c) => !hiddenCols.has(c.id));

  // Selection helpers
  const pageIndices = paged.map((r) => r.originalIndex);
  const pageSelectedCount = pageIndices.filter((i) => selected.has(i)).length;
  const isAllPageSelected =
    pageIndices.length > 0 && pageSelectedCount === pageIndices.length;
  const isSomePageSelected = pageSelectedCount > 0 && !isAllPageSelected;

  const toggleRow = useCallback((idx: number) => {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(idx) ? next.delete(idx) : next.add(idx);
      return next;
    });
  }, []);

  const toggleAllPage = useCallback(() => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (isAllPageSelected) {
        pageIndices.forEach((i) => next.delete(i));
      } else {
        pageIndices.forEach((i) => next.add(i));
      }
      return next;
    });
  }, [isAllPageSelected, pageIndices]);

  const toggleSort = useCallback((colId: string) => {
    setSort((prev) => {
      if (prev?.id === colId) {
        return prev.dir === 'asc' ? { id: colId, dir: 'desc' } : null;
      }
      return { id: colId, dir: 'asc' };
    });
    setPage(0);
  }, []);

  const toggleColumn = useCallback((colId: string) => {
    setHiddenCols((prev) => {
      const next = new Set(prev);
      next.has(colId) ? next.delete(colId) : next.add(colId);
      return next;
    });
  }, []);

  const cellPad = compact ? 'px-3 py-1.5' : 'px-4 py-3';
  const headPad = compact ? 'px-3 py-2' : 'px-4 py-3';
  const colCount = visibleColumns.length + (selectable ? 1 : 0);

  function renderCell(col: ColumnDef<T>, row: T): React.ReactNode {
    if (col.cell) return col.cell(row);
    if (col.accessor !== undefined) {
      const val = row[col.accessor];
      if (val === null || val === undefined) return <span className="text-slate-300">—</span>;
      return String(val);
    }
    return <span className="text-slate-300">—</span>;
  }

  return (
    <div className={cn('flex flex-col rounded-xl border border-slate-200 bg-white shadow-xs overflow-hidden', className)}>
      {/* Toolbar */}
      <div className="flex items-center justify-between gap-2 px-4 py-2.5 border-b border-slate-100 bg-white min-h-12">
        <div className="flex items-center gap-2 flex-1 min-w-0">{toolbar}</div>

        {/* Column visibility */}
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              className="shrink-0 gap-1.5 text-slate-600 h-8"
            >
              <Settings2 className="h-3.5 w-3.5" />
              <span className="hidden sm:inline text-xs">Colunas</span>
            </Button>
          </PopoverTrigger>
          <PopoverContent align="end" className="w-52 p-2">
            <p className="mb-2 px-1 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
              Visibilidade
            </p>
            <div className="space-y-0.5">
              {columns.map((col) => {
                const visible = !hiddenCols.has(col.id);
                return (
                  <label
                    key={col.id}
                    className="flex cursor-pointer items-center gap-2.5 rounded px-1.5 py-1.5 text-sm text-slate-700 hover:bg-slate-50 transition-colors"
                  >
                    <span
                      className={cn(
                        'flex h-4 w-4 shrink-0 items-center justify-center rounded border transition-colors',
                        visible
                          ? 'bg-sky-600 border-sky-600'
                          : 'border-slate-300 bg-white',
                      )}
                    >
                      {visible && <Check className="h-3 w-3 text-white" />}
                    </span>
                    <input
                      type="checkbox"
                      className="sr-only"
                      checked={visible}
                      onChange={() => toggleColumn(col.id)}
                      aria-label={`${visible ? 'Ocultar' : 'Mostrar'} coluna ${col.header}`}
                    />
                    <span className="truncate">{col.header}</span>
                  </label>
                );
              })}
            </div>
          </PopoverContent>
        </Popover>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              {selectable && (
                <th className={cn(headPad, 'w-10')}>
                  <Checkbox
                    checked={isAllPageSelected ? true : isSomePageSelected ? 'indeterminate' : false}
                    onCheckedChange={toggleAllPage}
                    aria-label="Selecionar página"
                  />
                </th>
              )}
              {visibleColumns.map((col) => (
                <th
                  key={col.id}
                  className={cn(
                    headPad,
                    'text-xs font-semibold uppercase tracking-wide text-slate-500 whitespace-nowrap',
                    ALIGN_CLASS[col.align ?? 'left'],
                    col.sortable &&
                      'cursor-pointer select-none hover:text-slate-900 hover:bg-slate-100 transition-colors',
                  )}
                  style={col.width ? { width: col.width } : undefined}
                  onClick={col.sortable ? () => toggleSort(col.id) : undefined}
                  aria-sort={
                    sort?.id === col.id
                      ? sort.dir === 'asc'
                        ? 'ascending'
                        : 'descending'
                      : 'none'
                  }
                >
                  <span className="inline-flex items-center gap-1">
                    {col.header}
                    {col.sortable &&
                      (sort?.id === col.id ? (
                        sort.dir === 'asc' ? (
                          <ChevronUp className="h-3 w-3 text-sky-600" />
                        ) : (
                          <ChevronDown className="h-3 w-3 text-sky-600" />
                        )
                      ) : (
                        <ChevronsUpDown className="h-3 w-3 text-slate-300" />
                      ))}
                  </span>
                </th>
              ))}
            </tr>
          </thead>

          <tbody className="bg-white divide-y divide-slate-100">
            {loading ? (
              Array.from({ length: pageSize }).map((_, i) => (
                <tr key={i}>
                  {selectable && (
                    <td className={cellPad}>
                      <Skeleton className="h-4 w-4 rounded" />
                    </td>
                  )}
                  {visibleColumns.map((col) => (
                    <td key={col.id} className={cellPad}>
                      <Skeleton
                        className={cn(
                          'h-4 rounded',
                          col.align === 'center' && 'mx-auto',
                          col.align === 'right' && 'ml-auto',
                        )}
                        style={{ width: `${50 + Math.random() * 40}%` }}
                      />
                    </td>
                  ))}
                </tr>
              ))
            ) : paged.length === 0 ? (
              <tr>
                <td colSpan={colCount} className="py-12 text-center">
                  {emptyState ?? (
                    <p className="text-sm text-slate-400">Sem dados para exibir.</p>
                  )}
                </td>
              </tr>
            ) : (
              paged.map(({ row, originalIndex }) => (
                <tr
                  key={originalIndex}
                  onClick={onRowClick ? () => onRowClick(row) : undefined}
                  className={cn(
                    'transition-colors hover:bg-slate-50',
                    selected.has(originalIndex) && 'bg-sky-50 hover:bg-sky-50',
                    onRowClick && 'cursor-pointer',
                    rowClassName?.(row),
                  )}
                >
                  {selectable && (
                    <td className={cellPad}>
                      <Checkbox
                        checked={selected.has(originalIndex)}
                        onCheckedChange={() => toggleRow(originalIndex)}
                        aria-label={`Selecionar linha ${originalIndex + 1}`}
                      />
                    </td>
                  )}
                  {visibleColumns.map((col) => (
                    <td
                      key={col.id}
                      className={cn(
                        cellPad,
                        'text-slate-700',
                        ALIGN_CLASS[col.align ?? 'left'],
                      )}
                      style={col.width ? { width: col.width } : undefined}
                    >
                      {renderCell(col, row)}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination footer */}
      <div className="flex items-center justify-between gap-4 border-t border-slate-100 bg-white px-4 py-2.5 text-xs">
        {/* Page size selector */}
        <div className="flex items-center gap-1.5 text-slate-500">
          <span>Por página:</span>
          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setPage(0);
            }}
            className="rounded border border-slate-200 bg-white px-1.5 py-0.5 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500"
            aria-label="Itens por página"
          >
            {PAGE_SIZE_OPTIONS.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        {/* Count label */}
        <span className="text-slate-500">
          {sorted.length === 0
            ? '0 itens'
            : `${page * pageSize + 1}–${Math.min(
                (page + 1) * pageSize,
                sorted.length,
              )} de ${sorted.length}`}
        </span>

        {/* Navigation */}
        <div className="flex items-center gap-0.5">
          {[
            {
              label: 'Primeira',
              icon: <ChevronsLeft className="h-4 w-4" />,
              disabled: page === 0,
              onClick: () => setPage(0),
            },
            {
              label: 'Anterior',
              icon: <ChevronLeft className="h-4 w-4" />,
              disabled: page === 0,
              onClick: () => setPage((p) => p - 1),
            },
            {
              label: 'Próxima',
              icon: <ChevronRight className="h-4 w-4" />,
              disabled: page >= pageCount - 1,
              onClick: () => setPage((p) => p + 1),
            },
            {
              label: 'Última',
              icon: <ChevronsRight className="h-4 w-4" />,
              disabled: page >= pageCount - 1,
              onClick: () => setPage(pageCount - 1),
            },
          ].map(({ label, icon, disabled, onClick }) => (
            <button
              key={label}
              onClick={onClick}
              disabled={disabled}
              aria-label={`${label} página`}
              className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 disabled:opacity-40 disabled:pointer-events-none transition-colors"
            >
              {icon}
            </button>
          ))}
          <span className="px-2 text-slate-600">
            {page + 1} / {pageCount}
          </span>
        </div>
      </div>

      {/* Selection bar */}
      {selectable && selected.size > 0 && (
        <div className="flex items-center justify-between gap-2 border-t border-sky-200 bg-sky-50 px-4 py-2 text-xs text-sky-700">
          <span>
            {selected.size} {selected.size === 1 ? 'item' : 'itens'} selecionado(s)
          </span>
          <button
            onClick={() => setSelected(new Set())}
            className="font-semibold underline-offset-2 hover:underline transition-all"
          >
            Limpar seleção
          </button>
        </div>
      )}
    </div>
  );
}
