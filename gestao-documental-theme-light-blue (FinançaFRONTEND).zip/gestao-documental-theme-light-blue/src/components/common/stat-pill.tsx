import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';

type TrendDir = 'up' | 'down' | 'neutral';
type FormatType = 'number' | 'currency' | 'percentage';

interface StatPillProps {
  value: number;
  label: string;
  /** Compared against value to derive trend when trend prop is omitted. */
  target?: number;
  trend?: TrendDir;
  format?: FormatType;
  /** Text prepended before the formatted value. */
  prefix?: string;
  /** Text appended after the formatted value. */
  suffix?: string;
  className?: string;
}

function formatValue(value: number, format: FormatType, prefix?: string, suffix?: string): string {
  let formatted: string;
  if (format === 'currency') {
    formatted = `AOA ${value.toLocaleString('pt', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  } else if (format === 'percentage') {
    formatted = `${value.toFixed(1)}%`;
  } else {
    formatted = value.toLocaleString('pt');
  }
  return `${prefix ?? ''}${formatted}${suffix ?? ''}`;
}

function deriveTrend(value: number, target?: number): TrendDir {
  if (target === undefined) return 'neutral';
  if (value > target) return 'up';
  if (value < target) return 'down';
  return 'neutral';
}

const TREND_CONFIG: Record<TrendDir, { icon: React.ElementType; className: string }> = {
  up: { icon: TrendingUp, className: 'text-green-600' },
  down: { icon: TrendingDown, className: 'text-red-500' },
  neutral: { icon: Minus, className: 'text-slate-400' },
};

/**
 * Compact metric pill with optional trend indicator.
 *
 * @example
 * <StatPill value={42} target={50} label="Documentos Pendentes" format="number" />
 * <StatPill value={4250000} label="Total Salários" format="currency" trend="up" />
 */
export function StatPill({
  value,
  label,
  target,
  trend,
  format = 'number',
  prefix,
  suffix,
  className,
}: StatPillProps) {
  const dir: TrendDir = trend ?? deriveTrend(value, target);
  const { icon: TrendIcon, className: trendClass } = TREND_CONFIG[dir];

  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-lg border border-slate-200 bg-white px-4 py-3 shadow-xs',
        className,
      )}
    >
      <div className="flex-1 min-w-0">
        <p className="truncate text-xs font-medium text-slate-500">{label}</p>
        <p className="mt-0.5 text-lg font-semibold tracking-tight text-slate-900">
          {formatValue(value, format, prefix, suffix)}
        </p>
        {target !== undefined && (
          <p className="mt-0.5 text-xs text-slate-400">
            Meta: {formatValue(target, format)}
          </p>
        )}
      </div>
      <div className={cn('shrink-0', trendClass)}>
        <TrendIcon className="h-5 w-5" />
      </div>
    </div>
  );
}
