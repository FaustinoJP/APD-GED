﻿import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { resolveFileUrl } from '@/lib/file-url';

export type TimelineVariant = 'default' | 'success' | 'error' | 'warning' | 'pending';

export interface TimelineItem {
  id: string;
  label: string;
  description?: string;
  date: string;
  icon?: React.ReactNode;
  variant?: TimelineVariant;
  user?: { nome: string; avatarUrl?: string };
}

interface TimelineProps {
  items: TimelineItem[];
  className?: string;
}

const VARIANT_DOT: Record<TimelineVariant, string> = {
  default: 'bg-slate-200 border-slate-300',
  success: 'bg-green-500 border-green-500',
  error: 'bg-red-500 border-red-500',
  warning: 'bg-amber-500 border-amber-500',
  pending: 'bg-sky-500 border-sky-500',
};

const VARIANT_LABEL: Record<TimelineVariant, string> = {
  default: 'text-slate-700',
  success: 'text-green-700',
  error: 'text-red-700',
  warning: 'text-amber-700',
  pending: 'text-sky-700',
};

function getInitials(nome: string): string {
  return nome
    .split(' ')
    .slice(0, 2)
    .map((n) => n[0]?.toUpperCase() ?? '')
    .join('');
}

function formatDate(iso: string): string {
  try {
    return format(new Date(iso), "d 'de' MMM 'às' HH:mm", { locale: ptBR });
  } catch {
    return iso;
  }
}

/**
 * Vertical timeline for circulation history and document events.
 *
 * @example
 * <Timeline items={[
 *   { id: '1', label: 'Aprovado', date: doc.atualizadoEm, variant: 'success',
 *     user: { nome: 'Admin Utilizador' } }
 * ]} />
 */
export function Timeline({ items, className }: TimelineProps) {
  if (items.length === 0) {
    return (
      <p className="py-6 text-center text-sm text-slate-400">
        Sem histórico de actividade.
      </p>
    );
  }

  return (
    <ol className={cn('relative space-y-0', className)}>
      {items.map((item, index) => {
        const variant: TimelineVariant = item.variant ?? 'default';
        const isLast = index === items.length - 1;

        return (
          <li key={item.id} className="relative flex gap-4 pb-6">
            {/* Connector line */}
            {!isLast && (
              <span
                aria-hidden
                className="absolute left-[11px] top-6 bottom-0 w-0.5 bg-slate-200"
              />
            )}

            {/* Dot / Icon */}
            <div className="relative mt-0.5 shrink-0">
              {item.icon ? (
                <div
                  className={cn(
                    'flex h-6 w-6 items-center justify-center rounded-full border-2',
                    VARIANT_DOT[variant],
                    variant !== 'default' && 'text-white',
                  )}
                >
                  <span className="[&>svg]:h-3 [&>svg]:w-3">{item.icon}</span>
                </div>
              ) : (
                <div
                  className={cn(
                    'h-6 w-6 rounded-full border-2',
                    VARIANT_DOT[variant],
                  )}
                />
              )}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0 pt-0.5">
              <div className="flex items-start justify-between gap-2 flex-wrap">
                <p className={cn('text-sm font-medium leading-snug', VARIANT_LABEL[variant])}>
                  {item.label}
                </p>
                <time
                  dateTime={item.date}
                  className="shrink-0 text-xs text-slate-400 whitespace-nowrap"
                >
                  {formatDate(item.date)}
                </time>
              </div>

              {item.user && (
                <div className="mt-1 flex items-center gap-1.5">
                  {item.user.avatarUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={resolveFileUrl(item.user.avatarUrl)}
                      alt={item.user.nome}
                      className="h-4 w-4 rounded-full object-cover"
                    />
                  ) : (
                    <span className="inline-flex h-4 w-4 items-center justify-center rounded-full bg-sky-100 text-[9px] font-bold text-sky-700">
                      {getInitials(item.user.nome)}
                    </span>
                  )}
                  <span className="text-xs text-slate-500">{item.user.nome}</span>
                </div>
              )}

              {item.description && (
                <p className="mt-1 text-xs text-slate-500">{item.description}</p>
              )}
            </div>
          </li>
        );
      })}
    </ol>
  );
}
