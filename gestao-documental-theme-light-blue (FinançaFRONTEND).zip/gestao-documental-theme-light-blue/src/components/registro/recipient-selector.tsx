﻿'use client';

import { useState } from 'react';
import { Search, X, Users, Building2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { Destinatario, User, Entity } from '@/types';

interface RecipientSelectorProps {
  value: Destinatario[];
  onChange: (value: Destinatario[]) => void;
  users?: User[];
  entities?: Entity[];
  /** If true, only one recipient can be selected at a time. */
  single?: boolean;
}

/**
 * Tabbed multi-select for document recipients (Utilizadores & Entidades).
 * Pass `single` for remetente fields that accept only one sender.
 *
 * @example
 * <RecipientSelector
 *   value={destinatarios}
 *   onChange={setDestinatarios}
 *   users={configStore.users}
 *   entities={configStore.entities}
 * />
 */
export function RecipientSelector({
  value,
  onChange,
  users = [],
  entities = [],
  single = false,
}: RecipientSelectorProps) {
  const [userQ, setUserQ] = useState('');
  const [entityQ, setEntityQ] = useState('');

  const isSelected = (tipo: Destinatario['tipo'], id: string) =>
    value.some((d) => d.tipo === tipo && d.id === id);

  function toggle(tipo: Destinatario['tipo'], id: string) {
    if (isSelected(tipo, id)) {
      onChange(value.filter((d) => !(d.tipo === tipo && d.id === id)));
    } else if (single) {
      onChange([{ tipo, id }]);
    } else {
      onChange([...value, { tipo, id }]);
    }
  }

  function getLabel(d: Destinatario): string {
    if (d.tipo === 'user') return users.find((u) => u.id === d.id)?.nome ?? d.id;
    if (d.tipo === 'entity') return entities.find((e) => e.id === d.id)?.nome ?? d.id;
    return d.id;
  }

  const filteredUsers = users.filter(
    (u) =>
      u.nome.toLowerCase().includes(userQ.toLowerCase()) ||
      u.email.toLowerCase().includes(userQ.toLowerCase()),
  );

  const filteredEntities = entities.filter((e) =>
    e.nome.toLowerCase().includes(entityQ.toLowerCase()),
  );

  return (
    <div className="space-y-2">
      {/* Selected chips */}
      {value.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {value.map((d) => (
            <Badge
              key={`${d.tipo}:${d.id}`}
              variant="secondary"
              className="gap-1 pr-1.5 text-xs"
            >
              {d.tipo === 'user' ? (
                <Users className="h-2.5 w-2.5" />
              ) : (
                <Building2 className="h-2.5 w-2.5" />
              )}
              {getLabel(d)}
              <button
                type="button"
                onClick={() => toggle(d.tipo, d.id)}
                className="ml-0.5 rounded-full p-0.5 hover:bg-slate-300/60"
                aria-label={`Remover ${getLabel(d)}`}
              >
                <X className="h-2.5 w-2.5" />
              </button>
            </Badge>
          ))}
        </div>
      )}

      <Tabs defaultValue="users">
        <TabsList className="h-7">
          <TabsTrigger value="users" className="gap-1 text-xs h-full">
            <Users className="h-3 w-3" />
            Utilizadores
          </TabsTrigger>
          <TabsTrigger value="entities" className="gap-1 text-xs h-full">
            <Building2 className="h-3 w-3" />
            Entidades
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users">
          <div className="mt-2 space-y-1.5">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-3 w-3 -translate-y-1/2 text-slate-400" />
              <Input
                value={userQ}
                onChange={(e) => setUserQ(e.target.value)}
                placeholder="Filtrar utilizadores..."
                className="h-7 pl-8 text-xs"
              />
            </div>
            <ScrollArea className="h-32 rounded-md border border-slate-100">
              <div className="p-1">
                {filteredUsers.length === 0 ? (
                  <p className="py-3 text-center text-xs text-slate-400">Sem resultados</p>
                ) : (
                  filteredUsers.map((u) => (
                    <label
                      key={u.id}
                      className={cn(
                        'flex cursor-pointer items-center gap-2 rounded px-2 py-1.5 hover:bg-slate-50 transition-colors',
                        isSelected('user', u.id) && 'bg-sky-50',
                      )}
                    >
                      <Checkbox
                        checked={isSelected('user', u.id)}
                        onCheckedChange={() => toggle('user', u.id)}
                        className="shrink-0"
                      />
                      <span className="min-w-0 flex-1 truncate text-xs font-medium text-slate-700">
                        {u.nome}
                      </span>
                      <span className="shrink-0 text-xs text-slate-400">{u.email}</span>
                    </label>
                  ))
                )}
              </div>
            </ScrollArea>
          </div>
        </TabsContent>

        <TabsContent value="entities">
          <div className="mt-2 space-y-1.5">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-3 w-3 -translate-y-1/2 text-slate-400" />
              <Input
                value={entityQ}
                onChange={(e) => setEntityQ(e.target.value)}
                placeholder="Filtrar entidades..."
                className="h-7 pl-8 text-xs"
              />
            </div>
            <ScrollArea className="h-32 rounded-md border border-slate-100">
              <div className="p-1">
                {filteredEntities.length === 0 ? (
                  <p className="py-3 text-center text-xs text-slate-400">Sem resultados</p>
                ) : (
                  filteredEntities.map((e) => (
                    <label
                      key={e.id}
                      className={cn(
                        'flex cursor-pointer items-center gap-2 rounded px-2 py-1.5 hover:bg-slate-50 transition-colors',
                        isSelected('entity', e.id) && 'bg-sky-50',
                      )}
                    >
                      <Checkbox
                        checked={isSelected('entity', e.id)}
                        onCheckedChange={() => toggle('entity', e.id)}
                        className="shrink-0"
                      />
                      <span className="min-w-0 flex-1 truncate text-xs font-medium text-slate-700">
                        {e.nome}
                      </span>
                      <span className="shrink-0 text-xs capitalize text-slate-400">
                        {e.tipo}
                      </span>
                    </label>
                  ))
                )}
              </div>
            </ScrollArea>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
