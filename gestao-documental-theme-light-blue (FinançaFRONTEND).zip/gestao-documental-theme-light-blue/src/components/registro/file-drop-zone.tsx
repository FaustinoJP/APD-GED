﻿'use client';

import { useCallback, useRef, useState } from 'react';
import { Upload, X, FileText, FileSpreadsheet, File, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import type { Attachment } from '@/types';
import type { UploadResult } from '@/lib/api/uploads';

interface FileDropZoneProps {
  attachments: Attachment[];
  onAdd: (attachment: Attachment) => void;
  onRemove: (id: string) => void;
  currentUserId: string;
  disabled?: boolean;
  /**
   * Se fornecida, cada ficheiro é imediatamente carregado para o servidor.
   * O resultado (URL, tamanho, formato) é usado em vez do base64.
   * Usado no modo API para pre-upload com rollback.
   */
  uploadFile?: (file: File) => Promise<UploadResult>;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function FileIcon({ format }: { format: string }) {
  if (format === 'pdf') return <FileText className="h-4 w-4 text-red-500" />;
  if (['doc', 'docx'].includes(format)) return <FileText className="h-4 w-4 text-blue-500" />;
  if (['xls', 'xlsx'].includes(format)) return <FileSpreadsheet className="h-4 w-4 text-green-600" />;
  return <File className="h-4 w-4 text-slate-400" />;
}

/**
 * Zona de drag-and-drop para upload de ficheiros.
 *
 * Modo localStorage (uploadFile não fornecida): converte para base64.
 * Modo API (uploadFile fornecida): envia imediatamente para o servidor;
 * o componente pai deve fazer rollback (apiDeleteUpload) se o registo for abandonado.
 */
export function FileDropZone({
  attachments,
  onAdd,
  onRemove,
  currentUserId,
  disabled = false,
  uploadFile,
}: FileDropZoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  // Mapa fileId → estado de upload ('uploading' | 'error')
  const [uploadingIds, setUploadingIds] = useState<Map<string, 'uploading' | 'error'>>(new Map());
  const inputRef = useRef<HTMLInputElement>(null);

  const processFiles = useCallback(
    async (files: FileList) => {
      const fileArray = Array.from(files);

      if (uploadFile) {
        // ── Modo API: pre-upload imediato ────────────────────────────────────
        await Promise.all(
          fileArray.map(async (file) => {
            const tempId = `pending-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
            setUploadingIds((prev) => new Map(prev).set(tempId, 'uploading'));

            try {
              const result = await uploadFile(file);
              setUploadingIds((prev) => {
                const next = new Map(prev);
                next.delete(tempId);
                return next;
              });
              onAdd({
                id: result.id,
                nome: result.nome,
                versao: 1,
                estado: 'check_in',
                tamanho: result.tamanho,
                formato: result.formato,
                url: result.url,
                adicionadoPor: currentUserId,
                criadoEm: new Date().toISOString(),
              });
            } catch {
              setUploadingIds((prev) => new Map(prev).set(tempId, 'error'));
              // Remover indicador de erro após 3s
              setTimeout(() => {
                setUploadingIds((prev) => {
                  const next = new Map(prev);
                  next.delete(tempId);
                  return next;
                });
              }, 3000);
            }
          }),
        );
      } else {
        // ── Modo localStorage: converter para base64 ─────────────────────────
        await Promise.all(
          fileArray.map(
            (file) =>
              new Promise<void>((resolve) => {
                const reader = new FileReader();
                reader.onload = (ev) => {
                  const url = ev.target?.result as string;
                  const ext = file.name.split('.').pop()?.toLowerCase() ?? 'bin';
                  onAdd({
                    id: `att-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
                    nome: file.name,
                    versao: 1,
                    estado: 'check_in',
                    tamanho: file.size,
                    formato: ext,
                    url,
                    _file: file,
                    adicionadoPor: currentUserId,
                    criadoEm: new Date().toISOString(),
                  });
                  resolve();
                };
                reader.readAsDataURL(file);
              }),
          ),
        );
      }
    },
    [onAdd, currentUserId, uploadFile],
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      if (!disabled && e.dataTransfer.files.length > 0) {
        void processFiles(e.dataTransfer.files);
      }
    },
    [disabled, processFiles],
  );

  const isUploading = uploadingIds.size > 0 && [...uploadingIds.values()].some((s) => s === 'uploading');
  const hasErrors = [...uploadingIds.values()].some((s) => s === 'error');

  return (
    <div className="space-y-3">
      {/* Drop zone */}
      <div
        role="button"
        tabIndex={disabled ? -1 : 0}
        aria-label="Área de upload de ficheiros"
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        onClick={() => !disabled && inputRef.current?.click()}
        onKeyDown={(e) => e.key === 'Enter' && !disabled && inputRef.current?.click()}
        className={cn(
          'flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed p-6 transition-all cursor-pointer select-none outline-none focus-visible:ring-2 focus-visible:ring-sky-500',
          isDragging
            ? 'border-sky-400 bg-sky-50 scale-[1.01]'
            : 'border-slate-200 bg-slate-50 hover:border-sky-300 hover:bg-slate-100',
          disabled && 'pointer-events-none opacity-50 cursor-default',
          hasErrors && 'border-red-300 bg-red-50',
        )}
      >
        {isUploading ? (
          <Loader2 className="h-8 w-8 animate-spin text-sky-400" />
        ) : hasErrors ? (
          <AlertCircle className="h-8 w-8 text-red-400" />
        ) : (
          <Upload className={cn('h-8 w-8 transition-colors', isDragging ? 'text-sky-500' : 'text-slate-300')} />
        )}
        <div className="text-center">
          <p className="text-sm font-medium text-slate-600">
            {isUploading
              ? 'A enviar para o servidor...'
              : hasErrors
              ? 'Erro ao enviar. Tente novamente.'
              : 'Arraste ficheiros aqui'}
          </p>
          {!isUploading && !hasErrors && (
            <p className="mt-0.5 text-xs text-slate-400">
              ou{' '}
              <span className="text-sky-500 underline underline-offset-2">
                clique para selecionar
              </span>
            </p>
          )}
        </div>
        <input
          ref={inputRef}
          type="file"
          multiple
          className="hidden"
          disabled={disabled}
          onChange={(e) => {
            if (e.target.files?.length) {
              void processFiles(e.target.files);
              e.target.value = '';
            }
          }}
        />
      </div>

      {/* Attachment list */}
      {attachments.length > 0 && (
        <ul className="space-y-1.5" aria-label="Ficheiros anexados">
          {attachments.map((att) => (
            <li
              key={att.id}
              className="flex items-center gap-3 rounded-lg border border-slate-100 bg-white px-3 py-2.5 shadow-xs"
            >
              <FileIcon format={att.formato} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <p className="truncate text-sm font-medium text-slate-700">{att.nome}</p>
                  {att.url && !att.url.startsWith('data:') && (
                    <span title="Ficheiro no servidor">
                      <CheckCircle className="h-3.5 w-3.5 shrink-0 text-emerald-500" />
                    </span>
                  )}
                </div>
                <p className="mt-0.5 text-xs text-slate-400">
                  {formatBytes(att.tamanho)} · {att.formato.toUpperCase()}
                </p>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="icon-sm"
                aria-label={`Remover ${att.nome}`}
                onClick={() => onRemove(att.id)}
                className="shrink-0 text-slate-400 hover:text-red-500"
              >
                <X className="h-3.5 w-3.5" />
              </Button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
