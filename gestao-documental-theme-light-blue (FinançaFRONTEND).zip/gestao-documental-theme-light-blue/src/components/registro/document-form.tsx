'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';
import { Save, Loader2, Clock, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { SectionCard } from '@/components/common/section-card';
import { ProvinceSelect } from '@/components/common/province-select';
import { LocationPicker } from '@/components/common/location-picker';
import { FieldRenderer } from '@/components/common/field-renderer';
import { TagInput } from '@/components/common/tag-input';
import { FuncionarioCombobox } from '@/components/common/funcionario-combobox';
import { FileDropZone } from './file-drop-zone';
import { RecipientSelector } from './recipient-selector';
import { useDocumentsStore } from '@/store/documents-store';
import { useConfigStore } from '@/store/config-store';
import { useFuncionariosStore } from '@/store/funcionarios-store';
import { useAuthStore } from '@/store/auth-store';
import { gerarNumeroDocumento } from '@/lib/db';
import { apiUploadFile, apiDeleteUpload } from '@/lib/api/uploads';
import type { Attachment, Destinatario, DocumentRecord, TipoRegistro } from '@/types';

const IS_API_MODE = process.env.NEXT_PUBLIC_DATA_SOURCE === 'api';

const NONE = '__none__';

// ─── Validation schema (fixed fields) ────────────────────────────────────────

const schema = z.object({
  tipoDocumentoId: z.string().min(1, 'Selecione o tipo de documento'),
  assunto: z.string().min(3, 'Mínimo 3 caracteres'),
  data: z.string().min(1, 'Data obrigatória'),
  confidencial: z.boolean(),
  regiao: z.string().optional(),
  localizacaoFisicaId: z.string().optional(),
  remetenteTexto: z.string().optional(),
  funcionarioId: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

// ─── Draft persistence ────────────────────────────────────────────────────────

interface DraftData {
  formValues: FormValues;
  destinatarios: Destinatario[];
  remetente: Destinatario[];
  camposValores: Record<string, unknown>;
  tags: string[];
}

// ─── Per-tipoRegistro labels ──────────────────────────────────────────────────

const LABELS: Record<TipoRegistro, { remetente: string; destinatario: string }> = {
  entrada: { remetente: 'Remetente (origem externa)', destinatario: 'Destinatário interno *' },
  saida: { remetente: 'Remetente interno', destinatario: 'Destinatário externo *' },
  interno: { remetente: 'Remetente', destinatario: 'Destinatário *' },
};

// ─── Props ────────────────────────────────────────────────────────────────────

interface DocumentFormProps {
  tipoRegistro: TipoRegistro;
  draftKey: string;
  onCancel: () => void;
  onSuccess: (doc: DocumentRecord) => void;
}

/**
 * Full document registration form, reused by all three registro pages.
 * Dynamic campo section renders based on the selected DocumentType.
 * Auto-saves a draft to localStorage every 800ms.
 *
 * @example
 * <DocumentForm
 *   tipoRegistro="entrada"
 *   draftKey="gd:draft:entrada"
 *   onCancel={() => setSheetOpen(false)}
 *   onSuccess={(doc) => router.push(`/documentos/${doc.id}`)}
 * />
 */
export function DocumentForm({
  tipoRegistro,
  draftKey,
  onCancel,
  onSuccess,
}: DocumentFormProps) {
  const { documentTypes, users, entities } = useConfigStore();
  const createDoc = useDocumentsStore((s) => s.create);
  const documents = useDocumentsStore((s) => s.documents);
  const loadDocs = useDocumentsStore((s) => s.load);
  const funcionarios = useFuncionariosStore((s) => s.funcionarios);
  const funcLoaded = useFuncionariosStore((s) => s.loaded);
  const loadFuncionarios = useFuncionariosStore((s) => s.load);
  const currentUser = useAuthStore((s) => s.currentUser);

  // ── State outside RHF (complex / array fields) ────────────────────────────
  const [destinatarios, setDestinatarios] = useState<Destinatario[]>([]);
  const [remetente, setRemetente] = useState<Destinatario[]>([]);
  const [camposValores, setCamposValores] = useState<Record<string, unknown>>({});
  const [tags, setTags] = useState<string[]>([]);
  const [anexos, setAnexos] = useState<Attachment[]>([]);
  const [camposErrors, setCamposErrors] = useState<Record<string, string>>({});
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const draftTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  // IDs dos ficheiros pré-carregados no servidor mas ainda não confirmados via submit
  const pendingUploadIds = useRef<Set<string>>(new Set());

  // ── RHF ───────────────────────────────────────────────────────────────────
  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      tipoDocumentoId: '',
      assunto: '',
      data: new Date().toISOString().split('T')[0],
      confidencial: false,
      regiao: '',
      localizacaoFisicaId: '',
      remetenteTexto: '',
      funcionarioId: NONE,
    },
  });

  const {
    register,
    handleSubmit,
    watch,
    control,
    setValue,
    formState: { errors, isSubmitting },
  } = form;

  // ── Derived ───────────────────────────────────────────────────────────────
  const compatibleTypes = documentTypes.filter(
    (dt) => dt.ativo && (dt.registro === tipoRegistro || dt.registro === 'todos'),
  );

  const tipoDocumentoId = watch('tipoDocumentoId');
  const funcionarioId = watch('funcionarioId');
  const selectedType = compatibleTypes.find((dt) => dt.id === tipoDocumentoId);

  // Documentos internos não exigem participantes (remetente/destinatários)
  const isInterno = tipoRegistro === 'interno';

  // Carregar dados auxiliares (funcionários para o seletor, documentos para sugestões de tags)
  useEffect(() => {
    if (!funcLoaded) loadFuncionarios();
    loadDocs();
  }, [funcLoaded, loadFuncionarios, loadDocs]);

  // Sugestões de tags: palavras-chave já usadas noutros documentos
  const tagSuggestions = useMemo(
    () => Array.from(new Set(documents.flatMap((d) => d.tags ?? []))).sort(),
    [documents],
  );

  // Reset campos when document type changes, preserving values for matching keys
  useEffect(() => {
    setCamposValores((prev) => {
      if (!selectedType) return {};
      const next: Record<string, unknown> = {};
      for (const campo of selectedType.campos) {
        next[campo.key] = prev[campo.key] ?? '';
      }
      return next;
    });
    setCamposErrors({});
  }, [tipoDocumentoId, selectedType]);

  // Clear remetenteTexto when a sistema remetente is selected
  useEffect(() => {
    if (remetente.length > 0) setValue('remetenteTexto', '');
  }, [remetente, setValue]);

  // ── Draft: load on first mount ────────────────────────────────────────────
  useEffect(() => {
    const raw = typeof window !== 'undefined' ? localStorage.getItem(draftKey) : null;
    if (!raw) return;
    try {
      const draft = JSON.parse(raw) as DraftData;
      form.reset(draft.formValues);
      setDestinatarios(draft.destinatarios ?? []);
      setRemetente(draft.remetente ?? []);
      setCamposValores(draft.camposValores ?? {});
      setTags(draft.tags ?? []);
    } catch {
      // corrupt draft — silently discard
    }
    // Only run once on mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [draftKey]);

  // ── Draft: autosave (debounced 800ms) ─────────────────────────────────────
  const formValues = watch();
  useEffect(() => {
    clearTimeout(draftTimer.current);
    draftTimer.current = setTimeout(() => {
      if (typeof window === 'undefined') return;
      const data: DraftData = { formValues, destinatarios, remetente, camposValores, tags };
      localStorage.setItem(draftKey, JSON.stringify(data));
      setLastSaved(new Date());
    }, 800);
    return () => clearTimeout(draftTimer.current);
  }, [formValues, destinatarios, remetente, camposValores, tags, draftKey]);

  // ── beforeunload guard: warn when uploads are pending ────────────────────
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (IS_API_MODE && pendingUploadIds.current.size > 0) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, []);

  // ── Attachment handlers ───────────────────────────────────────────────────
  const addAnexo = useCallback((att: Attachment) => {
    setAnexos((prev) => [...prev, att]);
    // Track server-uploaded files for rollback
    if (IS_API_MODE && att.url && !att.url.startsWith('data:')) {
      pendingUploadIds.current.add(att.id);
    }
  }, []);

  const removeAnexo = useCallback((id: string) => {
    setAnexos((prev) => {
      const att = prev.find((a) => a.id === id);
      // Rollback individual file if it was pre-uploaded
      if (IS_API_MODE && att?.url && !att.url.startsWith('data:')) {
        pendingUploadIds.current.delete(id);
        void apiDeleteUpload(id).catch(() => undefined);
      }
      return prev.filter((a) => a.id !== id);
    });
  }, []);

  // ── Cancel with rollback ──────────────────────────────────────────────────
  const handleCancel = useCallback(async () => {
    if (IS_API_MODE && pendingUploadIds.current.size > 0) {
      const confirmed = window.confirm(
        'Tem certeza que deseja cancelar? Os ficheiros já carregados serão eliminados.',
      );
      if (!confirmed) return;
      const ids = [...pendingUploadIds.current];
      pendingUploadIds.current.clear();
      await Promise.allSettled(ids.map((id) => apiDeleteUpload(id)));
    }
    onCancel();
  }, [onCancel]);

  // ── Submit ────────────────────────────────────────────────────────────────
  async function onSubmit(values: FormValues) {
    if (!isInterno && destinatarios.length === 0) {
      toast.error('Adicione pelo menos um destinatário.');
      return;
    }

    if (anexos.length === 0) {
      toast.error('Adicione pelo menos um ficheiro.');
      return;
    }

    // Validate required custom campos
    const requiredMissing = (selectedType?.campos ?? []).filter(
      (f) => f.obrigatorio && (camposValores[f.key] === '' || camposValores[f.key] == null),
    );

    if (requiredMissing.length > 0) {
      const errs: Record<string, string> = {};
      requiredMissing.forEach((f) => { errs[f.key] = 'Campo obrigatório'; });
      setCamposErrors(errs);
      toast.error(`Preencha os campos obrigatórios: ${requiredMissing.map((f) => f.label).join(', ')}`);
      return;
    }
    setCamposErrors({});

    setIsSaving(true);
    try {
      const numero = gerarNumeroDocumento(tipoRegistro);

      // Resolve remetente
      let remetenteId: string | undefined;
      let remetenteTexto: string | undefined;
      if (remetente.length > 0) {
        const r = remetente[0];
        remetenteId = r.id;
        remetenteTexto =
          r.tipo === 'user'
            ? users.find((u) => u.id === r.id)?.nome
            : entities.find((e) => e.id === r.id)?.nome;
      } else if (values.remetenteTexto) {
        remetenteTexto = values.remetenteTexto;
      }

      const doc = createDoc({
        numero,
        tipoRegistro,
        tipoDocumentoId: values.tipoDocumentoId,
        assunto: values.assunto,
        remetenteId,
        remetenteTexto,
        destinatarios,
        data: values.data,
        confidencial: values.confidencial,
        estado: 'novo',
        regiao: values.regiao || undefined,
        localizacaoFisicaId: values.localizacaoFisicaId || undefined,
        tags,
        camposValores,
        anexos,
        funcionarioId:
          values.funcionarioId && values.funcionarioId !== NONE
            ? values.funcionarioId
            : undefined,
        criadoPor: currentUser?.id ?? 'system',
      });

      pendingUploadIds.current.clear();
      localStorage.removeItem(draftKey);
      toast.success(`Documento ${doc.numero} registado com sucesso!`);
      onSuccess(doc);
    } finally {
      setIsSaving(false);
    }
  }

  const labels = LABELS[tipoRegistro];
  const busy = isSubmitting || isSaving;

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
      {/* ── Informações do Documento ─────────────────────────────────────── */}
      <SectionCard title="Informações do Documento">
        <div className="grid grid-cols-2 gap-4">
          {/* Tipo de Documento */}
          <div className="space-y-1.5">
            <Label className="text-xs font-medium text-slate-600">
              Tipo de Documento <span className="text-red-500">*</span>
            </Label>
            <Controller
              control={control}
              name="tipoDocumentoId"
              render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger
                    className={cn('h-9 w-full', errors.tipoDocumentoId && 'border-red-400')}
                  >
                    <SelectValue placeholder="Selecionar tipo..." />
                  </SelectTrigger>
                  <SelectContent>
                    {compatibleTypes.length === 0 ? (
                      <SelectItem value="__none__" disabled>
                        Nenhum tipo disponível
                      </SelectItem>
                    ) : (
                      compatibleTypes.map((dt) => (
                        <SelectItem key={dt.id} value={dt.id}>
                          {dt.nome}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              )}
            />
            {errors.tipoDocumentoId && (
              <p className="flex items-center gap-1 text-xs text-red-500">
                <AlertCircle className="h-3 w-3" />
                {errors.tipoDocumentoId.message}
              </p>
            )}
          </div>

          {/* Data */}
          <div className="space-y-1.5">
            <Label className="text-xs font-medium text-slate-600">
              Data <span className="text-red-500">*</span>
            </Label>
            <input
              type="date"
              {...register('data')}
              className={cn(
                'h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-xs focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1',
                errors.data && 'border-red-400',
              )}
            />
            {errors.data && (
              <p className="text-xs text-red-500">{errors.data.message}</p>
            )}
          </div>

          {/* Assunto */}
          <div className="col-span-2 space-y-1.5">
            <Label className="text-xs font-medium text-slate-600">
              Assunto <span className="text-red-500">*</span>
            </Label>
            <Input
              {...register('assunto')}
              placeholder="Descreva o assunto do documento..."
              className={cn('h-9', errors.assunto && 'border-red-400')}
            />
            {errors.assunto && (
              <p className="text-xs text-red-500">{errors.assunto.message}</p>
            )}
          </div>

          {/* Palavras-chave (tags) */}
          <div className="col-span-2 space-y-1.5">
            <Label className="text-xs font-medium text-slate-600">
              Palavras-chave
            </Label>
            <TagInput
              value={tags}
              onChange={setTags}
              suggestions={tagSuggestions}
              placeholder="Adicionar palavra-chave e premir Enter..."
            />
            <p className="text-xs text-slate-400">
              Facilitam a localização do documento na pesquisa avançada.
            </p>
          </div>

          {/* Confidencial */}
          <div className="col-span-2 flex items-center justify-between rounded-lg border border-slate-100 bg-slate-50 px-4 py-3">
            <div>
              <p className="text-sm font-medium text-slate-700">Documento Confidencial</p>
              <p className="text-xs text-slate-500">
                Restringe a visualização a utilizadores autorizados
              </p>
            </div>
            <Controller
              control={control}
              name="confidencial"
              render={({ field }) => (
                <Switch checked={field.value} onCheckedChange={field.onChange} />
              )}
            />
          </div>
        </div>
      </SectionCard>

      {/* ── Participantes ─────────────────────────────────────────────────── */}
      {/* Documentos internos não exigem participantes */}
      {!isInterno && (
        <SectionCard title="Participantes">
          <div className="space-y-5">
            {/* Remetente */}
            <div className="space-y-2">
              <Label className="text-xs font-medium text-slate-600">{labels.remetente}</Label>
              <RecipientSelector
                value={remetente}
                onChange={setRemetente}
                users={users}
                entities={entities}
                single
              />
              <div className="flex items-center gap-2 py-1">
                <div className="h-px flex-1 bg-slate-200" />
                <span className="text-xs text-slate-400">ou texto livre</span>
                <div className="h-px flex-1 bg-slate-200" />
              </div>
              <Input
                {...register('remetenteTexto')}
                placeholder="Nome ou entidade remetente..."
                className="h-8 text-sm"
                disabled={remetente.length > 0}
              />
            </div>

            {/* Destinatários */}
            <div className="space-y-2">
              <Label className="text-xs font-medium text-slate-600">
                {labels.destinatario}
              </Label>
              <RecipientSelector
                value={destinatarios}
                onChange={setDestinatarios}
                users={users}
                entities={entities}
              />
            </div>
          </div>
        </SectionCard>
      )}

      {/* ── Funcionário ───────────────────────────────────────────────────── */}
      <SectionCard
        title="Funcionário"
        description="Vincule este documento ao processo de um funcionário (opcional)."
        collapsible
      >
        <Controller
          control={control}
          name="funcionarioId"
          render={({ field }) => (
            <FuncionarioCombobox
              funcionarios={funcionarios}
              value={field.value || NONE}
              onChange={field.onChange}
            />
          )}
        />
        {funcionarioId && funcionarioId !== NONE && (
          <p className="mt-2 text-xs text-slate-400">
            Este documento aparecerá na ficha do funcionário selecionado.
          </p>
        )}
      </SectionCard>

      {/* ── Campos do Tipo de Documento ───────────────────────────────────── */}
      {selectedType && selectedType.campos.length > 0 && (
        <SectionCard
          title={`Campos: ${selectedType.nome}`}
          description="Campos específicos deste tipo de documento"
        >
          <div className="grid grid-cols-2 gap-4">
            {[...selectedType.campos]
              .sort((a, b) => a.ordem - b.ordem)
              .map((campo) => (
                <div
                  key={campo.key}
                  className={cn(campo.tipo === 'textarea' && 'col-span-2')}
                >
                  <FieldRenderer
                    field={campo}
                    value={camposValores[campo.key]}
                    onChange={(v) =>
                      setCamposValores((prev) => ({ ...prev, [campo.key]: v }))
                    }
                    error={camposErrors[campo.key]}
                  />
                </div>
              ))}
          </div>
        </SectionCard>
      )}

      {/* ── Região ────────────────────────────────────────────────────────── */}
      <SectionCard
        title="Região"
        description="Segmentação geográfica — define onde o documento aparece na árvore de arquivos"
        collapsible
      >
        <div className="max-w-sm space-y-1.5">
          <Label className="text-xs font-medium text-slate-600">Região</Label>
          <Controller
            control={control}
            name="regiao"
            render={({ field }) => (
              <ProvinceSelect
                value={field.value ?? ''}
                onChange={field.onChange}
                placeholder="Selecionar província..."
              />
            )}
          />
        </div>
      </SectionCard>

      {/* ── Localização Física ────────────────────────────────────────────── */}
      <SectionCard
        title="Localização Física"
        description="Onde o documento está fisicamente arquivado (sala, corredor, prateleira...)"
        collapsible
      >
        <Controller
          control={control}
          name="localizacaoFisicaId"
          render={({ field }) => (
            <LocationPicker
              value={field.value || undefined}
              onChange={(v) => field.onChange(v ?? '')}
            />
          )}
        />
      </SectionCard>

      {/* ── Ficheiros Anexos ──────────────────────────────────────────────── */}
      <SectionCard
        title="Ficheiros Anexos"
        description="Arraste ou selecione os ficheiros a anexar"
      >
        <FileDropZone
          attachments={anexos}
          onAdd={addAnexo}
          onRemove={removeAnexo}
          currentUserId={currentUser?.id ?? 'system'}
          disabled={busy}
          uploadFile={IS_API_MODE ? apiUploadFile : undefined}
        />
        {anexos.length === 0 && (
          <p className="mt-2 text-xs text-amber-600">
            Pelo menos um ficheiro é obrigatório.
          </p>
        )}
      </SectionCard>

      {/* ── Footer ────────────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between border-t border-slate-100 pt-4">
        <div className="flex items-center gap-1.5 text-xs text-slate-400">
          {lastSaved && (
            <>
              <Clock className="h-3 w-3" />
              Rascunho salvo às{' '}
              {lastSaved.toLocaleTimeString('pt-AO', {
                hour: '2-digit',
                minute: '2-digit',
              })}
            </>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => void handleCancel()}
            disabled={busy}
          >
            Cancelar
          </Button>
          <Button type="submit" size="sm" disabled={busy} className="gap-1.5">
            {busy ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <Save className="h-3.5 w-3.5" />
            )}
            Registar Documento
          </Button>
        </div>
      </div>
    </form>
  );
}
