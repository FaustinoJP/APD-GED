﻿'use client';

import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Plus, ExternalLink, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet';
import { PageHeader } from '@/components/common/page-header';
import { SearchFilters } from '@/components/common/search-filters';
import { DataTable } from '@/components/common/data-table';
import { StatusBadge } from '@/components/common/status-badge';
import { EmptyState } from '@/components/common/empty-state';
import { DocumentForm } from './document-form';
import { useDocumentsStore } from '@/store/documents-store';
import { useConfigStore } from '@/store/config-store';
import { usePermissions } from '@/hooks/use-permissions';
import { PermissionGuard } from '@/components/auth/permission-guard';
import type { ColumnDef } from '@/components/common/data-table';
import type { DocumentRecord, TipoRegistro } from '@/types';
import type { SearchParams } from '@/components/common/search-filters';
import type { AdvancedSearchParams } from '@/components/common/advanced-search-dialog';

// ─── Per-tipo metadata ────────────────────────────────────────────────────────

const META: Record<
  TipoRegistro,
  {
    title: string;
    description: string;
    buttonLabel: string;
    sheetTitle: string;
    sheetDescription: string;
    emptyTitle: string;
    emptyDescription: string;
    draftKey: string;
  }
> = {
  entrada: {
    title: 'Registo de Entradas',
    description: 'Documentos recebidos de entidades externas.',
    buttonLabel: 'Nova Entrada',
    sheetTitle: 'Nova Entrada',
    sheetDescription: 'Preencha os dados do documento recebido.',
    emptyTitle: 'Nenhuma entrada registada',
    emptyDescription: 'Clique em "Nova Entrada" para registar o primeiro documento recebido.',
    draftKey: 'gd:draft:entrada',
  },
  saida: {
    title: 'Registo de Saídas',
    description: 'Documentos enviados para entidades externas.',
    buttonLabel: 'Nova Saída',
    sheetTitle: 'Nova Saída',
    sheetDescription: 'Preencha os dados do documento a enviar.',
    emptyTitle: 'Nenhuma saída registada',
    emptyDescription: 'Clique em "Nova Saída" para registar o primeiro documento enviado.',
    draftKey: 'gd:draft:saida',
  },
  interno: {
    title: 'Registo de Internos',
    description: 'Documentos de circulação interna.',
    buttonLabel: 'Novo Interno',
    sheetTitle: 'Novo Documento Interno',
    sheetDescription: 'Preencha os dados do documento interno.',
    emptyTitle: 'Nenhum documento interno registado',
    emptyDescription: 'Clique em "Novo Interno" para registar o primeiro documento interno.',
    draftKey: 'gd:draft:interno',
  },
};

// ─── Props ────────────────────────────────────────────────────────────────────

interface RegistroPageProps {
  tipoRegistro: TipoRegistro;
}

/**
 * Shared layout for /registro/entradas, /registro/saidas and /registro/internos.
 * Shows a live DataTable of documents for the given tipoRegistro and a Sheet
 * with DocumentForm for creating new documents.
 *
 * @example
 * export default function EntradasPage() {
 *   return <RegistroPage tipoRegistro="entrada" />;
 * }
 */
export function RegistroPage({ tipoRegistro }: RegistroPageProps) {
  const router = useRouter();
  const { can } = usePermissions();

  // ── Stores ──────────────────────────────────────────────────────────────
  const docs = useDocumentsStore((s) => s.documents);
  const docsLoaded = useDocumentsStore((s) => s.loaded);
  const docsLoading = useDocumentsStore((s) => s.loading);
  const loadDocs = useDocumentsStore((s) => s.load);

  const { documentTypes, users, entities, funcionarios, loaded: configLoaded, loadAll } = useConfigStore();

  useEffect(() => {
    if (!configLoaded) loadAll();
    if (!docsLoaded) loadDocs();
  }, [configLoaded, loadAll, docsLoaded, loadDocs]);

  // ── Sheet state ──────────────────────────────────────────────────────────
  const [sheetOpen, setSheetOpen] = useState(false);

  // ── Search / filter state ────────────────────────────────────────────────
  const [searchQuery, setSearchQuery] = useState('');
  const [searchDate, setSearchDate] = useState('');
  const [searchType, setSearchType] = useState('');

  function handleSearch(params: SearchParams & AdvancedSearchParams) {
    setSearchQuery(params.query ?? '');
    setSearchDate(params.data ?? '');
    setSearchType(params.tipoDocumentoId ?? '');
  }

  // ── Filtered documents ───────────────────────────────────────────────────
  const funcMap = useMemo(
    () => Object.fromEntries(funcionarios.map((f) => [f.id, f])),
    [funcionarios],
  );

  const filteredDocs = useMemo(() => {
    return docs
      .filter((d) => d.tipoRegistro === tipoRegistro)
      .filter((d) => {
        if (!searchQuery) return true;
        const q = searchQuery.toLowerCase();
        const func = d.funcionarioId ? funcMap[d.funcionarioId] : undefined;
        return (
          d.numero.toLowerCase().includes(q) ||
          d.assunto.toLowerCase().includes(q) ||
          (d.remetenteTexto ?? '').toLowerCase().includes(q) ||
          (!!func && `${func.nome} ${func.apelido}`.toLowerCase().includes(q)) ||
          (!!func && func.numeroProcesso.toLowerCase().includes(q))
        );
      })
      .filter((d) => !searchDate || d.data === searchDate)
      .filter((d) => !searchType || d.tipoDocumentoId === searchType);
  }, [docs, tipoRegistro, searchQuery, searchDate, searchType, funcMap]);

  // ── Compatible document types for SearchFilters ──────────────────────────
  const compatibleTypes = useMemo(
    () =>
      documentTypes.filter(
        (dt) => dt.ativo && (dt.registro === tipoRegistro || dt.registro === 'todos'),
      ),
    [documentTypes, tipoRegistro],
  );

  // ── DataTable columns ────────────────────────────────────────────────────
  const columns = useMemo<ColumnDef<DocumentRecord>[]>(
    () => [
      {
        id: 'numero',
        header: 'Número',
        accessor: 'numero',
        sortable: true,
        width: 160,
      },
      {
        id: 'assunto',
        header: 'Assunto',
        accessor: 'assunto',
        sortable: true,
        cell: (row) => (
          <span className="block max-w-xs truncate text-sm text-slate-700" title={row.assunto}>
            {row.assunto}
          </span>
        ),
      },
      {
        id: 'tipo',
        header: 'Tipo',
        width: 170,
        cell: (row) => {
          const dt = documentTypes.find((d) => d.id === row.tipoDocumentoId);
          return (
            <span className="text-xs text-slate-600">{dt?.nome ?? '—'}</span>
          );
        },
      },
      {
        id: 'data',
        header: 'Data',
        accessor: 'data',
        sortable: true,
        width: 100,
        cell: (row) => (
          <span className="text-xs text-slate-600">
            {format(parseISO(row.data), 'dd/MM/yyyy', { locale: ptBR })}
          </span>
        ),
      },
      {
        id: 'remetente',
        header: 'Remetente',
        width: 160,
        cell: (row) => {
          const texto =
            row.remetenteTexto ??
            users.find((u) => u.id === row.remetenteId)?.nome;
          return (
            <span className="block max-w-[140px] truncate text-xs text-slate-600">
              {texto ?? '—'}
            </span>
          );
        },
      },
      {
        id: 'estado',
        header: 'Estado',
        width: 130,
        cell: (row) => <StatusBadge status={row.estado} />,
      },
      {
        id: 'confidencial',
        header: '',
        width: 36,
        align: 'center',
        cell: (row) =>
          row.confidencial ? (
            <Lock className="h-3.5 w-3.5 text-amber-500" aria-label="Confidencial" />
          ) : null,
      },
      {
        id: 'acoes',
        header: '',
        width: 48,
        align: 'center',
        cell: (row) => (
          <Button
            variant="ghost"
            size="icon-xs"
            asChild
            className="text-slate-400 hover:text-sky-600"
          >
            <Link href={`/documentos/${row.id}`} aria-label={`Ver ${row.numero}`}>
              <ExternalLink className="h-3.5 w-3.5" />
            </Link>
          </Button>
        ),
      },
    ],
    [documentTypes, users],
  );

  const meta = META[tipoRegistro];
  const canCreate = can('documents.create');

  return (
    <PermissionGuard required="documents.read">
      <div className="space-y-6 p-6">
        {/* ── Header ─────────────────────────────────────────────────────── */}
        <PageHeader
          title={meta.title}
          description={meta.description}
          onRefresh={() => {
            useDocumentsStore.setState({ loaded: false });
            loadDocs();
          }}
          primaryAction={
            canCreate
              ? {
                  label: meta.buttonLabel,
                  icon: <Plus className="h-3.5 w-3.5" />,
                  onClick: () => setSheetOpen(true),
                }
              : undefined
          }
        />

        {/* ── Search filters ──────────────────────────────────────────────── */}
        <SearchFilters
          onSearch={handleSearch}
          documentTypes={compatibleTypes}
          users={users}
        />

        {/* ── DataTable ───────────────────────────────────────────────────── */}
        <DataTable
          columns={columns}
          data={filteredDocs}
          loading={docsLoading}
          defaultPageSize={10}
          emptyState={
            <EmptyState
              title={meta.emptyTitle}
              description={meta.emptyDescription}
              action={
                canCreate
                  ? {
                      label: meta.buttonLabel,
                      onClick: () => setSheetOpen(true),
                    }
                  : undefined
              }
            />
          }
        />
      </div>

      {/* ── New document Sheet ──────────────────────────────────────────── */}
      <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
        <SheetContent
          className="w-full sm:max-w-3xl overflow-y-auto flex flex-col"
          side="right"
        >
          <SheetHeader className="shrink-0">
            <SheetTitle>{meta.sheetTitle}</SheetTitle>
            <SheetDescription>{meta.sheetDescription}</SheetDescription>
          </SheetHeader>

          <div className="flex-1 overflow-y-auto px-1 pb-2">
            {sheetOpen && (
              <DocumentForm
                tipoRegistro={tipoRegistro}
                draftKey={meta.draftKey}
                onCancel={() => setSheetOpen(false)}
                onSuccess={(doc) => {
                  setSheetOpen(false);
                  router.push(`/documentos/${doc.id}`);
                }}
              />
            )}
          </div>
        </SheetContent>
      </Sheet>
    </PermissionGuard>
  );
}
