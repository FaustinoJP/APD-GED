﻿"use client";

import { Construction } from "lucide-react";

interface PagePlaceholderProps {
  title: string;
  description?: string;
}

export function PagePlaceholder({ title, description }: PagePlaceholderProps) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-4 py-24">
      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-sky-50 text-sky-600">
        <Construction className="h-8 w-8" />
      </div>
      <div className="text-center">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">{title}</h1>
        <p className="mt-1 text-sm text-slate-500">
          {description ?? "Esta funcionalidade está em desenvolvimento."}
        </p>
      </div>
      <div className="mt-4 rounded-lg border border-dashed border-slate-300 bg-slate-50 px-8 py-4 text-center text-xs text-slate-400">
        Placeholder — implementação em breve
      </div>
    </div>
  );
}
