import { create } from 'zustand';
import type {
  CompanySettings,
  DocumentTemplate,
  DocumentType,
  Entity,
  Funcionario,
  LocationLevel,
  LocationNode,
  Role,
  User,
} from '@/types';
import {
  documentTypesRepo,
  entitiesRepo,
  rolesRepo,
  usersRepo,
  templatesRepo,
  funcionariosRepo,
  locationLevelsRepo,
  locationNodesRepo,
  getCompanySettings,
  setCompanySettings,
} from '@/lib/db';
import { GD_WRITE_ERROR_EVENT } from '@/lib/db/apiAdapter';

interface ConfigState {
  documentTypes: DocumentType[];
  entities: Entity[];
  roles: Role[];
  users: User[];
  funcionarios: Funcionario[];
  templates: DocumentTemplate[];
  locationLevels: LocationLevel[];
  locationNodes: LocationNode[];
  company: CompanySettings;
  loaded: boolean;

  loadAll: () => void;

  createDocumentType: (data: Omit<DocumentType, 'id'>) => DocumentType;
  updateDocumentType: (id: string, changes: Partial<DocumentType>) => void;
  removeDocumentType: (id: string) => void;

  createEntity: (data: Omit<Entity, 'id' | 'criadoEm'>) => Entity;
  updateEntity: (id: string, changes: Partial<Entity>) => void;
  removeEntity: (id: string) => void;

  createUser: (data: Omit<User, 'id' | 'criadoEm'>) => User;
  updateUser: (id: string, changes: Partial<User>) => void;
  removeUser: (id: string) => void;

  createRole: (data: Omit<Role, 'id'>) => Role;
  updateRole: (id: string, changes: Partial<Role>) => void;
  removeRole: (id: string) => void;

  createTemplate: (data: Omit<DocumentTemplate, 'id' | 'criadoEm'>) => DocumentTemplate;
  updateTemplate: (id: string, changes: Partial<DocumentTemplate>) => void;
  removeTemplate: (id: string) => void;

  createLocationLevel: (data: Omit<LocationLevel, 'id'>) => LocationLevel;
  updateLocationLevel: (id: string, changes: Partial<LocationLevel>) => void;
  removeLocationLevel: (id: string) => void;

  createLocationNode: (data: Omit<LocationNode, 'id' | 'criadoEm'>) => LocationNode;
  updateLocationNode: (id: string, changes: Partial<LocationNode>) => void;
  removeLocationNode: (id: string) => void;

  saveCompany: (settings: CompanySettings) => void;
}

export const useConfigStore = create<ConfigState>()((set) => ({
  documentTypes: [],
  entities: [],
  roles: [],
  users: [],
  funcionarios: [],
  templates: [],
  locationLevels: [],
  locationNodes: [],
  company: { nome: '' },
  loaded: false,

  loadAll: () => {
    set({
      documentTypes: documentTypesRepo.list(),
      entities: entitiesRepo.list(),
      roles: rolesRepo.list(),
      users: usersRepo.list(),
      funcionarios: funcionariosRepo.list(),
      templates: templatesRepo.list(),
      locationLevels: locationLevelsRepo.list(),
      locationNodes: locationNodesRepo.list(),
      company: getCompanySettings(),
      loaded: true,
    });
  },

  // DocumentTypes
  createDocumentType: (data) => {
    const dt = documentTypesRepo.create(data);
    set((s) => ({ documentTypes: [...s.documentTypes, dt] }));
    return dt;
  },
  updateDocumentType: (id, changes) => {
    documentTypesRepo.update(id, changes);
    set((s) => ({
      documentTypes: s.documentTypes.map((dt) =>
        dt.id === id ? { ...dt, ...changes } : dt,
      ),
    }));
  },
  removeDocumentType: (id) => {
    documentTypesRepo.remove(id);
    set((s) => ({ documentTypes: s.documentTypes.filter((dt) => dt.id !== id) }));
  },

  // Entities
  createEntity: (data) => {
    const entity = entitiesRepo.create({ ...data, criadoEm: new Date().toISOString() });
    set((s) => ({ entities: [...s.entities, entity] }));
    return entity;
  },
  updateEntity: (id, changes) => {
    entitiesRepo.update(id, changes);
    set((s) => ({
      entities: s.entities.map((e) => (e.id === id ? { ...e, ...changes } : e)),
    }));
  },
  removeEntity: (id) => {
    entitiesRepo.remove(id);
    set((s) => ({ entities: s.entities.filter((e) => e.id !== id) }));
  },

  // Users
  createUser: (data) => {
    const user = usersRepo.create({ ...data, criadoEm: new Date().toISOString() });
    set((s) => ({ users: [...s.users, user] }));
    return user;
  },
  updateUser: (id, changes) => {
    usersRepo.update(id, changes);
    set((s) => ({
      users: s.users.map((u) => (u.id === id ? { ...u, ...changes } : u)),
    }));
  },
  removeUser: (id) => {
    usersRepo.remove(id);
    set((s) => ({ users: s.users.filter((u) => u.id !== id) }));
  },

  // Roles
  createRole: (data) => {
    const role = rolesRepo.create(data);
    set((s) => ({ roles: [...s.roles, role] }));
    return role;
  },
  updateRole: (id, changes) => {
    rolesRepo.update(id, changes);
    set((s) => ({
      roles: s.roles.map((r) => (r.id === id ? { ...r, ...changes } : r)),
    }));
  },
  removeRole: (id) => {
    rolesRepo.remove(id);
    set((s) => ({ roles: s.roles.filter((r) => r.id !== id) }));
  },

  // Templates
  createTemplate: (data) => {
    const tpl = templatesRepo.create({ ...data, criadoEm: new Date().toISOString() });
    set((s) => ({ templates: [...s.templates, tpl] }));
    return tpl;
  },
  updateTemplate: (id, changes) => {
    templatesRepo.update(id, changes);
    set((s) => ({
      templates: s.templates.map((t) => (t.id === id ? { ...t, ...changes } : t)),
    }));
  },
  removeTemplate: (id) => {
    templatesRepo.remove(id);
    set((s) => ({ templates: s.templates.filter((t) => t.id !== id) }));
  },

  // Location levels
  createLocationLevel: (data) => {
    const level = locationLevelsRepo.create(data);
    set((s) => ({ locationLevels: [...s.locationLevels, level] }));
    return level;
  },
  updateLocationLevel: (id, changes) => {
    locationLevelsRepo.update(id, changes);
    set((s) => ({
      locationLevels: s.locationLevels.map((l) => (l.id === id ? { ...l, ...changes } : l)),
    }));
  },
  removeLocationLevel: (id) => {
    locationLevelsRepo.remove(id);
    set((s) => ({ locationLevels: s.locationLevels.filter((l) => l.id !== id) }));
  },

  // Location nodes
  createLocationNode: (data) => {
    const node = locationNodesRepo.create({ ...data, criadoEm: new Date().toISOString() });
    set((s) => ({ locationNodes: [...s.locationNodes, node] }));
    return node;
  },
  updateLocationNode: (id, changes) => {
    locationNodesRepo.update(id, changes);
    set((s) => ({
      locationNodes: s.locationNodes.map((n) => (n.id === id ? { ...n, ...changes } : n)),
    }));
  },
  removeLocationNode: (id) => {
    locationNodesRepo.remove(id);
    set((s) => ({ locationNodes: s.locationNodes.filter((n) => n.id !== id) }));
  },

  // Company settings
  saveCompany: (settings) => {
    setCompanySettings(settings);
    set({ company: settings });
  },
}));

// Reload parcial por coleção quando uma escrita na API falha
if (typeof window !== 'undefined') {
  const CONFIG_KEY_MAP: Record<string, () => void> = {
    'gd:users': () => useConfigStore.setState({ users: usersRepo.list() }),
    'gd:funcionarios': () => useConfigStore.setState({ funcionarios: funcionariosRepo.list() }),
    'gd:roles': () => useConfigStore.setState({ roles: rolesRepo.list() }),
    'gd:document_types': () => useConfigStore.setState({ documentTypes: documentTypesRepo.list() }),
    'gd:entities': () => useConfigStore.setState({ entities: entitiesRepo.list() }),
    'gd:templates': () => useConfigStore.setState({ templates: templatesRepo.list() }),
    'gd:location_levels': () => useConfigStore.setState({ locationLevels: locationLevelsRepo.list() }),
    'gd:location_nodes': () => useConfigStore.setState({ locationNodes: locationNodesRepo.list() }),
  };
  window.addEventListener(GD_WRITE_ERROR_EVENT, (e) => {
    const { key } = (e as CustomEvent<{ key: string }>).detail;
    CONFIG_KEY_MAP[key]?.();
  });
}
