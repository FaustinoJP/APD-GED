// Backward-compatible shim — sidebar state lives in useUiStore.
export { useUiStore as useSidebarStore } from './ui-store';
