import { create } from 'zustand';
import type { Notification } from '@/types';
import { notificationsRepo } from '@/lib/db';

interface NotificationState {
  notifications: Notification[];
  unreadCount: number;
  loaded: boolean;
  load: (userId: string) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
}

export const useNotificationStore = create<NotificationState>()((set, get) => ({
  notifications: [],
  unreadCount: 0,
  loaded: false,

  load: (userId) => {
    const all = notificationsRepo.query((n) => n.userId === userId);
    set({
      notifications: all,
      unreadCount: all.filter((n) => !n.lida).length,
      loaded: true,
    });
  },

  markAsRead: (id) => {
    notificationsRepo.update(id, { lida: true });
    set((s) => {
      const notifications = s.notifications.map((n) =>
        n.id === id ? { ...n, lida: true } : n,
      );
      return { notifications, unreadCount: notifications.filter((n) => !n.lida).length };
    });
  },

  markAllAsRead: () => {
    const { notifications } = get();
    notifications.forEach((n) => {
      if (!n.lida) notificationsRepo.update(n.id, { lida: true });
    });
    set((s) => ({
      notifications: s.notifications.map((n) => ({ ...n, lida: true })),
      unreadCount: 0,
    }));
  },
}));
