/**
 * Auth store — autenticação real via JWT (modo API) ou mock localStorage (modo local).
 *
 * Modo API  (NEXT_PUBLIC_DATA_SOURCE=api):
 *   login()          → POST /auth/login → armazena access token em memória
 *   logout()         → POST /auth/logout → limpa token + cookie httpOnly
 *   restoreSession() → POST /auth/refresh → renova token em cada boot
 *
 * Modo local (default):
 *   login()  → valida contra usersRepo (localStorage) — sem senha real
 *   logout() → limpa o estado Zustand
 */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, Role } from '@/types';
import { usersRepo, rolesRepo, auditRepo } from '@/lib/db';
import { getAdapter } from '@/lib/db/apiAdapter';
import { ApiStorageAdapter } from '@/lib/db/apiAdapter';
import { apiClient } from '@/lib/api/client';
import { clearToken, setToken } from '@/lib/api/token';

const IS_API_MODE = process.env.NEXT_PUBLIC_DATA_SOURCE === 'api';

interface AuthState {
  currentUser: User | null;
  currentRole: Role | null;
  isAuthenticated: boolean;
  _hasHydrated: boolean;
  setHasHydrated: (v: boolean) => void;
  login: (email: string, senha: string) => Promise<{ ok: boolean; error?: string }>;
  logout: () => Promise<void>;
  /** Restaura sessão após page refresh usando o cookie de refresh token. */
  restoreSession: () => Promise<void>;
  /** Dev-only: trocar utilizador sem palavra-passe. */
  switchUser: (userId: string) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      currentUser: null,
      currentRole: null,
      isAuthenticated: false,
      _hasHydrated: false,

      setHasHydrated: (v) => set({ _hasHydrated: v }),

      login: async (email, senha) => {
        if (IS_API_MODE) {
          try {
            const { data } = await apiClient.post<{
              accessToken: string;
              user: User;
            }>('/auth/login', { email, senha });

            setToken(data.accessToken);

            // Buscar o papel do utilizador
            let role: Role | null = null;
            try {
              const { data: roleData } = await apiClient.get<Role>(
                `/roles/${data.user.roleId}`,
              );
              role = roleData;
            } catch {
              // Se falhar, cria um objecto mínimo com o id
              role = { id: data.user.roleId, nome: '', descricao: '', permissions: [] };
            }

            set({ currentUser: data.user, currentRole: role, isAuthenticated: true });

            // Hidrata todas as colecções no cache do adaptador
            const adapter = getAdapter();
            if (adapter instanceof ApiStorageAdapter) {
              await adapter.hydrate();
            }

            return { ok: true };
          } catch (err: unknown) {
            const status = (err as any)?.response?.status;
            const isNetworkError = !status || status >= 500;
            const msg = isNetworkError
              ? 'Servidor indisponível. Por favor, tente novamente mais tarde.'
              : (err as { response?: { data?: { message?: string } } })?.response?.data
                  ?.message ?? 'Erro ao autenticar. Verifique as credenciais.';
            return { ok: false, error: String(msg) };
          }
        }

        // ── Modo local (mock) ────────────────────────────────────────────────
        const users = usersRepo.list();
        const user = users.find(
          (u) => u.email.toLowerCase() === email.toLowerCase().trim(),
        );
        if (!user) return { ok: false, error: 'Utilizador não encontrado.' };
        if (!user.ativo)
          return { ok: false, error: 'Conta desativada. Contacte o administrador.' };
        if (!senha.trim()) return { ok: false, error: 'Palavra-passe obrigatória.' };

        const role = rolesRepo.getById(user.roleId) ?? null;
        set({ currentUser: user, currentRole: role, isAuthenticated: true });

        auditRepo.create({
          evento: 'login',
          tabela: 'users',
          registroId: user.id,
          userId: user.id,
          ip: '127.0.0.1',
          data: new Date().toISOString(),
          detalhe: 'Login via formulário',
        });

        return { ok: true };
      },

      logout: async () => {
        if (IS_API_MODE) {
          try {
            await apiClient.post('/auth/logout');
          } catch {
            // Ignorar erro — limpar estado de qualquer forma
          }
          clearToken();
        }
        set({ currentUser: null, currentRole: null, isAuthenticated: false });
      },

      restoreSession: async () => {
        if (!IS_API_MODE) return;

        try {
          const { data } = await apiClient.post<{ accessToken: string }>(
            '/auth/refresh',
          );
          setToken(data.accessToken);

          const { data: user } = await apiClient.get<User>('/auth/me');
          let role: Role | null = null;
          try {
            const { data: roleData } = await apiClient.get<Role>(`/roles/${user.roleId}`);
            role = roleData;
          } catch {
            role = { id: user.roleId, nome: '', descricao: '', permissions: [] };
          }

          set({ currentUser: user, currentRole: role, isAuthenticated: true });

          const adapter = getAdapter();
          if (adapter instanceof ApiStorageAdapter) {
            await adapter.hydrate();
          }
        } catch (err: unknown) {
          const status = (err as any)?.response?.status;
          const isNetworkError = !status || status >= 500;

          if (isNetworkError) {
            // Relançar o erro de rede/conexão para ser tratado pelo SessionRestoreProvider
            throw err;
          }

          // Cookie expirado ou inválido — forçar logout silencioso
          clearToken();
          set({ currentUser: null, currentRole: null, isAuthenticated: false });
        }
      },

      switchUser: (userId) => {
        const user = usersRepo.getById(userId);
        if (!user) return;
        const role = rolesRepo.getById(user.roleId) ?? null;
        set({ currentUser: user, currentRole: role, isAuthenticated: true });
      },
    }),
    {
      name: 'gd:session',
      partialize: (state) => ({
        currentUser: state.currentUser,
        currentRole: state.currentRole,
        isAuthenticated: state.isAuthenticated,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true);
      },
    },
  ),
);
