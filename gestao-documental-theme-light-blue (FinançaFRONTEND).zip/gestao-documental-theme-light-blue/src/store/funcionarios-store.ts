import { create } from 'zustand';
import type { Funcionario } from '@/types';
import { funcionariosRepo } from '@/lib/db';
import { GD_WRITE_ERROR_EVENT } from '@/lib/db/apiAdapter';

interface FuncionariosState {
  funcionarios: Funcionario[];
  loading: boolean;
  loaded: boolean;
  load: () => void;
  reload: () => void;
  getById: (id: string) => Funcionario | undefined;
  create: (
    data: Omit<Funcionario, 'id' | 'criadoEm' | 'atualizadoEm'>,
  ) => Funcionario;
  update: (id: string, changes: Partial<Funcionario>) => Funcionario | undefined;
  remove: (id: string) => boolean;
}

export const useFuncionariosStore = create<FuncionariosState>()((set, get) => ({
  funcionarios: [],
  loading: false,
  loaded: false,

  load: () => {
    if (get().loaded) return;
    set({ loading: true });
    const funcionarios = funcionariosRepo.list();
    set({ funcionarios, loading: false, loaded: true });
  },

  reload: () => {
    set({ funcionarios: funcionariosRepo.list() });
  },

  getById: (id) => get().funcionarios.find((f) => f.id === id),

  create: (data) => {
    const now = new Date().toISOString();
    const funcionario = funcionariosRepo.create({
      ...data,
      criadoEm: now,
      atualizadoEm: now,
    });
    set((s) => ({ funcionarios: [...s.funcionarios, funcionario] }));
    return funcionario;
  },

  update: (id, changes) => {
    const now = new Date().toISOString();
    const updated = funcionariosRepo.update(id, {
      ...changes,
      atualizadoEm: now,
    });
    if (!updated) return undefined;
    set((s) => ({
      funcionarios: s.funcionarios.map((f) => (f.id === id ? updated : f)),
    }));
    return updated;
  },

  remove: (id) => {
    const ok = funcionariosRepo.remove(id);
    if (!ok) return false;
    set((s) => ({ funcionarios: s.funcionarios.filter((f) => f.id !== id) }));
    return true;
  },
}));

// Quando uma escrita na API falha e o cache é revertido, recarregar o store
if (typeof window !== 'undefined') {
  window.addEventListener(GD_WRITE_ERROR_EVENT, (e) => {
    const { key } = (e as CustomEvent<{ key: string }>).detail;
    if (key === 'gd:funcionarios') {
      useFuncionariosStore.getState().reload();
    }
  });
}
