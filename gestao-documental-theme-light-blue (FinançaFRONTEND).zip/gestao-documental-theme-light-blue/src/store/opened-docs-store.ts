import { create } from 'zustand';

interface OpenedDocsState {
  ids: string[];
  add: (id: string) => void;
  remove: (id: string) => void;
  clear: () => void;
}

/**
 * Session-only LRU store for the "Documentos Abertos" sidebar.
 * Keeps the last 10 opened document IDs. Not persisted — resets on refresh.
 */
export const useOpenedDocsStore = create<OpenedDocsState>()((set) => ({
  ids: [],
  add: (id) =>
    set((s) => ({
      ids: [id, ...s.ids.filter((i) => i !== id)].slice(0, 10),
    })),
  remove: (id) => set((s) => ({ ids: s.ids.filter((i) => i !== id) })),
  clear: () => set({ ids: [] }),
}));
