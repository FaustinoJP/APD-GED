import { create } from 'zustand';
import type {
  AcaoCirculacao,
  Circulation,
  CirculationResponse,
  DecisaoCirculacao,
  Destinatario,
  EstadoDocumento,
} from '@/types';
import { circulationsRepo, auditRepo, documentsRepo, notificationsRepo } from '@/lib/db';
import { GD_WRITE_ERROR_EVENT } from '@/lib/db/apiAdapter';
import { useAuthStore } from './auth-store';

export interface ForwardPayload {
  documentId: string;
  documentNumero?: string;
  acao: AcaoCirculacao;
  paraDestinatarios: Destinatario[];
  mensagem: string;
  dataLimite?: string;
  obrigatoriaTodos?: boolean;
  enviarEmail?: boolean;
  receberNotificacao?: boolean;
  /** Mapeamento zoneId → userId: quem assina cada zona (opcional, só para acao=assinar) */
  zoneAssignments?: Record<string, string>;
}

interface CirculationState {
  pendingCirculations: Circulation[];
  loaded: boolean;
  loadPending: (userId: string) => void;
  reloadPending: () => void;
  forward: (payload: ForwardPayload) => Circulation;
  respond: (
    circulationId: string,
    response: Omit<CirculationResponse, 'id' | 'criadoEm'>,
  ) => void;
}

const ACAO_LABEL: Record<AcaoCirculacao, string> = {
  aprovar: 'Aprovação',
  assinar: 'Assinatura',
  parecer: 'Parecer',
  despachar: 'Despacho',
  deferir: 'Deferimento',
  verificar: 'Verificação',
  encaminhar_interno: 'Encaminhamento interno',
  encaminhar_externo: 'Encaminhamento externo',
};

function resolveDocEstado(
  acao: AcaoCirculacao,
  decisao: DecisaoCirculacao,
): EstadoDocumento | null {
  if (decisao === 'rejeitado') return 'rejeitado';
  if (decisao === 'aprovado') return 'aprovado';
  if (decisao === 'deferido') return 'deferido';
  if (decisao === 'assinado') return 'concluido';
  if ((acao === 'despachar' || acao === 'verificar') && decisao === 'parecer_dado') return 'concluido';
  return null;
}

export const useCirculationStore = create<CirculationState>()((set) => ({
  pendingCirculations: [],
  loaded: false,

  forward: (payload) => {
    const now = new Date().toISOString();
    const currentUser = useAuthStore.getState().currentUser;
    const circ = circulationsRepo.create({
      documentId: payload.documentId,
      acao: payload.acao,
      deUserId: currentUser?.id ?? 'system',
      paraDestinatarios: payload.paraDestinatarios,
      mensagem: payload.mensagem,
      dataLimite: payload.dataLimite,
      obrigatoriaTodos: payload.obrigatoriaTodos ?? false,
      enviarEmail: payload.enviarEmail ?? false,
      receberNotificacao: payload.receberNotificacao ?? true,
      status: 'pendente',
      respostas: [],
      zoneAssignments: payload.zoneAssignments,
      criadoEm: now,
    });

    documentsRepo.update(payload.documentId, { estado: 'em_circulacao', atualizadoEm: now });

    const label = ACAO_LABEL[payload.acao] ?? payload.acao;
    const docRef = payload.documentNumero ?? payload.documentId;

    payload.paraDestinatarios
      .filter((d) => d.tipo === 'user')
      .forEach((d) => {
        notificationsRepo.create({
          userId: d.id,
          titulo: `Ação pendente: ${label}`,
          mensagem: `Tem uma acção de ${label} pendente no documento ${docRef}.${payload.mensagem ? ` Mensagem: "${payload.mensagem}"` : ''}`,
          lida: false,
          link: `/documentos/${payload.documentId}`,
          criadoEm: now,
        });
      });

    auditRepo.create({
      evento: 'encaminhado',
      tabela: 'documents',
      registroId: payload.documentId,
      userId: currentUser?.id ?? 'system',
      ip: '127.0.0.1',
      data: now,
      detalhe: `Encaminhado para ${payload.paraDestinatarios.length} destinatário(s) — ação: ${payload.acao}`,
    });

    return circ;
  },

  loadPending: (userId) => {
    const pending = circulationsRepo.query(
      (c) =>
        c.status === 'pendente' &&
        c.paraDestinatarios.some((d) => d.tipo === 'user' && d.id === userId),
    );
    set({ pendingCirculations: pending, loaded: true });
  },

  reloadPending: () => {
    const currentUser = useAuthStore.getState().currentUser;
    if (!currentUser) return;
    const pending = circulationsRepo.query(
      (c) =>
        c.status === 'pendente' &&
        c.paraDestinatarios.some((d) => d.tipo === 'user' && d.id === currentUser.id),
    );
    set({ pendingCirculations: pending });
  },

  respond: (circulationId, response) => {
    const now = new Date().toISOString();
    const resposta: CirculationResponse = { ...response, id: crypto.randomUUID(), criadoEm: now };
    const circ = circulationsRepo.getById(circulationId);
    if (!circ) return;

    const newRespostas = [...circ.respostas, resposta];
    const allDone = circ.obrigatoriaTodos
      ? newRespostas.length >= circ.paraDestinatarios.length
      : true;

    const updated = circulationsRepo.update(circulationId, {
      respostas: newRespostas,
      status: allDone ? 'respondido' : 'pendente',
    });

    if (allDone) {
      const newEstado = resolveDocEstado(circ.acao, response.decisao);
      if (newEstado) {
        documentsRepo.update(circ.documentId, { estado: newEstado, atualizadoEm: now });
      }

      if (circ.receberNotificacao) {
        notificationsRepo.create({
          userId: circ.deUserId,
          titulo: `Resposta recebida: ${response.decisao.replace(/_/g, ' ')}`,
          mensagem: `Resposta "${response.decisao.replace(/_/g, ' ')}" recebida na circulação de ${circ.acao}.${response.mensagem ? ` Nota: "${response.mensagem}"` : ''}`,
          lida: false,
          link: `/documentos/${circ.documentId}`,
          criadoEm: now,
        });
      }

      set((s) => ({
        pendingCirculations: s.pendingCirculations.filter((c) => c.id !== circulationId),
      }));
    } else if (updated) {
      set((s) => ({
        pendingCirculations: s.pendingCirculations.map((c) =>
          c.id === circulationId ? updated : c,
        ),
      }));
    }

    const currentUser = useAuthStore.getState().currentUser;
    auditRepo.create({
      evento: 'encaminhado',
      tabela: 'circulations',
      registroId: circulationId,
      userId: currentUser?.id ?? 'system',
      ip: '127.0.0.1',
      data: now,
      detalhe: `Resposta: ${response.decisao}`,
    });
  },
}));

// Quando uma escrita na API falha e o cache é revertido, recarregar circulações pendentes
if (typeof window !== 'undefined') {
  window.addEventListener(GD_WRITE_ERROR_EVENT, (e) => {
    const { key } = (e as CustomEvent<{ key: string }>).detail;
    if (key === 'gd:circulations' || key === 'gd:documents') {
      useCirculationStore.getState().reloadPending();
    }
  });
}
