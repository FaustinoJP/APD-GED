import { create } from 'zustand';
import type { DocumentRecord } from '@/types';
import { documentsRepo, auditRepo } from '@/lib/db';
import { GD_WRITE_ERROR_EVENT } from '@/lib/db/apiAdapter';
import { useAuthStore } from './auth-store';

function currentUserId(): string {
  return useAuthStore.getState().currentUser?.id ?? 'system';
}

interface DocumentsState {
  documents: DocumentRecord[];
  loading: boolean;
  loaded: boolean;
  load: () => void;
  reload: () => void;
  getById: (id: string) => DocumentRecord | undefined;
  create: (data: Omit<DocumentRecord, 'id' | 'criadoEm' | 'atualizadoEm'>) => DocumentRecord;
  update: (id: string, changes: Partial<DocumentRecord>) => DocumentRecord | undefined;
  remove: (id: string) => boolean;
}

export const useDocumentsStore = create<DocumentsState>()((set, get) => ({
  documents: [],
  loading: false,
  loaded: false,

  load: () => {
    if (get().loaded) return;
    set({ loading: true });
    const docs = documentsRepo.list();
    set({ documents: docs, loading: false, loaded: true });
  },

  reload: () => {
    const docs = documentsRepo.list();
    set({ documents: docs });
  },

  getById: (id) => get().documents.find((d) => d.id === id),

  create: (data) => {
    const now = new Date().toISOString();
    const doc = documentsRepo.create({ ...data, criadoEm: now, atualizadoEm: now });
    set((s) => ({ documents: [...s.documents, doc] }));
    auditRepo.create({
      evento: 'cadastrado',
      tabela: 'documents',
      registroId: doc.id,
      userId: currentUserId(),
      ip: '127.0.0.1',
      data: now,
      detalhe: `Documento ${doc.numero} registado`,
    });
    return doc;
  },

  update: (id, changes) => {
    const now = new Date().toISOString();
    const updated = documentsRepo.update(id, { ...changes, atualizadoEm: now });
    if (!updated) return undefined;
    set((s) => ({
      documents: s.documents.map((d) => (d.id === id ? updated : d)),
    }));
    auditRepo.create({
      evento: 'atualizado',
      tabela: 'documents',
      registroId: id,
      userId: currentUserId(),
      ip: '127.0.0.1',
      data: now,
    });
    return updated;
  },

  remove: (id) => {
    const ok = documentsRepo.remove(id);
    if (!ok) return false;
    set((s) => ({ documents: s.documents.filter((d) => d.id !== id) }));
    auditRepo.create({
      evento: 'eliminado',
      tabela: 'documents',
      registroId: id,
      userId: currentUserId(),
      ip: '127.0.0.1',
      data: new Date().toISOString(),
    });
    return true;
  },
}));

// Quando uma escrita na API falha e o cache é revertido, recarregar o store
if (typeof window !== 'undefined') {
  window.addEventListener(GD_WRITE_ERROR_EVENT, (e) => {
    const { key } = (e as CustomEvent<{ key: string }>).detail;
    if (key === 'gd:documents') {
      useDocumentsStore.getState().reload();
    }
  });
}
