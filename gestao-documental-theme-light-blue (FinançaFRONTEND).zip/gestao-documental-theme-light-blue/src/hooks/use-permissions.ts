'use client';

import { useAuthStore } from '@/store/auth-store';
import { hasPermission, hasAnyPermission, hasAllPermissions } from '@/lib/permissions';
import type { Permission, Role } from '@/types';

interface UsePermissionsResult {
  can: (permission: Permission) => boolean;
  canAny: (permissions: Permission[]) => boolean;
  canAll: (permissions: Permission[]) => boolean;
  role: Role | null;
}

export function usePermissions(): UsePermissionsResult {
  const currentRole = useAuthStore((s) => s.currentRole);

  return {
    can: (permission) => hasPermission(currentRole, permission),
    canAny: (permissions) => hasAnyPermission(currentRole, permissions),
    canAll: (permissions) => hasAllPermissions(currentRole, permissions),
    role: currentRole,
  };
}
